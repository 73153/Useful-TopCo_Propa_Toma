//
//  VideoVerticalVC.m
//  TOPCOD
//
//  Created by ashish on 25/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "VideoVerticalVC.h"
#import "YTPlayerView.h"
#import "UIViewController+NavigationBar.h"
#import "ProfileDetailCell.h"
#import "ProfileVC.h"
#import "AppDelegate.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "YouTubeHelper.h"
#import "Branch.h"
#import <FacebookSDK/FacebookSDK.h>

@interface VideoVerticalVC()<YTPlayerViewDelegate,UITableViewDataSource,UITableViewDelegate,ProfileDetailDelegate,SearchDelegate> {
    IBOutlet UILabel *lblStartTime;
    IBOutlet UILabel *lblEndTime;
    IBOutlet UISlider *slider;
    IBOutlet UITableView *tblView;
    IBOutlet UIButton *btnZoom;
    float totalMinutes;
}
@property(nonatomic, strong) IBOutlet YTPlayerView *playerView;
@property (nonatomic, strong) NSURL *url;

- (IBAction)onSliderChange:(id)sender;
-(IBAction)OnFullScreenTapped:(id)sender;
@end


@implementation VideoVerticalVC
NSString *videoId;
NSString *strTitle;
NSString *strVotes;
NSString *strUserName;
NSString *strProfile;
NSString *strUserID;
NSString *nVideoId;
NSString *strViewCount;
NSString *strContestId;


ProfileDetailCell *cell;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Video";
    [self setUpImageBackButton:@"left_arrow"];
    [self setUpImageRightButton:@"share" withSelector:@selector(socialSharingBtnClicked)];
    [self configureData];
    [self loadPopUpTable];
    
    [[YouTubeHelper sharedManager] setDelegate:self];
    [[YouTubeHelper sharedManager]getviewVideoCount:videoId];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
        [_videoHeight setConstant:500];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkState) name:@"FBSDKAccessTokenDidChangeNotification" object:nil];
}

-(void)returnNumberViewVideoCount:(int)count {
    strViewCount =[NSString stringWithFormat:@"%d",count];
    [tblView reloadData];
}

-(void)configureData {
    NSDictionary *dictUserDetail = UDGetObject(dictUserInfo);
    
    if(_fromVC==FromMyVidoes) {
        videoId = [_dictVideoInfo objectForKey:@"videoId"];
        strTitle = [_dictVideoInfo objectForKey:@"title"];
        strVotes = [_dictVideoInfo objectForKey:@"Votes"];
        strProfile = [dictUserDetail objectForKey:ProfileImage];
        strUserName = [NSString stringWithFormat:@"%@ %@",[dictUserDetail objectForKey:FirstName],[dictUserDetail objectForKey:LastName]];
    }
    else if (_fromVC==FromNews) {
        videoId = [_dictVideoInfo objectForKey:@"sNewsCode"];
        strTitle = [_dictVideoInfo objectForKey:@"sNewsTitle"];
        strVotes = @"";
        strProfile = [_dictVideoInfo objectForKey:@"sNewsImage"];
        strUserName = [_dictVideoInfo objectForKey:@"sNewsAddedBy"];
        [tblView setHidden:TRUE];
    }
    else if (_fromVC==FromContestVideos) {
        videoId = [_dictVideoInfo objectForKey:@"sVideo"];
        strTitle = [_dictVideoInfo objectForKey:@"sVideoTitle"];
        strVotes = [_dictVideoInfo objectForKey:@"sTotalVotes"];
        strContestId = [_dictVideoInfo objectForKey:@"nContestId"];
        
        
        if ([[_dictVideoInfo objectForKey:@"sFirstName"] isEqual:[NSNull null]]) {
            strUserName = [NSString stringWithFormat:@""];
        }
        else
            strUserName = [NSString stringWithFormat:@"%@ %@",[_dictVideoInfo objectForKey:@"sFirstName"],[_dictVideoInfo objectForKey:@"sLastName"]];
        if ([[_dictVideoInfo objectForKey:@"sProfileImage"] isEqual:[NSNull null]]) {
            strProfile = @"";
        }
        else
            strProfile =  [_dictVideoInfo objectForKey:@"sProfileImage"];
        strUserID = [dictUserDetail objectForKey:UserId];
        nVideoId =  [_dictVideoInfo objectForKey:@"nVideoId"];
    }
    else if (_fromVC==FromVotingHistory) {
        videoId = [_dictVideoInfo objectForKey:@"sVideo"];
        strTitle = [_dictVideoInfo objectForKey:@"sVideoTitle"];
        strVotes = @"";
        strProfile = [dictUserDetail objectForKey:ProfileImage];
        strUserName = [NSString stringWithFormat:@"%@ %@",[dictUserDetail objectForKey:FirstName],[dictUserDetail objectForKey:LastName]];
        
    }
    // For a full list of player parameters, see the documentation for the HTML5 player
    // at: https://developers.google.com/youtube/player_parameters?playerVersion=HTML5
    NSDictionary *playerVars = @{
                                 @"controls" : @1,
                                 @"playsinline" : @1,
                                 @"autohide" : @2,
                                 @"showinfo" : @0,
                                 @"modestbranding" : @0,
                                 @"rel" : @0
                                 };
    self.playerView.delegate = self;
    [self.playerView loadWithVideoId:videoId playerVars:playerVars];
    [self.playerView loadVideoById:videoId startSeconds:self.playerView.currentTime suggestedQuality:kYTPlaybackQualityHD720];  // Force HD Quality
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receivedPlaybackStartedNotification:)
                                                 name:@"Playback started"
                                               object:nil];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [tblView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    [slider setValue:0];
    lblStartTime.text = @"0:00";
    lblEndTime.text = @"0:00";
    tblView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    topDelegate.restrictRotation = FALSE;
    
    if (!topDelegate.restrictRotation) {
        NSLog(@"false");
    }
    
    
    
}

- (void)playerViewDidBecomeReady:(YTPlayerView *)playerView {
    float duration = playerView.duration;
    int minutes = floor(duration/60);
    int seconds = round(duration - (minutes * 60));
    NSString *time = [NSString stringWithFormat:@"%d:%02d", minutes, seconds];
    lblEndTime.text = time;
}


- (void)playerView:(YTPlayerView *)ytPlayerView didChangeToState:(YTPlayerState)state {
    //    NSString *message = [NSString stringWithFormat:@"Player state changed: %ld\n", (long)state];
    //    [self appendStatusText:message];
}

- (void)playerView:(YTPlayerView *)playerView didPlayTime:(float)playTime {
    float progress = playTime/self.playerView.duration;
    [slider setValue:progress];
    
    NSTimeInterval timeInterval = playTime;
    long seconds = lroundf(timeInterval); // Modulo (%) operator below needs int or long
    
    int mins = (seconds % 3600) / 60;
    int secs = seconds % 60;
    NSString *strTemp= [NSString stringWithFormat:@"%02d:%02d",mins,secs];
    lblStartTime.text = strTemp;
    
}
- (void)receivedPlaybackStartedNotification:(NSNotification *) notification {
    if([notification.name isEqual:@"Playback started"] && notification.object != self) {
        [self.playerView pauseVideo];
    }
}
- (IBAction)onSliderChange:(id)sender {
    float seekToTime = self.playerView.duration * slider.value;
    [self.playerView seekToSeconds:seekToTime allowSeekAhead:YES];
}

-(IBAction)OnFullScreenTapped:(id)sender {
    UITabBarController *tabBarController = (UITabBarController *)topDelegate.window.rootViewController;
    
    if([UIDevice currentDevice].orientation ==UIDeviceOrientationLandscapeLeft || [UIDevice currentDevice].orientation ==UIDeviceOrientationLandscapeRight) {
        [tabBarController.tabBar setHidden:FALSE];
        [[self navigationController] setNavigationBarHidden:NO animated:YES];
        NSNumber *value = [NSNumber numberWithInt:UIDeviceOrientationPortrait];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        [_videoHeight setConstant:self.view.frame.size.width-45];
        [btnZoom setImage:[UIImage imageNamed:@"zoom"] forState:UIControlStateNormal];
    }
    else {
        [[self navigationController] setNavigationBarHidden:YES animated:YES];
        [tabBarController.tabBar setHidden:YES];
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        [_videoHeight setConstant:self.view.frame.size.height-47];
        [btnZoom setImage:[UIImage imageNamed:@"zoomout"] forState:UIControlStateNormal];
    }
}

#pragma mark - Tableview Delegate and Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 100;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"ProfileDetailCell";
    
    cell = (ProfileDetailCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ProfileDetailCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    if (strProfile.length ) {
        
        JImage *img = [[ApplicationData sharedInstance]getJImage:strProfile andFrame:CGRectMake(cell.imgThumb.frame.origin.x,cell.imgThumb.frame.origin.y,cell.imgThumb.frame.size.width,cell.imgThumb.frame.size.height)];
        [cell.contentView addSubview:img];
    }
    cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:strTitle];
    cell.lblUserName.text = [[ApplicationData sharedInstance] isNullOrEmpty:strUserName];
    [cell.btnVotes setTitle:[NSString stringWithFormat:@"%@ Votes",strVotes] forState:UIControlStateNormal];
    if (strViewCount.length) {
        cell.lblNumberofViewsCount.text = [NSString stringWithFormat:@"Views:%@",strViewCount];
    }
    else
        cell.lblNumberofViewsCount.text = @"Views:0";
    if (_fromVC==FromNews || _fromVC==FromMyVidoes ||_fromVC==FromVotingHistory) {
        cell.btnVotes.hidden = TRUE;
    }
    else {
        [cell.btnVotes setTag:indexPath.section];
        cell.delegate = self;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    /* NSArray *viewContrlls=[[self navigationController] viewControllers];
     BOOL isProfileVCRoot = FALSE;
     for (id object in viewContrlls) {
     if ([object isKindOfClass:[ProfileVC class]]) {
     isProfileVCRoot = TRUE;
     [self.navigationController popToViewController:object animated:TRUE];
     }
     }
     if (!isProfileVCRoot) {
     AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
     UITabBarController *tabBarController = (UITabBarController *)appdel.window.rootViewController;
     [tabBarController setSelectedIndex:2];
     }*/
    
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    // do something before rotation
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    UITabBarController *tabBarController = (UITabBarController *)topDelegate.window.rootViewController;
    
    // do something after rotation
    if (fromInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || fromInterfaceOrientation == UIInterfaceOrientationLandscapeRight) {
        [tabBarController.tabBar setHidden:FALSE];
        [[self navigationController] setNavigationBarHidden:NO animated:YES];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
            [_videoHeight setConstant:500];
        else
            [_videoHeight setConstant:208];
        
        [btnZoom setImage:[UIImage imageNamed:@"zoom"] forState:UIControlStateNormal];
        
    }
    else if (fromInterfaceOrientation ==UIInterfaceOrientationPortrait ) {
        [[self navigationController] setNavigationBarHidden:YES animated:YES];
        [tabBarController.tabBar setHidden:YES];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
            [_videoHeight setConstant:self.view.frame.size.height-70];
        else
            [_videoHeight setConstant:self.view.frame.size.height-47];
        
        [btnZoom setImage:[UIImage imageNamed:@"zoomout"] forState:UIControlStateNormal];
        
    }
}

#pragma mark POPUP Delegate
#pragma mark - Delegate

-(void)loadPopUpTable{
    //    UIEdgeInsets buttonEdges = UIEdgeInsetsMake(0, 5, 0, -5);
    self.objPopUpTableController = [[PopUpTableViewController alloc] initWithStyle:UITableViewStylePlain];
    self.objPopUpTableController.dataSource = @[
                                                @"Facebook",
                                                @"Twitter",
                                                @"Google+",
                                                @"Copy Link"
                                                ];
    self.objPopUpTableController.tableView.frame = CGRectMake(self.navigationController.navigationBar.frame.size.width-160,self.navigationController.navigationBar.frame.size.height+20, 160,180);
    self.objPopUpTableController.delegate=self;
    self.objPopUpTableController.view.layer.zPosition = 100;
    
    //    self.objPopUpTableController.delegate = self;
    [self.view addSubview:self.objPopUpTableController.tableView];
    [self.objPopUpTableController toggleHidden:YES];
    
    self.objPopUpTableController.tableView.layer.borderWidth = 2;
    self.objPopUpTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.objPopUpTableController toggleHidden:YES];
    
}
#pragma mark - Helper methods

// A function for parsing URL parameters returned by the Feed Dialog.
- (NSDictionary*)parseURLParams:(NSString *)query {
    NSArray *pairs = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    for (NSString *pair in pairs) {
        NSArray *kv = [pair componentsSeparatedByString:@"="];
        NSString *val =
        [kv[1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        params[kv[0]] = val;
    }
    return params;
}


#pragma mark - Delegate


-(void)socialSharingBtnClicked {
    [self.objPopUpTableController toggleHidden:NO];
    return;
    
    /*  @autoreleasepool {
     // Code that creates autoreleased objects.
     
     NSString *socialUrl = [NSString stringWithFormat:@"https://www.youtube.com/watch?v=%@",videoId];
     NSURL *url = [NSURL URLWithString:socialUrl];
     NSString *strText = @"";
     if (_fromVC==FromContestVideos) {
     strText = [NSString stringWithFormat:@"https://deeplink.me/topcod.tv/shareFromContest/?id=%@&videoId=%@",strContestId,videoId];
     }
     else
     strText = [NSString stringWithFormat:@"Shared via TopCod\nhttp://www.topcod.tv"];
     // NSString *url1 = @"www.topcod.tv";
     NSArray *ary =[[NSArray alloc]initWithObjects:url,strText,nil];
     UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:ary applicationActivities:nil];
     NSArray *excludeActivities = @[UIActivityTypePostToWeibo,
     UIActivityTypeMessage,
     UIActivityTypeMail,
     UIActivityTypePrint,
     UIActivityTypeCopyToPasteboard,
     UIActivityTypeAssignToContact,
     UIActivityTypeSaveToCameraRoll,
     UIActivityTypeAddToReadingList,
     UIActivityTypePostToFlickr,
     UIActivityTypePostToVimeo,
     UIActivityTypePostToTencentWeibo,
     UIActivityTypeAirDrop,
     ];
     [activityViewController setValue:strText forKey:@"subject"];
     activityViewController.excludedActivityTypes = excludeActivities;
     if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
     [self presentViewController:activityViewController animated:YES completion:nil];
     }
     //if iPad
     else {
     // Change Rect to position Popover
     UIPopoverPresentationController *popPC = activityViewController.popoverPresentationController;
     popPC.barButtonItem = self.navigationItem.rightBarButtonItem;
     popPC.permittedArrowDirections = UIPopoverArrowDirectionAny;
     [self presentViewController:activityViewController animated:YES completion:nil];
     }
     }*/
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString{
    [self.objPopUpTableController toggleHidden:YES];
    [[Branch getInstance] setIdentity:@"190416407425471219"];
    
    NSString *strText = @"";
    if (_fromVC==FromContestVideos) {
        
        strText = [NSString stringWithFormat:@"https://bnc.lt/m/EiWQZdWgeo \n\n https://deeplink.me/topcod.tv/shareFromContest/?id=%@&videoId=%@",strContestId,videoId];
    }
    else
        strText = [NSString stringWithFormat:@"Shared via TopCod \n https://bnc.lt/m/EiWQZdWgeo \n\n http://www.topcod.tv"];
    
    if([selectedString isEqualToString:@"Facebook"]){
        [[Branch getInstance] userCompletedAction:@"share_facebook_click" withState:self.prepareBranchDict];
        
        // If the session state is any of the two "open" states when the button is clicked
        if (FBSession.activeSession.isOpen && [FBSession.activeSession.permissions indexOfObject:@"publish_actions"] != NSNotFound) {
            [self initiateFacebookShare];
        } else {
            NSArray *permissions = [[NSArray alloc] initWithObjects:
                                    @"publish_actions",
                                    nil];
            [FBSession.activeSession closeAndClearTokenInformation];
            [FBSession openActiveSessionWithPublishPermissions:permissions defaultAudience:FBSessionDefaultAudienceFriends allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState state, NSError *error) {
                [self sessionStateChanged:session state:state error:error];
            }];
        }
    }
    else if ([selectedString isEqualToString:@"Copy Link"]){
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = strText;
    }
    else if ([selectedString isEqualToString:@"Twitter"]){
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = strText;
        
        [[Branch getInstance] userCompletedAction:@"share_twitter_click" withState:self.prepareBranchDict];
        
        SLComposeViewController *twitterController= [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
        
        if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter]) {
            SLComposeViewControllerCompletionHandler completionHandler = ^(SLComposeViewControllerResult result) {
                [twitterController dismissViewControllerAnimated:YES completion:nil];
                switch(result){
                    case SLComposeViewControllerResultDone:
                        [[Branch getInstance] userCompletedAction:@"share_twitter_success"];
                        break;
                    case SLComposeViewControllerResultCancelled:
                    default:
                        break;
                }
            };
            
            [[Branch getInstance] getContentUrlWithParams:[self prepareBranchDict]  andChannel:@"twitter" andCallback:^(NSString *url, NSError *error) {
                
                // if there was no error, show the Twitter Share View Controller with the Branch deep link
                if (!error) {
                    [twitterController setInitialText:@"Shared via TopCod"];
                    [twitterController addURL:[NSURL URLWithString:url]];
                    [twitterController setCompletionHandler:completionHandler];
                    [self presentViewController:twitterController animated:YES completion:nil];
                }
            }];
        } else {
            UIAlertView *alert_Dialog = [[UIAlertView alloc] initWithTitle:@"No Twitter Account" message:@"You do not seem to have Twitter on this device" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert_Dialog show];
            alert_Dialog = nil;
        }
        
    }
    else if ([selectedString isEqualToString:@"Google+"]){
        [[Branch getInstance] userCompletedAction:@"share_google_click" withState:self.prepareBranchDict];
        
        @autoreleasepool {
            [[Branch getInstance] getContentUrlWithParams:[self prepareBranchDict]  andChannel:@"twitter" andCallback:^(NSString *url, NSError *error) {
                
                // NSString *url1 = @"www.topcod.tv";
                NSArray *ary =[[NSArray alloc] initWithObjects:[NSURL URLWithString:url],nil];
                UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:ary applicationActivities:nil];
                NSArray *excludeActivities = @[UIActivityTypePostToWeibo,
                                               UIActivityTypeMessage,
                                               UIActivityTypeMail,
                                               UIActivityTypePrint,
                                               UIActivityTypeCopyToPasteboard,
                                               UIActivityTypeAssignToContact,
                                               UIActivityTypeSaveToCameraRoll,
                                               UIActivityTypeAddToReadingList,
                                               UIActivityTypePostToFlickr,
                                               UIActivityTypePostToVimeo,
                                               UIActivityTypePostToTencentWeibo,
                                               UIActivityTypeAirDrop,
                                               UIActivityTypePostToFacebook,
                                               UIActivityTypePostToTwitter
                                               ];
                [activityViewController setValue:@"Shared via Topcod" forKey:@"subject"];
                activityViewController.excludedActivityTypes = excludeActivities;
                if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
                    [self presentViewController:activityViewController animated:YES completion:nil];
                }
                //if iPad
                else {
                    // Change Rect to position Popover
                    UIPopoverPresentationController *popPC = activityViewController.popoverPresentationController;
                    popPC.barButtonItem = self.navigationItem.rightBarButtonItem;
                    popPC.permittedArrowDirections = UIPopoverArrowDirectionAny;
                    [self presentViewController:activityViewController animated:YES completion:nil];
                }
            }];
        }
        
    }
}

-(void) checkState{
    if (FBSession.activeSession.isOpen && [FBSession.activeSession.permissions indexOfObject:@"publish_actions"] != NSNotFound) {
        [self initiateFacebookShare];
    } else {
        NSArray *permissions = [[NSArray alloc] initWithObjects:
                                @"publish_actions",
                                nil];
        [FBSession.activeSession closeAndClearTokenInformation];
        [FBSession openActiveSessionWithPublishPermissions:permissions defaultAudience:FBSessionDefaultAudienceFriends allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState state, NSError *error) {
            [self sessionStateChanged:session state:state error:error];
        }];
    }
}

#pragma mark - Facebook

- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState) state error:(NSError *)error {
    switch (state)
    {   case FBSessionStateOpen:
            [self initiateFacebookShare];
            break;
        case FBSessionStateClosed:
            //            [self.progressBar hide];
            break;
        case FBSessionStateClosedLoginFailed:
        {
            UIAlertView *alert_Dialog = [[UIAlertView alloc] initWithTitle:@"Facebook Alert" message:@"Please login again and than try to share." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert_Dialog show];
        }
            break;
        default:
            //            [self.progressBar hide];
            break;
    }
}

- (NSDictionary *)prepareBranchDict {
    return [[NSDictionary alloc] initWithObjects:@[
                                                   strContestId,
                                                   videoId,
                                                   ]
                                         forKeys:@[
                                                   @"id",
                                                   @"videoId",
                                                   ]];
}
- (void)initiateFacebookShare {
    
    // Create Branch link as soon as we know there is a valid Facebook session
    // Pass in the special Branch dictionary of keys/values you want to receive in the AppDelegate on initSession
    // Specify the channel to be 'facebook' for tracking on the Branch dashboard
    [[Branch getInstance] getContentUrlWithParams:[self prepareBranchDict]  andChannel:@"facebook" andCallback:^(NSString *url, NSError *error) {
        //        [self.progressBar hide];
        
        // If there is no error, do all the fancy foot work to initiate a share on Facebook
        
        if (!error) {
            id<FBGraphObject> object = [FBGraphObject graphObjectWrappingDictionary:[self prepareBranchDict]];
            
            // Create an action
            id<FBOpenGraphAction> action = (id<FBOpenGraphAction>)[FBGraphObject graphObject];
            
            // Link the object to the action
            [action setObject:object forKey:@"topcod"];
            [action setObject:@"true" forKey:@"fb:explicitly_shared"];
            
            FBOpenGraphActionParams *params = [[FBOpenGraphActionParams alloc] init];
            params.action = action;
            params.actionType = @"branchmetrics:create";
            
            // If the Facebook app is installed and we can present the share dialog
            if([FBDialogs canPresentShareDialogWithOpenGraphActionParams:params]) {
                // Show the share dialog
                [FBDialogs presentShareDialogWithOpenGraphAction:action
                                                      actionType:@"branchmetrics:create"
                                             previewPropertyName:@"topcod"
                                                         handler:^(FBAppCall *call, NSDictionary *results, NSError *error) {
                                                             if (!error) {
                                                                 // Success
                                                                  // track a successful share event via Facebook
                                                                 [[Branch getInstance] userCompletedAction:@"share_facebook_success"];
                                                             }
                                                         }];
            } else {
                [FBWebDialogs presentFeedDialogModallyWithSession:nil
                                                       parameters:[self prepareFBDict:url]
                                                          handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error) {
                                                              if (!error) {
                                                                  if (result == FBWebDialogResultDialogCompleted) {
                                                                      // Handle the publish feed callback
                                                                      NSDictionary *urlParams = [self parseURLParams:[resultURL query]];
                                                                      
                                                                      if ([urlParams valueForKey:@"post_id"]) {
                                                                          // Success
                                                                          // track a successful share event via Facebook
                                                                          [[Branch getInstance] userCompletedAction:@"share_facebook_success"];
                                                                      }
                                                                  }
                                                              }
                                                          }];
            }
        }
        
        
    }];
    
}
/*- (void)initiateFacebookShare {
 
 // Create Branch link as soon as we know there is a valid Facebook session
 // Pass in the special Branch dictionary of keys/values you want to receive in the AppDelegate on initSession
 // Specify the channel to be 'facebook' for tracking on the Branch dashboard
 [[Branch getInstance] getContentUrlWithParams:[self prepareBranchDict]  andChannel:@"facebook" andCallback:^(NSString *url, NSError *error) {
 //        [self.progressBar hide];
 
 // If there is no error, do all the fancy foot work to initiate a share on Facebook
 if (!error) {
 
 // Create an action
 id<FBOpenGraphAction> action = (id<FBOpenGraphAction>)[FBGraphObject graphObject];
 
 // Link the object to the action
 FBOpenGraphActionParams *params = [[FBOpenGraphActionParams alloc] init];
 params.action = action;
 
 // If the Facebook app is installed and we can present the share dialog
 if([FBDialogs canPresentShareDialogWithOpenGraphActionParams:params]){
 
 
 [FBWebDialogs presentFeedDialogModallyWithSession:nil
 parameters:[self prepareFBDict:url]
 handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error) {
 if (!error) {
 if (result == FBWebDialogResultDialogCompleted) {
 // Handle the publish feed callback
 NSDictionary *urlParams = [self parseURLParams:[resultURL query]];
 
 if ([urlParams valueForKey:@"post_id"]) {
 // Success
 // track a successful share event via Facebook
 [[Branch getInstance] userCompletedAction:@"share_facebook_success"];
 }
 }
 }
 }];
 }
 else{
 SLComposeViewController *facebookController= [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
 
 if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
 SLComposeViewControllerCompletionHandler completionHandler = ^(SLComposeViewControllerResult result) {
 [facebookController dismissViewControllerAnimated:YES completion:nil];
 switch(result){
 case SLComposeViewControllerResultDone:
 [[Branch getInstance] userCompletedAction:@"share_facebook_success"];
 break;
 case SLComposeViewControllerResultCancelled:
 default:
 break;
 }
 };
 
 [facebookController setInitialText:@"Shared via TopCod"];
 [facebookController addURL:[NSURL URLWithString:url]];
 [facebookController setCompletionHandler:completionHandler];
 [self presentViewController:facebookController animated:YES completion:nil];
 
 }
 }
 }
 
 }];
 
 }*/
- (NSDictionary *)prepareFBDict:(NSString *)url {
    
    return [[NSDictionary alloc] initWithObjects:@[
                                                   strContestId,
                                                   videoId,
                                                   url
                                                   ]
                                         forKeys:@[
                                                   @"id",
                                                   @"videoId",
                                                   @"link"
                                                   ]];
    
}


+ (instancetype)activityItemSourceUrlWithUrl:(NSURL *)url {
    VideoVerticalVC *wrapper = [[self alloc] init];
    wrapper.url = url;
    
    return wrapper;
}

- (id)activityViewControllerPlaceholderItem:(UIActivityViewController *)activityViewController {
    return [self activityViewController:activityViewController itemForActivityType:nil];
}

- (id)activityViewController:(UIActivityViewController *)activityViewController itemForActivityType:(NSString *)activityType {
    return self.url;
}

- (UIImage *)activityViewController:(UIActivityViewController *)activityViewController thumbnailImageForActivityType:(NSString *)activityType suggestedSize:(CGSize)size {
    UIImage* thumbnail; // get image from somewhere!
    return thumbnail;
}


-(void)onBtnVotingTappde:(id)sender {
    if (UDGetBool(isGLogin) == YES) {
        UIButton *btn = (UIButton *)sender;
        [[ApplicationData sharedInstance] showLoader];
        NSString *postString = [NSString stringWithFormat:@"nUserId=%@&nVideoId=%@&sVotes=%@",strUserID,nVideoId,@""];
        HTTPManager *manager = [HTTPManager managerWithURL:URL_ADDVOTE];
        manager.requestType= HTTPRequestTypeGeneral;
        manager.postString = postString;
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            NSLog(@"%@",bodyDict);
            [[ApplicationData sharedInstance] hideLoader];
            if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                btn.userInteractionEnabled = TRUE;
                int count = [strVotes intValue];
                count++;
                [cell.btnVotes setTitle:[NSString stringWithFormat:@"%d Votes",count] forState:UIControlStateNormal];
                strVotes = [NSString stringWithFormat:@"%d",count];
                [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Vote Successful" Message:[bodyDict valueForKey:@"msg"]];
            }
            else
                [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Max Votes" Message:[bodyDict valueForKey:@"msg"]];
            
            
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        }];
    }
    else {
        UIAlertView *alertDelete = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please sign in to access this feature." delegate:self cancelButtonTitle:nil otherButtonTitles:@"Cancel",@"Ok", nil];
        [alertDelete setTag:1];
        [alertDelete show];
        
        
    }
}

#pragma mark - UIAlertView Delegate Method
//------------------------------------------------------------------

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1){
        
        if(buttonIndex==1){
            UIViewController* rootController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SignInVC"];
            UINavigationController *naviCtrl = [[UINavigationController alloc]initWithRootViewController:rootController];
            naviCtrl.navigationBar.barTintColor = [UIColor clearColor];
            naviCtrl.navigationBar.translucent = NO;
            
            AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
            appdel.window.rootViewController = naviCtrl;
        }
        
        
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:TRUE];
    topDelegate.restrictRotation = TRUE;
    //[[NSNotificationCenter defaultCenter]removeObserver:self];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return TRUE;
    //    return (interfaceOrientation == UIInterfaceOrientationLandscape);
}



@end
