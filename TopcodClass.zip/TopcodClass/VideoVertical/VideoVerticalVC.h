//
//  VideoVerticalVC.h
//  TOPCOD
//
//  Created by ashish on 25/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopUpTableViewController.h"

typedef enum {
    FromNews,
    FromMyVidoes,
    FromContestVideos,
    FromVotingHistory,
} FromVC;

@interface VideoVerticalVC : UIViewController
@property(nonatomic, strong) NSMutableDictionary *dictVideoInfo;
@property (nonatomic,strong)IBOutlet NSLayoutConstraint *videoHeight;
@property (nonatomic, assign) FromVC fromVC;
@property (nonatomic, strong) PopUpTableViewController *objPopUpTableController;

@end
