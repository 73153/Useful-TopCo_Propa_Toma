#import "ParseManager.h"
#import "zObjects.h"
#import "ApplicationData.h"

@implementation ParseManager

+ (id)parseGeneralResponse:(NSData *)jsonContent {
    
    NSMutableDictionary *jsonResponse = [jsonContent JSONValue];
    if (jsonResponse == nil) {
        return nil;
    }
    return jsonResponse;
}

+ (id)parseForgotPasswordResponse:(NSData *)jsonContent {
    NSMutableDictionary *jsonResponse = [jsonContent JSONValue];
    if (jsonResponse == nil) {
        return nil;
    }
    return jsonResponse;
}


+ (id)parseLoginResponse:(NSData *)jsonContent {
    
    NSMutableDictionary *jsonResponse = [jsonContent JSONValue];
    if (jsonResponse != nil) {
       
        return jsonResponse;
    }
    else
        return nil;
}

+ (id)parseContenstListResponse:(NSData *)jsonContent{
    NSMutableDictionary *jsonResponse = [jsonContent JSONValue];
    ApplicationData *appData = [ApplicationData sharedInstance];
    NSMutableArray *arrSponsor;
    
    NSArray *arrContestList = [jsonResponse objectForKey:@"ContestList"];
    NSMutableArray *arrContest = [[NSMutableArray alloc] init];
    
    if (jsonResponse != nil) {
        for (NSDictionary *dict in arrContestList){
            appData.aCont = [[Contest alloc] init];
            appData.aCont.strContestId = [dict objectForKey:ContestId];
            appData.aCont.strContestName = [dict objectForKey:ContestName];
            appData.aCont.strContestDesc = [dict objectForKey:ContestDesc];
            appData.aCont.strContestPrice = [dict objectForKey:ContestPrice];
            appData.aCont.strContestRule = [dict objectForKey:ContentRule];
            appData.aCont.strContestImgUrl = [dict objectForKey:ContestImage];
            appData.aCont.strContestThumbImgUrl = [dict objectForKey:Contest_thumbImage];
            NSArray *arrSponsorDetail = [dict objectForKey:arrSponsorDetails];
            arrSponsor = [[NSMutableArray alloc] init];
            for (NSDictionary *dict in arrSponsorDetail) {
                appData.aSpons = [[Sponsor alloc] init];
                appData.aSpons.strSponsorId = [dict objectForKey:SponsorId];
                appData.aSpons.strSponsorName = [dict objectForKey:SponsorName];
                appData.aSpons.strSponsorDesc = [dict objectForKey:SponsorDesc];
                appData.aSpons.strSponsorUrl = [dict objectForKey:SponsorUrl];
                appData.aSpons.arrSponsorImage =[dict objectForKey:arrSponsorImages];
                [arrSponsor addObject:appData.aSpons];
            }
            appData.aCont.arrSponsor = arrSponsor;
            [arrContest addObject:appData.aCont];
        }
        return arrContest;
    }
    else
        return nil;
}

+ (id)parseVideoListResponse:(NSData *)jsonContent {
    NSMutableDictionary *jsonResponse = [jsonContent JSONValue];
    //ApplicationData *appData = [ApplicationData sharedInstance];
    if (jsonResponse != nil) {
        
        return jsonResponse;
    }
    else
        return nil;

}




@end

