//
//  EditProfile.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "EditProfileVC.h"
#import "UIViewController+NavigationBar.h"
#import "Constant.h"
#import "AppDelegate.h"

@interface EditProfileVC ()
{
    NSMutableDictionary *dict;
}
@end

@implementation EditProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Edit Profile";
    // Do any additional setup after loading the view.
}
//----------------------------------------------------------------

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.txtEmailId.enabled = NO;
    [self setPrePopulateData];
    if ( self != [self.navigationController.viewControllers objectAtIndex:0])
        [self setUpImageBackButton:@"left_arrow"];
    else
        self.navigationItem.leftBarButtonItem = nil;


}
//----------------------------------------------------------------
- (void) setPrePopulateData {
    dict = UDGetObject(dictUserInfo);
    self.txtFirstName.text = [[ApplicationData sharedInstance] isNullOrEmpty:[dict valueForKey:FirstName]];
    self.txtLastName.text = [[ApplicationData sharedInstance] isNullOrEmpty:[dict valueForKey:LastName]];
    self.txtEmailId.text =  [[ApplicationData sharedInstance] isNullOrEmpty:[dict valueForKey:EmailId]];
}

//----------------------------------------------------------------

#pragma mark - IBAction Methods
- (void)btnSubmitPressed:(id)sender {
    [[ApplicationData sharedInstance] showLoader];
    if(self.txtFirstName.text.length <= 2) {
        [[ApplicationData sharedInstance] hideLoader];
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"First Name too Short"];
        return;
    }
    else if (self.txtLastName.text.length <= 2){
        [[ApplicationData sharedInstance] hideLoader];
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Last Name too Short"];
        return;
    }
    else if (![self.txtPassword.text isEqualToString:self.txtConfirmPassword.text]) {
        [[ApplicationData sharedInstance] hideLoader];
        if (self.txtPassword.text.length < 6) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Password length should be minimum 5 Character."];
            return;
        }
        else
            
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Passowrd not match"];
        return;
    }
    else {
    
    
    NSString *postString = [NSString stringWithFormat:@"nUserId=%@&sFirstName=%@&sLastName=%@&sPassword=%@&sEmail=%@",[dict valueForKey:UserId],self.txtFirstName.text,self.txtLastName.text,self.txtPassword.text,self.txtEmailId.text];

    HTTPManager *manager = [HTTPManager managerWithURL:URL_EDITUSER];
    [manager setPostString:postString];
    manager.requestType= HTTPRequestTypeGeneral;
        
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
            NSDictionary *dictUsrInfo = UDGetObject(dictUserInfo);
            NSMutableDictionary *dictTemp = [[NSMutableDictionary alloc]initWithDictionary:dictUsrInfo];
            [dictTemp setObject:@"true" forKey:Password];
            UDSetObject(dictTemp,dictUserInfo);
        }

        AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        appDelegateTemp.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
        [appDelegateTemp setUpTabBar];
        
        //qwertyapp47
        //Qwerty@@123
        
//        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:rootController];
//        AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
//        appDel.window.rootViewController = navVC;

    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        
    }];
    }
}

//------------------------------------------------------------------------------

#pragma mark - UITextField Delegate
#pragma mark
//------------------------------------------------------------------------------

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return TRUE;
}
//------------------------------------------------------------------------------

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    [self animateTextField:textField up:YES];
}
//------------------------------------------------------------------------------

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
}
//------------------------------------------------------------------------------

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -80; // tweak as needed
    const float movementDuration = 0.5f; // tweak as needed
    int movement = (up ? movementDistance : -movementDistance);
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}



//----------------------------------------------------------------

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
