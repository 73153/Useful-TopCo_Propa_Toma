//
//  MyVideoListVC.h
//  TOPCOD
//
//  Created by ashish on 25/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.


//This Class is use for display login user upload Video list From Youtube.
//Video Fetch From user youtube account.


#import <UIKit/UIKit.h>
#import "GTLServiceYouTube.h"

typedef enum {
    MyVideos,
    VotingHistoryVideos,
    SubmitVideos,
} VIDEOTYPE;

@interface MyVideoListVC : UIViewController
@property (nonatomic, assign) VIDEOTYPE videoType;
@property (nonatomic,strong)NSString *strContestID;
@property (nonatomic,strong)NSString *strUserID;
@property (nonatomic,retain) NSArray *arrUserVideoList;
@property (nonatomic,retain) UIRefreshControl *refresh;
@end
