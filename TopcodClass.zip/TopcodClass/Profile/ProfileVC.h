//
//  ProfileVC.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

//This class is use for diplay User Profile.
// for diaplay votes left and no. of subscribers,

#import <UIKit/UIKit.h>

@interface ProfileVC : UIViewController
@property (nonatomic,retain) IBOutlet UIButton *btnProfile;
@property (nonatomic,retain) IBOutlet UILabel *lblUserName;
@property (nonatomic,strong) IBOutlet NSLayoutConstraint *photoTopPosition;
@property (nonatomic,strong) IBOutlet NSLayoutConstraint *subscirberLeftPosition;
@property (nonatomic,strong) IBOutlet NSLayoutConstraint *videoRightPosition;

@end
