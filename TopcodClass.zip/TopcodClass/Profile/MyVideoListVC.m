 //
//  MyVideoListVC.m
//  TOPCOD
//
//  Created by ashish on 25/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "MyVideoListVC.h"
#import "UIViewController+NavigationBar.h"
#import "VideoListCell.h"
#import "ApplicationData.h"
#import "YTPlayerView.h"
#import "VideoVerticalVC.h"
#import "SubmitContestVC.h"
#import "GTLQueryYouTube.h"
#import "GTLServiceYouTube.h"
#import "GTLYouTubeVideoListResponse.h"

@interface MyVideoListVC ()<UITableViewDataSource,UITableViewDelegate,YTPlayerViewDelegate,VideoListDelegate,UIGestureRecognizerDelegate> {
    NSMutableArray *aryVideoList;
    IBOutlet UITableView *tblView;
}

@end

@implementation MyVideoListVC

- (void)viewDidLoad {
    [super viewDidLoad];
}
- (void)viewWillAppear:(BOOL)animated {
    if (_videoType==MyVideos) {
        self.navigationItem.title = @"My Videos";
        aryVideoList = [[NSMutableArray alloc]initWithArray:[ApplicationData sharedInstance].aryVideoList];
        
    }
    else if (_videoType==VotingHistoryVideos) {
        self.navigationItem.title = @"Voting History";
        aryVideoList = [[NSMutableArray alloc]initWithArray:[ApplicationData sharedInstance].aryVotingVideoList];
    }
    else {
        self.navigationItem.title = @"Submit Videos";
        aryVideoList = [[NSMutableArray alloc]initWithArray:[ApplicationData sharedInstance].aryVideoList];
        [self setVideoStatus];
        self.arrUserVideoList = [[NSArray alloc] init];
        [self getUserVideoListData];
    }
    UISwipeGestureRecognizer *recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleSwipeLeft:)];
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionRight)];
    [tblView addGestureRecognizer:recognizer];
    
    [self setUpImageBackButton:@"left_arrow"];
    tblView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.refresh = [[UIRefreshControl alloc] initWithFrame:CGRectZero];
    [self.refresh addTarget:self action:@selector(getUserVideoListData)
           forControlEvents:UIControlEventValueChanged];
    [tblView addSubview:self.refresh];
}

-(void)setVideoStatus {
        [aryVideoList enumerateObjectsUsingBlock:^(id obj2, NSUInteger idx2, BOOL *stop2) {
                [obj2 setValue:@"0" forKey:@"isSubmitted"];
            [aryVideoList replaceObjectAtIndex:(int)idx2 withObject:obj2];
        }];
}

-(void)getUserVideoListData {
    [[ApplicationData sharedInstance] showLoader];
    NSDictionary *dictUInfo = UDGetObject(dictUserInfo);
    HTTPManager *manager = [HTTPManager managerWithURL:URL_USERVIDEOLIST];
    NSString *postString = [NSString stringWithFormat:@"%@=%@&nContestId=%@",UserId,[dictUInfo objectForKey:UserId],_strContestID];
    [manager setPostString:postString];
    manager.requestType= HTTPRequestTypeGeneral;
    
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        [[ApplicationData sharedInstance] hideLoader];
        if ([[bodyDict objectForKey:@"status"] integerValue] == jSuccess) {
            self.arrUserVideoList =(NSArray *)[ bodyDict objectForKey:@"VideoList"];
            [self checkSubmitedVideoList];
        }
        else {
            [tblView reloadData];
        }
        [self.refresh endRefreshing];

    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
        [self.refresh endRefreshing];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        [self.refresh endRefreshing];
    }];
}
- (void) checkSubmitedVideoList {
    [self.arrUserVideoList enumerateObjectsUsingBlock:^(id obj1, NSUInteger idx1, BOOL *stop1) {
         NSString *strSubmitedVideoId = [obj1 objectForKey:@"sVideo"];
        [aryVideoList enumerateObjectsUsingBlock:^(id obj2, NSUInteger idx2, BOOL *stop2) {
            NSString *strVideoId = [obj2 objectForKey:@"videoId"];
            if ([strSubmitedVideoId isEqualToString:strVideoId]) {
                    [obj2 setValue:@"1" forKey:@"isSubmitted"];
            }

            [aryVideoList replaceObjectAtIndex:(int)idx2 withObject:obj2];

        }];
        [tblView reloadData];
        [self.refresh endRefreshing];
    }];
    
    
}
- (void) handleSwipeLeft:(UIGestureRecognizer*)recogniser {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Tableview Delegate and Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return aryVideoList.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"VideoListCell";
    VideoListCell *cell = (VideoListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    CGFloat cellsize;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"VideoListCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    if (_videoType==SubmitVideos){
        NSString *textTitle = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"title"];
        CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:textTitle font:[UIFont systemFontOfSize:20] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
        NSString *textdesc = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"];
        CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:20] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
        cellsize =  textheight +  height + cell.lblTitle.frame.size.height +cell.btnNumberOfVotes.frame.size.height+ 10.0;
        cell.btnSubmitVideos.hidden = YES;

    }
else if (_videoType==MyVideos) {
    NSString *textTitle = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"title"];
    CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:textTitle font:[UIFont systemFontOfSize:17] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)-20];
    NSString *textdesc = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"];
    CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:17] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)-20];
     cellsize =  textheight +  height + 30;

}
else if (_videoType==VotingHistoryVideos) {
    NSString *textTitle = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"title"];
    CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:textTitle font:[UIFont systemFontOfSize:20] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
    NSString *textdesc = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"];
    CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:20] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
     cellsize =  textheight +  height + 30;
}
    if (cellsize<100) {
        return 100;
    }
    if (cellsize>161) {
        if (_videoType==MyVideos)
            return 140;
        else
            return 161;
    }
    else
        return cellsize;
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        NSString *simpleTableIdentifier = [NSString stringWithFormat:@"%ld %ld",(long)indexPath.section,(long)indexPath.row];
        VideoListCell *cell = (VideoListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
        if (cell == nil)
        {
            [tableView registerNib:[UINib nibWithNibName:@"VideoListCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
            cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
            [cell.btnNumberOfVotes setTitle:[NSString stringWithFormat:@"%@ Votes",[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"votes"]] forState:UIControlStateNormal];
            NSDictionary *playerVars = @{
                                         @"controls" : @0,
                                         @"autohide" : @1,
                                         @"showinfo" : @0,
                                         @"modestbranding" : @1
                                         };
            NSString *strVideoID;
            if (_videoType==SubmitVideos) {
                [cell.btnSubmitVideos setHidden:FALSE];
                [cell.btnSubmitVideos setTag:indexPath.section];
                cell.delegate = self;
                strVideoID = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"videoId"];
                cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"title"]];
                cell.lblTitle.numberOfLines = 2;
                CGSize size = [cell.lblTitle.text sizeWithFont:cell.lblTitle.font
                                     constrainedToSize:CGSizeMake(cell.lblTitle.frame.size.width,
                                                                  2 * cell.lblTitle.font.lineHeight)
                                         lineBreakMode:NSLineBreakByWordWrapping];
                cell.lblTitle.bounds = CGRectMake(0, 0,
                                          cell.lblTitle.frame.size.width,
                                          size.height);
            //    [cell.lblTitle sizeToFit];
                if ([[[aryVideoList objectAtIndex:indexPath.section] valueForKey:@"isSubmitted"] isEqualToString:@"1"]) {
                    cell.btnSubmitVideos.hidden = YES;
                }
                else {
                    cell.btnSubmitVideos.hidden = NO;
                    cell.btnSubmitVideos.frame = CGRectMake(cell.lblTitle.frame.origin.x, cell.lblTitle.frame.size.height + cell.lblTitle.frame.origin.y + 5 , cell.btnSubmitVideos.frame.size.width, cell.btnSubmitVideos.frame.size.height);
                }
                
                if(![[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"]isEqualToString:@""]) {
                    cell.btnNumberOfVotes.hidden = TRUE;
                    UITextView *txtview;
                    txtview=
                    [[UITextView alloc]initWithFrame:CGRectMake(cell.btnNumberOfVotes.frame.origin.x,cell.btnSubmitVideos.frame.origin.y+cell.btnSubmitVideos.frame.size.height+25,self.view.frame.size.width-145,60)];
                    if (IS_IPAD)
                        [txtview setFont: [UIFont systemFontOfSize:17]];
                    else
                        [txtview setFont:[UIFont systemFontOfSize:14]];
                    [txtview setDelegate:nil];
                    [txtview setReturnKeyType:UIReturnKeyDone];
                    [txtview setTag:1];
                    
                    [txtview setBackgroundColor:[UIColor clearColor]];
                    [txtview setScrollEnabled:TRUE];
                    txtview.editable = FALSE;
                    [txtview setText:[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"]];
                    [cell.contentView addSubview:txtview];
                }
                else {
                    cell.btnNumberOfVotes.hidden = TRUE;
                    [cell.constBottom setConstant:5];
                }
            }
            else if (_videoType==MyVideos) {
                cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"title"]];
                [cell.lblTitle sizeToFit];
                UITextView*txtview =
                [[UITextView alloc]initWithFrame:CGRectMake(cell.lblTitle.frame.origin.x,cell.lblTitle.frame.origin.y+cell.lblTitle.frame.size.height+5,self.view.frame.size.width-145,70)];
                [txtview setBackgroundColor:[UIColor clearColor]];
                [txtview setDelegate:nil];
                [txtview setReturnKeyType:UIReturnKeyDone];
                [txtview setTag:1];
                [txtview setFont:[UIFont systemFontOfSize:14]];
                [txtview setScrollEnabled:TRUE];
                txtview.editable = FALSE;
                [txtview setText:[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"descriptionProperty"]];
                [cell.contentView addSubview:txtview];
                [cell.btnNumberOfVotes setHidden:TRUE];

                strVideoID = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"videoId"];
                cell.btnSubmitVideos.hidden = YES;
                
            }
            else if (_videoType==VotingHistoryVideos) {
                [cell.btnNumberOfVotes setTitle:[NSString stringWithFormat:@"%@ Votes",[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"sUserVotes"]] forState:UIControlStateNormal];
                cell.btnNumberOfVotes.userInteractionEnabled = FALSE;
                strVideoID = [[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"sVideo"];
                cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:[[aryVideoList objectAtIndex:indexPath.section]valueForKey:@"sVideoTitle"]];
                [cell.lblTitle sizeToFit];
                cell.btnSubmitVideos.hidden = YES;

            }
            [cell.imgThumnail loadWithVideoId:strVideoID playerVars:playerVars];
            cell.imgThumnail.playbackQuality = kYTPlaybackQualitySmall;
            [cell.imgThumnail setUserInteractionEnabled:FALSE];
            cell.imgThumnail.layer.cornerRadius = 6;
            cell.imgThumnail.layer.masksToBounds = YES;

            cell.selectionStyle = UITableViewCellSelectionStyleNone;

            
        }
        else {
            if (_videoType==SubmitVideos) {
                if ([[[aryVideoList objectAtIndex:indexPath.section] valueForKey:@"isSubmitted"] isEqualToString:@"1"]) {
                    cell.btnSubmitVideos.hidden = YES;
                }
                else
                    cell.btnSubmitVideos.hidden = NO;
            }
        }
    
    
        return cell;
        
    return nil;
}

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}

//- (void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    if(scrollView == tblView)
//    {
//        [(UITableView*)scrollView setDataSource:nil];
//    }
//}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    UITableViewCell *cell = (UITableViewCell *)[tblView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[VideoListCell class]]) {
        VideoVerticalVC* rootController = (VideoVerticalVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoVerticalVC"];
        rootController.fromVC = FromMyVidoes;
        if (_videoType==VotingHistoryVideos) {
            rootController.fromVC=FromVotingHistory;
        }
        rootController.dictVideoInfo = [NSMutableDictionary new];
        [rootController.dictVideoInfo addEntriesFromDictionary:[aryVideoList objectAtIndex:indexPath.section]];
        [self.navigationController pushViewController:rootController animated:TRUE];
    }
    
}

-(void)loadVideo:(id)info {
    
}

- (void)playerView:(YTPlayerView *)ytPlayerView didChangeToState:(YTPlayerState)state {
    //    NSString *message = [NSString stringWithFormat:@"Player state changed: %ld\n", (long)state];
    //    [self appendStatusText:message];
}

- (void)playerView:(YTPlayerView *)playerView didPlayTime:(float)playTime {
    
}
- (void)receivedPlaybackStartedNotification:(NSNotification *) notification {
}

-(void)btnSubmitVideoTapped:(id)sender {
//    UIButton *btn = (UIButton *)sender;
//    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
//                                                             bundle: nil];
//    
//    SubmitContestVC *controller = (SubmitContestVC*)[mainStoryboard
//                                    instantiateViewControllerWithIdentifier: @"SubmitContestVC"];
//    
//    
//   controller.dictSelectedVideo = [aryVideoList objectAtIndex:btn.tag];
//    [self.navigationController pushViewController:controller animated:YES];
    
    UIButton *btn = (UIButton *)sender;
    [[ApplicationData sharedInstance]showLoader];
    NSString *strVideoID = [[aryVideoList objectAtIndex:btn.tag]valueForKey:@"videoId"];
    NSString *strVideoTitle = [[aryVideoList objectAtIndex:btn.tag]valueForKey:@"title"];
    NSDictionary *dict = UDGetObject(dictUserInfo);
    NSString *strUserID = [dict valueForKey:UserId];
    //strContestID
    NSString *postString = [NSString stringWithFormat:@"nContestId=%@&nUserId=%@&sVideo=%@&sVideoTitle=%@",_strContestID,strUserID,strVideoID,strVideoTitle];
    HTTPManager *manager = [HTTPManager managerWithURL:URL_SUBMITVIDEO];
    
    [manager setPostString:postString];
    manager.requestType = HTTPRequestTypeGeneral;
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        [[ApplicationData sharedInstance] hideLoader];
        NSLog(@"%@",bodyDict);
        if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
            [[aryVideoList objectAtIndex:btn.tag]setObject:@"1" forKey:@"isSubmitted"];
            [tblView reloadData];
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Video has been successfully added."];
        }
        else {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[bodyDict valueForKey:@"msg"]];
        }
        
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] hideLoader];
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
    }];

}



@end
