//
//  EditProfile.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

//This Class is use for Edit Profile Details.
// Edit First Name, Last Name, Password.

#import <UIKit/UIKit.h>
#import "HTTPManager.h"
#import "ApplicationData.h"

@interface EditProfileVC : UIViewController<HTTPManagerDelegate>{
    ApplicationData *appData;
}
@property (nonatomic,strong) IBOutlet UITextField *txtFirstName;
@property (nonatomic,strong) IBOutlet UITextField *txtLastName;
@property (nonatomic,strong) IBOutlet UITextField *txtEmailId;
@property (nonatomic,strong) IBOutlet UITextField *txtPassword;
@property (nonatomic,strong) IBOutlet UITextField *txtConfirmPassword;
@property (nonatomic,strong) IBOutlet UIButton *btnSubmit;

- (IBAction)btnSubmitPressed:(id)sender;

@end
