//
//  ProfileVC.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "ProfileVC.h"
#import "UIViewController+NavigationBar.h"
#import "Constant.h"
#import "YouTubeHelper.h"
#import "ApplicationData.h"
#import "GTLYouTube.h"
#import "MyVideoListVC.h"
#import "ContestListVC.h"
#import "AppDelegate.h"
#import "SubmitContestVC.h"
#import "GTLQueryYouTube.h"


@interface ProfileVC() <YouTubeHelperDelegate>
{
    IBOutlet UILabel *lblSubscribers;
    IBOutlet UILabel *lblVotesLeft;
    IBOutlet UILabel *lblVideos;
}

-(IBAction)OnbtnMyVideosTapped:(id)sender;
-(IBAction)OnbtnSubmitVideoTapped:(id)sender;
-(IBAction)OnbtnVotingHistoryTapped:(id)sender;

@end

@implementation ProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Profile";
    [self setUpImageRightButtonWithText:@"logout"];
    dispatch_queue_t backgroundQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    __weak ProfileVC *weakSelf = self;
    NSDictionary *dictUserDetail = UDGetObject(dictUserInfo);
    
    dispatch_async(backgroundQueue, ^{
        NSData *avatarData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dictUserDetail objectForKey:@"sProfileImage"]]];
        if (avatarData) {
            // Update UI from the main thread when available
            dispatch_async(dispatch_get_main_queue(), ^{
                ProfileVC *strongSelf = weakSelf;
                if (strongSelf) {
                    UIImage *profileImage = [[ApplicationData sharedInstance] image:[UIImage imageWithData:avatarData] scaledToSize:CGSizeMake(150,150)];
                    profileImage = [[ApplicationData sharedInstance] imageWithRoundedCornersSize:52.0 usingImage:profileImage];
                    [self.btnProfile setImage:profileImage forState:UIControlStateNormal];
                }
            });
        }
    });
    lblVotesLeft.text = @"0\nVotes Left";
    [self.lblUserName setText:[NSString stringWithFormat:@"%@ %@",[[ApplicationData sharedInstance] isNullOrEmpty:[dictUserDetail objectForKey:@"sFirstName"]],[[ApplicationData sharedInstance] isNullOrEmpty:[dictUserDetail objectForKey:@"sLastName"]]]];

    // Do any additional setup after loading the view.
}
//------------------------------------------------------------------------------

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (IS_IPAD) {
    [lblSubscribers setFont:[UIFont systemFontOfSize:15]];
    [lblVotesLeft setFont:[UIFont systemFontOfSize:15]];
    [lblVideos setFont:[UIFont systemFontOfSize:15]];
    [self.lblUserName setFont:[UIFont systemFontOfSize:20]];
    }
    [[ApplicationData sharedInstance]showLoader];
    [[YouTubeHelper sharedManager] setDelegate:self];
    [[YouTubeHelper sharedManager] getChannelList];
    [[YouTubeHelper sharedManager]getMySubscribersCount];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ) {
        _photoTopPosition.constant = 90;
        _subscirberLeftPosition.constant = 50;
        _videoRightPosition.constant = 60;
    }
    else {
        _photoTopPosition.constant = 30;
        _subscirberLeftPosition.constant = 36;
        _videoRightPosition.constant = 40;
    }
}
//------------------------------------------------------------------------------

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // Always display the camera UI.
}

//------------------------------------------------------------------------------
#pragma mark - IBAction Methods
#pragma mark
//------------------------------------------------------------------------------


-(IBAction)OnbtnMyVideosTapped:(id)sender {
    MyVideoListVC* rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
    rootController.videoType = MyVideos;
    [self.navigationController pushViewController:rootController animated:TRUE];

}
//------------------------------------------------------------------------------

-(IBAction)OnbtnSubmitVideoTapped:(id)sender {
    NSArray *viewContrlls=[[self navigationController] viewControllers];
    BOOL isContestListVCRoot = FALSE;
    for (id object in viewContrlls) {
        if ([object isKindOfClass:[ContestListVC class]]) {
            isContestListVCRoot = TRUE;
            [self.navigationController popToViewController:object animated:TRUE];
        }
    }
    if (!isContestListVCRoot) {
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        SubmitContestVC *controller = (SubmitContestVC*)[mainStoryboard
        instantiateViewControllerWithIdentifier: @"SubmitContestVC"];
        
        
      //  controller.dictSelectedVideo = [aryVideoList objectAtIndex:btn.tag];
        [self.navigationController pushViewController:controller animated:YES];
        
        
//        MyVideoListVC* rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
//        rootController.videoType = SubmitVideos;
//        rootController.strContestID = [NSString new];
//     //   rootController.strContestID = self.objConst.strContestId;
//        [self.navigationController pushViewController:rootController animated:TRUE];
//        AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
//        UITabBarController *tabBarController = (UITabBarController *)appdel.window.rootViewController;
//        [tabBarController setSelectedIndex:0];
        
    }
//    MyVideoListVC* rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
//    rootController.videoType = SubmitVideos;
//    [self.navigationController pushViewController:rootController animated:TRUE];
}
//------------------------------------------------------------------------------

-(IBAction)OnbtnVotingHistoryTapped:(id)sender {
    MyVideoListVC* rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
    rootController.videoType = VotingHistoryVideos;
    NSDictionary *dictUserDetail = UDGetObject(dictUserInfo);
    rootController.strUserID = [NSString stringWithFormat:@"%@",[dictUserDetail valueForKey:UserId]];
    [self.navigationController pushViewController:rootController animated:TRUE];

}

//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------
- (void)showAuthenticationViewController:(UIViewController *)authView;
{
    [self.navigationController pushViewController:authView animated:YES];
}
//------------------------------------------------------------------------------

- (void)uploadedVideosPlaylist:(NSArray *)array
{
    [ApplicationData sharedInstance].aryVideoList = [NSMutableArray new];
    
    NSLog(@"uploaded list:");
    
    for (int ii = 0; ii < array.count; ii++) {
        GTLYouTubePlaylistItem* item = array[ii];
        NSLog(@"    %@", item.snippet.title);
        NSLog(@"    %@", item.snippet.descriptionProperty);
        
        NSMutableDictionary *dict = [NSMutableDictionary new];
        
        [dict setObject:item.snippet.title forKey:@"title"];
        [dict setObject:item.snippet.descriptionProperty forKey:@"descriptionProperty"];
        [dict setObject:item.contentDetails.videoId forKey:@"videoId"];
        [dict setObject:@"0" forKey:@"votes"];
        [dict setObject:@"0" forKey:@"isSubmitted"];
        [dict setObject:item.snippet.channelTitle forKey:@"channelTitle"];
        
        [[ApplicationData sharedInstance].aryVideoList addObject:dict];
    }
    lblVideos.text = [NSString stringWithFormat:@"%lu\nVideos",(unsigned long)[ApplicationData sharedInstance].aryVideoList.count];
        [self getVotingVideoList];
       [[ApplicationData sharedInstance]hideLoader];
}
//------------------------------------------------------------------------------

-(void)returnNumberOfSubscribers:(int)count {
    lblSubscribers.text = [NSString stringWithFormat:@"%d\nSubscribers",count];
}
//------------------------------------------------------------------------------

-(void)getVotingVideoList {
    NSDictionary *dictUserDetail = UDGetObject(dictUserInfo);

    NSString *postString = [NSString stringWithFormat:@"nUserId=%@",[dictUserDetail valueForKey:UserId]];
    HTTPManager *manager = [HTTPManager managerWithURL:URL_GETVOTEHISTORY];
    manager.requestType= HTTPRequestTypeGeneral;
    manager.postString = postString;
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        lblVotesLeft.text = [NSString stringWithFormat:@"%ld\nVotes Left",(long)[[bodyDict valueForKey:@"sRemainingVotes"]integerValue]];
        [ApplicationData sharedInstance].aryVotingVideoList = [NSMutableArray new];
        [ApplicationData sharedInstance].aryVotingVideoList = [bodyDict valueForKey:@"VoteList"];
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        
    }];
    
}
//------------------------------------------------------------------------------



@end
