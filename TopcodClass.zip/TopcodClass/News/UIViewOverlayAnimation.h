//
//  LVSuccessfulRegistration.h
//  forfone
//
//  Created by Ilker Baltaci on 2/6/13.
//
//

#import <UIKit/UIKit.h>
#import "JImage.h"
@interface UIViewOverlayAnimation : UIView{
    JImage *boxOverlay;
    UIButton *closeButton;
}
- (id)initWithFrame:(CGRect)frame andImageName:(JImage *)img;

- (void)showInView:(UIView *)aView;

@end
