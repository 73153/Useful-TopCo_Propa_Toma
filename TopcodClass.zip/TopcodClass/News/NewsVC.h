//
//  NewsVC.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

//This class is use for diplay News.

#import <UIKit/UIKit.h>

@interface NewsVC : UIViewController
@property (nonatomic,retain) UIRefreshControl *refresh;
@end
