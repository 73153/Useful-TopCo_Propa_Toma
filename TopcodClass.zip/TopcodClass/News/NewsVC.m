//
//  NewsVC.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "NewsVC.h"
#import "VideoListCell.h"
#import "twitterPostCell.h"
#import "HTTPManager.h"
#import "YTPlayerView.h"
#import "ApplicationData.h"
#import "VideoVerticalVC.h"
#import "UIViewOverlayAnimation.h"
#import "ImageCell.h"

@interface NewsVC ()<UITableViewDataSource,UITableViewDelegate,YTPlayerViewDelegate> {
    NSMutableArray *aryNewsList;
    IBOutlet UITableView *tblView;
}

@end

@implementation NewsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"News";
    aryNewsList = [NSMutableArray new];
    tblView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.refresh = [[UIRefreshControl alloc] initWithFrame:CGRectZero];
    [self.refresh addTarget:self action:@selector(retrieveNewsData)
           forControlEvents:UIControlEventValueChanged];
    [tblView addSubview:self.refresh];
    [[ApplicationData sharedInstance]showLoader];
}
//------------------------------------------------------------------------------

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
    [self retrieveNewsData];

}

//------------------------------------------------------------------------------
#pragma mark - Spare Mathods
#pragma mark
//------------------------------------------------------------------------------

-(void)retrieveNewsData {
    HTTPManager *manager = [HTTPManager managerWithURL:URL_GETNEWSLIST];
    NSString *boundary = @"----1010101010";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    manager.requestType = HTTPRequestTypeGeneral;
    [manager StartUploadPostData:nil Boundry:contentType OnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        
        if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
            aryNewsList = [[NSMutableArray alloc] init];
            aryNewsList = [bodyDict objectForKey:@"NewsList"];
            [tblView reloadData];
            [[ApplicationData sharedInstance]hideLoader];
        }
        else {
            
            // [[ApplicationData sharedInstance] ShowAlertWithTitle:@"" Message:[bodyDict valueForKey:@"msg"]];
            
        }
        [self.refresh endRefreshing];
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        
    }];

}

//------------------------------------------------------------------------------
#pragma mark - Tableview Delegate and Datasource
#pragma mark
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return aryNewsList.count;
}
//------------------------------------------------------------------------------

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
//------------------------------------------------------------------------------

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}
//------------------------------------------------------------------------------

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}

//------------------------------------------------------------------------------

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strNewsType = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsType"];

    if ([strNewsType isEqualToString:@"Video"]){
        static NSString *simpleTableIdentifier = @"VideoListCell";
        VideoListCell *cell = (VideoListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"VideoListCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            
        }
        NSString *textTitle = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsTitle"];
        CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:textTitle font:[UIFont systemFontOfSize:20] width:self.view.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
        NSString *textdesc = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"dNewsDate"];
        CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:20] width:self.view.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)];
        CGFloat cellsize =  textheight +  height + 30;

        
        if (cellsize < 100) {
            return 100;
        }
        else
            return cellsize;
    }
    else if ([strNewsType isEqualToString:@"Image"]) {
        if ([[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] length]
            ) {
            return 342;
        }else
        return 40;
    }
    else
    {
        
            NSString *textdesc = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsDesc"];
            CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:14] width:270];
        if ([[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] length]
            ) {
            if (height<54) {
                
                return 500-height-8;
            }
            
            return 450;
        }
        else {
            if (height<54) {
                
                return 130;
            }
            
            return 160;
        }
        

    }
    return 0;
}

//------------------------------------------------------------------------------

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strNewsType = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsType"];
    
    if ([strNewsType isEqualToString:@"Video"]) {
        
        static NSString *simpleTableIdentifier = @"VideoListCell";
        VideoListCell *cell = (VideoListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"VideoListCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
//            [tableView registerNib:[UINib nibWithNibName:@"VideoListCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
//            cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        }
        NSDictionary *playerVars = @{@"controls":@0,
                                     @"playsinline":@1,
                                     @"autohide":@1,
                                     @"showinfo":@0,
                                     @"modestbranding":@1};
        
        [cell.imgThumnail loadWithVideoId:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsCode"] playerVars:playerVars];
        cell.imgThumnail.playbackQuality = kYTPlaybackQualitySmall;
        cell.imgThumnail.layer.cornerRadius = 6;
        cell.imgThumnail.layer.masksToBounds = YES;
        [cell.imgThumnail setUserInteractionEnabled:FALSE];

        [cell.lblTitle setText:[[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsTitle"]]];
        [cell.btnNumberOfVotes setImage:nil forState:UIControlStateNormal];
        [cell.btnNumberOfVotes setTitle:[[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"dNewsDate"]] forState:UIControlStateNormal];
        cell.btnNumberOfVotes.titleLabel.font = [UIFont systemFontOfSize:12];
        return cell;
        
    }
    else if ([strNewsType isEqualToString:@"Twitt"]||[strNewsType isEqualToString:@"Facebook"] ) {
        
        static NSString *simpleTableIdentifier = @"twitterPostCell";
        twitterPostCell *cell = (twitterPostCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"twitterPostCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell.tvNewsTitle setText:[[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsTitle"]]];
        [cell.tvNewsDesc setText:[[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsDesc"]]];
        [cell.tvNewsDesc setContentOffset:CGPointMake(0,0)];
        
        NSString *strDate = [[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"dNewsDate"]];
        if ([[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsThumb"] length]
            ) {
        JImage *img = [[ApplicationData sharedInstance]getJImage:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsThumb"] andFrame:CGRectMake(cell.btnThumb.frame.origin.x,cell.btnThumb.frame.origin.y,cell.btnThumb.frame.size.width,cell.btnThumb.frame.size.height)];
        
        [cell.contentView addSubview:img];
        [cell.contentView bringSubviewToFront:cell.btnThumb];
        img.layer.cornerRadius = 6;
        img.layer.masksToBounds = YES;
        }
        if ([[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] length]
            ) {
                [cell.imgNewsFull setHidden: NO];
                [cell.imgNewsFull initWithImageAtURL:[NSURL URLWithString:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"]]];

                cell.imgNewsFull.layer.cornerRadius = 6;
                cell.imgNewsFull.layer.masksToBounds = YES;
        } else {
            cell.imgHeight.constant = 0;
            
           // [cell.imgNewsFull setHidden: YES];
        }

        if ([strNewsType isEqualToString:@"Twitt"]) {
            cell.imgNewsType.image = [UIImage imageNamed:@"twitter-bird"];
            [cell.lblNewsDate setText:[NSString stringWithFormat:@"Tweet posted %@",[[ApplicationData sharedInstance] isNullOrEmpty:strDate]]];

        }
        else if ([strNewsType isEqualToString:@"Facebook"]) {
            cell.imgNewsType.image = [UIImage imageNamed:@"facebook"];
            [cell.lblNewsDate setText:[NSString stringWithFormat:@"FB posted %@",[[ApplicationData sharedInstance] isNullOrEmpty:strDate]]];
        }
        else
            cell.imgNewsType.image = [UIImage imageNamed:@""];
        
        NSString *textdesc = [[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsDesc"];
        CGFloat height = [[ApplicationData sharedInstance] getTextHeightOfText:textdesc font:[UIFont systemFontOfSize:14] width:cell.frame.size.width - 30];
        if (height<58) {
            cell.descrHeight.constant = height+8;
        }
        
        return cell;
        
    }
    else if ([strNewsType isEqualToString:@"Image"]) {
        static NSString *simpleTableIdentifier = @"ImageCell";
        ImageCell *cell = (ImageCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            [tableView registerNib:[UINib nibWithNibName:@"ImageCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
            cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [cell.lblNewsTitle setText:[[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsTitle"]]];
        
        NSString *strDate = [[ApplicationData sharedInstance] isNullOrEmpty:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"dNewsDate"]];
        [cell.lblNewsDate setText:[[ApplicationData sharedInstance] isNullOrEmpty:strDate]];
        
        JImage *img = (JImage *)[cell.contentView viewWithTag:1000];
        if (img) {
            [img removeFromSuperview];
        }
        if ([[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] length]) {
        if (IS_IPAD) {
            img.hidden = NO;
            cell.contentView.frame=CGRectMake(cell.contentView.frame.origin.x, cell.contentView.frame.origin.y, self.view.frame.size.width, cell.contentView.frame.size.height);
            img = [[ApplicationData sharedInstance]getJImage:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] andFrame:CGRectMake(cell.imgNewsType.frame.origin.x,cell.imgNewsType.frame.origin.y,cell.contentView.frame.size.width,cell.imgNewsType.frame.size.height)];
            CGSize imageSize = img.image.size;
            [img sizeThatFits:imageSize];
            CGPoint imageViewCenter = img.center;
            imageViewCenter.x = CGRectGetMidX(cell.contentView.frame);
            [img setCenter:imageViewCenter];
        }
        else {
            img = [[ApplicationData sharedInstance]getJImage:[[aryNewsList objectAtIndex:indexPath.section]valueForKey:@"sNewsImage"] andFrame:CGRectMake(cell.imgNewsType.frame.origin.x,cell.imgNewsType.frame.origin.y,cell.imgNewsType.frame.size.width,cell.imgNewsType.frame.size.height)];
        }
        }
        else {
            img.hidden = YES;
        }
        img.tag = 1000;
        [cell.contentView addSubview:img];
        img.layer.cornerRadius = 6;
        img.layer.masksToBounds = YES;
        
        return cell;
        
    }
    return nil;
}
//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}

//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    UITableViewCell *cell = (UITableViewCell *)[tblView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[VideoListCell class]]) {
        VideoVerticalVC* rootController = (VideoVerticalVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoVerticalVC"];
        rootController.fromVC = FromNews;
        rootController.dictVideoInfo = [NSMutableDictionary new];
        [rootController.dictVideoInfo addEntriesFromDictionary:[aryNewsList objectAtIndex:indexPath.section]];

        [self.navigationController pushViewController:rootController animated:TRUE];
    }

}
  
/*-(void)onbtnFullScreenImageTapped:(UIButton *)sender {
   // JImage *img = [[ApplicationData sharedInstance]getJImage:[[aryNewsList objectAtIndex:sender.tag]valueForKey:@"sNewsImage"] andFrame:CGRectMake((self.view.frame.size.width-269)/2,(self.view.frame.size.height-324)/2, 269, 324)];
    
    JImage *img = [[ApplicationData sharedInstance]getJImage:[[aryNewsList objectAtIndex:sender.tag-5000]valueForKey:@"sNewsImage"] andFrame:CGRectMake(10,70,DEVICE_FRAME.size.width-20,DEVICE_FRAME.size.height-44)];
   
    UIViewOverlayAnimation *overlayAnimation = [[UIViewOverlayAnimation alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) andImageName:img];
    [overlayAnimation showInView:self.view];

}
*/
//------------------------------------------------------------------------------
#pragma mark - YTPlayerView Methods
#pragma mark
//------------------------------------------------------------------------------

- (void)playerView:(YTPlayerView *)ytPlayerView didChangeToState:(YTPlayerState)state {
    //    NSString *message = [NSString stringWithFormat:@"Player state changed: %ld\n", (long)state];
    //    [self appendStatusText:message];
}
//------------------------------------------------------------------------------

- (void)playerView:(YTPlayerView *)playerView didPlayTime:(float)playTime {
    
}
//------------------------------------------------------------------------------

- (void)receivedPlaybackStartedNotification:(NSNotification *) notification {
}
//------------------------------------------------------------------------------


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
