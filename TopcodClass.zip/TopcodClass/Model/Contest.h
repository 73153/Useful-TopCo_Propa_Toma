//
//  Contest.h
//  TopCode
//
//  Created by tusharpatel on 03/07/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contest : NSObject

@property (nonatomic,strong) NSString *strContestId;
@property (nonatomic,strong) NSString *strContestName;
@property (nonatomic,strong) NSString *strContestDesc;
@property (nonatomic,strong) NSString *strContestPrice;
@property (nonatomic,strong) NSString *strContestRule;
@property (nonatomic,strong) NSString *strContestImgUrl;
@property (nonatomic,strong) NSString *strContestThumbImgUrl;
@property (nonatomic,strong) NSMutableArray *arrSponsor;



@end
