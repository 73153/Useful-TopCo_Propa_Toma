//
//  Sponsor.h
//  TopCode
//
//  Created by tusharpatel on 03/07/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Sponsor : NSObject
@property (nonatomic,strong) NSString *strSponsorId;
@property (nonatomic,strong) NSString *strSponsorName;
@property (nonatomic,strong) NSString *strSponsorDesc;
@property (nonatomic,strong) NSString *strSponsorUrl;
@property (nonatomic,strong) NSArray *arrSponsorImage;
@end
