//
//  SubmitContestVC.m
//  TopCode
//
//  Created by tusharpatel on 12/09/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "SubmitContestVC.h"
#import "ContestListCell.h"
#import "ApplicationData.h"
#import "UIViewController+NavigationBar.h"
#import "MyVideoListVC.h"

@interface SubmitContestVC ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation SubmitContestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpImageBackButton:@"left_arrow"];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
    self.navigationItem.title = @"Contests List";
    appData = [ApplicationData sharedInstance];
    [self getContestListData];
}
//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------

-(void)getContestListData {
    [[ApplicationData sharedInstance] showLoader];
    HTTPManager *manager = [HTTPManager managerWithURL:URL_CONTESTLIST];
    manager.requestType= HTTPManagerTypeGetContestList;
    
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        [[ApplicationData sharedInstance] hideLoader];
        self.arrContestList =(NSMutableArray *) bodyDict;
        [_tblView reloadData];
        
        
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
    }];
}
//------------------------------------------------------------------------------

#pragma mark - Tableview Delegate and Datasource
#pragma mark
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.arrContestList.count;
}
//------------------------------------------------------------------------------

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
//------------------------------------------------------------------------------

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
//------------------------------------------------------------------------------

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}

//------------------------------------------------------------------------------

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"ContestListCell";
    
    ContestListCell *cell = (ContestListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ContestListCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    appData.aCont =[self.arrContestList objectAtIndex:indexPath.section];
    
    NSString *text = appData.aCont.strContestDesc;
    CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:text font:[UIFont systemFontOfSize:9] width:self.view.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)+ 10.0];
    CGFloat cellsize =  textheight + cell.btnMoreContestInfo.frame.size.height+ cell.lblTitle.frame.size.height+cell.lblSponsor.frame.size.height+cell.lblPrize.frame.size.height ;
    
    if (textheight>30 && textheight<50) {
        return cellsize+15;
    }
    else
        return 150;
    
}

//------------------------------------------------------------------------------

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *simpleTableIdentifier = [NSString stringWithFormat:@"%ld %ld",(long)indexPath.section,(long)indexPath.row];
    ContestListCell *cell = (ContestListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    appData.aCont =[self.arrContestList objectAtIndex:indexPath.section];
    
    if (cell == nil)
    {
        [tableView registerNib:[UINib nibWithNibName:@"ContestListCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        JImage *img = [[ApplicationData sharedInstance]getJImage:appData.aCont.strContestThumbImgUrl andFrame:CGRectMake(cell.imgThumnail.frame.origin.x,cell.imgThumnail.frame.origin.y
                                                                                                                         ,cell.imgThumnail.frame.size.width,cell.imgThumnail.frame.size.height)];
        [cell.contentView addSubview:img];
        
        img.layer.cornerRadius = 6;
        img.layer.masksToBounds = YES;
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    
    cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestName];
    Sponsor *objSponsor;
    if (appData.aCont.arrSponsor.count>0) {
        objSponsor = [appData.aCont.arrSponsor objectAtIndex:0];
        cell.lblSponsor.text = [NSString stringWithFormat:@"Sponsor: %@",[[ApplicationData sharedInstance] isNullOrEmpty:objSponsor.strSponsorName]];
    }
    
    cell.lblPrize.text = [NSString stringWithFormat:@"Prize: %@",[[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestPrice]];
   // cell.lblDesc.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestDesc];
    cell.tvDesc.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestDesc];

    cell.btnMoreContestInfo.tag = indexPath.section;
    cell.delegate = self;
    cell.btnMoreContestInfo.hidden =YES;
    cell.lblViewVideo.hidden = YES;
    cell.imgerrow.hidden = YES;
    // ... set up the cell here ...
    return cell;
}
//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}

//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Contest *objConst = [self.arrContestList objectAtIndex:indexPath.section];
    MyVideoListVC *rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
        rootController.videoType = SubmitVideos;
    rootController.strContestID = [objConst valueForKey:@"strContestId"];
        [self.navigationController pushViewController:rootController animated:TRUE];
    
//    Contest *objConst = [self.arrContestList objectAtIndex:indexPath.section];
//    _strConstantId = [objConst valueForKey:@"strContestId"];
//    NSString *strAltertext = [NSString stringWithFormat:@"Do you want to select %@ Contest",[objConst valueForKey:@"strContestName"]];
//    
//    UIAlertView *alertDelete = [[UIAlertView alloc] initWithTitle:@"Attention !" message:strAltertext delegate:self cancelButtonTitle:nil otherButtonTitles:@"No",@"Yes", nil];
//    [alertDelete setTag:1];
//    [alertDelete show];
    
//    ContestVideosVC *controller = (ContestVideosVC*)[mainStoryboard instantiateViewControllerWithIdentifier: @"ContestVideosVC"];
//    controller.objConst = [self.arrContestList objectAtIndex:indexPath.section];
//    
//    [self.navigationController pushViewController:controller animated:YES];
    
}
//------------------------------------------------------------------------------

#pragma mark - UIAlertView Delegate Method
//------------------------------------------------------------------

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1){
        
        if(buttonIndex==1){
            [appData showLoader];
        NSString *strVideoID =[self.dictSelectedVideo valueForKey:@"videoId"];
        NSString *strVideoTitle = [self.dictSelectedVideo valueForKey:@"title"];
        NSDictionary *dict = UDGetObject(dictUserInfo);
        NSString *strUserID = [dict valueForKey:UserId];
                //strContestID
        NSString *postString = [NSString stringWithFormat:@"nContestId=%@&nUserId=%@&sVideo=%@&sVideoTitle=%@",_strConstantId,strUserID,strVideoID,strVideoTitle];
            HTTPManager *manager = [HTTPManager managerWithURL:URL_SUBMITVIDEO];
            [manager setPostString:postString];
            manager.requestType = HTTPRequestTypeGeneral;
                [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
                    [[ApplicationData sharedInstance] hideLoader];
                   NSLog(@"%@",bodyDict);
                   if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                 //   [[aryVideoList objectAtIndex:btn.tag]setObject:@"1" forKey:@"isSubmitted"];
                        [_tblView reloadData];
                    [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Video has been successfully added."];
                    [self.navigationController popViewControllerAnimated:YES];
                    }
                    else {
                    [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[bodyDict valueForKey:@"msg"]];
                    [self.navigationController popViewControllerAnimated:YES];
                    }
            
                } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
                    [[ApplicationData sharedInstance] hideLoader];
                    [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
                    
                } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
                }];
        }
        
        
    }
}

@end
