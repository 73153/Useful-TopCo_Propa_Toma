//
//  ContestListVCViewController.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.


// This Class is use for Display Contest List.
//

#import <UIKit/UIKit.h>
#import "HTTPManager.h"
#import "ApplicationData.h"

@interface ContestListVC : UIViewController <HTTPManagerDelegate>
{
    ApplicationData *appData;
}
@property (nonatomic,strong) NSArray *arrContestList;
@property (nonatomic,retain) UIRefreshControl *refresh;

@end
