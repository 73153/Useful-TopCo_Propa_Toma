//
//  ContestVC.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "ContestVC.h"
#import "UIViewController+NavigationBar.h"
#import "Sponsor.h"
#import "JImage.h"
#import "GTLYouTube.h"
#import "YouTubeHelper.h"
#import "MyVideoListVC.h"
#import "AppDelegate.h"


@interface ContestVC () <YouTubeHelperDelegate>{
    UIScrollView *scrViewInner;
}
-(IBAction)OnbtnSubmitVideoTapped:(id)sender;
@end

@implementation ContestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Contest";
    [self setUpImageBackButton:@"left_arrow"];
    [self.scrViewOuter touchesShouldCancelInContentView:_imgBG];
//    self.txtDesc.text = self.objSpos.strSponsorDesc;
//    self.lblUrl.text = self.objSpos.strSponsorUrl;
    
    [self setSponsor];
    //self.scrViewOuter.backgroundColor = [UIColor colorWithRed:132 green:0 blue:0 alpha:1];
}
//------------------------------------------------------------------------------

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestName];
    self.txtContestDtl.text = [NSString stringWithFormat:@"Prize: %@ \nContest Description: %@ \nRules: %@", [[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestPrice],[[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestDesc],[[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestRule]];
    self.txtContestDtl.editable = NO;
    self.txtContestDtl.backgroundColor = [UIColor clearColor];
    if (IS_IPAD) {
        self.txtContestDtl.font =[UIFont systemFontOfSize:30];
    }
}
//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------
-(void) setSponsor{
    NSInteger numberofSponsor = self.objConst.arrSponsor.count;
    for (int i = 0; i < numberofSponsor; i++) {
        Sponsor *objSponsor = [self.objConst.arrSponsor objectAtIndex:i];
        if ([objSponsor.strSponsorId isKindOfClass:[NSNull class]]) {
            return;
        }
        CGFloat myOrigin = i * (DEVICE_FRAME.size.width-70);
        myOrigin+=10;
        self.scrViewOuter.tag = i;
        self.scrViewOuter.pagingEnabled = YES;
        if (i==0) {
            if(IS_IPAD) {
                scrViewInner = [[UIScrollView alloc]initWithFrame:CGRectMake(myOrigin,5,((DEVICE_FRAME.size.width *236)/320)+110,((DEVICE_FRAME.size.height *47)/480))];
            } else {
            scrViewInner = [[UIScrollView alloc]initWithFrame:CGRectMake(myOrigin,5,((DEVICE_FRAME.size.width *236)/320)-20,((DEVICE_FRAME.size.height *47)/480))];
            }
            scrViewInner.pagingEnabled = TRUE;

            
            NSInteger numberOfImages = objSponsor.arrSponsorImage.count;
            if (objSponsor.arrSponsorImage.count) {
            for (int j = 0; j < numberOfImages; j++) {
                [scrViewInner setTag:j];
                //set the origin of the sub view
                CGFloat myOrigin = j * scrViewInner.frame.size.width;
                //create the sub view and allocate memory
                JImage *img = [[ApplicationData sharedInstance]getJImage:[[objSponsor.arrSponsorImage objectAtIndex:j]valueForKey:Sponsor_thumbImage] andFrame:CGRectMake(myOrigin, 0, scrViewInner.frame.size.width, scrViewInner.frame.size.height)];
                [img setContentMode:UIViewContentModeScaleAspectFit];
                //add the subview to the scroll view
                [scrViewInner addSubview:img];
                scrViewInner.delegate = self;
                }
            }
            scrViewInner.contentSize = CGSizeMake(scrViewInner.frame.size.width * numberOfImages,((DEVICE_FRAME.size.height *47)/480));
        UITextView *txtView = [[UITextView alloc] initWithFrame:CGRectMake(myOrigin-2, scrViewInner.frame.size.height+scrViewInner.frame.origin.y,DEVICE_FRAME.size.width-86, ((DEVICE_FRAME.size.height *40)/480))];
                
        txtView.textColor = [UIColor whiteColor];
        txtView.backgroundColor = [UIColor clearColor];
        txtView.text = objSponsor.strSponsorDesc;
        txtView.textAlignment = NSTextAlignmentCenter;
            txtView.editable = NO;
            if (IS_IPAD) {
                txtView.font = [txtView.font fontWithSize:25];
            }
        [self.scrViewOuter addSubview:txtView];
        
        UILabel *lblUrl = [[UILabel alloc] initWithFrame:CGRectMake(myOrigin, txtView.frame.size.height+txtView.frame.origin.y+5,DEVICE_FRAME.size.width-86, ((DEVICE_FRAME.size.height *24)/480))];
        lblUrl.text = [[ApplicationData sharedInstance] isNullOrEmpty:objSponsor.strSponsorUrl];
        lblUrl.textColor = [UIColor whiteColor];
        lblUrl.textAlignment = NSTextAlignmentCenter;
            lblUrl.backgroundColor = [UIColor clearColor];
            if (IS_IPAD) {
                lblUrl.font = [lblUrl.font fontWithSize:25];
            }
        [self.scrViewOuter addSubview:lblUrl];
        }

        [self.scrViewOuter addSubview:scrViewInner];
        CGPoint scrollPoint = CGPointMake(0, 0);
        [scrViewInner setContentOffset:scrollPoint animated:YES];
    }
  //  self.scrViewOuter.contentSize = CGSizeMake((DEVICE_FRAME.size.width-70) * numberofSponsor,((DEVICE_FRAME.size.height *154)/480));
    self.scrViewOuter.contentSize = CGSizeMake((DEVICE_FRAME.size.width-70) * numberofSponsor,(self.lblUrl.frame.origin.y + self.lblUrl.frame.size.width));
    //we set the origin to the 3rd page
    CGPoint scrollPoint = CGPointMake(0, 0);
    //change the scroll view offset the the 3rd page so it will start from there
    [self.scrViewOuter setContentOffset:scrollPoint animated:YES];

}
//------------------------------------------------------------------------------

- (void)showAuthenticationViewController:(UIViewController *)authView;
{
    [self.navigationController pushViewController:authView animated:YES];
}
//------------------------------------------------------------------------------

- (void)uploadedVideosPlaylist:(NSArray *)array {
    [ApplicationData sharedInstance].aryVideoList = [NSMutableArray new];
    NSLog(@"uploaded list:");
    for (int ii = 0; ii < array.count; ii++) {
        GTLYouTubePlaylistItem* item = array[ii];
        NSLog(@"    %@", item.snippet.title);
        NSLog(@"    %@", item.snippet.descriptionProperty);
        NSMutableDictionary *dict = [NSMutableDictionary new];
        [dict setObject:item.snippet.title forKey:@"title"];
        [dict setObject:item.snippet.descriptionProperty forKey:@"descriptionProperty"];
        [dict setObject:item.contentDetails.videoId forKey:@"videoId"];
        [dict setObject:@"0" forKey:@"votes"];
        [dict setObject:@"0" forKey:@"isSubmitted"];
        [dict setObject:item.snippet.channelTitle forKey:@"channelTitle"];
        [[ApplicationData sharedInstance].aryVideoList addObject:dict];
    }
    [[ApplicationData sharedInstance]hideLoader];
    [self showVideoListScreen];
}
//------------------------------------------------------------------------------

- (void)showVideoListScreen {
    MyVideoListVC* rootController = (MyVideoListVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyVideoListVC"];
    rootController.videoType = SubmitVideos;
    rootController.strContestID = [NSString new];
    rootController.strContestID = self.objConst.strContestId;
    [self.navigationController pushViewController:rootController animated:TRUE];
}

#pragma mark - UIAlertView Delegate Method
//------------------------------------------------------------------

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1){
        
        if(buttonIndex==1){
            UIViewController* rootController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SignInVC"];
            UINavigationController *naviCtrl = [[UINavigationController alloc]initWithRootViewController:rootController];
            naviCtrl.navigationBar.barTintColor = [UIColor clearColor];
            naviCtrl.navigationBar.translucent = NO;
            
            AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
            appdel.window.rootViewController = naviCtrl;
        }
    }
}

//------------------------------------------------------------------------------
#pragma mark - IBAction Methods
#pragma mark
//------------------------------------------------------------------------------
-(IBAction)OnbtnSubmitVideoTapped:(id)sender {
    if (UDGetBool(isGLogin) == NO) {
        UIAlertView *alertDelete = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please sign in to access this feature." delegate:self cancelButtonTitle:nil otherButtonTitles:@"Cancel",@"Ok", nil];
        [alertDelete setTag:1];
        [alertDelete show];
    }
    else if (UDGetBool(isGLogin) == YES) {
        if ([ApplicationData sharedInstance].aryVideoList.count==0) {
            [[ApplicationData sharedInstance]showLoader];
            [[YouTubeHelper sharedManager] setDelegate:self];
            [[YouTubeHelper sharedManager] getChannelList];
        }
        else {
            [self showVideoListScreen];
        }
    }
}
//------------------------------------------------------------------------------

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    //find the page number you are on
    if (scrollView == self.scrViewOuter) {
        for (UIView *view in [self.scrViewOuter subviews]) {
            if ([view isKindOfClass:[UIScrollView class]]||[view isKindOfClass:[UILabel class]] || [view isKindOfClass:[UITextView class]]) {
                [view removeFromSuperview];
            }
        }
        CGFloat pageWidth = (DEVICE_FRAME.size.width-70);
        int page = floor((self.scrViewOuter.contentOffset.x - pageWidth / 2) / pageWidth) + 1 ;
        int temp = page;
        
        if (temp>0) {
            temp--;
        }
        CGFloat myOrigin = page * (DEVICE_FRAME.size.width-70);
        myOrigin +=10;
        if(IS_IPAD) {
            scrViewInner = [[UIScrollView alloc]initWithFrame:CGRectMake(myOrigin,5,((DEVICE_FRAME.size.width *236)/320)+110,((DEVICE_FRAME.size.height *47)/480))];
        } else {
        scrViewInner = [[UIScrollView alloc]initWithFrame:CGRectMake(myOrigin+10,5,((DEVICE_FRAME.size.width *236)/320) - 20,((DEVICE_FRAME.size.height *47)/480))];
        }
        [scrViewInner setTag:page];
        scrViewInner.pagingEnabled = TRUE;
        Sponsor *spons  = [self.objConst.arrSponsor objectAtIndex:page];
        NSInteger numberOfViews = spons.arrSponsorImage.count;
        for (int j = 0; j < numberOfViews; j++) {
            //set the origin of the sub view
            CGFloat myOrigin = j * scrViewInner.frame.size.width;
            //create the sub view and allocate memory
            JImage *img = [[ApplicationData sharedInstance]getJImage:[[spons.arrSponsorImage objectAtIndex:j]valueForKey:Sponsor_thumbImage] andFrame:CGRectMake(myOrigin, 0, scrViewInner.frame.size.width, scrViewInner.frame.size.height)];
            [img setContentMode:UIViewContentModeScaleAspectFit];
            //add the subview to the scroll view
            [scrViewInner addSubview:img];
            scrViewInner.delegate = self;
        }
        [scrViewInner setBackgroundColor:[UIColor clearColor]];
        UITextView *txtView = [[UITextView alloc] initWithFrame:CGRectMake(myOrigin, scrViewInner.frame.size.height+scrViewInner.frame.origin.y,DEVICE_FRAME.size.width-86, ((DEVICE_FRAME.size.height *66)/480))];
        txtView.textColor = [UIColor whiteColor];
        txtView.backgroundColor = [UIColor clearColor];
        txtView.text = [[ApplicationData sharedInstance] isNullOrEmpty:spons.strSponsorDesc];
        if (IS_IPAD) {
            txtView.font =[UIFont systemFontOfSize:25];
        }
        txtView.editable = NO;
        txtView.textAlignment = NSTextAlignmentCenter;
        [self.scrViewOuter addSubview:txtView];
        
        UILabel *lblUrl = [[UILabel alloc] initWithFrame:CGRectMake(myOrigin, txtView.frame.size.height+txtView.frame.origin.y+10,DEVICE_FRAME.size.width-86, ((DEVICE_FRAME.size.height *24)/480))];
        lblUrl.text = [[ApplicationData sharedInstance] isNullOrEmpty:spons.strSponsorUrl];
        lblUrl.textColor = [UIColor whiteColor];
        lblUrl.backgroundColor = [UIColor clearColor];
        lblUrl.textAlignment = NSTextAlignmentCenter;
        lblUrl.numberOfLines = 0;
        [self.scrViewOuter addSubview:lblUrl];
        
        scrViewInner.contentSize = CGSizeMake(scrViewInner.frame.size.width * numberOfViews,((DEVICE_FRAME.size.height *47)/480));
        [self.scrViewOuter addSubview:scrViewInner];
        if (IS_IPAD) {
            lblUrl.font = [lblUrl.font fontWithSize:25];
        }
        NSLog(@"Scrolling - You are now on page %i",page);
    }
}
//------------------------------------------------------------------------------

//dragging ends, please switch off paging to listen for this event
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView
                     withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *) targetContentOffset NS_AVAILABLE_IOS(5_0){
    
}

//------------------------------------------------------------------------------

@end
