
 //
//  ContestVideosVC.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "ContestVideosVC.h"
#import "VideoListCell.h"
#import "UIViewController+NavigationBar.h"
#import "ContestListCell.h"
#import "ContestVC.h"
#import "VideoVerticalVC.h"

@interface ContestVideosVC ()<UITableViewDataSource,UITableViewDelegate,ContestListDelegate> {
    IBOutlet UITableView *tblView;
}

@end

@implementation ContestVideosVC

-(void)viewDidLoad {
    [super viewDidLoad];
    appData = [ApplicationData sharedInstance];
    self.navigationItem.title = @"Contest Videos";
    [self setUpImageBackButton:@"left_arrow"];
    tblView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.lblContestName.text = [NSString stringWithFormat:@"Contest Name: %@", [[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestName]];
    if (self.objConst.arrSponsor.count>0) {
        self.objSpons = [self.objConst.arrSponsor objectAtIndex:0];
    }
    self.lblSponsorName.text = [NSString stringWithFormat:@"Sponsor Name: %@",[[ApplicationData sharedInstance] isNullOrEmpty:self.objSpons.strSponsorName]];
    self.lblPrice.text = [NSString stringWithFormat:@"Prize: %@", [[ApplicationData sharedInstance] isNullOrEmpty:self.objConst.strContestPrice]];
    self.refresh = [[UIRefreshControl alloc] initWithFrame:CGRectZero];
    [self.refresh addTarget:self action:@selector(getContestVideoList)
           forControlEvents:UIControlEventValueChanged];
    [tblView addSubview:self.refresh];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
    [self getContestVideoList];
}
//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------
-(void)getContestVideoList {
   NSDictionary *dict = UDGetObject(dictUserInfo);

    [[ApplicationData sharedInstance] showLoader];
    NSString *postString = [NSString stringWithFormat:@"nContestId=%@&nUserId=%@",self.objConst.strContestId,[dict objectForKey:UserId]];
    HTTPManager *manager = [HTTPManager managerWithURL:URL_VIDEOLIST];
    manager.postString = postString;
    manager.requestType= HTTPRequestTypeGetVideoList;
    
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        [[ApplicationData sharedInstance] hideLoader];
        if ([[bodyDict valueForKey:@"status"] integerValue] != jSuccess) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[bodyDict valueForKey:@"msg"]];
        }
        else {
            NSArray *sortedArray =(NSArray *)[bodyDict valueForKey:@"VideoList"];
            NSSortDescriptor *sorter = [[NSSortDescriptor alloc] initWithKey:@"sTotalVotes.intValue" ascending:NO];
            NSArray *sorters = [[NSArray alloc] initWithObjects:sorter, nil];
            sortedArray = [sortedArray sortedArrayUsingDescriptors:sorters];
            self.arrVideoList = [[NSMutableArray alloc] init];
            [self.arrVideoList addObjectsFromArray:sortedArray];
            self.arrVideoList =(NSMutableArray *) sortedArray;
        }
        [self.refresh endRefreshing];
         [tblView reloadData];
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        
    }];
    
    
}
//------------------------------------------------------------------------------

#pragma mark - Tableview Delegate and Datasource
#pragma mark
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.arrVideoList.count != 0)
    return self.arrVideoList.count;
    else
        return 0;
}
//------------------------------------------------------------------------------

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
//------------------------------------------------------------------------------

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
//------------------------------------------------------------------------------

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}
//------------------------------------------------------------------------------


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.section == 0  ) {
//    
//    static NSString *simpleTableIdentifier = @"ContestListCell";
//    
//    ContestListCell *cell = (ContestListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
//    if (cell == nil)
//    {
//        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ContestListCell" owner:self options:nil];
//        cell = [nib objectAtIndex:0];
//    }
//  //  appData.aCont =[self.arrContestList objectAtIndex:indexPath.section];
//    
//    NSString *text = _objConst.strContestDesc;
//    CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:text font:[UIFont systemFontOfSize:9] width:cell.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)+ 10.0];
//    CGFloat cellsize =  textheight + cell.btnMoreContestInfo.frame.size.height+ + cell.lblTitle.frame.size.height + 40.0;
//    
//    
//    if (textheight>30) {
//        return cellsize;
//    }
//    else
//        return 135;
//
//    }
//    else {
        return 100;
//    }
}

//------------------------------------------------------------------------------

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *simpleTableIdentifier = [NSString stringWithFormat:@"%ld %ld",(long)indexPath.section,(long)indexPath.row];
    VideoListCell *cell = (VideoListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        [tableView registerNib:[UINib nibWithNibName:@"VideoListCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];

       cell.selectionStyle = UITableViewCellSelectionStyleNone;
        NSDictionary *playerVars = @{
                                     @"controls" : @0,
                                     @"autohide" : @1,
                                     @"showinfo" : @0,
                                     @"modestbranding" : @1
                                     };
        NSString *strVideoID = [[self.arrVideoList objectAtIndex:indexPath.section]valueForKey:@"sVideo"];
        [cell.imgThumnail loadWithVideoId:strVideoID playerVars:playerVars];
        [cell.imgThumnail loadVideoById:strVideoID startSeconds:cell.imgThumnail.currentTime suggestedQuality:kYTPlaybackQualitySmall];  // Force HD Quality
        cell.imgThumnail.layer.cornerRadius = 6;
        cell.imgThumnail.layer.masksToBounds = YES;
        [cell.imgThumnail setUserInteractionEnabled:FALSE];
        NSString *strVideoAddedby = [NSString stringWithFormat:@"%@ %@",[[ApplicationData sharedInstance] isNullOrEmpty:[[self.arrVideoList objectAtIndex:indexPath.section]valueForKey:@"sFirstName"]],[[ApplicationData sharedInstance] isNullOrEmpty:[[self.arrVideoList objectAtIndex:indexPath.section]valueForKey:@"sLastName"]]];
        [cell.btnSubmitVideos setTitle:strVideoAddedby forState:UIControlStateNormal];
        [cell.btnSubmitVideos setHidden:FALSE];
        [cell.btnSubmitVideos setImage:nil forState:UIControlStateNormal];
        [cell.btnSubmitVideos setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        cell.btnSubmitVideos.titleLabel.font = [UIFont systemFontOfSize:12];
        cell.btnNumberOfVotes.titleLabel.font = [UIFont systemFontOfSize:12];


    }
    cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:[[self.arrVideoList objectAtIndex:indexPath.section]valueForKey:@"sVideoTitle"]];
    
    [cell.btnNumberOfVotes setTitle:[NSString stringWithFormat:@"%@ Votes",[[self.arrVideoList objectAtIndex:indexPath.section]valueForKey:@"sTotalVotes"]] forState:UIControlStateNormal];

    return cell;
}
//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
    
}
//------------------------------------------------------------------------------


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    UITableViewCell *cell = (UITableViewCell *)[tblView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[VideoListCell class]]) {
        
        VideoVerticalVC* rootController = (VideoVerticalVC *)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoVerticalVC"];
        rootController.fromVC = FromContestVideos;
        rootController.dictVideoInfo = [NSMutableDictionary new];
        [rootController.dictVideoInfo addEntriesFromDictionary:[self.arrVideoList objectAtIndex:indexPath.section]];
        [self.navigationController pushViewController:rootController animated:TRUE];
    }
    else {
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        ContestVC *controller = (ContestVC*)[mainStoryboard
                                             instantiateViewControllerWithIdentifier: @"ContestVC"];
        controller.objConst = _objConst;
        [self.navigationController pushViewController:controller animated:YES];
    }
}
//------------------------------------------------------------------------------

#pragma mark - Navigation
#pragma mark
//------------------------------------------------------------------------------

- (void)moreContestInfoTapped:(id)sender {
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    ContestVC *controller = (ContestVC*)[mainStoryboard
    instantiateViewControllerWithIdentifier: @"ContestVC"];
    [self.navigationController pushViewController:controller animated:YES];
}
//------------------------------------------------------------------------------

@end
