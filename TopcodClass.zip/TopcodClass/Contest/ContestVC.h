//
//  ContestVC.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

//This Class is use for contest Detail and Spansor Detail.

#import <UIKit/UIKit.h>
#import "Contest.h"
#import "Sponsor.h"
#import "ApplicationData.h"

@interface ContestVC : UIViewController<UIScrollViewDelegate>
{
    ApplicationData *appData;
}
@property (nonatomic,retain) Contest *objConst;
@property (nonatomic,retain) Sponsor *objSpos;

@property (nonatomic,retain) IBOutlet UITextView *txtDesc;
@property (nonatomic,retain) IBOutlet UIImageView *imgBG;
@property (nonatomic,retain) IBOutlet UILabel *lblUrl;
@property (nonatomic,retain) IBOutlet UILabel *lblTitle;
@property (nonatomic,retain) IBOutlet UIScrollView *scrViewOuter;
@property (nonatomic,retain) NSArray *arrSponsorImg;
@property (nonatomic,retain) NSArray *arrSponsor;
@property (nonatomic,retain) IBOutlet UITextView *txtContestDtl;
 @end
