//
//  SubmitContestVC.h
//  TopCode
//
//  Created by tusharpatel on 12/09/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ApplicationData.h"

@interface SubmitContestVC : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    ApplicationData *appData;
}
@property (nonatomic,strong) IBOutlet UITableView *tblView;
@property (nonatomic,strong) NSMutableArray *arrContestList;
@property (nonatomic,strong) NSDictionary *dictSelectedVideo;
@property (nonatomic,strong) NSString *strConstantId;

@end
