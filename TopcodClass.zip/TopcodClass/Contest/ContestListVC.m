//
//  ContestListVCViewController.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "ContestListVC.h"
#import "ContestListCell.h"
#import "ContestVideosVC.h"
#import "ContestVC.h"

@interface ContestListVC ()<ContestListDelegate,UITableViewDataSource,UITableViewDelegate> {
    
    IBOutlet UITableView *tblView;
}

@end

@implementation ContestListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Contests List";
    appData = [ApplicationData sharedInstance];
    tblView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.refresh = [[UIRefreshControl alloc] initWithFrame:CGRectZero];
    [self.refresh addTarget:self action:@selector(getContestListData)
           forControlEvents:UIControlEventValueChanged];
    [tblView addSubview:self.refresh];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
    [self getContestListData];
    }
//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------

-(void)getContestListData { 
    [[ApplicationData sharedInstance] showLoader];
    HTTPManager *manager = [HTTPManager managerWithURL:URL_CONTESTLIST];
    manager.requestType= HTTPManagerTypeGetContestList;
    
    [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
        NSLog(@"%@",bodyDict);
        [[ApplicationData sharedInstance] hideLoader];
        self.arrContestList =(NSArray *) bodyDict;
        [tblView reloadData];
        [self.refresh endRefreshing];
        
    } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"No record Found"];
        
    } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
    }];
}
//------------------------------------------------------------------------------

#pragma mark - Tableview Delegate and Datasource
#pragma mark
//------------------------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.arrContestList.count;
}
//------------------------------------------------------------------------------

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
//------------------------------------------------------------------------------

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
//------------------------------------------------------------------------------

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *v = [UIView new];
    [v setBackgroundColor:[UIColor clearColor]];
    return v;
}

//------------------------------------------------------------------------------

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
   static NSString *simpleTableIdentifier = @"ContestListCell";
    
    ContestListCell *cell = (ContestListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ContestListCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    appData.aCont =[self.arrContestList objectAtIndex:indexPath.section];

    NSString *text = appData.aCont.strContestDesc;
   CGFloat textheight =  [[ApplicationData sharedInstance] getTextHeightOfText:text font:[UIFont systemFontOfSize:9] width:self.view.frame.size.width - (cell.imgThumnail.frame.origin.x + cell.imgThumnail.frame.size.width)+ 10.0];
        CGFloat cellsize =  textheight + cell.btnMoreContestInfo.frame.size.height+ cell.lblTitle.frame.size.height+cell.lblSponsor.frame.size.height+cell.lblPrize.frame.size.height + 30;
    
    if (textheight>30 && textheight<50) {
        return cellsize+15;
    }
    else
        return 150;
}

//------------------------------------------------------------------------------

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *simpleTableIdentifier = [NSString stringWithFormat:@"%ld %ld",(long)indexPath.section,(long)indexPath.row];
    ContestListCell *cell = (ContestListCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    appData.aCont =[self.arrContestList objectAtIndex:indexPath.section];
    JImage *photoImage = (JImage *)[cell.contentView viewWithTag:1000+indexPath.section];
    if (cell == nil)
    {
        [tableView registerNib:[UINib nibWithNibName:@"ContestListCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        photoImage = [[ApplicationData sharedInstance]getJImage:appData.aCont.strContestThumbImgUrl andFrame:CGRectMake(cell.imgThumnail.frame.origin.x,cell.imgThumnail.frame.origin.y
                                                                                                                         ,cell.imgThumnail.frame.size.width,cell.imgThumnail.frame.size.height)];
        [photoImage setTag:indexPath.section+1000];
        [cell.contentView addSubview:photoImage];
        
        photoImage.layer.cornerRadius = 6;
        photoImage.layer.masksToBounds = YES;

        cell.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    else {
        [photoImage initWithImageAtURL:[NSURL URLWithString:appData.aCont.strContestThumbImgUrl]];
    }
    
    cell.lblTitle.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestName];
    Sponsor *objSponsor;
    if (appData.aCont.arrSponsor.count>0) {
        objSponsor = [appData.aCont.arrSponsor objectAtIndex:0];
        cell.lblSponsor.text = [NSString stringWithFormat:@"Sponsor: %@",[[ApplicationData sharedInstance] isNullOrEmpty:objSponsor.strSponsorName]];
    }
    
    cell.lblPrize.text = [NSString stringWithFormat:@"Prize: %@",[[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestPrice]];
  ///  cell.lblDesc.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestDesc];
    cell.tvDesc.text = [[ApplicationData sharedInstance] isNullOrEmpty:appData.aCont.strContestDesc];

    cell.btnMoreContestInfo.tag = indexPath.section;
    cell.btnMoreContestInfo.layer.cornerRadius = 13;
    if (IS_IPAD) {
        cell.btnMoreContestInfo.titleLabel.font = [UIFont systemFontOfSize:11];
    }
    cell.delegate = self;

    // ... set up the cell here ...
    return cell;
}
//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView  willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}

//------------------------------------------------------------------------------

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"bundle: nil];
    
    ContestVideosVC *controller = (ContestVideosVC*)[mainStoryboard instantiateViewControllerWithIdentifier: @"ContestVideosVC"];
    controller.objConst = [self.arrContestList objectAtIndex:indexPath.section];

    [self.navigationController pushViewController:controller animated:YES];

}
//------------------------------------------------------------------------------

#pragma mark - Delegate
#pragma mark
//------------------------------------------------------------------------------

- (void)moreContestInfoTapped:(id)sender {
    UIButton *btn = (UIButton *)sender;
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    ContestVC *controller = (ContestVC*)[mainStoryboard
                                                     instantiateViewControllerWithIdentifier: @"ContestVC"];
    
    
    controller.objConst = [self.arrContestList objectAtIndex:btn.tag];
    [self.navigationController pushViewController:controller animated:YES];
}

//------------------------------------------------------------------------------


@end
