//
//  ContestVideosVC.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

//This Class is use for Diplay Contest Video List.


#import <UIKit/UIKit.h>
#import "Contest.h"
#import "Sponsor.h"
#import "ApplicationData.h"
@interface ContestVideosVC : UIViewController
{
    ApplicationData *appData;
}
@property (nonatomic,retain) Contest *objConst;
@property (nonatomic,retain) Sponsor *objSpons;
@property (nonatomic,retain) UIRefreshControl *refresh;
@property (nonatomic,strong) IBOutlet UILabel *lblContestName;
@property (nonatomic,strong) IBOutlet UILabel *lblSponsorName;
@property (nonatomic,strong) IBOutlet UILabel *lblPrice;
@property (nonatomic,strong) NSMutableArray *arrVideoList;

@end
