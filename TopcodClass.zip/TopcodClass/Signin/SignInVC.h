//
//  MasterViewController.h
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.

// This class is use for Manual Login.
// User Can login by Youtube and Google Sdk.


#import <UIKit/UIKit.h>
#import "ApplicationData.h"
#import "HTTPManager.h"
@interface SignInVC : UIViewController<HTTPManagerDelegate>
- (IBAction)onbtnLoginAsGuestTapped:(id)sender;
@end

