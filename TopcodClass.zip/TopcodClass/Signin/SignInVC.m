//
//  MasterViewController.m
//  TOPCOD
//
//  Created by ashish on 23/06/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import "SignInVC.h"
#import "AppDelegate.h"
#import "YouTubeHelper.h"

@interface SignInVC ()<UITextFieldDelegate,YouTubeHelperDelegate> {
    IBOutlet UITextField *txtUserName;
    IBOutlet UITextField *txtPasswordName;
    IBOutlet UIButton *btnRememberMe;
}

-(IBAction)OnbtnRememberMeTapped:(id)sender;
-(IBAction)OnbtnSubmitTapped:(id)sender;
-(IBAction)OnbtnSignInWithGoogleTapped:(id)sender;

@property NSMutableArray *objects;


@end
@implementation SignInVC

//------------------------------------------------------------------------------

#pragma mark - View lifecycle
#pragma mark
//------------------------------------------------------------------------------


- (void)awakeFromNib {
    [super awakeFromNib];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
    }
}
//------------------------------------------------------------------------------

- (id)initWithNibName:(NSString *)nibNameOrNil
               bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}
//------------------------------------------------------------------------------


- (void)viewDidLoad {
    [self.navigationController.navigationBar setTranslucent:YES];
    self.navigationController.view.backgroundColor = [UIColor clearColor];
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [[UIImage alloc] init];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];

    [super viewDidLoad];
    
}
//------------------------------------------------------------------------------

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:TRUE];
  
    if (UDGetBool(isRemember) == TRUE) {
        txtUserName.text = UDGetValue(EmailId);
        btnRememberMe.selected = TRUE;
    }
   
}
//------------------------------------------------------------------------------
#pragma mark - Spare Methods
#pragma mark
//------------------------------------------------------------------------------

- (void)showAuthenticationViewController:(UIViewController *)authView;
{
    [self.navigationController pushViewController:authView animated:YES];
}

//------------------------------------------------------------------------------


-(void)returnUserProfile:(NSMutableDictionary *)dictUserProfile {
    [ApplicationData sharedInstance].isGoogleLogin = YES;
    UDSetBool([ApplicationData sharedInstance].isGoogleLogin,isGLogin);
    NSMutableDictionary *dictProfileData = [dictUserProfile valueForKey:@"profileData"];
    NSMutableDictionary *dictAuthData = [dictUserProfile valueForKey:@"authData"];
    
    NSString *strPicture = [dictProfileData objectForKey:@"picture"];
    NSString *strEmail = [dictProfileData objectForKey:@"email"];
    NSString *strUserID = [dictAuthData objectForKey:@"userID"];
    NSString *strFName = [dictProfileData objectForKey:@"given_name"];
    NSString *strLName = [dictProfileData objectForKey:@"family_name"];
    
    if (strEmail.length != 0) {
        [[ApplicationData sharedInstance] showLoader];
        
        NSString *postString = [NSString stringWithFormat:@"sEmail=%@&sYoutubeId=%@&sProfileImage=%@&sFirstName=%@&sLastName=%@",strEmail,strUserID,strPicture,strFName,strLName];
        HTTPManager *manager = [HTTPManager managerWithURL:URL_REGISTER];
        
        [manager setPostString:postString];
        manager.requestType = HTTPRequestTypeGeneral;
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            NSLog(@"%@",bodyDict);
            AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication]delegate];

            if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
                [dict setObject:[bodyDict valueForKey:UserId] forKey:UserId];
                [dict setObject:[dictProfileData objectForKey:@"given_name"] forKey:FirstName];
                [dict setObject:[dictProfileData objectForKey:@"family_name"] forKey:LastName];
                [dict setObject:strEmail forKey:EmailId];
                [dict setObject:strUserID forKey:YoutubeId];
                [dict setObject:strPicture forKey:ProfileImage];
                [dict setObject:@"" forKey:Password];

                UDSetObject(dict,dictUserInfo);
                [[ApplicationData sharedInstance] hideLoader];
                appDel.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
            }
            else {
                NSMutableDictionary *dict1 = [[NSMutableDictionary alloc] init];
                NSDictionary *dict = [bodyDict valueForKey:@"UserDetails"];
                
                [dict1 setObject:[dict valueForKey:UserId] forKey:UserId];
                [dict1 setObject:[dict valueForKey:FirstName] forKey:FirstName];
                [dict1 setObject:[dict valueForKey:LastName] forKey:LastName];
                [dict1 setObject:[dict valueForKey:EmailId] forKey:EmailId];
                [dict1 setObject:[dict valueForKey:YoutubeId] forKey:YoutubeId];
                [dict1 setObject:strPicture forKey:ProfileImage];
                [dict1 setObject:[dict valueForKey:Password] forKey:Password];
                UDSetObject(dict1 , dictUserInfo);
                [[ApplicationData sharedInstance] hideLoader];
                    appDel.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
            }
            // TP Comment
            
            [appDel setUpTabBar];
            appDel.isTabBarSet=YES;
            
            
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
        }];
    }
}

//------------------------------------------------------------------------------
#pragma mark - Action
#pragma mark
//------------------------------------------------------------------------------

-(IBAction)OnbtnSignInWithGoogleTapped:(id)sender {
    AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    appDelegateTemp.isLoginWithGoogle=true;
    [[YouTubeHelper sharedManager] setDelegate:self];
    [[YouTubeHelper sharedManager] initYoutubeService];
    [[YouTubeHelper sharedManager] authenticate];
}
//------------------------------------------------------------------------------

-(IBAction)OnbtnRememberMeTapped:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (btn.selected) {
        btn.selected = FALSE;
        UDSetBool(FALSE, isRemember);
    }
    else{
        UDSetBool(TRUE, isRemember);
        btn.selected = TRUE;
    }
}
-(IBAction)OnbtnSubmitTapped:(id)sender {
    [[ApplicationData sharedInstance] showLoader];
    if (txtUserName.text.length != 0 && txtPasswordName.text.length != 0) {
        if (btnRememberMe.selected == TRUE) {
            UDSetValue(txtUserName.text, EmailId);
        }
        else{
            
            UDSetValue(@"", EmailId);
        }
        NSString *postString = [NSString stringWithFormat:@"sEmail=%@&sPassword=%@",txtUserName.text,txtPasswordName.text];
        
        HTTPManager *manager = [HTTPManager managerWithURL:URL_LOGIN];
        [manager setPostString:postString];
        manager.requestType= HTTPRequestTypeLogin;
        
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            
            NSLog(@"%@",bodyDict);
            [[ApplicationData sharedInstance] hideLoader];
            if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                NSDictionary *dictUserDetails = [bodyDict objectForKey:@"userdetails"];
                UDSetObject(dictUserDetails, dictUserInfo);
                AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
                appDelegateTemp.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
                [appDelegateTemp setUpTabBar];
            }
            else {
                [[ApplicationData sharedInstance] hideLoader];
                [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[bodyDict objectForKey:@"msg"]];
                
            }
            
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:@"Invalid Username and Password"];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
            
        }];
    } else{
        [[ApplicationData sharedInstance] hideLoader];
        [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert " Message:@"Please Enter UserName and Password"];
    }
}

//---------------------------------------------------------------------

- (IBAction)onbtnLoginAsGuestTapped:(id)sender {
    [ApplicationData sharedInstance].isGoogleLogin = NO;
    UDSetBool([ApplicationData sharedInstance].isGoogleLogin, isGLogin);
    AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    appDelegateTemp.window.rootViewController = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
    [appDelegateTemp setUpTabBar];
}
//---------------------------------------------------------------------

#pragma mark - UIAlertView Delegate
#pragma mark
//---------------------------------------------------------------------

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
}

//------------------------------------------------------------------------------

#pragma mark - UITextField Delegate
#pragma mark
//------------------------------------------------------------------------------

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return TRUE;
}
//------------------------------------------------------------------------------

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
        [self animateTextField:textField up:YES];
}
//------------------------------------------------------------------------------

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];

}
//------------------------------------------------------------------------------

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -80; // tweak as needed
    const float movementDuration = 0.5f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

//------------------------------------------------------------------------------

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
//        DetailViewController *controller = (DetailViewController *)[[segue destinationView Controller] topViewController];
//        [controller setDetailItem:object];
//        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
//        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}


@end
