//
//  JImage.m
//  TopCode
//
//  Created by tusharpatel on 09/07/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

//JImage.m

#import "JImage.h"

static NSCache *imagecache;

@implementation JImage
@synthesize ai,connection, data;

-(void)initWithImageAtURL:(NSURL*)url
{
    [self setContentMode:UIViewContentModeScaleAspectFit];
    if (!ai){
        [self setAi:[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge]];
        [ai startAnimating];
        [ai setTranslatesAutoresizingMaskIntoConstraints:NO];
        [ai setCenter:self.center];
        [self addSubview:ai];
    }
    
    NSURLRequest* request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReturnCacheDataElseLoad timeoutInterval:60];
    
    
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

- (void)setImageAtURL:(NSURL *)url
{
    if (!ai){
        [self setAi:[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray]];
        [ai startAnimating];
        [ai setCenter:self.center];
        [self addSubview:ai];
        
        [ai setTranslatesAutoresizingMaskIntoConstraints:NO];
        NSLayoutConstraint *centerConst = [NSLayoutConstraint constraintWithItem:ai attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
        [self addConstraint:centerConst];
        centerConst = [NSLayoutConstraint constraintWithItem:ai attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0];
        [self addConstraint:centerConst];
        
    }
    
    NSURLRequest* request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReturnCacheDataElseLoad timeoutInterval:60];
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
}

- (void)connection:(NSURLConnection *)theConnection	didReceiveData:(NSData *)incrementalData {
    if (data==nil) data = [[NSMutableData alloc] initWithCapacity:2048];
    [data appendData:incrementalData];
}

- (void)connectionDidFinishLoading:(NSURLConnection*)theConnection
{
    [self setImage:[UIImage imageWithData: data]];
    [ai removeFromSuperview];
    
    ai = nil;
}

@end
/*//Include the definition in your class where you want to use the image
-(UIImageView*)downloadImage:(NSURL*)url:(CGRect)frame {
    
    JImage *photoImage=[[JImage alloc] init];
    
    photoImage.backgroundColor = [UIColor clearColor];
    
    [photoImage setFrame:frame];
    
    [photoImage setContentMode:UIViewContentModeScaleToFill];
    
    [photoImage initWithImageAtURL:url];
    
    return photoImage;
}


//How to call the class

UIImageView *imagV=[self downloadImage:url :rect];

//you can call the downloadImage function in looping statement and subview the returned  imageview.
//it will help you in lazy loading of images.


//Hope this will help*/