//
//  TabBarVC.h
//  TopCode
//
//  Created by tusharpatel on 24/08/15.
//  Copyright (c) 2015 ashish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarVC : UITabBarController

@end
