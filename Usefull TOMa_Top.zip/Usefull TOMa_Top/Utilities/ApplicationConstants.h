//
//  ApplicationConstants.h
//  BeefOBrady
//
//  Created by Aruna on 16/01/13.
//  Copyright (c) 2012 Ayansys Solutions Private Limited. All rights reserved.
//

#ifndef BeefOBrady_Header_h
#define BeefOBrady_Header_h





#ifndef informationToSend
#define informationToSend [NSString stringWithFormat:@"screen: %s in method : %s",strrchr(__FILE__,'/'),__PRETTY_FUNCTION__]
#endif

#ifndef GoogleAnalyticsInformation
#define GoogleAnalyticsInformation 	NSError *err_;\
if (![[GANTracker sharedTracker] trackPageview:informationToSend withError:&err_])\
{\
	NSLog(@"Error: %@", err_);\
}
#endif



/////////////////////MACROS TO BE VISIBLE THROUGHT THE APPLICATION//////////////////////////////


#ifndef UseTryCatch
#define UseTryCatch 1//use 0 to disable and 1 to enable the try catch throughout the application


//Warning:Do not Enable this Macro for general purpose...use it if u are intentionally dubbugging for some unexpected method calls
#ifndef UsePTMName
#define UsePTMName 0//use 0 to disable and 1 to enable printing the method name throughout the application


#if UseTryCatch


#if UsePTMName
#define TCSTART @try{NSLog(@"\n%s\n",__PRETTY_FUNCTION__);
#else
#define TCSTART @try{
#endif

#define TCEND  }@catch(NSException *e){NSLog(@"\n\n\n\n\n\n\
\n\n|EXCEPTION FOUND HERE...PLEASE DO NOT IGNORE\
\n\n|FILE NAME         %s\
\n\n|LINE NUMBER       %d\
\n\n|METHOD NAME       %s\
\n\n|EXCEPTION REASON  %@\
\n\n\n\n\n\n\n",strrchr(__FILE__,'/'),__LINE__, __PRETTY_FUNCTION__,e);};


#else

#define TCSTART
#define TCEND

#endif
#endif


#endif

/////////////////////MACROS TO BE VISIBLE THROUGHT THE APPLICATION//////////////////////////////
#define CURRENT_DEVICE [[UIDevice currentDevice] userInterfaceIdiom]
#define iPad ((CURRENT_DEVICE==UIUserInterfaceIdiomPad)?YES:NO)
#define iPhone ((CURRENT_DEVICE==UIUserInterfaceIdiomPhone)?YES:NO)

#define CURRENT_DEVICE_VERSION [[UIDevice currentDevice]systemVersion].floatValue

//isiPhone6 represents both iphone-6 and 6+
#define isiPhone6 ((iPhone && ([[UIScreen mainScreen] bounds].size.width > 320.0f))?YES:NO)

//isiPhone6 represents iphone-6+
#define isiPhone6PLUS ((iPhone && ([[UIScreen mainScreen] bounds].size.width > 375.0f))?YES:NO)

#define UITextAlignmentCenter (CURRENT_DEVICE_VERSION<6.0)?UITextAlignmentCenter:NSTextAlignmentCenter
#define UITextAlignmentLeft (CURRENT_DEVICE_VERSION<6.0)?UITextAlignmentLeft:NSTextAlignmentLeft
#define UITextAlignmentRight (CURRENT_DEVICE_VERSION<6.0)?UITextAlignmentRight:NSTextAlignmentRight
//Helvetica Neue
#define tabTitlesFontName @"HelveticaNeue-Bold"
#define titleFontName   @"HelveticaNeue-Bold"
#define descriptionTextFontName @"HelveticaNeue"
#define rewardAlertTextFontName @"BrandonGrotesque-Light"
#define headerTitleFontName @"FetteEngD"
#define dateFontName    @"HelveticaNeue"
#define changeSecurityQstnFont    @"HelveticaNeue-Bold"
#define coffeeServiceFont    @"CoffeeService"
#define GeosansLightFont  @"GeosansLight"
#define CenturyGothicFont @"CenturyGothic"
#define RewardTitleFontName @"FetteEngD"

#define coffeeServiceSize   (iPad?45:24)
#define SectionHeaderTitleFontSize (iPad?30.0f:20.0f)
#define tableRowSelectedColor [UIColor colorWithRed:(197.0/255.0) green:(217.0/255.0) blue:(267.0/255.0) alpha:1.0]
#define tabTitlesFontSize (iPad?18.0f:10.0f)
#define titleFontSize   (iPad?22.0f:16.0f)
#define cellTitleFontSize  (iPad?22.0f:(isiPhone6?(isiPhone6PLUS?14.0:13.0):12.0f))

#define changeSecurityQstnFontSize (iPad?25.0f:16.0f)                                                                                                                                                                                                                                                                                                                                                 

#define CenturyGothicFontSize (iPad?38:16)
#define locationNameSize (iPad?21.0f:15.0f)
#define locationAddressSize (iPad?19.0f:13.0f)
#define InfoTitleFontSize (iPad?25.0f:16.0f)
#define descriptionTextFontSize (iPad?22.0f:16.0f)
#define notificationTextFontSize (iPad?22.0f:14.0f)
#define headerTitleFontSize (iPad?45.0f:(isiPhone6PLUS?28.0f:24.0f))
#define headerTitleFontSize6Plus (iPad?45.0f:26.0f)
#define headerTitleNewFontSize (iPad?45.0f:21.0f)
#define rewardCellHeaderFontSize (iPad?22.0f:16.0f)
#define LoginTitleFontSize (iPad?41.0f:24.0f)
#define dateFontSize    (iPad?18.0f:12.0f)
#define addressFontSize    (iPad?20.0f:14.0f)
#define surveyTitleFontSize (iPad?20.0f:14.0f)
#define GeosansLightFontSize (iPad?38:20)
#define menuTitleTextFontSize (iPad?22.0f:12.0f)
#define menuDescTextFontSize (iPad?20.0f:10.0f)

#define PROFILE_LEFTLABEL_FONT_SIZE (iPad?40:22)

#define REWARD_PROFILE_TOTAL_COUNT_FONT_SIZE (iPad?95:70)
#define REWARD_PROFILE_LEFTLABEL_FONT_SIZE (iPad?50:25)
#define REWARD_PROFILE_FAVLABEL_FONT_SIZE (iPad?53:28)
#define REWARD_PROFILE_LEFTCOUNT_FONT_SIZE (iPad?22:13)
#define REWARD_PROFILE_USERNAME_FONT_SIZE (iPad?45:28)

#define REWARD_NUMBER_COUNT_FONT_SIZE (iPad?50:30)
#define REWARD_TEXT_COUNT_FONT_SIZE (iPad?38:20)


#define CELL_CONTENT_WIDTH (iPad?728.0f:(isiPhone6?[[UIScreen mainScreen] bounds].size.width-20:300.0f))
#define CELL_CONTENT_MARGIN 5.0f
#define CELL_PLUGPHOTOHEIGHT (iPad?600.0f:300.0f)
#define CELL_PLUGPHOTOWIDTH (iPad?600.0f:300.0f)
#define CELL_RATEIMAGEVIEWHEIGHT (iPad?75.0f:20.0f)
#define CELL_RATEIMAGEVIEWWIDTH (iPad?505:100)

#define COMMENTOR_IMAGE_WIDTH (iPad?40.0f:25.0f)
#define COMMENTOR_IMAGE_HEIGHT (iPad?40.0f:25.0f)

#define FAVOURITE_IMAGE_WIDTH (iPad?30.0f:25.0f)
#define FAVOURITE_IMAGE_HEIGHT (iPad?30.0f:25.0f)

#define HEADER_WIDTH (iPad?748:(isiPhone6?[[UIScreen mainScreen] bounds].size.width-10:310.0f))
#define HEADER_MARGIN (iPad?10.0f:5.0f)

#define iPadCOMMENTCELLORIGINX (CURRENT_DEVICE_VERSION<7.0)?0:45
#define iPhoneCOMMENTCELLORIGINX (CURRENT_DEVICE_VERSION<7.0)?0:10
#define HEADER_MARGIN_WIDTH 5
#define HEADER_MARGIN_HEIGHT 5
#define VIEW_WIDTH (iPad?768:320)
#define VIEW_ORIGIN 0

#define REVIEWER_IMAGE_WIDTH (iPad?60.0f:40.0f)
#define REVIEWER_IMAGE_HEIGHT (iPad?60.0f:40.0f)

//Refresh the table on pull of table
#define kReleaseToReloadStatus	0
#define kPullToReloadStatus		1
#define kLoadingStatus			2

//for Zoom in and out the map
#define TIME_FOR_SHRINKING 0.61f // Has to be different from SPEED_OF_EXPANDING and has to end in 'f'
#define TIME_FOR_EXPANDING 0.60f // Has to be different from SPEED_OF_SHRINKING and has to end in 'f'
#define SCALED_DOWN_AMOUNT 0.01  // For example, 0.01 is one hundredth of the normal size
#define KEYBOARD_PORTRAIT_HEIGHT (iPad?264:216)

//#define COMMENT_TEXTVIEW_HEIGHT (iPad?127:30)
#define COMMENTVIEW_BAR_HEIGHT (iPad?177:109)
#define COMMENTVIEW_BAR_WIDTH (iPad?685:(isiPhone6?[[UIScreen mainScreen] bounds].size.width-20:300.0f))
#define COMMENTVIEW_TABLEORIGINY (iPad?75:53)
#define kOFFSET_FOR_KEYBOARD (iPad?45:130)

#define MINIMUMQUESTIONVIEWHEIGHT (iPad?100:70)
#define HEADERHEIGHT (iPad?65:40)
#define MAXQUESTIONSDISPLAYAREAIPhone5 450
#define MAXQUESTIONSDISPLAYAREANORMAL   365
#define MAXQUESTIONSDISPLAYAREA (iPad?844:((appDelegate.window.frame.size.height>480)?MAXQUESTIONSDISPLAYAREAIPhone5:MAXQUESTIONSDISPLAYAREANORMAL))
#define SURVEYVIW_WIDTH (iPad?730:300)

#define LINEIMAGE_FRAME (iPad ? CGRectMake(0, 62, 768, 13):CGRectMake(0, 38, [[UIScreen mainScreen] bounds].size.width, 13))



#define APP_VERSION 1.0

//Memorial Health System Demo Api key
//#define API_KEY @"c2044ea9fed93d932c86012aae8b1d1211f479e4"

//Health Demo Live API key
//#define API_KEY @"c2044ea9fed93d932c86012aae8b1d1211f479e4";

//Health Demo Demo API key
//#define API_KEY @"8480ed1e91ff607bfc095175593bdca6f699e953"
//Baldwin API-KEY
//#define API_KEY @"42db629a54355a99f436bb5eb3cdb15631a8db33"

//Tomah
//#if DISTRIBUTION
#define APP_URL @"https://tomah.patientconnecter.com"
//#else
//#define APP_URL @"http://tomah.patientstaging.com"
//#endif

//#if DISTRIBUTION
#define API_KEY @"4b690f51fd8a295199ce8955535878fdac08a3fe"
//#else
//#define API_KEY @"849ec04ca35a1c5dbc776f15d492b6dbbc220d42"
//#endif

//baldwin
//#if DISTRIBUTION
//#define APP_URL @"https://baldwin.patientconnecter.com"
//#else
//#define APP_URL @"http://baldwin.patientstaging.com"
//#endif

//#define API_KEY @"42db629a54355a99f436bb5eb3cdb15631a8db33"

//#define APP_URL @"https://www.patientconnecter.com"
//#define API_KEY @"15e12427a1919c3dc25de31cdbf71cc21b1d3764"

#define AIRBRAKE_API_KEY @"24e5af544fb68171c29db7bf34b25023"

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? YES : NO)


#define ENCRYPTION_KEY_LENGHT 28

#define UDSetObject(value, key) [[NSUserDefaults standardUserDefaults] setObject:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetValue(value, key) [[NSUserDefaults standardUserDefaults] setValue:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetBool(value, key) [[NSUserDefaults standardUserDefaults] setInteger:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetInt(value, key) [[NSUserDefaults standardUserDefaults] setFloat:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetFloat(value, key) [[NSUserDefaults standardUserDefaults] setBool:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]

#define UDGetObject(key) [[NSUserDefaults standardUserDefaults] objectForKey:(key)]
#define UDGetValue(key) [[NSUserDefaults standardUserDefaults] valueForKey:(key)]
#define UDGetInt(key) [[NSUserDefaults standardUserDefaults] integerForKey:(key)]
#define UDGetFloat(key) [[NSUserDefaults standardUserDefaults] floatForKey:(key)]
#define UDGetBool(key) [[NSUserDefaults standardUserDefaults] boolForKey:(key)]

#define UDRemoveObject(key) [[NSUserDefaults standardUserDefaults] removeObjectForKey:(key)]

#define noOfInsur @"noOfInsurance"


#endif

