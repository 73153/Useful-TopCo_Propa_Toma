//
//  LocationAnnotation.m
//  iPhoneChatterPlug
//
//  Created by Josh on 5/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LocationAnnotation.h"

@implementation LocationAnnotation

@synthesize location;
@synthesize coordinate;
@synthesize title;
@synthesize subtitle;
@synthesize imgPath;

- (id) initWithCoordinate:(CLLocationCoordinate2D) coordinateInput withLocaiton: (NSMutableDictionary*) locationInput {
	coordinate = coordinateInput;
    location = locationInput;
    title = [location objectForKey:@"locName"];
    subtitle = [location objectForKey:@"address"];
    imgPath = [location objectForKey:@"imgPath"];
    
	return self;
}

@end
