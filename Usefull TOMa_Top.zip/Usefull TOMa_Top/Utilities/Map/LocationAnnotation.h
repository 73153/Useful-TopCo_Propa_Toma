//
//  LocationAnnotation.h
//  iPhoneChatterPlug
//
//  Created by Josh on 5/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface LocationAnnotation : NSObject <MKAnnotation> {
    NSMutableDictionary* location;
    CLLocationCoordinate2D coordinate;
    NSString *title;
    NSString *subtitle;
   NSString *imgPath;
   // NSString *locId;
}

@property (nonatomic, strong) NSMutableDictionary *location;
@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) NSString *imgPath;

-(id)initWithCoordinate:(CLLocationCoordinate2D) coordinate withLocaiton: (NSMutableDictionary*) location;

@end
