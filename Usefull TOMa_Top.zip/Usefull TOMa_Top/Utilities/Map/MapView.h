//
//  MapView.h
//  MapView
//
//  Created by aruna on 12/6/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/Mapkit.h>
#import <MapKit/MKAnnotation.h>
#import <CoreLocation/CoreLocation.h>
#import "LocationAnnotation.h"

@protocol MapViewDelegate <NSObject>

@optional

-(void) didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation;
-(void) didFailedToUpdateLocationWithError:(NSError *)error;

-(void) performRightCalloutAction:(id)sender;
//-(void) performLeftCalloutAction:(id)sender;

@end

@interface MapView : MKMapView <MKMapViewDelegate,CLLocationManagerDelegate>{

    //MKMapView *mapView;
    MKPlacemark *mPlacemark;
    CLLocationManager *locationManager;
    UIImage *annotationImage;
    //UIImage *leftCallOutImage;
    id <MapViewDelegate> mapDelegate;
    BOOL showLeftCalloutAccessory; 
    BOOL showRightCalloutAccessory;
    
}

//@property(nonatomic, strong) UIImage *leftCallOutImage;
@property(nonatomic, strong) UIImage *annotationImage;
@property(nonatomic, strong) CLLocationManager *locationManager;
//@property(nonatomic, strong) MKMapView *mapView;
@property(nonatomic, strong) MKPlacemark *mPlacemark;

@property (nonatomic, strong) id <MapViewDelegate> mapDelegate;

@property (nonatomic, readwrite) BOOL showLeftCalloutAccessory; 
@property (nonatomic, readwrite) BOOL showRightCalloutAccessory;

@property (nonatomic, readwrite) BOOL stopUpdatingLocationInfo;

- (void) loadMapData:(NSMutableArray *)businessLocations_MArray withSpan:(MKCoordinateSpan )span;
- (CLLocationCoordinate2D) getLatitudeLongitudeForAddress:(NSString *)address;

@end
