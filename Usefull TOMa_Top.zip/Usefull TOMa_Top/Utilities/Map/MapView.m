//
//  MapView.m
//  MapView
//
//  Created by aruna on 12/6/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "MapView.h"


@implementation MapView

@synthesize locationManager;
//@synthesize myLocation;
//@synthesize mapView;
@synthesize mPlacemark;
@synthesize mapDelegate;
@synthesize annotationImage;
//@synthesize leftCallOutImage;
@synthesize showLeftCalloutAccessory;
@synthesize showRightCalloutAccessory;
@synthesize stopUpdatingLocationInfo;

-(id)init {
    TCSTART
    if (self = [super init]) {
        //set the mapview properties like frame, type etc...
        //self.frame = frame;
        self.delegate = self;
        self.mapType = MKMapTypeStandard;
        self.showsUserLocation = TRUE;
        
        //initialize the locationmanager class to update us on the location details
        locationManager = [[CLLocationManager alloc] init];
        stopUpdatingLocationInfo = YES;
        locationManager.delegate = self;
        locationManager.desiredAccuracy = 50;
        [locationManager startUpdatingLocation];
    }
    return self;
    TCEND
}

//load tableview with respective data
- (void) loadMapData:(NSMutableArray *)businessLocations_MArray withSpan:(MKCoordinateSpan )span {
    TCSTART
    MKCoordinateRegion region; //defines which portion of the map to display.
//    self.showsUserLocation = TRUE; //Boolean value indicating whether the map may display the user location
    //MKCoordinateSpan span = {0.05, 0.05}; //defines the area spanned by a map region.
        
    NSMutableArray *locationMarkers = [[NSMutableArray alloc] init];
    
    //clear previous place markers
    for (id item in [self annotations]) {
        if (![item isKindOfClass:[MKUserLocation class]])
            [locationMarkers addObject:item];
    }
    
    [self removeAnnotations:locationMarkers];
    locationMarkers = nil;
    CGFloat lat = 0;
    CGFloat lng = 0;
    int i = 0;
    //set the annotation points based on latitude and longitude of locations.
    for (; i < [businessLocations_MArray count]; i++) {
        
        region.center.latitude =  [[[businessLocations_MArray objectAtIndex:i] objectForKey:@"lat"] doubleValue]; 
        region.center.longitude = [[[businessLocations_MArray objectAtIndex:i] objectForKey:@"lng"] doubleValue]; 
        lat +=  [[[businessLocations_MArray objectAtIndex:i] objectForKey:@"lat"] doubleValue];
        lng += [[[businessLocations_MArray objectAtIndex:i] objectForKey:@"lng"] doubleValue];
        
        LocationAnnotation *annotation = [[LocationAnnotation alloc] initWithCoordinate:region.center withLocaiton:[businessLocations_MArray objectAtIndex:i]];
        //set the address of location as annotation title (** its importent to get the callout for an MKAnnotationView)
       // annotation.title = [[businessLocations_MArray objectAtIndex:i] objectForKey:@"locName"];
       // annotation.subtitle = [[businessLocations_MArray objectAtIndex:i] objectForKey:@"address"];
        
        region.span = span;
        [self setRegion:region animated:YES];
        [self addAnnotation:annotation];
    }
    CGFloat count = businessLocations_MArray.count;
    if (count > 0) {
        lat = lat/count;
        lng = lng/count;
        //region.center.latitude = lat;
        //region.center.longitude = lng;
        self.centerCoordinate = CLLocationCoordinate2DMake(lat, lng);
        //region.span = span;
        //[self setRegion:region animated:YES];
    }
    TCEND
}


//Get the latitude and longitude based on the address.
-(CLLocationCoordinate2D) getLatitudeLongitudeForAddress:(NSString *)address {
    TCSTART
	NSError *error = nil;
    CLLocationCoordinate2D location;
    
    NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps/geo?q=%@&output=csv", 
                           [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
	NSString *locationString = [NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSUTF8StringEncoding error:&error];
    
	NSArray *listItems = [locationString componentsSeparatedByString:@","];
	
	location.latitude = 0.0;
	location.longitude = 0.0;
	
	if([listItems count] >= 4 && [[listItems objectAtIndex:0] isEqualToString:@"200"]) {
		location.latitude = [[listItems objectAtIndex:2] doubleValue];
		location.longitude = [[listItems objectAtIndex:3] doubleValue];
	}
	else {
		//Show error
	}
	if(location.latitude == 0.0 || location.longitude == 0.0)
	{
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Unable to find the location" delegate:self cancelButtonTitle:@"Ok"	otherButtonTitles:nil,nil];
		[alert show];
	}
	return location;
    TCEND
}

#pragma mark - map actions,getting location

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    TCSTART
    if (stopUpdatingLocationInfo) {
        [locationManager stopUpdatingLocation]; //uncomment to stop getting updates of a location
    }
    //locationManager = nil;
    // self.myLocation = newLocation;
    
//    NSLog(@"User Latitude and longitude are lat:%f lang:%f",newLocation.coordinate.latitude,newLocation.coordinate.longitude);
    //check whether delegate conforms to the protocol or not before calling it.
    if ([mapDelegate conformsToProtocol:@protocol(MapViewDelegate)]  && [mapDelegate respondsToSelector:@selector(didUpdateToLocation:fromLocation:)]) {
        [mapDelegate didUpdateToLocation:newLocation fromLocation:oldLocation];
    }
    TCEND
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
   TCSTART
    if ([error domain] == kCLErrorDomain) {
        if ([mapDelegate conformsToProtocol:@protocol(MapViewDelegate)] && [mapDelegate respondsToSelector:@selector(didFailedToUpdateLocationWithError:)]) {
            [mapDelegate didFailedToUpdateLocationWithError:error];
        }
        [locationManager stopUpdatingLocation];
    }
    TCEND
}

// TODO: We should implement this with a reasonable error message...
// -(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error


-(MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation {
    TCSTART
    
    //check whether the location is user location or different, if it is users location then return nil.
	if ([annotation isKindOfClass:[MKUserLocation class]]) {
//        MKPlacemark
        MKPinAnnotationView *mkPinAnnView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"locationPin"];
        if (!mkPinAnnView) {
            mkPinAnnView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"locationPin"];
        } else {
            mkPinAnnView.annotation = annotation;
        }
        mkPinAnnView.pinColor = MKPinAnnotationColorRed;
        mkPinAnnView.animatesDrop = TRUE;
		return mkPinAnnView;
    }
    /** use MKAnnotationView to customize the annotation pin image.
     */
    
    //create a MKAnnotationview to show a locations image.
	UIButton *rightCallOutAccessoryBtn = nil;
    UIImageView *leftCallOut = nil;
    MKAnnotationView *annView = [mapView dequeueReusableAnnotationViewWithIdentifier:@"shouldreuseThis"];  
    if (!annView) {
        annView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"shouldreuseThis"];
    }
    annView.image = annotationImage;
   // MKPinAnnotationView *mkPinAnnView = nil;
    //mkPinAnnView = (MKPinAnnotationView *) [mapView dequeueReusableAnnotationViewWithIdentifier:@"locationPin"];
   // if (!mkPinAnnView) {
   //     mkPinAnnView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"locationPin"];
  //  } else {
  //      mkPinAnnView.annotation = annotation;
  //  }
//    mkPinAnnView.pinColor = MKPinAnnotationColorRed;
//    NSLog(@"annotation image :%@",annotationImage);
    //annView.image = self.annotationImage;
    //annView.animatesDrop = TRUE;
    annView.canShowCallout = YES;
    annView.calloutOffset = CGPointMake(-5, 5);
    
    //annView.canShowCallout = TRUE;
    
    if (showRightCalloutAccessory) {
        //create a button to display on the right side of the standard callout bubble. we use this generally to move to the next page from that location.
        rightCallOutAccessoryBtn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        //[rightCallOutAccessoryBtn addTarget:self action:@selector(rightCallOutAccessoryTapped:) forControlEvents:UIControlEventTouchUpInside];
       // [btnDetails setTitle:annotation.title forState:UIControlStateNormal];
        annView.rightCalloutAccessoryView = rightCallOutAccessoryBtn;
        //mkPinAnnView.rightCalloutAccessoryView = rightCallOutAccessoryBtn;
    }
    
    if (showLeftCalloutAccessory) {
        //create a custom view in this case its a image view display on the left side of the standard callout bubble.
        leftCallOut = [[UIImageView alloc]init];
        leftCallOut.frame = CGRectMake(0, 0, 30, 30);
        
        if([annotation isMemberOfClass:[LocationAnnotation class]]) {
            [leftCallOut setImageWithURL:[NSURL URLWithString:[((LocationAnnotation*)annotation).location objectForKey:@"imgPath"]] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
        } else {
            [leftCallOut setImage:[UIImage imageNamed:@"default-avatar-business"]];
        }
        annView.leftCalloutAccessoryView = leftCallOut;
        //mkPinAnnView.leftCalloutAccessoryView   = leftCallOut;
    }
    
    if ([annotation isMemberOfClass:[LocationAnnotation class]]) {
        
        if ([((LocationAnnotation*)annotation).location objectForKey:@"locId"]) {
//            NSLog(@"location id is %@",[((LocationAnnotation*)annotation).location objectForKey:@"locId"]);
            rightCallOutAccessoryBtn.titleLabel.text = [((LocationAnnotation*)annotation).location objectForKey:@"locId"];
        }
    }
    return annView;
    //return mkPinAnnView;
    TCEND
}

-(void)rightCallOutAccessoryTapped:(id)sender {
//    if ([mapDelegate conformsToProtocol:@protocol(MapViewDelegate)] && [mapDelegate respondsToSelector:@selector(performRightCalloutAction:)]) {
//        [mapDelegate performRightCalloutAction:sender];
//    }
}

//-(void)lectCallOutAccessoryTapped:(id)sender{
//    if ([mapDelegate conformsToProtocol:@protocol(MapViewDelegate)] && [mapDelegate respondsToSelector:@selector(performLeftCalloutAction:)]) {
//        [mapDelegate performLeftCalloutAction:sender];
//    }
//}
- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control {
    TCSTART
//    NSLog(@"mapdeatiled view");
    if ([mapDelegate conformsToProtocol:@protocol(MapViewDelegate)] && [mapDelegate respondsToSelector:@selector(performRightCalloutAction:)]) {
        [mapDelegate performRightCalloutAction:view.annotation];
    }
    TCEND
}

@end
