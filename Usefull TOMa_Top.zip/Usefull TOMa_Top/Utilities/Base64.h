//
//  Base64.h
//  Base64Encode
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/NSString.h>


@interface Base64 : NSObject {
    
}

+ (NSString *) encodeBase64WithData:(NSData *)data;
//+ (NSData *) base64DataFromString:(NSString *)string;
+ (NSData *)decodeBase64WithString:(NSString *)strBase64;
@end
