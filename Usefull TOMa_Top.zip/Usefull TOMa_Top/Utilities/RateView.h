//
//  RateView.h
//  CustomView
//
//  Created by Ray Wenderlich on 7/30/10.
//  Copyright 2010 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RateView;

@protocol RateViewDelegate
- (void)rateView:(RateView *)rateView ratingDidChange:(float)rating;
@end

@interface RateView : UIView {
    UIImage *_notSelectedImage;
    UIImage *_halfSelectedImage;
    UIImage *_fullSelectedImage;
    float _rating;
    BOOL _editable;
    NSMutableArray *_imageViews;
    int _maxRating;
    int _midMargin;
    int _leftMargin;
    CGSize _minImageSize;
    id <RateViewDelegate> _delegate;
    
    NSMutableDictionary *questionDict;
    int questionIndex;
}

@property (strong,nonatomic) UIImage *notSelectedImage;
@property (strong,nonatomic) UIImage *halfSelectedImage;
@property (strong,nonatomic) UIImage *fullSelectedImage;
@property  (nonatomic) float rating;
@property  BOOL editable;
@property  (nonatomic) int maxRating;
@property (strong, nonatomic) id <RateViewDelegate> delegate;
@property  int leftMargin;
@property (nonatomic, strong) NSMutableDictionary *questionDict;
@property (nonatomic, readwrite) int questionIndex;


@end