@interface NSString (Acani)

- (NSString*) stringByTrimmingLeadingCharactersInSet:(NSCharacterSet *)characterSet;
- (NSString*) stringByTrimmingLeadingWhitespaceAndNewlineCharacters;
- (NSString*) stringByTrimmingTrailingCharactersInSet:(NSCharacterSet *)characterSet;
- (NSString*) stringByTrimmingTrailingWhitespaceAndNewlineCharacters;

- (NSString*) stringFromMD5;
- (NSString*) encodedString;
- (NSString*) decodedString;
- (NSString *) substituteEmoticons;
- (NSString*) decodedStringUTF8 ;
@end
