//
//  ShowAlert.m
//  iPhoneChatterPlug
//
//  Created by Anjali Nennelli on 3/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ShowAlert.h"


@implementation ShowAlert

- (void) showAlert:(NSString *)alertMessage {
	
	//NSLog(@"message: %@",alertMessage);
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message: alertMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
}

- (void) showWarning:(NSString *)alertMessage {
	
	//NSLog(@"message: %@",alertMessage);
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Oops" message: alertMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];	
}

- (void) showError:(NSString *)alertMessage {
	
    if ([alertMessage isKindOfClass:[NSString class]]) {
       // NSLog(@"message: %@",alertMessage);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Oh Dear..." message:alertMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];	

    }
}

@end
