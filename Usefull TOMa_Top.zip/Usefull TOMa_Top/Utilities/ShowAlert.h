//
//  ShowAlert.h
//  iPhoneChatterPlug
//
//  Created by Anjali Nennelli on 3/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ShowAlert : NSObject {
    
    
}

- (void) showAlert:(NSString *)alertMessage;
- (void) showError:(NSString *)alertMessage;
- (void) showWarning:(NSString *)alertMessage;

@end
