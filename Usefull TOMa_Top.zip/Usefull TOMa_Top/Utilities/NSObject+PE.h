//
//  NSObject+PE.h
//  iPhoneChatterPlug
//
//  Created by Josh on 5/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sys/utsname.h>

@interface NSObject (PE)

- (BOOL) isNull:(NSObject*) object;
- (BOOL) isNotNull:(NSObject*) object;
- (NSDate*) dateFromString:(NSString *)dateString;
- (NSString*) stringFromDate:(NSDate*) date;
- (NSString*)deviceModelName;
- (NSString *)randomStringWithLength:(int)length;
@end
