//
//  JXBarChartView.m
//  JXBarChartViewExample
//
//  Created by Jagadeesh .


#import "JXBarChartView.h"

@interface JXBarChartView()
@property (nonatomic) CGContextRef context;
@property (nonatomic, strong) NSMutableArray *textIndicatorsLabels;
@property (nonatomic, strong) NSMutableArray *digitIndicatorsLabels;
@end

@implementation JXBarChartView
@synthesize values = _values;
@synthesize maxValue = _maxValue;
@synthesize textIndicators = _textIndicators;
@synthesize textColor = _textColor;
@synthesize barHeight = _barHeight;
@synthesize barMaxWidth = _barMaxWidth;
@synthesize startPoint = _startPoint;
@synthesize gradient = _gradient;
@synthesize colorArray = _colorArray;


- (id)initWithFrame:(CGRect)frame
         startPoint:(CGPoint)startPoint
             values:(NSMutableArray *)values
           maxValue:(float)maxValue
     textIndicators:(NSMutableArray *)textIndicators
          textColor:(UIColor *)textColor
          barHeight:(float)barHeight
        barMaxWidth:(float)barMaxWidth
           gradient:(CGGradientRef)gradient
      barColorArray:(NSMutableArray *)colorArray
{
    self = [super initWithFrame:frame];
    if (self) {
        _values = values;
        _maxValue = maxValue;
        _textIndicatorsLabels = [[NSMutableArray alloc] initWithCapacity:[values count]];
        _digitIndicatorsLabels = [[NSMutableArray alloc] initWithCapacity:[values count]];
        _textIndicators = textIndicators;
        _startPoint = startPoint;
        _textColor = textColor ? textColor : [UIColor orangeColor];
        _barHeight = barHeight;
        _barMaxWidth = barMaxWidth;
        _colorArray = colorArray;
        if (gradient) {
            _gradient = gradient;
        } else {
            CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
            //blue gradient
            CGFloat locations[] = {0.0, 0.5, 1.0};
            CGFloat colorComponents[] = {
                0.254, 0.599, 0.82, 1.0, //red, green, blue, alpha
                0.192, 0.525, 0.75, 1.0,
                0.096, 0.415, 0.686, 1.0
            };
            size_t count = 3;
            CGGradientRef defaultGradient = CGGradientCreateWithColorComponents(colorSpace, colorComponents, locations, count);
            _gradient = defaultGradient;
            CGColorSpaceRelease(colorSpace);
        }
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)setLabelTextDefaults:(UILabel *)label
{
    label.textColor = self.textColor;
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setFont:[UIFont boldSystemFontOfSize: iPad?15:11]];
    label.backgroundColor = [UIColor clearColor];
}

- (void)setLabelDefaults:(UILabel *)label
{
    label.textColor = self.textColor;
    [label setTextAlignment:NSTextAlignmentLeft];
    label.adjustsFontSizeToFitWidth = YES;
    [label setFont:[UIFont boldSystemFontOfSize: iPad?15:11]];
    label.backgroundColor = [UIColor clearColor];
}

- (void)drawRectangle:(CGRect)rect context:(CGContextRef)context withUIColor:(UIColor*)color
{
    CGContextSaveGState(self.context);
    CGContextAddRect(self.context, rect);
    CGContextClipToRect(self.context, rect);
    CGPoint startPoint = CGPointMake(rect.origin.x, rect.origin.y);
    CGPoint endPoint = CGPointMake(rect.origin.x + rect.size.width, rect.origin.y);
//    CGContextDrawLinearGradient(self.context, self.gradient, startPoint, endPoint, 0);
    UIColor *darkGradientColor = color;
    UIColor *lightGradientColor = color;
//    CGFloat locations[2] = {0.5, 1.0};
    CFArrayRef colors = (__bridge CFArrayRef) [NSArray arrayWithObjects:(id)lightGradientColor.CGColor,(id)darkGradientColor.CGColor,nil];
    CGColorSpaceRef colorSpc = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradientNew = CGGradientCreateWithColors(colorSpc, colors, NULL);
    CGContextDrawLinearGradient(context, gradientNew, startPoint, endPoint, kCGGradientDrawsAfterEndLocation); //Adjust second point according to your view height
    CGContextRestoreGState(self.context);

}

- (void)drawRect:(CGRect)rect
{
    self.context = UIGraphicsGetCurrentContext();
    int count = (int)[self.values count];
    float startx = self.startPoint.x;
    float starty = self.startPoint.y;
    float barMargin = 0.5;
    float marginOfBarAndDigit = 2;
    float marginOfTextAndBar = 8;
    float digitWidth = iPad?80:50;
    float textWidth = iPad?120:90;
    for (int i = 0; i < count; i++) {
        //handle textlabel
        float textMargin_y = (i * (self.barHeight + barMargin)) + starty;
        UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(startx, textMargin_y, textWidth, self.barHeight)];
        textLabel.text = self.textIndicators[i];
        [self setLabelTextDefaults:textLabel];
        @try {
            UILabel *originalTextLabel = self.textIndicatorsLabels[i];
            if (originalTextLabel) {
                [originalTextLabel removeFromSuperview];
            }
        }
        @catch (NSException *exception) {
            [self.textIndicatorsLabels insertObject:textLabel atIndex:i];
        }
        [self addSubview:textLabel];
        
        //handle bar
        float barMargin_y = (i * (self.barHeight + barMargin)) + starty;
        float v = [self.values[i] floatValue] <= self.maxValue ? [self.values[i] floatValue]: self.maxValue;
        float rate = v / self.maxValue;
        float barWidth = rate * self.barMaxWidth;
        CGRect barFrame = CGRectMake(startx + textWidth + marginOfTextAndBar, barMargin_y, barWidth, self.barHeight);
        [self drawRectangle:barFrame context:self.context withUIColor:_colorArray[i]];
        //handle digitlabel
        UILabel *digitLabel = [[UILabel alloc] initWithFrame:CGRectMake(barFrame.origin.x + barFrame.size.width + marginOfBarAndDigit, barFrame.origin.y, digitWidth, barFrame.size.height)];
        //digitLabel.text = [self.values[i] stringValue];
        //digitLabel.text = [NSString stringWithFormat:@"%.f",round([self.values[i] floatValue])];
        
//        if ([self.values[i] floatValue] == (int)[self.values[i] floatValue]) {
//            digitLabel.text = [self.values[i] stringValue];
//        }
//        else {
//            NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
//            [formatter setNumberStyle:NSNumberFormatterNoStyle];
//            [formatter setMaximumFractionDigits:3];
//            //[formatter setRoundingMode: NSNumberFormatterRoundUp];
//            NSString *numberString = [formatter stringFromNumber:self.values[i]];
//            digitLabel.text = numberString;
//        }
        
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
        [formatter setMaximumFractionDigits:0];
        NSString *numberString = [formatter stringFromNumber:[NSNumber numberWithFloat:round([self.values[i] floatValue])]];
        digitLabel.text = numberString;
        
        [self setLabelDefaults:digitLabel];
        @try {
            UILabel *originalDigitLabel = self.digitIndicatorsLabels[i];
            if (originalDigitLabel) {
                [originalDigitLabel removeFromSuperview];
            }
        }
        @catch (NSException *exception) {
            [self.digitIndicatorsLabels insertObject:digitLabel atIndex:i];
        }
        [self addSubview:digitLabel];
    }
}

- (void)setValues:(NSMutableArray *)values
{
    for (int i = 0; i < [values count]; i++) {
        _values[i] = values[i];
    }
    [self setNeedsDisplay];
}

@end
