//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "RedeemService.h"

@interface RedeemSpecialViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,RedeemServiceDelegate> {
    
    NSString *imgUrlStrng;
    CPSpecial *special;
    UITableView *redeemSpecialTable;
    AppDelegate *appDelegate;
    
    NSString *locationId;
    id caller;
    
    BOOL repeatablyRedeemable;

}

- (id)initWithSpecial:(CPSpecial *)specialEvent withImgUrl:(NSString *)imageUrlStrng andLocationId:(NSString *)loc_id FromViewController:(id)viewcontrollerRef canRepeatablyRedeemable:(BOOL)canRepeatablyRedeemable;

@end
