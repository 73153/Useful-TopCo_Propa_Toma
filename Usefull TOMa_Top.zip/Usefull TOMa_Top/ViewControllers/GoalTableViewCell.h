//
//  GoalTableViewCell.h
//  Baldwin
//
//  Created by Jagadeesh J on 10/12/14.
//  Copyright (c) 2014 Spoors. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoalTableViewCell : UITableViewCell <UITextFieldDelegate> {
    
    id __unsafe_unretained delegate;
    UILabel *leftLabel;
    UITextField *rightTextField;
    NSIndexPath *indexPath;
    BOOL hideLeftLabel;
}

@property (nonatomic, assign) id delegate;
@property (nonatomic, retain) UILabel *leftLabel;
@property (nonatomic, retain) UITextField *rightTextField;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic, retain) UIImageView *cellBgView;
//@property (nonatomic, retain) int hideLeftLabel;
@property (nonatomic, readwrite) BOOL hideLeftLabel;

@end

@protocol GoalTextFieldDelegate

-(void)textFieldDidReturnWithIndexPath:(NSIndexPath*)_indexPath;
-(void)updateTextLabelAtIndexPath:(NSIndexPath*)_indexPath string:(NSString*)_string;
-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath;

@end
