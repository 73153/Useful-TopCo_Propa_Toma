//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import <Foundation/Foundation.h>

#import "MapView.h"

@protocol BusinessRewardsServiceDelegate <NSObject>

@required
-(void)didFinishedGettingBusinessRewards:(NSDictionary *)response;
-(void)didFailedTogetBusinessRewards:(NSString *)errorMsg;

@end

@interface BusinessRewardsService : NSObject <CPRankAchievementServiceDelegate,MapViewDelegate> {
    id caller;
    
    NSString *requestURL;
    NSString *auth_token;
    BOOL isRequestForRefresh;
    NSString *latitude;
    NSString *longitude;
    
    NSInteger pageNumber;
    NSInteger perPage;
}

@property(nonatomic,strong)    NSString *requestURL;
@property(nonatomic,strong)    NSString *auth_token;
@property(nonatomic,strong)     NSString *apiKey;
@property (nonatomic, readwrite) BOOL isRequestForRefresh;

-(id)initWithCaller:(id)caller_;
-(void)getGlobalBusinessRewards;

@end