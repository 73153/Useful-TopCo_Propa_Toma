//
//  HealthTrackerViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 18/11/14.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "JXBarChartView.h"
#import "RefreshView.h"
#import "GoalTableViewCell.h"

typedef enum CPGraphDateRange : NSUInteger {
    CPGraphRangeToday,
    CPGraphRangeWeek,
    CPGraphRangeMonth
}CPGraphDateRange;

@interface HealthTrackerViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CPGraphStreamServiceDelegate,UIWebViewDelegate,UITextViewDelegate,GoalTextFieldDelegate,UITextFieldDelegate,UIScrollViewDelegate> {
    AppDelegate *appDelegate;
    NSMutableDictionary *dataDictionary;
    UITableView *fitnessGraphsTableView;
    CPGraphMode graphModeType;
    BOOL isFitBitCheckStatus;
    BOOL isTableContentOffset;
    RefreshView *refreshView;
    BOOL checkForRefresh;
    BOOL reloading;
    UIWebView *userSignUpWebView;
    BOOL isNetworkIndicator;
    NSMutableDictionary *updateGoalTextLabelDictionary;
    UITextField *cellTextFieldRef;
    CPFitbitDailyGoals *dynamicFitbitGoalData;
    CPRunkeeperDailyGoals *dynamicRunkeeprGoalData;
    CGPoint tableOffset;
    NSNumber *userAccount;
}

@property (weak, nonatomic) IBOutlet UILabel *tabbarTitleLabel;
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *fitBitButton;
@property (weak, nonatomic) IBOutlet UIButton *runKeeperButton;
@property (weak, nonatomic) IBOutlet UIView *customTabBar;
@property (weak, nonatomic) IBOutlet UIImageView *customTabImageView;
@property (nonatomic,retain) NSMutableDictionary *dataDictionary;
@property (nonatomic,retain) NSMutableDictionary *compareDataDictionary;
@property (nonatomic,retain) NSMutableArray *rowDataArray;
@property (nonatomic,retain) NSMutableArray *compareRowDataArray;
@property (weak, nonatomic) IBOutlet UIImageView *lineView;
@property (weak, nonatomic) IBOutlet UIButton *todayButton;
@property (weak, nonatomic) IBOutlet UIButton *past7dayButton;
@property (weak, nonatomic) IBOutlet UIButton *past30dayButton;
@property (nonatomic, retain) NSMutableArray *colourArray;
@property (nonatomic, readwrite) CPGraphDateRange graphRangeTypeCheck;
@property (nonatomic, readwrite) CPGraphMode graphModeType;
@property (nonatomic, retain) RefreshView *refreshView;

- (IBAction)popTheViewController:(id)sender;
- (IBAction)fitBitButtonAction:(id)sender;
- (IBAction)runKeeperButtonAction:(id)sender;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
-(float)getMaxNumber:(NSArray*)aArray;
-(UIView *)getCustomProgressiveViewWithGoalPoint:(float)goalPoint withAcheivedPoint:(float)acheivedPoint withColor:(UIColor*)aColor;

- (IBAction)todayButtonAction:(id)sender;
- (IBAction)past7dayButtonAction:(id)sender;
- (IBAction)past30dayButtonAction:(id)sender;


@end
