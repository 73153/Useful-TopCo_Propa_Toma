//
//  ToastView.h
//  Health Demo
//
//  Created by Jagadeesh J on 14/07/14.
//
//

#import <UIKit/UIKit.h>

@interface ToastView : UIView

@property (strong, nonatomic) UILabel *textLabel;
+ (void)showToastInParentView: (UIView *)parentView withText:(NSString *)text withDuaration:(float)duration;

@end
