//
//  LoginViewController.m
//  ChatterPlug
//
//  Created by shiva on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "SignUpViewController.h"

#import "ForgotPasswordViewController.h"
@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        userNameTextField.borderStyle = UITextBorderStyleNone;
        
        // On iOS 4.0+ only, listen for background notification
        if(&UIApplicationWillResignActiveNotification != nil)
        {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
        }
        
        // On iOS 4.0+ only, listen for foreground notification
        if(&UIApplicationWillEnterForegroundNotification != nil)
        {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
        }
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardHideNotification) name:UIKeyboardWillHideNotification object:nil];
    }
    return self;
}


- (void)keyBoardHideNotification {
    if (isViewModeUp) {
        [self setViewMovedUp:NO];
    }
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
   // NSLog(@"applicationWillResignActive from loginview");
//    userNameTextField.text = @"";
//    passWordTextField.text = @"";
    [userNameTextField resignFirstResponder];
    [passWordTextField resignFirstResponder];
    
    if (isViewModeUp) {
        [self setViewMovedUp:NO];
    }
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
  //   NSLog(@"applicationWillEnterForeground in loginview");
    if ([self isNotNull:userNameTextField]) {
        //[userNameTextField becomeFirstResponder];
        //[self setViewMovedUp:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)showUserguideLineView {
    TCSTART
    //Show UserGuideLine View
    if(![[NSUserDefaults standardUserDefaults] objectForKey:@"LaunchStatus"]) {
        NSLog(@"First Launch Check In");
        UserGuideLinesViewController *guideLinesVC;
        if(iPad) {
            guideLinesVC = [[UserGuideLinesViewController alloc] initWithNibName:@"UserGuideLinesViewController" bundle:nil];
        } else {
            guideLinesVC = [[UserGuideLinesViewController alloc] initWithNibName:@"UserGuideLinesViewController~iPhone" bundle:nil];
        }
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:guideLinesVC];
        [self.navigationController presentViewController:navController animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
        }];
        
    }
    TCEND
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    //[[NSNotificationCenter defaultCenter] removeObserver:self];
    [self showUserguideLineView];
    /**
    loginButton.layer.cornerRadius = 5.0f;
    loginButton.layer.masksToBounds = YES;
    
    signUpButton.layer.cornerRadius = 5.0f;
    signUpButton.layer.masksToBounds = YES;
    
    // Do any additional setup after loading the view from its nib.
    userNameTextField.backgroundColor = [UIColor colorWithRed:(44.0f/255.0f) green:(45.0f/255.0f) blue:(47.0f/255.0f) alpha:1.0f];
    userNameTextField.layer.cornerRadius = 5.0f;
    passWordTextField.backgroundColor = [UIColor colorWithRed:(44.0f/255.0f) green:(45.0f/255.0f) blue:(47.0f/255.0f) alpha:1.0f];
    passWordTextField.layer.cornerRadius = 5.0f;
     */

//    headerLabel.textColor = [appDelegate colorWithHexString:@"2977a8"];
    headerLabel.textColor = [UIColor whiteColor];
    headerLabel.font = [UIFont fontWithName:CenturyGothicFont size:LoginTitleFontSize];
    [headerLabel setHidden:YES];
    [userNameTextField setFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize]];
    [passWordTextField setFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize]];
    
    [userNameTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [passWordTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    
    if (!iPad) {
        if (isiPhone6) {
            //Iphone 6 And iPhone 6+ compatibility
            userNameTextField.frame = CGRectMake(userNameTextField.frame.origin.x, appDelegate.window.frame.size.height-208 , appDelegate.window.frame.size.width-2*userNameTextField.frame.origin.x, userNameTextField.frame.size.height);
            passWordTextField.frame = CGRectMake(passWordTextField.frame.origin.x, appDelegate.window.frame.size.height-208+40, appDelegate.window.frame.size.width-2*passWordTextField.frame.origin.x, passWordTextField.frame.size.height);
            forgotPasswordButton.frame = CGRectMake(appDelegate.window.frame.size.width-userNameTextField.frame.origin.x-forgotPasswordButton.frame.size.width, appDelegate.window.frame.size.height-208+82, forgotPasswordButton.frame.size.width, forgotPasswordButton.frame.size.height);
            float buttonSpacing=40.0;
            if(isiPhone6PLUS) buttonSpacing=50.0;
            signUpButton.frame = CGRectMake((appDelegate.window.frame.size.width-268-buttonSpacing)/2, appDelegate.window.frame.size.height-208+88+34, signUpButton.frame.size.width, signUpButton.frame.size.height);
            loginButton.frame = CGRectMake(signUpButton.frame.size.width+signUpButton.frame.origin.x+buttonSpacing, appDelegate.window.frame.size.height-208+88+34,loginButton.frame.size.width, loginButton.frame.size.height);
        }
        else if (appDelegate.window.frame.size.height > 480) {
//            backgroundImageView.image = [UIImage imageNamed:@"loginbgiPhone5"];
            userNameTextField.frame = CGRectMake(userNameTextField.frame.origin.x, 380-10, userNameTextField.frame.size.width, userNameTextField.frame.size.height);
            passWordTextField.frame = CGRectMake(passWordTextField.frame.origin.x, 420-10, passWordTextField.frame.size.width, passWordTextField.frame.size.height);
            forgotPasswordButton.frame = CGRectMake(forgotPasswordButton.frame.origin.x, 458-10, forgotPasswordButton.frame.size.width, forgotPasswordButton.frame.size.height);
            signUpButton.frame = CGRectMake(signUpButton.frame.origin.x, 492-10, signUpButton.frame.size.width, signUpButton.frame.size.height);
            loginButton.frame = CGRectMake(loginButton.frame.origin.x, 492-10,loginButton.frame.size.width, loginButton.frame.size.height);
        } else {
            backgroundImageView.image = [UIImage imageNamed:@"login_chatterplug_blue"];
            if (!(CURRENT_DEVICE_VERSION >= 7.0))
            {
                userNameTextField.frame = CGRectMake(userNameTextField.frame.origin.x, userNameTextField.frame.origin.y-3, userNameTextField.frame.size.width, userNameTextField.frame.size.height);
                passWordTextField.frame = CGRectMake(passWordTextField.frame.origin.x, passWordTextField.frame.origin.y-3, passWordTextField.frame.size.width, passWordTextField.frame.size.height);
                forgotPasswordButton.frame = CGRectMake(forgotPasswordButton.frame.origin.x, forgotPasswordButton.frame.origin.y-3, forgotPasswordButton.frame.size.width, forgotPasswordButton.frame.size.height);
                signUpButton.frame = CGRectMake(signUpButton.frame.origin.x, signUpButton.frame.origin.y-3, signUpButton.frame.size.width, signUpButton.frame.size.height);
                loginButton.frame = CGRectMake(loginButton.frame.origin.x, loginButton.frame.origin.y-3,loginButton.frame.size.width, loginButton.frame.size.height);
            }
                
        }
    }
    TCEND
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    UIView *userNamepaddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    userNameTextField.leftView = userNamepaddingView;
    userNameTextField.leftViewMode = UITextFieldViewModeAlways;
	
    UIView *passWordpaddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    passWordTextField.leftView = passWordpaddingView;
    passWordTextField.leftViewMode = UITextFieldViewModeAlways;
    
    //vivek
//   userNameTextField.text=@"neel@zaptechsolutions.com";
//   passWordTextField.text = @"zaptech123";
//    userNameTextField.text=@"vivek@zaptechsolutions.com";
//    passWordTextField.text = @"123456789";
    TCEND
}

- (void)viewDidAppear:(BOOL)animated {

}


- (IBAction)btnForgotPasswordTouched:(id)sender {
    @try {
        [userNameTextField resignFirstResponder];
        [passWordTextField resignFirstResponder];
        ForgotPasswordViewController *forgotPWDVC = nil;
//        if ([self isNull:forgotPWDVC]) {
            if (iPad) {
                forgotPWDVC = [[ForgotPasswordViewController alloc]initWithNibName:@"ForgotPasswordViewController" bundle:nil];
            } else {
                forgotPWDVC = [[ForgotPasswordViewController alloc]initWithNibName:@"ForgotPasswordViewController~iPhone" bundle:nil];
            }
//        }
        [self.navigationController pushViewController:forgotPWDVC animated:YES];
        forgotPWDVC.emailAddress = userNameTextField.text;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(IBAction)btnLogInTouched:(id)sender {
    
    @try {
        //compare username & pwds before POSTING request
        if ([self validateInput] ) {
            NSString *lowerCaseUserName=[userNameTextField.text lowercaseString];
            [appDelegate loginUser:lowerCaseUserName password:passWordTextField.text];
        }	
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}


-(IBAction)btnSignUpTouched:(id)sender {
    
    @try {
        [userNameTextField resignFirstResponder];
        [passWordTextField resignFirstResponder];
        SignUpViewController *signUpVC = nil;
//        if ([self isNull:signUpVC]) {
            if (iPad) {
                signUpVC = [[SignUpViewController alloc]initWithNibName:@"SignUpViewController" bundle:nil];
            } else {
                signUpVC = [[SignUpViewController alloc]initWithNibName:@"SignUpViewController~iPhone" bundle:nil];
            }
//        }
        [self.navigationController pushViewController:signUpVC animated:YES];
        [signUpVC setEmailAndPasswordInRegDictEmailAddress:userNameTextField.text password:passWordTextField.text];
    }
    @catch (NSException *exception) {
          NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(BOOL) validateInput {
    
    @try {
        // email field
        if ([self isNotNull:userNameTextField] && ![appDelegate validateEmailWithString:userNameTextField.text]) {
            [appDelegate showErrorMsg:@"Please enter valid email address."];
            [userNameTextField becomeFirstResponder];
            return FALSE;
        }
        //password field
        if (passWordTextField.text.length < 8) {
            [appDelegate showErrorMsg:@"Please enter a valid password of 8 characters or more."];
            [passWordTextField becomeFirstResponder];
            return FALSE;
        }
        return TRUE;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma mark -
#pragma mark UITextFieldDelegate Methods

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
	
    return TRUE;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    @try {
        if ([textField isEqual:userNameTextField] || [textField isEqual:passWordTextField])
        {
            //move the main view, so that the keyboard does not hide it.
            if  (self.view.frame.origin.y >= 0)
            {
                if (!isViewModeUp) {
                    [self setViewMovedUp:YES];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
    @try {
        if(textField.tag < 1) {
            switch (textField.tag) {
                case 0:
                    [passWordTextField becomeFirstResponder];
                    return YES;
                default:
                    break;
            }
        }
        
        if (textField.tag == 1) {
            if (isViewModeUp) {
                [self setViewMovedUp:NO];
            }
        }
        
        [textField resignFirstResponder];
        
        return TRUE;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)setViewMovedUp:(BOOL)movedUp {
  
    @try {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.5]; // if you want to slide up the view
        
        CGRect viewRect = self.view.frame;
        CGRect bgImageViewRect = backgroundImageView.frame;
        if (movedUp) {
            isViewModeUp = YES;
                // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
                // 2. increase the size of the view so that the area behind the keyboard is covered up.
                //bgImageViewRect.size.height -= kOFFSET_FOR_KEYBOARD;
                //bgImageViewRect.origin.y  += 75;
                // bgImageViewRect.size.height -= 10;
            viewRect.origin.y -= /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
            viewRect.size.height += /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
        }
        else
            {
            isViewModeUp = NO;
                // revert back to the normal state.
                // bgImageViewRect.size.height += kOFFSET_FOR_KEYBOARD;
                //bgImageViewRect.origin.y  -= 75;
                // bgImageViewRect.size.height += 10;
            
            viewRect.origin.y += /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
            viewRect.size.height -= /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
            }
        self.view.frame = viewRect;
        backgroundImageView.frame = bgImageViewRect;

        [UIView commitAnimations];

    }
    @catch (NSException *exception) {
          NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
