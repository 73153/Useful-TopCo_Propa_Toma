//
//  SignUpViewController.h
//  ChatterPlug
//
//  Created by shiva on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegistrationCell.h"
@class AppDelegate;


@interface SignUpViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,UIActionSheetDelegate,RegistrationTextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource> {

    UITableView *registrationTableView;
    /** appDelegate is a AppDelegate instance which is a controller for the app. Required to get the more comments(Plugs & Replies).
     */
    AppDelegate *appDelegate;
    
    UIView *pickerViewDateView;
    UIActionSheet *pickerViewDateActionSheet;
    UIDatePicker *datePicker;
    
    NSMutableDictionary *regDict;
    NSArray *placeHoldersArray;
    
    UITextField *cellTextFieldRef;
    
    IBOutlet UILabel *signUpLabel;
    
    __weak IBOutlet UILabel *headerLabel;
    
        // UI PICKER VIEW
    UIView  *statesView;
    UIPickerView *statesPickerView;
    UIToolbar *statesToolBar;
    NSArray *usStatesArray;
    
}
- (void)setEmailAndPasswordInRegDictEmailAddress:(NSString *)emailAddress password:(NSString *)password;
/** pops the sign up page to login view controller page.
 */
-(IBAction)btnCancelTouched:(id)sender;

/** calls appDelegate signup request method by passing fullname,email address & password fields.
 */
-(IBAction)btnSignUpTouched:(id)sender;

/** validates the user entered email/username and password fields with the following conditions and sends True/False
 1.Checks whether full name is null or not.
 2.Checks for password minimum characters limit-8.
 3.Checks email adress is valid or not.
 */
- (BOOL)validateInputWithIncludePatientId:(BOOL)includePatientId;

- (void)selectedSecurityQuestion:(NSString *)question;

@end
