//
//  VerifySecurityQuestionViewController.h
//  Memorial
//
//  Created by Aruna on 19/09/13.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface VerifySecurityQuestionViewController : UIViewController<UITextFieldDelegate> {
    IBOutlet UILabel *questionLabel;
    IBOutlet UITextField *answerTextField;
    IBOutlet UILabel *titleLabel;
    AppDelegate *appDelegate;
    NSString *securityQue;
    id caller;
}
@property (weak, nonatomic) IBOutlet UIButton *okButton;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andQuestion:(NSString *)question andCaller:(id)callbackObj;
- (IBAction)onClickOfOkButton:(id)sender;
- (IBAction)onClickOfCancelButton:(id)sender;
@end
