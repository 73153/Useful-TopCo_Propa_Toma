//
//  SessionOutLoginViewController.m
//  Health Demo
//
//  Created by Jagadeesh J on 13/08/14.
//
//

#import "SessionOutLoginViewController.h"

@interface SessionOutLoginViewController ()

@end

@implementation SessionOutLoginViewController
@synthesize userName,signInButton,signInAsAnotherButton,passwordTextBox,userNameTextField;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        // On iOS 4.0+ only, listen for background notification
        if(&UIApplicationWillResignActiveNotification != nil)
        {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
        }
        
        // On iOS 4.0+ only, listen for foreground notification
        if(&UIApplicationWillEnterForegroundNotification != nil)
        {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
        }
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardHideNotification) name:UIKeyboardWillHideNotification object:nil];
    }
    return self;
}

- (void)keyBoardHideNotification {
    if (isViewModeUp) {
        [self setViewMovedUp:NO];
    }
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
    // NSLog(@"applicationWillResignActive from loginview");
    //    userNameTextField.text = @"";
    //    passWordTextField.text = @"";
    [userNameTextField resignFirstResponder];
    [passwordTextBox resignFirstResponder];
    
    if (isViewModeUp) {
        [self setViewMovedUp:NO];
    }
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
    //   NSLog(@"applicationWillEnterForeground in loginview");
    
}
- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    //[[NSNotificationCenter defaultCenter] removeObserver:self];
    [userNameTextField setFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize]];
    [passwordTextBox setFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize]];
    // Do any additional setup after loading the view from its nib.
    [userNameTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [passwordTextBox setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    
    [signInButton addTarget:self action:@selector(signInButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    [signInAsAnotherButton addTarget:self action:@selector(signInAsAnotherButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    NSString *encryptedUserName=@"";
    if(userName.length > 4)
    {
        encryptedUserName=[userName substringToIndex:4];
        for(int tempVar=1; tempVar <= userName.length-4 ; tempVar++ )
        {
            encryptedUserName=[encryptedUserName stringByAppendingString:@"*"];
        }
    }
    else
    {
        encryptedUserName=userName;
    }
    userNameTextField.text = encryptedUserName;
    
    if (!iPad) {
        if (isiPhone6) {
            //Iphone 6 And iPhone 6+ compatibility
            backgroundImageView.image = [UIImage imageNamed:@"login_chatterplug_blue"];
            sessionTimeoutInfo.frame = CGRectMake(sessionTimeoutInfo.frame.origin.x, appDelegate.window.frame.size.height-208, appDelegate.window.frame.size.width-2*sessionTimeoutInfo.frame.origin.x, sessionTimeoutInfo.frame.size.height);
            userNameTextField.frame = CGRectMake(userNameTextField.frame.origin.x, appDelegate.window.frame.size.height-208+25, appDelegate.window.frame.size.width-2*userNameTextField.frame.origin.x, userNameTextField.frame.size.height);
            passwordTextBox.frame = CGRectMake(passwordTextBox.frame.origin.x, appDelegate.window.frame.size.height-208+60, appDelegate.window.frame.size.width-2*passwordTextBox.frame.origin.x, passwordTextBox.frame.size.height);
            signInAsAnotherButton.frame = CGRectMake(signInAsAnotherButton.frame.origin.x, appDelegate.window.frame.size.height-208+60+62, (appDelegate.window.frame.size.width-60)/2, signInAsAnotherButton.frame.size.height);
            signInButton.frame = CGRectMake(signInAsAnotherButton.frame.size.width+40, appDelegate.window.frame.size.height-208+60+62,(appDelegate.window.frame.size.width-60)/2, signInButton.frame.size.height);
        }
        else if (appDelegate.window.frame.size.height > 480) {
            backgroundImageView.image = [UIImage imageNamed:@"login_chatterplug_blue"];
            sessionTimeoutInfo.frame = CGRectMake(sessionTimeoutInfo.frame.origin.x, 370, sessionTimeoutInfo.frame.size.width, sessionTimeoutInfo.frame.size.height);
            userNameTextField.frame = CGRectMake(userNameTextField.frame.origin.x, 395, userNameTextField.frame.size.width, userNameTextField.frame.size.height);
            passwordTextBox.frame = CGRectMake(passwordTextBox.frame.origin.x, 430, passwordTextBox.frame.size.width, passwordTextBox.frame.size.height);
            signInAsAnotherButton.frame = CGRectMake(signInAsAnotherButton.frame.origin.x, 492, signInAsAnotherButton.frame.size.width, signInAsAnotherButton.frame.size.height);
            signInButton.frame = CGRectMake(signInButton.frame.origin.x, 492,signInButton.frame.size.width, signInButton.frame.size.height);
        } else {
            backgroundImageView.image = [UIImage imageNamed:@"login_chatterplug_blue"];
        }
    }
    TCEND
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
    }
}


- (void)viewWillAppear:(BOOL)animated {
    TCSTART

    UIView *passWordpaddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    passwordTextBox.leftView = passWordpaddingView;
    passwordTextBox.leftViewMode = UITextFieldViewModeAlways;
    TCEND
}
-(void)signInButtonAction
{
    NSLog(@"Sign In Called.");
    
    @try {
        //compare username & pwds before POSTING request
        if ([self validateInput] ) {
            
            [appDelegate loginUser:userName password:passwordTextBox.text];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(BOOL) validateInput {
    
    @try {
        // email field
//        if ([self isNotNull:userName] && ![appDelegate validateEmailWithString:userName]) {
//            [appDelegate showErrorMsg:@"Please enter valid email address."];
//            return FALSE;
//        }
        //password field
        if (passwordTextBox.text.length < 8) {
            [appDelegate showErrorMsg:@"Please enter a valid password of 8 characters or more."];
            [passwordTextBox becomeFirstResponder];
            return FALSE;
        }
        return TRUE;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)signInAsAnotherButtonAction
{
    NSLog(@"Sign In As another Called");
    @try {
        [appDelegate createAndSetLogingViewControllerToWindow];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark -
#pragma mark UITextFieldDelegate Methods

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
	if (textField.tag == 0) {
        return FALSE;
    }
    return TRUE;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    @try {
        if ([textField isEqual:passwordTextBox])
        {
            //move the main view, so that the keyboard does not hide it.
            if  (self.view.frame.origin.y >= 0) {
                if (!isViewModeUp) {
                    [self setViewMovedUp:YES];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
    @try {
        if(textField.tag < 1) {
            switch (textField.tag) {
                case 0:
                    [passwordTextBox becomeFirstResponder];
                    return YES;
                default:
                    break;
            }
        }
        
        if (textField.tag == 1) {
            if (isViewModeUp) {
                [self setViewMovedUp:NO];
            }
        }
        
        [textField resignFirstResponder];
        
        return TRUE;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)setViewMovedUp:(BOOL)movedUp {
    
    @try {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.5]; // if you want to slide up the view
        
        CGRect viewRect = self.view.frame;
        CGRect bgImageViewRect = backgroundImageView.frame;
        if (movedUp) {
            isViewModeUp = YES;
            // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
            // 2. increase the size of the view so that the area behind the keyboard is covered up.
            //bgImageViewRect.size.height -= kOFFSET_FOR_KEYBOARD;
            //bgImageViewRect.origin.y  += 75;
            // bgImageViewRect.size.height -= 10;
            viewRect.origin.y -= /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
            viewRect.size.height += /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
        }
        else
        {
            isViewModeUp = NO;
            // revert back to the normal state.
            // bgImageViewRect.size.height += kOFFSET_FOR_KEYBOARD;
            //bgImageViewRect.origin.y  -= 75;
            // bgImageViewRect.size.height += 10;
            
            viewRect.origin.y += /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
            viewRect.size.height -= /*(appDelegate.window.frame.size.height > 480) ?kOFFSET_FOR_KEYBOARDiPhone : */kOFFSET_FOR_KEYBOARD;
        }
        self.view.frame = viewRect;
        backgroundImageView.frame = bgImageViewRect;
        
        [UIView commitAnimations];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
