//
//  SessionOutLoginViewController.h
//  Health Demo
//
//  Created by Jagadeesh J on 13/08/14.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface SessionOutLoginViewController : UIViewController < UITextFieldDelegate>
{
    AppDelegate *appDelegate;
    NSString *userName;
    
    IBOutlet UIImageView *backgroundImageView;
    IBOutlet UILabel *sessionTimeoutInfo;
    
    /** set to YES when view goes up and NO when view is down.
     */
    BOOL isViewModeUp;
}
@property (weak, nonatomic) IBOutlet UITextField *userNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextBox;
@property (weak, nonatomic) IBOutlet UIButton *signInButton;
@property (weak, nonatomic) IBOutlet UIButton *signInAsAnotherButton;
@property (nonatomic,retain) NSString *userName;


@end
