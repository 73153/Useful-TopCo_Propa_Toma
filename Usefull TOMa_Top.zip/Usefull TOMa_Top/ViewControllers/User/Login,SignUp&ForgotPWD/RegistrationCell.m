//
//  RegistrationCell.m
//  MemorialHealthSystem
//
//  Created by Aruna on 15/06/13.
//
//

#import "RegistrationCell.h"

@implementation RegistrationCell
@synthesize delegate;
@synthesize cellTextField;
@synthesize indexPath;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    @try {
        if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
            
            cellTextField = [[UITextField alloc] initWithFrame:CGRectZero];
            cellTextField.borderStyle = UITextBorderStyleNone;
            cellTextField.backgroundColor = [UIColor clearColor];
            cellTextField.background = [UIImage imageNamed:@"login_textfield_550x67"];
            cellTextField.clearsOnBeginEditing = NO;
            cellTextField.autocorrectionType = UITextAutocorrectionTypeNo;
            [cellTextField setDelegate:self];
            [cellTextField setFont:[UIFont fontWithName:titleFontName size:titleFontSize]];
            cellTextField.textColor = [UIColor whiteColor];
            UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
            cellTextField.leftView = paddingView;
            cellTextField.leftViewMode = UITextFieldViewModeAlways;
            [cellTextField setReturnKeyType:UIReturnKeyNext];
            cellTextField.keyboardType = UIKeyboardTypeDefault;
            cellTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
            [self addSubview:cellTextField];
        }
        self.backgroundColor = [UIColor clearColor];
        self.backgroundView = nil;
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//Layout our fields in case of a layoutchange (fix for iPad doing strange things with margins if width is > 400)
- (void)layoutSubviews {
    
    @try {
        [super layoutSubviews];
        CGRect origFrame = self.contentView.frame;
       
        if (iPad) {
            cellTextField.frame = CGRectMake(origFrame.origin.x+10, 7.5, 648, 45);
        } else {
            cellTextField.frame = CGRectMake(origFrame.origin.x+10, 7.5, [[UIScreen mainScreen] bounds].size.width-40, 35);
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
}

- (BOOL) textFieldShouldBeginEditing:(UITextField *)textField {
	
    @try {

        return TRUE;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    @try {
        if([delegate respondsToSelector:@selector(textFielddidBeginEditingWithField:andIndexPath:)]) {
            
            [delegate performSelector:@selector(textFielddidBeginEditingWithField:andIndexPath:) withObject:textField withObject:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
    @try {
        if([delegate respondsToSelector:@selector(textFieldDidReturnWithIndexPath:)]) {
            
            [delegate performSelector:@selector(textFieldDidReturnWithIndexPath:) withObject:indexPath];
        }
        
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    @try {
        NSString *textString = self.cellTextField.text;
//        if (indexPath.row == 5) {
//            NSRegularExpression *numbersOnly = [NSRegularExpression regularExpressionWithPattern:@"[0-9]+" options:NSRegularExpressionCaseInsensitive error:nil];
//            NSInteger numberOfMatches = [numbersOnly numberOfMatchesInString:string options:0 range:NSMakeRange(0, string.length)];
//            if (numberOfMatches != 1 && string.length != 0) {
//                return NO;
//            }
//        }
//        NSLog(@"TextString:%@",textString);
        if (range.length > 0) {
            textString = [textString stringByReplacingCharactersInRange:range withString:@""];
        } else {
            if(range.location == [textString length]) {
                textString = [textString stringByAppendingString:string];
            } else {
                textString = [textString stringByReplacingCharactersInRange:range withString:string];
            }
        }
//        NSLog(@"TextString:%@",textString);
        if([delegate respondsToSelector:@selector(updateTextLabelAtIndexPath:string:)]) {
            [delegate performSelector:@selector(updateTextLabelAtIndexPath:string:) withObject:indexPath withObject:textString];
        }
        
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    if (action == @selector(paste:) || action == @selector(copy:) || action == @selector(cut:)) {
        //        return [super canPerformAction:action withSender:sender];
    }
    return NO;
}
- (void)dealloc {
    //
    //	[leftLabel release];
    //	[rightTextField release];
    //	[indexPath release];
    //    [super dealloc];
}

@end
