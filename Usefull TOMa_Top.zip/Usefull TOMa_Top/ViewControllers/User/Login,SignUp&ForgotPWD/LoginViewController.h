//
//  LoginViewController.h
//  ChatterPlug
//
//  Created by shiva on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignUpViewController.h"
#import "ForgotPasswordViewController.h"
#import "UserGuideLinesViewController.h"

@class AppDelegate;

@interface LoginViewController : UIViewController <UITextFieldDelegate> {
    
    /** loginButton is an instance of UIButton created through Interface Builder and linked using FilesOwner in IB.
     On touchUpInside login action triggers
     */
    IBOutlet UIButton *loginButton;
    
    /** signUpButton is an instance of UIButton created through Interface Builder and linked using FilesOwner in IB.
     On touchUpInside sign-up action triggers, and loads the sign-up page.
     */
    IBOutlet UIButton *signUpButton;
    
    /** forgotPasswordButton is an instance of UIButton created through Interface Builder and linked using FilesOwner in IB.
     On touchUpInside forgotPassword action triggers.
     */
    IBOutlet UIButton *forgotPasswordButton;
    
    /** userNameTextField is an instance of UITextField created through Interface Builder and linked using FilesOwner in IB. Have given the background image "textfield.png" and made the bacground color to clear color, keyboard return type is set to "Next".
     On selection keyboard appears and also moves the view up the keyboard along with texfields and other UIcomponents in the login screen. And editing can be identified through UITextFieldDelegate methods.
     */
    IBOutlet UITextField *userNameTextField;
    
    /** passWordTextField is an instance of UITextField created through Interface Builder and linked using FilesOwner in IB. Have given the background image "textfield.png" and made the bacground color to clear color, keyboard return type is set to "Done" and also enabled secure texting.
     On selection keyboard appears and also moves the view up the keyboard along with texfields and other UIcomponents in the login screen. And editing can be identified through UITextFieldDelegate methods.
     */
    IBOutlet UITextField *passWordTextField;
    
    /** backgroundImageView is an instance of UIImageView created through interface builder and linked using filesowner in IB. This is used to set the background image LoginBG.png to login screen.
     */
    IBOutlet UIImageView *backgroundImageView;
    
    /** appDelegate is a AppDelegate instance which is a controller for the app. Required to get the more comments(Plugs & Replies).
     */
    AppDelegate *appDelegate;
    
    /** set to YES when view goes up and NO when view is down.
     */
    BOOL isViewModeUp;
 
    IBOutlet UILabel *headerLabel;
    
}

/** pushed to forgotpassword screen from login viewcontroller
 */
-(IBAction)btnForgotPasswordTouched:(id)sender;

/** validates the username/emial and password text and call the loginuser method which is in AppDelegate.
 */
-(IBAction)btnLogInTouched:(id)sender;

/** pushed to sign-up page to register the user 
 */
-(IBAction)btnSignUpTouched:(id)sender;


/** validates the user entered email/username and password fields with the following conditions and sends True/False
 1.Checks whether user entered any character or not.
 2.Checks for password minimum characters limit-8.
 */
-(BOOL) validateInput;

/** 
 1. moves the view's origin up so that the text field that will be hidden come above the keyboard 
 2. increases the size of the view so that the area behind the keyboard is covered up.
 */
-(void)setViewMovedUp:(BOOL)movedUp;
@end
