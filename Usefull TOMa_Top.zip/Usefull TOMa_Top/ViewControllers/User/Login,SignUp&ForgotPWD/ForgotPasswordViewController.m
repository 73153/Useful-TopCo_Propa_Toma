//
//  ForgotPasswordViewController.m
//  ChatterPlug
//
//  Created by shiva on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ForgotPasswordViewController.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "VerifySecurityQuestionViewController.h"
@interface ForgotPasswordViewController () {
    VerifySecurityQuestionViewController *verifyVC;
}

@end
@implementation ForgotPasswordViewController
@synthesize emailAddress;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        // Do any additional setup after loading the view from its nib.
        [emailAddressTextField becomeFirstResponder];
        UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
        emailAddressTextField.leftView = paddingView;
        emailAddressTextField.leftViewMode = UITextFieldViewModeAlways;
        [emailAddressTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
        emailAddressTextField.text = emailAddress;
        if(isiPhone6){
            [headerLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-headerLabel.frame.size.width)/2,headerLabel.frame.origin.y, headerLabel.frame.size.width, headerLabel.frame.size.height)];
            [emailAddressTextField setFrame:CGRectMake((appDelegate.window.frame.size.width-emailAddressTextField.frame.size.width)/2,emailAddressTextField.frame.origin.y, emailAddressTextField.frame.size.width, emailAddressTextField.frame.size.height)];
            [emailNewPasswordButton setFrame:CGRectMake((appDelegate.window.frame.size.width-emailNewPasswordButton.frame.size.width)/2,emailNewPasswordButton.frame.origin.y, emailNewPasswordButton.frame.size.width, emailNewPasswordButton.frame.size.height)];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(IBAction)popToLoginScreen:(id)sender {
    
    @try {
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(IBAction)emailNewPassword:(id)sender {
    
    @try {
        if ([appDelegate validateEmailWithString:emailAddressTextField.text] ) {
            NSString *lowerCaseUserName=[emailAddressTextField.text lowercaseString];
            [appDelegate sendNewPasswordToEmail:lowerCaseUserName fromViewController:self];
        } else {
            [appDelegate showErrorMsg:@"Please enter valid email address."];
            [emailAddressTextField becomeFirstResponder];
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)didFinishedMailingNewPassword:(NSDictionary *)result {
    
    @try {
//        
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        if ([self isNotNull:result] && [self isNotNull:[result objectForKey:@"success"]] && [[result objectForKey:@"success"] boolValue]) {
            [appDelegate showSuccessMsg:@"Password sent successfully to your email"];
            [self.navigationController popViewControllerAnimated:YES];
        } else if ([self isNotNull:result] && [self isNotNull:[result objectForKey:@"security_question"]]) {
            if (iPad) {
//                [appDelegate showSuccessMsg:@"Password sent successfully to your email"];
//                [self.navigationController popViewControllerAnimated:YES];
                verifyVC = [[VerifySecurityQuestionViewController alloc] initWithNibName:@"VerifySecurityQuestionViewController" bundle:nil andQuestion:[result objectForKey:@"security_question"] andCaller:self];
                [self.view addSubview:verifyVC.view];
            } else {
                verifyVC = [[VerifySecurityQuestionViewController alloc] initWithNibName:@"VerifySecurityQuestionViewController~iPhone" bundle:nil andQuestion:[result objectForKey:@"security_question"] andCaller:self];
                //[self.navigationController pushViewController:verifyVC animated:YES];
                [self.view addSubview:verifyVC.view];
            }
             
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)didfailedToMailNewPassword:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        if ([errorMsg rangeOfString:@"Email not found" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            [appDelegate showErrorMsg:@"The email you entered is not associated with a user account. Please try again."];
        } else {
            [appDelegate showErrorMsg:errorMsg];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
//    The email you entered is not associated with a user account. Please try again.
}

- (void)enteredSecurityAnswer:(NSDictionary *)securityQueNAnswerDict {
    TCSTART
    if ([self isNotNull:[securityQueNAnswerDict objectForKey:@"answer"]]) {
        NSString *lowerCaseUserName=[emailAddressTextField.text lowercaseString];
        [appDelegate verifySecurityQuestionWithAnswer:[securityQueNAnswerDict objectForKey:@"answer"] toEmailId:lowerCaseUserName fromViewController:self];
    }
    TCEND
}

- (void)didVerifySecurityQuestionAnswer {
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate showSuccessMsg:@"Password sent successfully to your email"];
    [verifyVC.view removeFromSuperview];
    verifyVC = nil;
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didFailedToVerifySecurityQuestionAnswerWithError:(NSString *)errorMsg {
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    NSMutableString *string = [[NSMutableString alloc] initWithString:errorMsg];
    if ([string hasPrefix:@"(\n"]) {
        [string replaceOccurrencesOfString:@"(\n" withString:@"" options:NSCaseInsensitiveSearch range:[string rangeOfString:@"(\n"]];
    }
    if ([string hasSuffix:@"\n)\n "]) {
        [string replaceOccurrencesOfString:@"\n)\n " withString:@"" options:NSCaseInsensitiveSearch range:[string rangeOfString:@"\n)\n "]];
    }
    [appDelegate showErrorMsg:string];
}

#pragma mark -
#pragma mark UITextFieldDelegate Methods

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField{
	
    return TRUE;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
	[textField resignFirstResponder];
    
	return TRUE;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
