//
//  SignUpViewController.m
//  ChatterPlug
//
//  Created by shiva on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SignUpViewController.h"
#import "AppDelegate.h"
#import "RegistrationCell.h"
#import "SecurityQuestionsViewController.h"
#import "ChatterPlugViewController.h"

@implementation SignUpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        regDict = [[NSMutableDictionary alloc] init];
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}



- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
        
        placeHoldersArray = [[NSArray alloc] initWithObjects:@"Full Name",@"Email Address",@"Password",@"Address",@"Zip code",@"Birthdate",@"Phone Number",@"Security Question",@"Security Answer", nil];
        usStatesArray= [[NSArray alloc] initWithObjects:@"AL",@"AK", @"AZ",@"AR",@"CA",@"CO",@"CT",@"DE",@"FL",@"GA",@"HI",@"ID",@"IL",@"IN",@"IA",@"KS",@"KY",@"LA",@"ME",@"MD",@"MA",@"MI",@"MN",@"MS",@"MO",@"MT",@"NE",@"NV",@"NH",@"NJ",@"NM",@"NY",@"NC",@"ND",@"OH",@"OK",@"OR",@"PA",@"RI",@"SC",@"SD",@"TN",@"TX",@"UT",@"VT",@"VA",@"WA",@"WV",@"WI",@"WY", nil];
        
        signUpLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        signUpLabel.text = @"SIGN UP";
        
        CGFloat tableOriginY;
        CGFloat tableOriginX;
        CGFloat tableFooterViewHeight;
        //CGRect noIDEmailMeMyIdRect;
        CGRect signUpButtonRect;
        if (iPad) {
            tableFooterViewHeight = 110;
            //noIDEmailMeMyIdRect = CGRectMake(55, 40, 314, 60);
            signUpButtonRect = CGRectMake(55, 40, 728, 60);
            tableOriginY = 83;
        } else {
            tableFooterViewHeight = 100;
            //noIDEmailMeMyIdRect = CGRectMake(20, 40, 134, 50);
            signUpButtonRect = CGRectMake(20, 40, 150, 50);
            tableOriginY = 50;
        }
        if (CURRENT_DEVICE_VERSION < 7.0) {
            tableOriginX = 0;
        } else {
            if (iPad) {
                tableOriginX = 55;
                // noIDEmailMeMyIdRect = CGRectMake(10, 40, 314, 60);
                signUpButtonRect = CGRectMake(self.view.frame.size.width/4-20, 40, 728/2, 60);
            } else {
                tableOriginX = 10;
                //noIDEmailMeMyIdRect = CGRectMake(10, 40, 134, 50);
                signUpButtonRect = CGRectMake((self.view.frame.size.width/2)-75, 40, 150, 50);
            }
        }
        NSLog(@"WIDTH: %f, HEIGHT: %f",appDelegate.window.frame.size.width,self.view.frame.size.height);
        
        CGFloat windowWidth;
        if(isiPhone6) {
            [headerLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-headerLabel.frame.size.width)/2, headerLabel.frame.origin.y, headerLabel.frame.size.width, headerLabel.frame.size.height)];
            windowWidth=appDelegate.window.frame.size.width;
        } else { windowWidth=self.view.frame.size.width; }
        
        registrationTableView = [[UITableView alloc] initWithFrame:CGRectMake(tableOriginX, tableOriginY, windowWidth - (2 * tableOriginX),self.view.frame.size.height - tableOriginY ) style:UITableViewStyleGrouped];
        registrationTableView.bounces=true;
        registrationTableView.delegate = self;
        registrationTableView.dataSource = self;
        registrationTableView.showsVerticalScrollIndicator = YES;
        [self.view addSubview:registrationTableView];
        registrationTableView.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
        registrationTableView.backgroundView.backgroundColor = [UIColor clearColor];
        registrationTableView.backgroundColor = [UIColor clearColor];
        registrationTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        registrationTableView.separatorColor = [UIColor clearColor];
        
        UIView *tableFooter_View = [[UIView alloc]initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, tableFooterViewHeight)];
        registrationTableView.tableFooterView = tableFooter_View;
        
        //        UIButton *noIDEmailMeMyId = [UIButton buttonWithType:UIButtonTypeCustom];
        //        [noIDEmailMeMyId setBackgroundImage:[UIImage imageNamed:@"signup_emailMyId"] forState:UIControlStateNormal];
        //        [noIDEmailMeMyId setBackgroundImage:[UIImage imageNamed:@"signup_emailMyId_f"] forState:UIControlStateHighlighted];
        //        noIDEmailMeMyId.frame = noIDEmailMeMyIdRect;
        //        noIDEmailMeMyId.backgroundColor = [UIColor clearColor];
        //        [noIDEmailMeMyId addTarget:self action:@selector(btnSignUpTouched:) forControlEvents:UIControlEventTouchUpInside];
        //        noIDEmailMeMyId.tag = -10;
        //        [tableFooter_View addSubview:noIDEmailMeMyId];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        
        UIButton *signUPButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [signUPButton setBackgroundImage:[UIImage imageNamed:@"signupBtn"] forState:UIControlStateNormal];
        [signUPButton setBackgroundImage:[UIImage imageNamed:@"signupBtn_f"] forState:UIControlStateHighlighted];
        signUPButton.frame = signUpButtonRect;
        signUPButton.backgroundColor = [UIColor clearColor];
        [signUPButton addTarget:self action:@selector(btnSignUpTouched:) forControlEvents:UIControlEventTouchUpInside];
        signUPButton.tag = -11;
        [tableFooter_View addSubview:signUPButton];
        
        //FROM
        CGSize labelSize = [@"By Signing Up you agree to our   " sizeWithFont:[UIFont fontWithName:dateFontName size:dateFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 30)];
        CGSize label1Size = [@" and " sizeWithFont:[UIFont fontWithName:dateFontName size:dateFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 30)];
        
        UIView *termsAndConditionsView = [[UIView alloc]initWithFrame:CGRectMake(10, -signUPButton.frame.size.height+15, appDelegate.window.frame.size.width, tableFooterViewHeight)];
        //By Signing Up you agree to our Terms of Use and Privacy Policy
        CGSize termsBtnSize = [@"Terms of Use" sizeWithFont:[UIFont fontWithName:dateFontName size:dateFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 30)];
        
        CGSize policBtnSize = [@"Privacy Policy" sizeWithFont:[UIFont fontWithName:dateFontName size:dateFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 30)];
        
        
        UILabel *label1 = [[UILabel alloc]init];
        label1.textColor = [UIColor whiteColor];
        label1.backgroundColor = [UIColor clearColor];
        label1.text = @"By Signing Up you agree to our   ";
        
        label1.font=[UIFont fontWithName:dateFontName size:dateFontSize];
        [termsAndConditionsView addSubview:label1];
        
        UIButton *termsBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        UILabel *label2 = [[UILabel alloc]init];
        UIButton *policyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [termsBtn setTitle:@"Terms of Use" forState:UIControlStateNormal];
        label2.text = @" and ";
        [policyBtn setTitle:@"Privacy Policy" forState:UIControlStateNormal];
        
        if (iPad) {
            CGRect labelRect = CGRectMake(5, signUPButton.frame.size.height-16, labelSize.width, labelSize.height);
            label1.frame =labelRect;
            termsBtn.frame = CGRectMake(labelSize.width, signUPButton.frame.size.height-13, termsBtnSize.width,termsBtnSize.height);
            label2.frame = CGRectMake(label1.frame.size.width +termsBtn.frame.size.width, signUPButton.frame.size.height-16, label1Size.width, label1Size.height);
            policyBtn.frame = CGRectMake(label1.frame.size.width +termsBtn.frame.size.width+label2.frame.size.width , signUPButton.frame.size.height-13, policBtnSize.width,policBtnSize.height);
            
        }else{
            
            CGRect labelRect;
            
            if (CURRENT_DEVICE_VERSION>=7.0) {
                labelRect= CGRectMake(5, signUPButton.frame.size.height-16, labelSize.width, labelSize.height);
                label1.frame =labelRect;
                termsBtn.frame = CGRectMake(labelSize.width +5, signUPButton.frame.size.height-14, termsBtnSize.width,termsBtnSize.height);
                if(isiPhone6PLUS) {
                    label2.frame = CGRectMake(termsBtn.frame.size.width+termsBtn.frame.origin.x+5, signUPButton.frame.size.height-14, label1Size.width, label1Size.height);
                    policyBtn.frame = CGRectMake(label2.frame.size.width+label2.frame.origin.x+ 5, signUPButton.frame.size.height-14, policBtnSize.width,policBtnSize.height);
                }
                else  {
                    label2.frame = CGRectMake(2, signUPButton.frame.size.height-15+label1.frame.size.height, label1Size.width, label1Size.height);
                    policyBtn.frame = CGRectMake(label2.frame.size.width + 5, signUPButton.frame.size.height-13+label1.frame.size.height, policBtnSize.width,policBtnSize.height);
                }
            }else{
                labelRect= CGRectMake(11, signUPButton.frame.size.height-16, labelSize.width, labelSize.height);
                label1.frame =labelRect;
                termsBtn.frame = CGRectMake(labelSize.width +5, signUPButton.frame.size.height-15, termsBtnSize.width,termsBtnSize.height);
                
                label2.frame = CGRectMake(8, signUPButton.frame.size.height-15+label1.frame.size.height, label1Size.width, label1Size.height);
                policyBtn.frame = CGRectMake(label2.frame.size.width + 10, signUPButton.frame.size.height-15+label1.frame.size.height, policBtnSize.width,policBtnSize.height);
            }
        }
        
        [termsBtn setTitleColor:[appDelegate colorWithHexString:@"2977a8"] forState:UIControlStateNormal];
        [termsBtn.titleLabel setFont:[UIFont fontWithName:dateFontName size:dateFontSize]];
        termsBtn.tag = 2000;
        
        [termsBtn addTarget:self action:@selector(termsAndPoliciesClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        [termsAndConditionsView addSubview:termsBtn];
        
        
        
        label2.textColor = [UIColor whiteColor];
        label2.backgroundColor = [UIColor clearColor];
        
        label2.font = [UIFont fontWithName:dateFontName size:dateFontSize];
        [termsAndConditionsView addSubview:label2];
        
        [policyBtn setTitleColor:[appDelegate colorWithHexString:@"2977a8"] forState:UIControlStateNormal];
        [policyBtn.titleLabel setFont:[UIFont fontWithName:dateFontName size:dateFontSize]];
        policyBtn.tag = 2001;
        
        [policyBtn addTarget:self action:@selector(termsAndPoliciesClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        [termsAndConditionsView addSubview:policyBtn];
        [tableFooter_View addSubview:termsAndConditionsView];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)setEmailAndPasswordInRegDictEmailAddress:(NSString *)emailAddress password:(NSString *)password {
    TCSTART
    if ([self isNotNull:emailAddress]) {
        [regDict setObject:emailAddress forKey:@"email"];
    }
    if ([self isNotNull:password]) {
        [regDict setObject:password forKey:@"password"];
    }
    
    [registrationTableView reloadData];
    TCEND
}
- (IBAction)btnCancelTouched:(id)sender {
    @try {
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)btnSignUpTouched:(id)sender {
    @try {
        UIButton *btn = (UIButton *)sender;
        BOOL includePatientId;
        if (btn.tag == -10) {
            // No Patient Id Email Me My Id
            includePatientId = NO;
            
        } else {
            // SignUp with Patient Id
            includePatientId = YES;
        }
        
        if ([self validateInputWithIncludePatientId:includePatientId]) {
            NSLog(@"Success");
            [appDelegate signUpUserWithDetails:regDict];
        } else {
            NSLog(@"Fialure");
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)validateInputWithIncludePatientId:(BOOL)includePatientId {
    
    @try {
        
        NSString *fullname = [regDict objectForKey:@"fullname"];
        NSString *emailAddr = [regDict objectForKey:@"email"];
        //        NSString *username = [regDict objectForKey:@"username"];
        NSString *pwd = [regDict objectForKey:@"password"];
        NSString *birthdate = [regDict objectForKey:@"birth_day"];
        
        NSString *phoneNumber = [regDict objectForKey:@"phone_number"];
        NSString *address = [regDict objectForKey:@"address"];
        //        NSString *city = [regDict objectForKey:@"city"];
        //        NSString *state = [regDict objectForKey:@"state"];
        NSString *zipCode = [regDict objectForKey:@"zip_code"];
        NSString *securityQue = [regDict objectForKey:@"security_question"];
        NSString *securityAnswer = [regDict objectForKey:@"security_answer"];
        //NSString *patientId = [regDict objectForKey:@"patientid"];
        
        NSDate *today = [NSDate date];
        NSDateFormatter *FormatDate = [[NSDateFormatter alloc] init];
        [FormatDate setLocale: [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
        [FormatDate setDateFormat:@"yyyy-MM-dd"];
        NSDate *selectedDate = [FormatDate dateFromString:birthdate];
        NSLog(@"todayDate:%@ and SelectedDate:%@",today,selectedDate);
        
        BOOL isValid = YES;
        // full name field
        if (fullname.length == 0) {
            [appDelegate showErrorMsg:@"Please enter full name"];
            isValid = NO;
        }
        
        //email field
        if(isValid) {
            if (emailAddr.length > 0) {
                isValid = [appDelegate validateEmailWithString:emailAddr];
                //email field failed
                if(!isValid) {
                    [appDelegate showErrorMsg:@"Please enter valid email address."];
                }
            } else {
                isValid = NO;
                [appDelegate showErrorMsg:@"Please enter email address"];
            }
        }
        
        //username field
        //        if (isValid) {
        //            if (username.length <= 0) {
        //                [appDelegate showErrorMsg:@"Please enter user name"];
        //                isValid = NO;
        //            }
        //        }
        
        //password field
        if ((isValid && pwd.length < 8) || (pwd.length > 20)) {
            [appDelegate showErrorMsg:@"Please enter a valid password of min 8 and max 20 characters"];
            isValid = NO;
        }
        //Address address
        if (isValid) {
            if (address.length <= 0) {
                [appDelegate showErrorMsg:@"Please enter address"];
                isValid = NO;
                return NO;
            }
        }
        
        // City city
        //        if (isValid) {
        //            if ([self isNull:city]||city.length<=0) {
        //                [appDelegate showErrorMsg:@"Please enter city"];
        //                isValid = NO;
        //                return NO;
        //            }
        //        }
        //
        //            //State state
        //        if (isValid) {
        //            if ([self isNull:state]||state.length<=0) {
        //                [appDelegate showErrorMsg:@"Please enter state"];
        //                isValid = NO;
        //                return NO;
        //            }
        //        }
        
        
        //BirthDate
        if (isValid) {
            if (birthdate.length == 0) {
                [appDelegate showErrorMsg:@"Please select birthdate"];
                isValid = NO;
                return NO;
            } else if([selectedDate compare:today] == NSOrderedDescending) {
                [appDelegate showErrorMsg:@"Please select valid date."];
                isValid = NO;
                return NO;
            }
        }
        
        //Phone number phone_number
        if (isValid) {
            if (phoneNumber.length <= 0) {
                [appDelegate showErrorMsg:@"Please enter phone number."];
                isValid = NO;
                return NO;
            }
        }
        
        
        //zip code
        if(isValid) {
            if (zipCode.length <= 0) {
                isValid = NO;
                [appDelegate showErrorMsg:@"Please enter zip code."];
            } else {
                isValid = [appDelegate varifyUSZipcode:zipCode];
                if (!isValid) {
                    [appDelegate showErrorMsg:@"Please enter valid zip code"];
                }
            }
        }
        
        // Security Question security_question
        if (isValid) {
            if (securityQue.length <= 0) {
                [appDelegate showErrorMsg:@"Please select security question"];
                isValid = NO;
            }
        }
        
        // Security Answer security_answer
        if (isValid) {
            if (securityAnswer.length <= 0) {
                [appDelegate showErrorMsg:@"Please enter security answer"];
                isValid = NO;
            }
        }
        
        // patient Id
        //        if (isValid && includePatientId && patientId.length <= 0) {
        //            [appDelegate showErrorMsg:@"Please enter patientid."];
        //            isValid = NO;
        //        }
        return isValid;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)configureTheDatePicker {
    
    @try {
        NSDateFormatter *FormatDate = [[NSDateFormatter alloc] init];
        
        [FormatDate setLocale: [[NSLocale alloc]
                                initWithLocaleIdentifier:@"en_US"]];
        [FormatDate setDateFormat:@"yyyy-MM-dd"];
        if (iPad) {
            pickerViewDateView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1024)];
            pickerViewDateView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
            UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, 788, self.view.frame.size.width, 216)];
            theDatePicker.backgroundColor = [UIColor whiteColor];
            theDatePicker.datePickerMode = UIDatePickerModeDate;
            if ([self isNotNull:[regDict objectForKey:@"birth_day"]]) {
                theDatePicker.date = [FormatDate dateFromString:[regDict objectForKey:@"birth_day"]];
            }
            if ([self isNull:[regDict objectForKey:@"birth_day"] ]) {
                [self reloadTableWithSelectedDate:theDatePicker];
            }
            //[theDatePicker release];
            [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDate:) forControlEvents:UIControlEventValueChanged];
            
            UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 744, self.view.frame.size.width, 44)];
            pickerToolbar.barStyle=UIBarStyleBlackOpaque;
            [pickerToolbar sizeToFit];
            NSMutableArray *barItems = [[NSMutableArray alloc] init];
            UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
            [barItems addObject:flexSpace];
            
            [pickerToolbar setItems:barItems animated:YES];
            [pickerViewDateView addSubview:pickerToolbar];
            [pickerViewDateView addSubview:theDatePicker];
            [self.view addSubview:pickerViewDateView];
        } else {
            if(isiPhone6 || CURRENT_DEVICE_VERSION >= 8.0) {
                pickerViewDateView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height)];
                pickerViewDateView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
                UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, appDelegate.window.frame.size.height-216, appDelegate.window.frame.size.width, 216)];
                theDatePicker.backgroundColor = [UIColor whiteColor];
                theDatePicker.datePickerMode = UIDatePickerModeDate;
                if ([self isNotNull:[regDict objectForKey:@"birth_day"]]) {
                    theDatePicker.date = [FormatDate dateFromString:[regDict objectForKey:@"birth_day"]];
                }
                if ([self isNull:[regDict objectForKey:@"birth_day"] ]) {
                    [self reloadTableWithSelectedDate:theDatePicker];
                }
                //[theDatePicker release];
                [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDate:) forControlEvents:UIControlEventValueChanged];
                
                UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, appDelegate.window.frame.size.height-216-44, appDelegate.window.frame.size.width, 44)];
                pickerToolbar.barStyle=UIBarStyleBlackOpaque;
                [pickerToolbar sizeToFit];
                NSMutableArray *barItems = [[NSMutableArray alloc] init];
                UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
                [barItems addObject:flexSpace];
                
                [pickerToolbar setItems:barItems animated:YES];
                [pickerViewDateView addSubview:pickerToolbar];
                [pickerViewDateView addSubview:theDatePicker];
                [self.view addSubview:pickerViewDateView];
            }
            else {
                pickerViewDateActionSheet = [[UIActionSheet alloc] initWithTitle:@"How many?"
                                                                        delegate:self
                                                               cancelButtonTitle:nil
                                                          destructiveButtonTitle:nil
                                                               otherButtonTitles:nil];
                
                UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, 44.0, 0.0, 0.0)];
                theDatePicker.datePickerMode = UIDatePickerModeDate;
                theDatePicker.backgroundColor = [UIColor whiteColor];
                if ([self isNotNull:[regDict objectForKey:@"birth_day"]]) {
                    theDatePicker.date = [FormatDate dateFromString:[regDict objectForKey:@"birth_day"]];
                }
                if ([self isNull:[regDict objectForKey:@"birth_day"]]) {
                    [self reloadTableWithSelectedDate:theDatePicker];
                }
                
                [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDate:) forControlEvents:UIControlEventValueChanged];
                
                UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
                pickerToolbar.barStyle=UIBarStyleBlackOpaque;
                [pickerToolbar sizeToFit];
                NSMutableArray *barItems = [[NSMutableArray alloc] init];
                UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
                [barItems addObject:flexSpace];
                
                [pickerToolbar setItems:barItems animated:YES];
                [pickerViewDateActionSheet addSubview:pickerToolbar];
                [pickerViewDateActionSheet addSubview:theDatePicker];
                [pickerViewDateActionSheet showInView:appDelegate.window];
                [pickerViewDateActionSheet setBounds:CGRectMake(0,0,320, 464)];
                //360
                NSIndexPath *indexpth = [registrationTableView indexPathForSelectedRow];
                //            CGRect scrollFrame = [registrationTableView rectForRowAtIndexPath:indexpth];
                //            [registrationTableView scrollRectToVisible:scrollFrame animated:YES];
                
                [registrationTableView scrollToRowAtIndexPath:indexpth atScrollPosition:UITableViewScrollPositionTop animated:YES];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)DatePickerCancelSelected:(id)sender {
    [self DatePickerDoneClick];
}
#pragma mark
#pragma mark DatePicker Related
-(void)reloadTableWithSelectedDate:(id)sender{
    
    @try {
        datePicker = (UIDatePicker *)sender;
        NSDateFormatter *FormatDate = [[NSDateFormatter alloc] init];
        
        [FormatDate setLocale: [[NSLocale alloc]
                                initWithLocaleIdentifier:@"en_US"]];
        [FormatDate setDateFormat:@"yyyy-MM-dd"];
        
        [regDict setObject:[FormatDate stringFromDate:datePicker.date] forKey:@"birth_day"];
        
        [registrationTableView reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)DatePickerDoneClick{
    
    @try {
        if (iPad) {
            [pickerViewDateView removeFromSuperview];
            pickerViewDateView = nil;
            
        } else {
            if(isiPhone6 || CURRENT_DEVICE_VERSION >= 8.0) {
                [pickerViewDateView removeFromSuperview];
                pickerViewDateView = nil;
            }
            else {
                [pickerViewDateActionSheet dismissWithClickedButtonIndex:0 animated:YES];
                pickerViewDateActionSheet = nil;
            }
            //rearrange the table
            
        }
        pickerViewDateView.hidden=TRUE;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Table ScrollView Methods
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
    @try {
        if([self isNotNull:cellTextFieldRef]) {
            [cellTextFieldRef resignFirstResponder];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma mark -
#pragma mark Table view data source
- (void)configureCell:(RegistrationCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    @try {
        switch (indexPath.section) {
            case 0:
                cell.cellTextField.placeholder = [placeHoldersArray objectAtIndex:indexPath.row];
                
                if (indexPath.row == 2) {
                    cell.cellTextField.secureTextEntry  = YES;
                }
                break;
            default:
                break;
        }
        cell.indexPath = indexPath;
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark RegistrationCellDelegate Methods

-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath {
    TCSTART
    cellTextFieldRef = _textField;
    NSIndexPath *local_indexPath = _indexPath;
    if (_indexPath.row>4 && _indexPath.row < 9) {
//        NSInteger newLast = [local_indexPath indexAtPosition:local_indexPath.length-1]+1;
//        local_indexPath = [[local_indexPath indexPathByRemovingLastIndex] indexPathByAddingIndex:newLast];
//        
//        [registrationTableView scrollToRowAtIndexPath:_indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        
        
        CGRect cellRectFromIndexPath = [registrationTableView rectForRowAtIndexPath:_indexPath];
        cellRectFromIndexPath.origin.y = cellRectFromIndexPath.origin.y - ((!iPad)?100:416);
        [registrationTableView setContentOffset:CGPointMake(registrationTableView.contentOffset.x, cellRectFromIndexPath.origin.y)];
        
    } else if(_indexPath.row>4) {
        CGRect cellRectFromIndexPath = [registrationTableView rectForRowAtIndexPath:_indexPath];
        cellRectFromIndexPath.origin.y = cellRectFromIndexPath.origin.y - ((!iPad)?100:416);
        [registrationTableView setContentOffset:CGPointMake(registrationTableView.contentOffset.x, cellRectFromIndexPath.origin.y)];
    }
    TCEND
}

- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    @try {
        NSLog(@"row: %ld, section: %d",(long)indexPath.row,indexPath.section);
        if (indexPath.row != 4 && indexPath.row != 9 && indexPath.row != 7 && indexPath.section == 0) {
            if(indexPath.row==6)
            {
                [self.view endEditing:true];
                [self gotoSecurityQuestionsViewController];
                return;
            }else if (indexPath.row==8){
                [self.view endEditing:true];
            }
            
            
            NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row+1 inSection:indexPath.section];
            [[(RegistrationCell*)[registrationTableView cellForRowAtIndexPath:path] cellTextField] becomeFirstResponder];
            [registrationTableView scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionTop animated:YES];
        } else {
            //            NSLog(@"Cell textfield: %@",cellTextFieldRef);
            //            if (indexPath.row == 4) {
            //                [[(RegistrationCell*)[registrationTableView cellForRowAtIndexPath:indexPath] cellTextField] resignFirstResponder];
            //                [self initialisePickerView];
            //
            //            } else
            if (indexPath.row ==4) {
                [[(RegistrationCell*)[registrationTableView cellForRowAtIndexPath:indexPath] cellTextField] resignFirstResponder];
                [self configureTheDatePicker];
                
            } else {
                [[(RegistrationCell*)[registrationTableView cellForRowAtIndexPath:indexPath] cellTextField] resignFirstResponder];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateTextLabelAtIndexPath:(NSIndexPath*)indexPath string:(NSString*)string {
    
    @try {
        // NSLog(@"See input: %@ from section: %d row: %d, should update models appropriately", string, indexPath.section, indexPath.row);
        if(indexPath.section == 0) {
            if(indexPath.row == 0) {
                [regDict setObject:string forKey:@"fullname"];
            } else if(indexPath.row == 1) {
                NSString *lowerCaseUserMailId=[string lowercaseString];
                [regDict setObject:lowerCaseUserMailId forKey:@"email"];
            }
            //            else if(indexPath.row == 2) {
            //                [regDict setObject:string forKey:@"username"];
            //            }
            else if(indexPath.row == 2) {
                NSInteger passwordStrength = [appDelegate checkPasswordStrength:string];
                [appDelegate showPasswordStrength:passwordStrength forTextField:cellTextFieldRef];
                
                [regDict setObject:string forKey:@"password"];
                
            } else if (indexPath.row == 6) {
                [regDict setObject:string forKey:@"phone_number"];
            } else if (indexPath.row == 3) {
                [regDict setObject:string forKey:@"address"];
            }
            //			else if (indexPath.row == 4) {
            //                [regDict setObject:string forKey:@"city"];
            //            } else if (indexPath.row == 5) {
            //                [regDict setObject:string forKey:@"state"];
            //            }
            else if (indexPath.row == 4) {
                [regDict setObject:string forKey:@"zip_code"];
            } else if (indexPath.row == 8) {
                [regDict setObject:string forKey:@"security_answer"];
            }
            //else if (indexPath.row == 7) {
            //                [regDict setObject:string forKey:@"patientid"];
            //            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
-(void)termsAndPoliciesClicked:(id)sender{
    UIButton *btn = (UIButton *)sender;
    TCSTART
    NSLog(@"btn tag: %d",btn.tag);
    
    ChatterPlugViewController *chatterPlugViewContr;
    if(btn.tag == 2001) {
        chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://chatterplug.com/privacy_policy"];
        chatterPlugViewContr.titleStr = @"Privacy Policy";
    } else if(btn.tag == 2000) {
        //chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://chatterplug.com/terms_of_use"];
        chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:[NSString stringWithFormat:@"%@/terms_and_conditions",APP_URL]];
        chatterPlugViewContr.titleStr = @"Terms of Use";
    }
    
    [self.navigationController pushViewController:chatterPlugViewContr animated:YES];
    
    TCEND
}

- (void)whereToFindPatientIdBtnClicked:(id)sender {
    TCSTART
    NSString *messageStr = @"1. Ask the receptionist or your Care Provider \n2. Look in the upper right hand corner of your bill";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Find your Patient ID#" message: messageStr delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    TCEND
}

#pragma mark
#pragma TableView Delegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return placeHoldersArray.count;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    @try {
        return [[UIView alloc] initWithFrame:CGRectZero];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath  {
    return (iPad?60:45);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        CGFloat cellTextFieldHeight;
        if (iPad) {
            cellTextFieldHeight = 60;
        } else {
            cellTextFieldHeight = 45;
        }
        CGFloat cellHeight;
        //            cellHeight = (iPad?75:65);
        cellHeight = (iPad?60:45);
        //UIButton *WhrPatientIdBtn = nil;
        ////// For first section of edit ui
        if (indexPath.section == 0 && indexPath.row != 5 && indexPath.row != 7) {
            
            NSString *CellIdentifier = [NSString stringWithFormat:@"cell%d%d",indexPath.section,indexPath.row];
            RegistrationCell *cell = (RegistrationCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            if (cell == nil) {
                cell = [[RegistrationCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                
                //                CGSize btnSize = [@"Where to find your Patient ID#" sizeWithFont:[UIFont fontWithName:dateFontName size:dateFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 30)];
                //                WhrPatientIdBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                //                WhrPatientIdBtn.frame = CGRectMake(((iPad?660:(appDelegate.window.frame.size.width-30)) - btnSize.width), cellTextFieldHeight + 10, btnSize.width,btnSize.height);
                //                [WhrPatientIdBtn setTitle:@"Where to find your Patient ID#" forState:UIControlStateNormal];
                //                [WhrPatientIdBtn setTitleColor:[appDelegate colorWithHexString:@"2977a8"] forState:UIControlStateNormal];
                //                [WhrPatientIdBtn.titleLabel setFont:[UIFont fontWithName:dateFontName size:dateFontSize]];
                //                [WhrPatientIdBtn addTarget:self action:@selector(whereToFindPatientIdBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
                //                WhrPatientIdBtn.tag = -1000000;
                //                [cell.contentView addSubview:WhrPatientIdBtn];
            }
            
            //            if ([self isNull:WhrPatientIdBtn]) {
            //                WhrPatientIdBtn = (UIButton *)[cell.contentView viewWithTag:-1000000];
            //            }
            //            WhrPatientIdBtn.hidden = YES;
            [self configureCell:cell atIndexPath:indexPath];
            //cell.cellTextField.keyboardType = UIKeyboardTypeDefault;
            //cell.cellTextField.returnKeyType = UIReturnKeyNext;
            
            if (indexPath.row == 0) {
                if ([self isNotNull:[regDict objectForKey:@"fullname"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"fullname"];
                }
            }
            
            if (indexPath.row == 1) {
                if ([self isNotNull:[regDict objectForKey:@"email"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"email"];
                }
                cell.cellTextField.keyboardType = UIKeyboardTypeEmailAddress;
            }
            
            //            if (indexPath.row == 2) {
            //                if ([self isNotNull:[regDict objectForKey:@"username"]]) {
            //                    cell.cellTextField.text = [regDict objectForKey:@"username"];
            //                }
            //            }
            
            if (indexPath.row == 2) {
                if ([self isNotNull:[regDict objectForKey:@"password"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"password"];
                }
            }
            if (indexPath.row == 3) {
                if ([self isNotNull:[regDict objectForKey:@"address"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"address"];
                }
            }
            if (indexPath.row == 4) {
                if ([self isNotNull:[regDict objectForKey:@"zip_code"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"zip_code"];
                }
                //                cell.cellTextField.returnKeyType = UIReturnKeyDone;
            }
            if (indexPath.row == 6) {
                if ([self isNotNull:[regDict objectForKey:@"phone_number"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"phone_number"];
                }
            }
            
            
            
            //            if (indexPath.row == 4) {
            //                if ([self isNotNull:[regDict objectForKey:@"city"]]) {
            //                    cell.cellTextField.text = [regDict objectForKey:@"city"];
            //                }
            //            }
            
            
            
            
            if (indexPath.row == 8) {
                if ([self isNotNull:[regDict objectForKey:@"security_answer"]]) {
                    cell.cellTextField.text = [regDict objectForKey:@"security_answer"];
                    
                }
                cell.cellTextField.returnKeyType = UIReturnKeyDone;
                
                registrationTableView.contentSize = CGSizeMake(registrationTableView.frame.size.width, registrationTableView.frame.size.height+100);
            }
            
            //            if (indexPath.row == 7) {
            //                if ([self isNotNull:[regDict objectForKey:@"patientid"]]) {
            //                    cell.cellTextField.text = [regDict objectForKey:@"patientid"];
            //                }
            //                WhrPatientIdBtn.hidden = NO;
            //                cell.cellTextField.returnKeyType = UIReturnKeyDone;
            //            }
            cell.backgroundColor = [UIColor clearColor];
            cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
            [cell.cellTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
            return cell;
        } else { // show the date & securityquestions by creating a new cell which is of UITableCell
            
            NSString *CellIdentifier = [NSString stringWithFormat:@"cell%d%d",indexPath.section,indexPath.row];
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            UILabel *leftLabel = nil;
            UIView  *backgroundView = nil;
            UIImageView *backGroundImgView = nil;
            
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                
                backgroundView = [[UIView alloc] init];
                backgroundView.backgroundColor = [UIColor clearColor];
                backgroundView.tag = 1;
                
                [cell.contentView addSubview:backgroundView];
                
                backGroundImgView = [[UIImageView alloc] init];
                backGroundImgView.tag = 2;
                [backgroundView addSubview:backGroundImgView];
                
                leftLabel  = [[UILabel alloc]init];
                leftLabel.backgroundColor = [UIColor clearColor];
                leftLabel.font = [UIFont fontWithName:titleFontName size:descriptionTextFontSize];
                leftLabel.textColor = [UIColor lightGrayColor];
                leftLabel.textAlignment = NSTextAlignmentLeft;
                [leftLabel setTag:3];
                [backgroundView addSubview:leftLabel ];
                
            }
            if (!backgroundView) {
                backgroundView = (UIView *)[cell.contentView viewWithTag:1];
            }
            if (!backGroundImgView) {
                backGroundImgView = (UIImageView *)[backgroundView viewWithTag:2];
            }
            if (!leftLabel)
                leftLabel = (UILabel*)[backgroundView viewWithTag:3];
            
            if (iPad) {
                backgroundView.frame = CGRectMake(10, 7.5, 648, 45);
            } else {
                backgroundView.frame = CGRectMake(10, 7.5, appDelegate.window.frame.size.width-40, 35);
            }
            backGroundImgView.image = [UIImage imageNamed:@"login_textfield_550x67"];
            backGroundImgView.frame = CGRectMake(0, 0, backgroundView.frame.size.width, backgroundView.frame.size.height);
            
            leftLabel.frame = CGRectMake(5, 0, backgroundView.frame.size.width - 5, backgroundView.frame.size.height);
            //            if (indexPath.row == 5) {
            //                if ([self isNotNull:[regDict objectForKey:@"state"]]) {
            //                    leftLabel.text = [regDict objectForKey:@"state"];
            //                    leftLabel.textColor = [UIColor whiteColor];
            //                } else {
            //                    leftLabel.text = @"Select State";
            //                    leftLabel.textColor = [UIColor lightGrayColor];
            //                }
            //            } else
            if(indexPath.row == 5) {
                if ([self isNotNull:[regDict objectForKey:@"birth_day"]]) {
                    leftLabel.text = [regDict objectForKey:@"birth_day"];
                    leftLabel.textColor = [UIColor whiteColor];
                } else {
                    leftLabel.text = [placeHoldersArray objectAtIndex:indexPath.row];
                    leftLabel.textColor = [UIColor lightGrayColor];
                }
            } else if (indexPath.row == 7) {
                if ([self isNotNull:[regDict objectForKey:@"security_question"]]) {
                    leftLabel.text = [regDict objectForKey:@"security_question"];
                    leftLabel.textColor = [UIColor whiteColor];
                } else {
                    leftLabel.text = [placeHoldersArray objectAtIndex:indexPath.row];
                    leftLabel.textColor = [UIColor lightGrayColor];
                }
            }
            
            cell.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundView = nil;
            return cell;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark
#pragma mark TableView delegate methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        
        if (indexPath.row == 5) {
            [cellTextFieldRef resignFirstResponder];
            [self configureTheDatePicker];
        }
        //		else if(indexPath.row == 5){
        //            [cellTextFieldRef resignFirstResponder];
        //                [self initialisePickerView];
        //        }
        else if (indexPath.row == 7) {
            [self gotoSecurityQuestionsViewController];
        }
        else if (indexPath.row == 8) {
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)gotoSecurityQuestionsViewController {
    TCSTART
    NSString *selectedQue;
    if ([self isNotNull:[regDict objectForKey:@"security_question"]]) {
        selectedQue = [regDict objectForKey:@"security_question"];
    }
    SecurityQuestionsViewController *securityQuestionsVC;
    if (iPad) {
        securityQuestionsVC = [[SecurityQuestionsViewController alloc] initWithNibName:@"SecurityQuestionsViewController~iPad" bundle:nil SelectedSecurityQuestion:selectedQue withFrame:self.view.frame withCaller:self];
    } else {
        securityQuestionsVC = [[SecurityQuestionsViewController alloc] initWithNibName:@"SecurityQuestionsViewController~iPhone" bundle:nil SelectedSecurityQuestion:selectedQue withFrame:appDelegate.window.frame withCaller:self];
    }
    [self.navigationController pushViewController:securityQuestionsVC animated:YES];
    TCEND
}
- (void)selectedSecurityQuestion:(NSString *)question {
    [regDict setObject:question forKey:@"security_question"];
    [registrationTableView reloadData];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

//ADDING PICKER VIEW
#pragma mark US STATES
#pragma mark pickerView Datasource and delgate methods
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [usStatesArray count];
    
}
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    //    CGSize nameSize;
    return 44;
}
//-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
//    TCSTART
//    UIView *myView;
//
//    UILabel *customLabel;// = [[UILabel alloc]init];
//    CGSize nameSize;
//    NSString *nameVal = [usStatesArray objectAtIndex:row];
//
////    if (isCommunicationTypeSelected) {
////        CPPhysician *physician = [physiciansArray objectAtIndex:row];
////
////        nameVal = physician.physicianName;
////            //        return myView;
////
////    }else{
////        NSLog(@"CommunicatonType: %@",[communicationTypesArray objectAtIndex:row]);
////
////            //        CPCcommunicationType *communicationType = [communicationTypesArray objectAtIndex:row];
////        NSDictionary *communicationType = [communicationTypesArray objectAtIndex:row];
////            //        return [communicationType objectForKey:@"name"];
////            //        customLabel.text = [communicationType objectForKey:@"name"];
////        nameVal=[communicationType objectForKey:@"name"];
////
////
////    }
//    if ([self isNotNull:nameVal]) {
//        nameSize = [nameVal sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 2000.0f) lineBreakMode:NSLineBreakByWordWrapping];
//    }
//    NSLog(@"name: %@",nameVal);
//    CGFloat heightOfTheRow;
//    heightOfTheRow = 65;
//    if (nameSize.height > heightOfTheRow) {
//        heightOfTheRow = nameSize.height ;
//    }
//
//    CGFloat movableHeight;
//    if (iPad) {
//        movableHeight = (iPad?0:20);
//    }else{
//        movableHeight = (CURRENT_DEVICE_VERSION>=7.0?0:20);
//    }
//    NSLog(@"height: %f",heightOfTheRow);
//
//    customLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.origin.x ,self.view.frame.origin.y-movableHeight, CELL_CONTENT_WIDTH-20 ,heightOfTheRow)];
//    myView =[[UIView alloc]initWithFrame:CGRectMake(self.view.frame.origin.x+5 ,self.view.frame.origin.y-20, CELL_CONTENT_WIDTH-5 ,heightOfTheRow)];
//
//    customLabel.numberOfLines = 0;
//    customLabel.backgroundColor=[UIColor clearColor];
//    customLabel.textColor =[UIColor blackColor];
//    [myView addSubview:customLabel];
//    customLabel.text = nameVal;
//    customLabel.textAlignment = UITextAlignmentCenter;
//        //    customLabel.textAlignment =NSTextAlignmentLeft;
//    return myView;
//    TCEND
//}


-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [usStatesArray objectAtIndex:row];
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    TCSTART
    [regDict setObject:[usStatesArray objectAtIndex:row] forKey:@"state"];
    [registrationTableView reloadData];
    TCEND
}


#pragma mark toolbar done clicked
- (IBAction)toolbarDoneSelected:(id)sender {
    statesView.hidden = YES;
    [registrationTableView reloadData];
    
}

- (void)initialisePickerView {
    TCSTART
    if ([self isNull:statesView]) {
        statesView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, 1024)];
        statesView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        //        216
        int height;
        //        if (CURRENT_DEVICE_VERSION < 7.0) {
        //            height = 300;
        //        }else{
        height = 216;
        //        }
        //        statesPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - 216, self.view.frame.size.width, 400)];
        statesPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height -height, appDelegate.window.frame.size.width, 400)];
        
        [statesView addSubview:statesPickerView];
        statesPickerView.delegate = self;
        statesPickerView.dataSource = self;
        statesPickerView.showsSelectionIndicator = YES;
        statesPickerView.backgroundColor = [UIColor whiteColor];
        statesPickerView.tag = 26;
        
        //        statesToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (216 + 44), self.view.frame.size.width, 44)];
        statesToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (height + 44), appDelegate.window.frame.size.width, 44)];
        
        [statesToolBar setBarStyle:UIBarStyleBlack];
        
        UIBarButtonItem *leftBarbutton = [[UIBarButtonItem alloc] initWithTitle:@"Select State:" style:UIBarButtonItemStylePlain target:nil action:nil];
        //    if (!iPad) {
        leftBarbutton.width = (iPad?450:245);
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, leftBarbutton.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
        txtLabel.textAlignment = NSTextAlignmentLeft;
        txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        txtLabel.text = @"Select State:";
        leftBarbutton.customView = txtLabel;
        //    }
        
        UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *rightbutton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(toolbarDoneSelected:)];
        //        rightbutton.title
        //        rightbutton
        statesToolBar.items = [NSArray arrayWithObjects:leftBarbutton,flexibleSpace,rightbutton, nil];
        
        if ([self isNull:[regDict objectForKey:@"state"]]) {
            [regDict setObject:@"AL" forKey:@"state"];
        }
        
        [statesView addSubview:statesToolBar];
        
        [self.view addSubview:statesView];
    } else {
        statesView.hidden = NO;
        [statesPickerView reloadAllComponents];
    }
    [registrationTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:6 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    //    editTable.contentInset = UIEdgeInsetsMake(0.0, 0.0f, 310, 0.0f);
    //    [editTable setContentOffset:CGPointMake(editTable.contentOffset.x, 310) animated:YES];
    TCEND
}

- (void)keyboardWillShow:(NSNotification *)sender
{
    CGSize kbSize = [[[sender userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    NSTimeInterval duration = [[[sender userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    [UIView animateWithDuration:duration animations:^{
        UIEdgeInsets edgeInsets = UIEdgeInsetsMake(0, 0, kbSize.height, 0);
        [registrationTableView setContentInset:edgeInsets];
        [registrationTableView setScrollIndicatorInsets:edgeInsets];
    }];
}

- (void)keyboardWillHide:(NSNotification *)sender
{
    NSTimeInterval duration = [[[sender userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    [UIView animateWithDuration:duration animations:^{
        UIEdgeInsets edgeInsets = UIEdgeInsetsZero;
        [registrationTableView setContentInset:edgeInsets];
        [registrationTableView setScrollIndicatorInsets:edgeInsets];
    }];
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
