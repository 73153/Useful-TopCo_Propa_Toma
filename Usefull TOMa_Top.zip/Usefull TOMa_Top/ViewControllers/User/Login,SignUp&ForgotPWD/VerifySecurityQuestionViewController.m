//
//  VerifySecurityQuestionViewController.m
//  Memorial
//
//  Created by Aruna on 19/09/13.
//
//

#import "VerifySecurityQuestionViewController.h"

@interface VerifySecurityQuestionViewController ()

@end

@implementation VerifySecurityQuestionViewController
@synthesize okButton,cancelButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andQuestion:(NSString *)question andCaller:(id)callbackObj
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        securityQue = question;
        caller = callbackObj;
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
    [appDelegate setLeftPaddingforTextField:answerTextField];
    questionLabel.text = securityQue;
    questionLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
    answerTextField.delegate = self;
    [answerTextField becomeFirstResponder];
    [answerTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    if(iPad){
        [okButton setImage:[UIImage imageNamed:@"VerifyOk"] forState:UIControlStateNormal];
        [okButton setImage:[UIImage imageNamed:@"VerifyOk"] forState:UIControlStateHighlighted];
        [cancelButton setImage:[UIImage imageNamed:@"VerifyCancel"] forState:UIControlStateNormal];
        [cancelButton setImage:[UIImage imageNamed:@"VerifyCancel"] forState:UIControlStateHighlighted];
    }
    TCEND
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (IBAction)onClickOfOkButton:(id)sender {
    TCSTART
    if ([self isNotNull:answerTextField] && answerTextField.text.length > 0) {
        answerTextField.text = [appDelegate removingLastSpecialCharecter:answerTextField.text];
    }
   
    if (answerTextField.text.length > 0 && [self isNotNull:caller] && [caller respondsToSelector:@selector(enteredSecurityAnswer:)]) {
        NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:securityQue,@"question",answerTextField.text,@"answer", nil];
        [caller enteredSecurityAnswer:dict];
    }
    TCEND
}

- (IBAction)onClickOfCancelButton:(id)sender {
    TCSTART
    [self.view removeFromSuperview];
    TCEND
}

#pragma mark -
#pragma mark UITextFieldDelegate Methods

- (BOOL) textFieldShouldBeginEditing:(UITextField *)textField {
	
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSLog(@"textFieldShouldReturn in verify security");
	[answerTextField resignFirstResponder];
    
	return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [answerTextField resignFirstResponder];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [answerTextField resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
