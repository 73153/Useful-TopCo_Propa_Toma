//
//  RegistrationCell.h
//  MemorialHealthSystem
//
//  Created by Aruna on 15/06/13.
//
//

#import <UIKit/UIKit.h>

@interface RegistrationCell : UITableViewCell <UITextFieldDelegate> {
    
	id __unsafe_unretained delegate;
	UITextField *cellTextField;
	NSIndexPath *indexPath;
}

@property (nonatomic, assign) id delegate;
@property (nonatomic, retain) UITextField *cellTextField;
@property (nonatomic, retain) NSIndexPath *indexPath;

@end

@protocol RegistrationTextFieldDelegate

-(void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath;
-(void)updateTextLabelAtIndexPath:(NSIndexPath*)_indexPath string:(NSString*)_string;
-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath;

@end
