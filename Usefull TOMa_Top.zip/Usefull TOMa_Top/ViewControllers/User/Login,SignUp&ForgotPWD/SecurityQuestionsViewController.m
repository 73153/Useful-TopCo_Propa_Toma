//
//  SecurityQuestionsViewController.m
//  Memorial
//
//  Created by Aruna on 18/09/13.
//
//

#import "SecurityQuestionsViewController.h"

@interface SecurityQuestionsViewController ()

@end

@implementation SecurityQuestionsViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil SelectedSecurityQuestion:(NSString *)selectedString withFrame:(CGRect)frame withCaller:(id)caller_
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        selectedQueString = selectedString;
        self.view.frame = frame;
        caller = caller_;
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    headerLabel.text = @"SECURITY QUESTIONS";
    headerLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    if(isiPhone6) {
        headerLabel.frame=CGRectMake((appDelegate.window.frame.size.width-headerLabel.frame.size.width)/2, headerLabel.frame.origin.y, headerLabel.frame.size.width, headerLabel.frame.size.height);
    }
    securityQuestionsArray = [[NSMutableArray alloc] initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"SecurityQuestions"]];

    if ([self isNotNull:appDelegate.userProfileDataModel.authToken]) {
        [appDelegate getBusinessInfoWithCaller:self andAuthTokenNeeded:YES];
    } else {
        [appDelegate getBusinessInfoWithCaller:self andAuthTokenNeeded:NO];
    }
    
    [appDelegate showActivityIndicatorInView:self.view];
    if (CURRENT_DEVICE_VERSION >= 7.0f) {
        securityQuestionsTableView.frame = CGRectMake(10, securityQuestionsTableView.frame.origin.y, self.view.frame.size.width - 20, securityQuestionsTableView.frame.size.height);
    }
    securityQuestionsTableView.backgroundColor = [UIColor clearColor];
    securityQuestionsTableView.backgroundView = Nil;
    
    [securityQuestionsTableView reloadData];
    TCEND
	// Do any additional setup after loading the view.
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark BusinessInfo Service delegate methods
- (void)didReceivedBusinessInfo:(CPBusinessInfo *) businessInfo {
    TCSTART
    
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    if ([self isNotNull:businessInfo.physiciansArray] && businessInfo.physiciansArray.count > 0) {
        [appDelegate savePhysicians:businessInfo.physiciansArray];
    }
    
    if ([self isNotNull:businessInfo.responseTimeFrame]) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.responseTimeFrame forKey:@"responseTimeFrame"];
    }
    if ([self isNotNull:businessInfo.securityQuestions] && businessInfo.securityQuestions.count > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.securityQuestions forKey:@"SecurityQuestions"];
    }
    if ([self isNotNull:businessInfo.insuranceProviders] && businessInfo.insuranceProviders.count > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.insuranceProviders forKey:@"insuranceProviders"];
    }
    [securityQuestionsArray removeAllObjects];
    [securityQuestionsArray addObjectsFromArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"SecurityQuestions"]];
    
    [securityQuestionsTableView reloadData];
    TCEND
}

- (void)didFailToReceiveBusinessInfoWithError:(NSError*) error {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate showErrorMsg:[error localizedDescription]];
    TCEND
}

- (IBAction)onClickOfCancel:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return securityQuestionsArray.count;
}

//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
//    return @"Select a Question : ";
//}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return (iPad?70:50);
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    TCSTART
    CGFloat originX;
    if (CURRENT_DEVICE_VERSION < 7.0) {
        originX = (iPad?40:10);
    } else {
        originX = (iPad?10:5);
    }
    UIView *headerView = [[UIView alloc] init];
    headerView.backgroundColor = [UIColor clearColor];
    UILabel *headerLabelTitle = [[UILabel alloc] initWithFrame:CGRectMake(originX, 0, CELL_CONTENT_WIDTH, (iPad?70:50))];
    headerLabelTitle.font = [UIFont fontWithName:titleFontName size:titleFontSize];
    headerLabelTitle.textAlignment = NSTextAlignmentLeft;
    headerLabelTitle.text = @"Choose a security question";
    headerLabelTitle.backgroundColor = [UIColor clearColor];
    headerLabelTitle.textColor = [UIColor whiteColor];
    
    [headerView addSubview:headerLabelTitle];
    return headerView;
    TCEND
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
  return  [self getrowHeightAtIndexPath:indexPath];
    TCEND
}

- (CGFloat)getrowHeightAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    CGFloat strHeight;
    CGSize strSize = [[securityQuestionsArray objectAtIndex:indexPath.row] sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH, 1000) lineBreakMode:NSLineBreakByWordWrapping];
    strHeight = strSize.height + CELL_CONTENT_MARGIN * 2;
    if (strHeight > 50) {
        return strHeight;
    } else {
        return 50;
    }
    TCEND
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    NSString *CellIdentifier = @"securityquestionscell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
        cell.textLabel.font = [UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize];
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        cell.textLabel.backgroundColor = [UIColor clearColor];
    }
    cell.textLabel.text = [securityQuestionsArray objectAtIndex:indexPath.row];
    CGFloat height = [self getrowHeightAtIndexPath:indexPath];
    
    cell.textLabel.frame = CGRectMake(CELL_CONTENT_MARGIN, CELL_CONTENT_MARGIN, CELL_CONTENT_WIDTH, height- (CELL_CONTENT_MARGIN * 2));
    if ([self isNotNull:selectedQueString] && [[securityQuestionsArray objectAtIndex:indexPath.row] caseInsensitiveCompare:selectedQueString] == NSOrderedSame) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
//        cell.textLabel.textColor = [UIColor blueColor];
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
//        cell.textLabel.textColor = [UIColor whiteColor];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    TCEND
}

- (void)setRoundedRectToCell:(UITableViewCell *)cell andIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    //    cell.layer.cornerRadius = 0.0f;
    //    cell.layer.masksToBounds = YES;
    if (indexPath.row == 0) {
        [appDelegate setMaskTo:cell byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft withRadii:CGSizeMake(5.0f, 5.0f)];
    } else if (indexPath.row == (securityQuestionsArray.count - 1)) {
        [appDelegate setMaskTo:cell byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(5.0f, 5.0f)];
    }
    TCEND
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (CURRENT_DEVICE_VERSION >= 7.0f) {
            [self setRoundedRectToCell:cell andIndexPath:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
    } else {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    NSString *string = [securityQuestionsArray objectAtIndex:indexPath.row];
    if ([self isNotNull:caller] && [caller respondsToSelector:@selector(selectedSecurityQuestion:)]) {
        [caller selectedSecurityQuestion:string];
    }
    [self.navigationController popViewControllerAnimated:YES];
    TCEND
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
