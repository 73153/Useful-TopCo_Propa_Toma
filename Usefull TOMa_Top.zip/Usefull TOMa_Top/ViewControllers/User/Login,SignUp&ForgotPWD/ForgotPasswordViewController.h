//
//  ForgotPasswordViewController.h
//  ChatterPlug
//
//  Created by shiva on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProfileService.h"
//#import "VerifySecurityQuestionViewController.h"

@class AppDelegate;

@interface ForgotPasswordViewController : UIViewController<UITextFieldDelegate,ProfileServiceDelegate> {
    
    /** backButton is an instance of UIButton created through Interface Builder and linked using FilesOwner in IB.
     On touchUpInside popup's the ForgotPassword to loginViewController page
     */
    IBOutlet UIButton *backButton;
    
    /** emailNewPasswordButton is an instance of UIButton created through Interface Builder and linked using FilesOwner in IB.
     On touchUpInside triggers an action method emialNewPassword.
     */
    IBOutlet UIButton *emailNewPasswordButton;  
    
    /** emailAddressTextField is an instance of UITextField created through Interface Builder and linked using FilesOwner in IB. Have given the background color & keyboard return type is set to Done by default it calls the keyboard by setting an texfield.becomefristresponder to YES.
     */
    IBOutlet UITextField *emailAddressTextField;
    
    /** appDelegate is a AppDelegate instance which is a controller for the app. Required to get the more comments(Plugs & Replies).
     */
    AppDelegate *appDelegate;
    
    //HeaderText Outlet for iphone6 comaptibility
    __weak IBOutlet UILabel *headerLabel;
    
    NSString *emailAddress;
}

@property (nonatomic, retain) NSString *emailAddress;

/** pops the ForgotPassword screen to loginscreen by calling an API "[self.navigationController popViewControllerAnimated:YES]"
 */
-(IBAction)popToLoginScreen:(id)sender;

/** sends the email address to appdelegate to make a forgotpassword request, server will post the new password to mentioned email-id
 */
-(IBAction)emailNewPassword:(id)sender;

- (void)enteredSecurityAnswer:(NSDictionary *)securityQueNAnswerDict;
@end
