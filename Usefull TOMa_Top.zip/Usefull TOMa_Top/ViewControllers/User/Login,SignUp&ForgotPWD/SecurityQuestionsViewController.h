//
//  SecurityQuestionsViewController.h
//  Memorial
//
//  Created by Aruna on 18/09/13.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface SecurityQuestionsViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,CPBusinessInfoServiceDelegate> {
    IBOutlet UITableView *securityQuestionsTableView;
    IBOutlet UILabel *headerLabel;
    NSString *selectedQueString;
    NSMutableArray *securityQuestionsArray;
    AppDelegate *appDelegate;
    
    id caller;
}

- (IBAction)onClickOfCancel:(id)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil SelectedSecurityQuestion:(NSString *)selectedString withFrame:(CGRect)frame withCaller:(id)caller_;
@end
