//
//  RedeemCutomButton.h
//  Baldwin
//
//  Created by Jagadeesh J on 06/12/14.
//  Copyright (c) 2014 Spoors. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RedeemCutomButton : UIButton
@property (nonatomic, retain) NSIndexPath *indexPath;

/** Type 1 for heartsymbol(like), 2 for push & 3 for Email
 */
@property (nonatomic, readwrite) BOOL isRedeem;

@end
