//
//  UserGuideLinesViewController.m
//  Health Demo
//
//  Created by Aruna on 23/07/14.
//
//

#import "UserGuideLinesViewController.h"
#import "AppDelegate.h"
#import "ToastView.h"

@interface UserGuideLinesViewController () {
    AppDelegate *appDelegate;
}

@end

@implementation UserGuideLinesViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];

    NSString *urlString=[NSString stringWithFormat:@"%@/terms_and_conditions",APP_URL];
    requestM = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    [requestM setValue:API_KEY forHTTPHeaderField:@"X-ChatterPlug-API-Key"];
    [guidelinesWebView loadRequest:requestM];
    
    guidelinesWebView.opaque = NO;
    guidelinesWebView.backgroundColor = [UIColor clearColor];
    
    UIBarButtonItem *leftBarBtn = [[UIBarButtonItem alloc] initWithTitle:@"Decline" style:UIBarButtonItemStyleBordered target:self action:@selector(decline)];
    self.navigationItem.leftBarButtonItem = leftBarBtn;
    
    UIBarButtonItem *rightBarBtn = [[UIBarButtonItem alloc] initWithTitle:@"Accept" style:UIBarButtonItemStyleBordered target:self action:@selector(accept)];
    self.navigationItem.rightBarButtonItem = rightBarBtn;
    
    self.title = @"Terms of Use";

    TCEND
}

- (void)accept {
    TCSTART
    [guidelinesWebView stopLoading];
    [_urlConnection cancel];
    [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"LaunchStatus"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    TCEND
}
- (void)decline {
    [ToastView showToastInParentView:self.view withText:@"To access the app. You need to accept the user agreement." withDuaration:5.0];
}

#pragma mark - NURLConnection delegate
- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge;
{
    TCSTART
    NSLog(@"WebController Got auth challange via NSURLConnection");
    
    if ([challenge previousFailureCount] == 0) {
        _authenticated = YES;
        
        NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
        
        [challenge.sender useCredential:credential forAuthenticationChallenge:challenge];
        
    } else {
        [[challenge sender] cancelAuthenticationChallenge:challenge];
    }
    TCEND
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
{
    NSLog(@"WebController received response via NSURLConnection");
    
    // remake a webview call now that authentication has passed ok.
    _authenticated = YES;
    [guidelinesWebView loadRequest:requestM];
    
    // Cancel the URL connection otherwise we double up (webview + url connection, same url = no good!)
    [_urlConnection cancel];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    // The request has failed for some reason!
    // Check the error var
    NSLog(@"NSURL connection failed!");
    isNetworkIndicator = NO;
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:guidelinesWebView];
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Network Alert" message:@"Please check your internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];

}

// We use this method is to accept an untrusted site which unfortunately we need to do, as our PVM servers are self signed.
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

#pragma mark WebView Delegate Methods

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
{
    TCSTART
    NSLog(@"Did start loading: %@ auth:%d", [[request URL] absoluteString], _authenticated);
    if (!isNetworkIndicator) {
        isNetworkIndicator = YES;
        [appDelegate showNetworkIndicator];
        [appDelegate showActivityIndicatorInView:webView];
    }
    if (!_authenticated)
    {
        _authenticated = NO;
        
        _urlConnection = [[NSURLConnection alloc] initWithRequest:requestM delegate:self];
        [_urlConnection start];
        
        return NO;
    }
    
    return YES;
    TCEND
}

-(void)webViewDidStartLoad:(UIWebView *)webView_ {
    
    @try {
        if (!isNetworkIndicator) {
            isNetworkIndicator = YES;
            [appDelegate showNetworkIndicator];
            [appDelegate showActivityIndicatorInView:webView_];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webViewDidFinishLoad:(UIWebView *)webView_ {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webView:(UIWebView *)webView_ didFailLoadWithError:(NSError *)error {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
        if (error.code == NSURLErrorCancelled){
            return;
            //        }return; // this is Error -999
            // error handling for "real" errors here
            //        [appDelegate showErrorMsg:[error localizedDescription]];
        }
        //        [appDelegate showErrorMsg:[error localizedDescription]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
