//
//  EditView.h
//  ChatterPlug
//
//  Created by Pankaj yadav on 16/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Base64.h"
#import "ProfileDataModel.h"
#import "ProfileService.h"
#import "ELCTextfieldCell.h"
#import "NotificationDetails.h"
#import "BusinessRewardsViewController.h"

@class AppDelegate;

@interface UserProfileEditViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource,UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,ProfileServiceDelegate,UIPopoverControllerDelegate,ELCTextFieldDelegate,UIActionSheetDelegate>
{
    UITableView *editTable;
    
    UIDatePicker *datePicker;
    NSMutableDictionary *arrayofLeftLabel_Dictionary;
    
    UIView *pickerViewDateView;
    UIActionSheet *pickerViewDateActionSheet;
    NSArray *headerSecName_Arr;
    
    id caller_;
    
    UITextField *cellTextFieldRef;
    AppDelegate *appDelegate;
    
    UIView *addConfirmationView;
    UIImageView *preview_imgView;
    UIView *photoPopUp_View;
    BOOL isImgSourceTypeCamera;
    
    UIPopoverController *popover;
    
    
    
    NSString *changeAvatarReqFor;
    
    
    // Insurance
    UIView  *insurancePickerDisplayView;
    UIPickerView *insurancePickerView;
    UIToolbar *toolBar;
    
    // Preferred contact
    UIView  *preferredContactMethodView;
    UIPickerView *preferredContactPickerView;
    UIToolbar *preferredContactToolBar;
    NSArray *preferredContactsArray;
    
    NSArray *insuranceProvidersArray;
    NSString *previousSelectedAppointmentMethod;
    NSArray *notificationArray;
    
    // UI PICKER VIEW
    UIView  *statesView;
    UIPickerView *statesPickerView;
    UIToolbar *statesToolBar;
    NSArray *usStatesArray;
    
    UIViewController *imageFullView;
    UILabel *titleLabel;
    NSInteger noOfInsurancePic;
    UIImage *newAvatarImage;
    
}


@property (nonatomic,retain) UIImage *frontCard;
@property (nonatomic,retain) UIImage *frontCard2;
@property (nonatomic,retain) UIImage *frontCard3;

@property (nonatomic,retain) UIImage *backCard;
@property (nonatomic,retain) UIImage *backCard2;
@property (nonatomic,retain) UIImage *backCard3;



@property (nonatomic) NSInteger selectedIndex;


@property (nonatomic,retain) ProfileDataModel *profiledatamodel;
@property (nonatomic, retain) UIPopoverController *popover;
- (void)configureTheDatePicker; //for configuring the date picker in a action sheet with a toolbar for done and it initiated when user want to set his birthday
- (id)initWithCaller:(id)caller;
- (void)DatePickerDoneClick;
- (void)openCamera;
- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSize:(CGSize)targetSize;
- (void)reloadData;
@end
