//
//  LVSuccessfulRegistration.h
//  forfone
//
//  Created by Ilker Baltaci on 2/6/13.
//
//

#import <UIKit/UIKit.h>

@interface UIViewOverlayAnimation : UIView{
    UIImageView *boxOverlay;
    UIButton *closeButton;
}


- (void)showInView:(UIView *)aView;
- (id)initWithFrame:(CGRect)frame cardImage:(UIImage*)cardImage;

@end
