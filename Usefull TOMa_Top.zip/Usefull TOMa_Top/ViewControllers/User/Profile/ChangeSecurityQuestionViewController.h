//
//  ChangeSecurityQuestionViewController.h
//  Memorial
//
//  Created by Aruna on 20/09/13.
//
//

#import <UIKit/UIKit.h>
#import "ProfileDataModel.h"
#import "ELCTextfieldCell.h"
#import "AppDelegate.h"

@interface ChangeSecurityQuestionViewController : UIViewController<UITableViewDataSource, UITableViewDelegate, ELCTextFieldDelegate,ProfileServiceDelegate> {
    UITableView *changeSecQueTableView;
    ProfileDataModel *userProfile;
    NSMutableDictionary *securityDict;
    AppDelegate *appDelegate;
}

- (id)initWithFrame:(CGRect)frame profileDataModal:(ProfileDataModel *)profileDataModal andCaller:(id)caller;
- (void)selectedSecurityQuestion:(NSString *)question;
@end
