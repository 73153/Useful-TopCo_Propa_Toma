//
//  ProfileDataModel.h
//  ChatterPlug
//
//  Created by Pankaj yadav on 30/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProfileDataModel : NSObject<NSCoding> {
    NSString *userBio;
    NSString *birthDay;
    NSString *businessFollowersCount;
    NSString *commentsCount;
    NSString *userEmail;
    NSString *favoritesCount;
    NSString *firstName;
    NSString *gender;
    NSString *userId;
    NSString *lastName;
    NSString *likesCount;
    NSString *likesRecievedCount;
    NSString *location;
    NSString *phoneNo;
    NSString *reviewsCount;
    NSString *url;
    NSString *zipCode;
    NSString *avatarImageUrl;
    NSDictionary *avatarImageUrlDictionary;
    NSString *goldRanksCount;
    NSString *siverRanksCount;
    NSString *bronzeRanksCount;
    NSString *authToken;
    NSData   *avatarImageData;
    NSString *userName;
    NSString *passwordStr;
    NSNumber *isShowGender;
    NSNumber *isShowLocation;
    NSArray *sharingOutlets;
    
    NSString *emailStr;
    NSString *zipStr;
    
    NSString *urlStr;
    NSString *biostr;
    
    NSString *genderStr;
    NSString *date;
    
    NSNumber *badge_count;
    NSString *city;
    NSString *state;
    NSString *address;
    
    BOOL you_follow_user;
    BOOL user_follows_you;
    
    NSString *followersCount;
    NSString *followingsCount;
    
    NSString *patientID;
    NSString *securityQuestion;
    NSString *securityAnswer;
    
    NSData *insuranceFrontCardData;
    NSData *insuranceBackCardData;
    
    NSString *insurance_provider_id;
    NSString *preferredAppointmentContactMethod;
    NSString *preferredAppointmentContactData;
    NSString    *insuranceBackCardUrl;
    NSString    *insuranceFrontCardUrl;
    
    NSString    *insuranceBackTwoCardUrl;
    NSString    *insuranceFrontTwoCardUrl;
    
    NSString    *insuranceBackThreeCardUrl;
    NSString    *insuranceFrontThreeCardUrl;
    
    NSArray *skipPushNotifications;
    NSArray *skipEmailNotifications;
    NSArray *notificationPreferences;
    
    NSString *currentRewardRank;
    NSString *currentRewardPoints;
    NSString *nextRewardRank;
    NSString *pointsUntilNextRewardRank;
    
}

@property(nonatomic,strong) NSData *avatarImageData;
@property (nonatomic, strong) NSData *insuranceFrontCardData;
@property (nonatomic, strong)  NSData *insuranceBackCardData;

@property (nonatomic, strong) NSData *insuranceFrontCardTwoData;
@property (nonatomic, strong)  NSData *insuranceBackCardTwoData;

@property (nonatomic, strong) NSData *insuranceFrontCardThreeData;
@property (nonatomic, strong)  NSData *insuranceBackCardThreeData;

@property (nonatomic, strong)  NSMutableArray *aryInsuranceCards;
@property(nonatomic,strong) NSNumber *isShowGender;
@property(nonatomic,strong) NSNumber *isShowLocation;

@property(nonatomic,strong) NSString *userName;

@property(nonatomic,strong) NSString *passwordStr;
@property(nonatomic,strong) NSString *userBio;
@property(nonatomic,strong) NSString *birthDay;
@property(nonatomic,strong) NSString *businessFollowersCount;
@property(nonatomic,strong) NSString *commentsCount;
@property(nonatomic,strong) NSString *userEmail;
@property(nonatomic,strong) NSString *favoritesCount;
@property(nonatomic,strong) NSString *firstName;
@property(nonatomic,strong) NSString *gender;
@property(nonatomic,strong) NSString *userId;
@property(nonatomic,strong) NSString *likesCount;
@property(nonatomic,strong) NSString *likesRecievedCount;
@property(nonatomic,strong) NSString *location;
@property(nonatomic,strong) NSString *phoneNo;
@property(nonatomic,strong) NSString *reviewsCount;
@property(nonatomic,strong) NSString *url;
@property(nonatomic,strong) NSString *zipCode;
@property(nonatomic,strong) NSString *avatarImageUrl;
@property(nonatomic,strong) NSString *goldRanksCount;
@property(nonatomic,strong) NSString *siverRanksCount;
@property(nonatomic,strong) NSString *bronzeRanksCount;
@property(nonatomic,strong) NSString *authToken;
@property(nonatomic,strong) NSString *full_name;
@property(nonatomic,strong) NSArray *sharingOutlets;

@property(nonatomic,strong) NSNumber *badge_count;
@property(nonatomic,strong) NSString *city;
@property(nonatomic,strong) NSString *state;
@property(nonatomic,strong) NSString *date;
@property (nonatomic, readwrite) BOOL you_follow_user;
@property (nonatomic, readwrite) BOOL user_follows_you;

@property (nonatomic, strong) NSString *followersCount;
@property (nonatomic, strong) NSString *followingsCount;

@property (nonatomic, strong) NSString *patientID;

@property (nonatomic, strong) NSString * address;
@property (nonatomic, strong) NSString * securityQuestion;
@property (nonatomic, strong) NSString * securityAnswer;

@property (nonatomic, strong) NSString * insurance_provider_id;
@property (nonatomic, strong) NSString * insurance_provider_id2;
@property (nonatomic, strong) NSString * insurance_provider_id3;

@property (nonatomic, strong) NSString * preferredAppointmentContactMethod;
@property (nonatomic, strong) NSString * preferredAppointmentContactData;
@property (nonatomic, strong) NSString * insuranceBackCardUrl;
@property (nonatomic, strong) NSString * insuranceFrontCardUrl;

@property (nonatomic, strong) NSString * insuranceBackTwoCardUrl;
@property (nonatomic, strong) NSString * insuranceFrontTwoCardUrl;

@property (nonatomic, strong) NSString * insuranceBackThreeCardUrl;
@property (nonatomic, strong) NSString * insuranceFrontThreeCardUrl;

@property (nonatomic, strong) NSArray *skipPushNotifications;
@property (nonatomic, strong) NSArray *skipEmailNotifications;
@property (nonatomic, strong) NSArray *notificationPreferences;
@property (nonatomic, strong) NSDictionary *avatarImageUrlDictionary;

@property (nonatomic, retain) NSString *currentRewardRank;
@property (nonatomic, retain) NSString *currentRewardPoints;
@property (nonatomic, retain) NSString *nextRewardRank;
@property (nonatomic, retain) NSString *pointsUntilNextRewardRank;

@end
