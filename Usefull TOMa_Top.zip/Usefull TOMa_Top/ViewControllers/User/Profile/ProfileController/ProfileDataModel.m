//
//  ProfileDataModel.m
//  ChatterPlug
//
//  Created by Pankaj yadav on 30/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ProfileDataModel.h"

@implementation ProfileDataModel

@synthesize isShowGender;
@synthesize isShowLocation;
@synthesize sharingOutlets;
@synthesize passwordStr;
@synthesize userName;
@synthesize avatarImageData;

@synthesize authToken;
@synthesize bronzeRanksCount;
@synthesize siverRanksCount;
@synthesize goldRanksCount;
@synthesize avatarImageUrl;
@synthesize zipCode;
@synthesize url;
@synthesize reviewsCount;
@synthesize phoneNo;
@synthesize location;
@synthesize likesRecievedCount;
@synthesize likesCount;
//@synthesize lastName;
@synthesize userId;
@synthesize gender;
@synthesize firstName;
@synthesize favoritesCount;
@synthesize userEmail;
@synthesize commentsCount;
@synthesize businessFollowersCount;
@synthesize birthDay;
@synthesize userBio;
@synthesize full_name;
@synthesize badge_count;
@synthesize city;
@synthesize state;
@synthesize date;

@synthesize user_follows_you;
@synthesize you_follow_user;

@synthesize followersCount;
@synthesize followingsCount;
@synthesize patientID;
@synthesize address;
@synthesize securityQuestion;
@synthesize securityAnswer;

@synthesize insuranceBackCardData;
@synthesize insuranceFrontCardData;
@synthesize insurance_provider_id;
@synthesize preferredAppointmentContactMethod;
@synthesize preferredAppointmentContactData;
@synthesize insuranceFrontCardUrl;
@synthesize insuranceBackCardUrl,insuranceFrontTwoCardUrl,insuranceBackTwoCardUrl,insuranceFrontThreeCardUrl,insuranceBackThreeCardUrl,insuranceBackCardThreeData,insuranceFrontCardTwoData,insuranceBackCardTwoData,insuranceFrontCardThreeData;

@synthesize skipEmailNotifications;
@synthesize skipPushNotifications;
@synthesize notificationPreferences;
@synthesize avatarImageUrlDictionary;

@synthesize currentRewardPoints;
@synthesize currentRewardRank;
@synthesize pointsUntilNextRewardRank;
@synthesize nextRewardRank;
@synthesize aryInsuranceCards,insurance_provider_id3,insurance_provider_id2;


- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties, other class variables, etc
    [encoder encodeObject:self.isShowGender forKey:@"isShowGender"];
    [encoder encodeObject:self.isShowLocation forKey:@"isShowLocation"];
    [encoder encodeObject:self.sharingOutlets forKey:@"sharingOutlets"];
    [encoder encodeObject:self.passwordStr forKey:@"passwordStr"];
    [encoder encodeObject:self.userName forKey:@"userName"];
    [encoder encodeObject:self.avatarImageData forKey:@"avatarImageData"];
    [encoder encodeObject:self.authToken forKey:@"authToken"];
    [encoder encodeObject:self.bronzeRanksCount forKey:@"bronzeRanksCount"];
    [encoder encodeObject:self.siverRanksCount forKey:@"siverRanksCount"];
    [encoder encodeObject:self.goldRanksCount forKey:@"goldRanksCount"];
    [encoder encodeObject:self.avatarImageUrl forKey:@"avatarImageUrl"];
    [encoder encodeObject:self.zipCode forKey:@"zipCode"];
    [encoder encodeObject:self.url forKey:@"url"];
    [encoder encodeObject:self.reviewsCount forKey:@"reviewsCount"];
    [encoder encodeObject:self.phoneNo forKey:@"phoneNo"];
    [encoder encodeObject:self.location forKey:@"location"];
    [encoder encodeObject:self.likesRecievedCount forKey:@"likesRecievedCount"];
    [encoder encodeObject:self.likesCount forKey:@"likesCount"];
    [encoder encodeObject:self.userId forKey:@"userId"];
    [encoder encodeObject:self.gender forKey:@"gender"];
    [encoder encodeObject:self.firstName forKey:@"firstName"];
    [encoder encodeObject:self.favoritesCount forKey:@"favoritesCount"];
    [encoder encodeObject:self.userEmail forKey:@"userEmail"];
    [encoder encodeObject:self.commentsCount forKey:@"commentsCount"];
    [encoder encodeObject:self.businessFollowersCount forKey:@"businessFollowersCount"];
    [encoder encodeObject:self.birthDay forKey:@"birthDay"];
    [encoder encodeObject:self.userBio forKey:@"userBio"];
    [encoder encodeObject:self.full_name forKey:@"full_name"];
    [encoder encodeObject:self.badge_count forKey:@"badge_count"];
    [encoder encodeObject:self.city forKey:@"city"];
    [encoder encodeObject:self.state forKey:@"state"];
    [encoder encodeObject:self.date forKey:@"date"];
    [encoder encodeBool:self.you_follow_user forKey:@"you_follow_user"];
    [encoder encodeBool:self.user_follows_you forKey:@"user_follows_you"];
    
    [encoder encodeObject:self.followersCount forKey:@"followersCount"];
    [encoder encodeObject:self.followingsCount forKey:@"followingsCount"];
    
    [encoder encodeObject:self.patientID forKey:@"patientID"];
    [encoder encodeObject:self.address forKey:@"address"];
    [encoder encodeObject:self.securityAnswer forKey:@"securityAnswer"];
    [encoder encodeObject:self.securityQuestion forKey:@"securityQuestion"];
    [encoder encodeObject:self.aryInsuranceCards forKey:@"aryInsuranceCards"];
    [encoder encodeObject:self.insurance_provider_id forKey:@"insurance_provider_id"];
    [encoder encodeObject:self.insurance_provider_id2 forKey:@"insurance_provider_id2"];
    [encoder encodeObject:self.insurance_provider_id3 forKey:@"insurance_provider_id3"];

    
    [encoder encodeObject:self.preferredAppointmentContactMethod forKey:@"preferred_appointment_contact_method"];
    [encoder encodeObject:self.preferredAppointmentContactData forKey:@"preferred_appointment_contact_data"];
    
    
    
    [encoder encodeObject:self.skipPushNotifications forKey:@"skipPushNotifications"];
    [encoder encodeObject:self.skipEmailNotifications forKey:@"skipEmailNotifications"];
    [encoder encodeObject:self.notificationPreferences forKey:@"notificationPreferences"];
    [encoder encodeObject:self.avatarImageUrlDictionary forKey:@"avatarImageUrlDictionary"];
    
    [encoder encodeObject:self.currentRewardRank forKey:@"currentRewardRank"];
    [encoder encodeObject:self.currentRewardPoints forKey:@"currentRewardPoints"];
    [encoder encodeObject:self.nextRewardRank forKey:@"nextRewardRank"];
    [encoder encodeObject:self.pointsUntilNextRewardRank forKey:@"pointsUntilNextRewardRank"];
    
    [encoder encodeObject:self.insuranceBackCardUrl forKey:@"insuranceBackCardUrl"];
    [encoder encodeObject:self.insuranceFrontCardUrl forKey:@"insuranceFrontCardUrl"];
    [encoder encodeObject:self.insuranceBackTwoCardUrl forKey:@"insuranceBackTwoCardUrl"];
    [encoder encodeObject:self.insuranceFrontTwoCardUrl forKey:@"insuranceFrontTwoCardUrl"];
    [encoder encodeObject:self.insuranceBackThreeCardUrl forKey:@"insuranceBackThreeCardUrl"];
    [encoder encodeObject:self.insuranceFrontThreeCardUrl forKey:@"insuranceFrontThreeCardUrl"];
    
    [encoder encodeObject:self.insuranceBackCardData forKey:@"insuranceBackCardData"];
    [encoder encodeObject:self.insuranceFrontCardData forKey:@"insuranceFrontCardData"];
    [encoder encodeObject:self.insuranceFrontCardTwoData forKey:@"insuranceFrontCardTwoData"];
    [encoder encodeObject:self.insuranceBackCardTwoData forKey:@"insuranceBackCardTwoData"];
    [encoder encodeObject:self.insuranceBackCardThreeData forKey:@"insuranceBackCardThreeData"];
    [encoder encodeObject:self.insuranceFrontCardThreeData forKey:@"insuranceFrontCardThreeData"];
    
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties, other class vars
        self.isShowGender = [decoder decodeObjectForKey:@"isShowGender"];
        self.isShowLocation = [decoder decodeObjectForKey:@"isShowLocation"];
        self.sharingOutlets = [decoder decodeObjectForKey:@"sharingOutlets"];
        self.passwordStr = [decoder decodeObjectForKey:@"passwordStr"];
        self.userName = [decoder decodeObjectForKey:@"userName"];
        self.avatarImageData = [decoder decodeObjectForKey:@"avatarImageData"];
        self.authToken = [decoder decodeObjectForKey:@"authToken"];
        self.bronzeRanksCount = [decoder decodeObjectForKey:@"bronzeRanksCount"];
        self.siverRanksCount = [decoder decodeObjectForKey:@"siverRanksCount"];
        self.goldRanksCount = [decoder decodeObjectForKey:@"goldRanksCount"];
        self.avatarImageUrl = [decoder decodeObjectForKey:@"avatarImageUrl"];
        self.zipCode = [decoder decodeObjectForKey:@"zipCode"];
        self.url = [decoder decodeObjectForKey:@"url"];
        self.reviewsCount = [decoder decodeObjectForKey:@"reviewsCount"];
        self.phoneNo = [decoder decodeObjectForKey:@"phoneNo"];
        self.location = [decoder decodeObjectForKey:@"location"];
        self.likesRecievedCount = [decoder decodeObjectForKey:@"likesRecievedCount"];
        self.likesCount = [decoder decodeObjectForKey:@"likesCount"];
        self.userId = [decoder decodeObjectForKey:@"userId"];
        self.gender = [decoder decodeObjectForKey:@"gender"];
        self.firstName = [decoder decodeObjectForKey:@"firstName"];
        self.favoritesCount = [decoder decodeObjectForKey:@"favoritesCount"];
        self.userEmail = [decoder decodeObjectForKey:@"userEmail"];
        self.commentsCount = [decoder decodeObjectForKey:@"commentsCount"];
        self.businessFollowersCount = [decoder decodeObjectForKey:@"businessFollowersCount"];
        self.birthDay = [decoder decodeObjectForKey:@"birthDay"];
        self.userBio = [decoder decodeObjectForKey:@"userBio"];
        self.full_name = [decoder decodeObjectForKey:@"full_name"];
        self.badge_count = [decoder decodeObjectForKey:@"badge_count"];
        self.city = [decoder decodeObjectForKey:@"city"];
        self.state = [decoder decodeObjectForKey:@"state"];
        self.date = [decoder decodeObjectForKey:@"date"];
        self.user_follows_you = [decoder decodeBoolForKey:@"user_follows_you"];
        self.you_follow_user = [decoder decodeBoolForKey:@"you_follow_user"];
        
        self.followersCount = [decoder decodeObjectForKey:@"followersCount"];
        self.followingsCount = [decoder decodeObjectForKey:@"followingsCount"];
        
        self.patientID = [decoder decodeObjectForKey:@"patientID"];
        self.address = [decoder decodeObjectForKey:@"address"];
        self.securityQuestion = [decoder decodeObjectForKey:@"securityQuestion"];
        self.securityAnswer = [decoder decodeObjectForKey:@"securityAnswer"];
        self.aryInsuranceCards = [decoder decodeObjectForKey:@"aryInsuranceCards"];
        self.insurance_provider_id = [decoder decodeObjectForKey:@"insurance_provider_id"];
        self.insurance_provider_id2 = [decoder decodeObjectForKey:@"insurance_provider_id2"];
        self.insurance_provider_id3 = [decoder decodeObjectForKey:@"insurance_provider_id3"];

        self.preferredAppointmentContactData = [decoder decodeObjectForKey:@"preferred_appointment_contact_data"];
        self.preferredAppointmentContactMethod = [decoder decodeObjectForKey:@"preferred_appointment_contact_method"];
        
        
        self.skipEmailNotifications = [decoder decodeObjectForKey:@"skipEmailNotifications"];
        self.skipPushNotifications = [decoder decodeObjectForKey:@"skipPushNotifications"];
        self.notificationPreferences = [decoder decodeObjectForKey:@"notificationPreferences"];
        self.avatarImageUrlDictionary = [decoder decodeObjectForKey:@"avatarImageUrlDictionary"];
        
        self.currentRewardRank = [decoder decodeObjectForKey:@"currentRewardRank"];
        self.currentRewardPoints = [decoder decodeObjectForKey:@"currentRewardPoints"];
        self.nextRewardRank = [decoder decodeObjectForKey:@"nextRewardRank"];
        self.pointsUntilNextRewardRank = [decoder decodeObjectForKey:@"pointsUntilNextRewardRank"];
        
        self.insuranceBackCardUrl   = [decoder decodeObjectForKey:@"insuranceBackCardUrl"];
        self.insuranceFrontCardUrl   = [decoder decodeObjectForKey:@"insuranceFrontCardUrl"];
        self.insuranceBackTwoCardUrl   = [decoder decodeObjectForKey:@"insuranceBackTwoCardUrl"];
        self.insuranceFrontTwoCardUrl   = [decoder decodeObjectForKey:@"insuranceFrontTwoCardUrl"];
        self.insuranceBackThreeCardUrl   = [decoder decodeObjectForKey:@"insuranceBackThreeCardUrl"];
        self.insuranceFrontThreeCardUrl   = [decoder decodeObjectForKey:@"insuranceFrontThreeCardUrl"];
        
        self.insuranceBackCardData   = [decoder decodeObjectForKey:@"insuranceBackCardData"];
        self.insuranceFrontCardData   = [decoder decodeObjectForKey:@"insuranceFrontCardData"];
        self.insuranceFrontCardTwoData   = [decoder decodeObjectForKey:@"insuranceFrontCardTwoData"];
        self.insuranceBackCardTwoData   = [decoder decodeObjectForKey:@"insuranceBackCardTwoData"];
        self.insuranceBackCardThreeData   = [decoder decodeObjectForKey:@"insuranceBackCardThreeData"];
        self.insuranceFrontCardThreeData   = [decoder decodeObjectForKey:@"insuranceFrontCardThreeData"];
        
    }
    return self;
}

@end