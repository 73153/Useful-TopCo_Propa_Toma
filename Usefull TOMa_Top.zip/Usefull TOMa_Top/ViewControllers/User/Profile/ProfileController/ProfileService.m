//
//  ProfileController.m
//  ChatterPlug
//
//  Created by Pankaj yadav on 30/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ProfileService.h"
#import "ProfileDataModel.h"
#import "AppDelegate.h"
@implementation ProfileService

@synthesize editInfoDictionary;
@synthesize requestURL;
@synthesize auth_token;
@synthesize userName;
@synthesize deviceToken;
@synthesize apiKey;
@synthesize password;
@synthesize emailAddress;
@synthesize user_id;
@synthesize currentPassword;
@synthesize modifiedPassword;
@synthesize fullName;

- (id)initWithCaller:(id)caller
{
    if (self = [super init]) {
        caller_ = caller;
    }
    return  self;
}

#pragma mark Login User by authenticating userName and password
- (void)authenticateUser {
    @try {
        CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
        parameters.apiKey = apiKey;
        parameters.isDebug = YES;
        parameters.applicationURL = [NSURL URLWithString:requestURL];
        CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
        [service authenticateUserWithUserNameOrEmailId:userName password:password andDeviceToken:self.deviceToken];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didReceiveProfile:(CPUserEntity*)userProfileData withAuthenticationToken:(NSString*) authenticationToken {
    TCSTART
    NSDictionary *userDict = [NSDictionary dictionaryWithObjectsAndKeys:userProfileData,@"user",authenticationToken,@"authToken", nil];
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    ProfileDataModel *dataModal = [appDelegate parseProfileInfo:userDict];
    
    NSDictionary *profileInfoDict = [[NSDictionary alloc]initWithObjectsAndKeys:dataModal,@"ProfileData", nil];
    if ([caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedLoadingProfileInfo:)]) {
        [caller_ didFinishedLoadingProfileInfo:profileInfoDict];
    }
    
    [appDelegate saveUserData:dataModal];
    TCEND
}
- (void)didFailToReceiveProfileWithError:(NSError*) error {
    @try {
        if (caller_ && [caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToLoadProfileInfoWithError:)]) {
            [caller_ didFailToLoadProfileInfoWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark GetProfile Related
- (void)getProfileInfo {
    @try {
        CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
        parameters.apiKey = apiKey;
        parameters.isDebug = YES;
        parameters.applicationURL = [NSURL URLWithString:requestURL];
        parameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        parameters.authenticationToken = auth_token;
        
        CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:caller_];
        [service getUserProfileWithUserId:[NSNumber numberWithInteger:[user_id integerValue]]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark UpdateProfile Related
- (void)updateUserProfile {
    @try {
        CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
        parameters.apiKey = apiKey;
        parameters.isDebug = YES;
        parameters.applicationURL = [NSURL URLWithString:requestURL];
        parameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        parameters.authenticationToken = auth_token;
        
        CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
        CPUserEntity *entity = [[CPUserEntity alloc] init];
        
        if ([self isNotNull:editInfoDictionary]) {
            if ([self isNotNull:[editInfoDictionary objectForKey:@"full_name"]]) {
                entity.name = [editInfoDictionary objectForKey:@"full_name"];
            }
            //            if ([self isNotNull:[editInfoDictionary objectForKey:@"username"]]) {
            //                entity.userName = [editInfoDictionary objectForKey:@"username"];
            //            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"email"]]) {
                entity.emailId = [editInfoDictionary objectForKey:@"email"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"address"]]) {
                entity.address = [editInfoDictionary objectForKey:@"address"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"city"]]) {
                entity.city = [editInfoDictionary objectForKey:@"city"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"state"]]) {
                entity.state = [editInfoDictionary objectForKey:@"state"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"patient_id"]]) {
                entity.patientId = [editInfoDictionary objectForKey:@"patient_id"];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"zip_code"]]) {
                entity.zipCode = [editInfoDictionary objectForKey:@"zip_code"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"phone_number"]]) {
                entity.phoneNumber = [editInfoDictionary objectForKey:@"phone_number"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"gender"]]) {
                if ([[editInfoDictionary objectForKey:@"gender"] rangeOfString:@"M" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                    entity.gender = CPGenderMale;
                } else {
                    entity.gender = CPGenderFemale;
                }
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"birth_day"]]) {
                entity.birthDateString = [editInfoDictionary objectForKey:@"birth_day"];
                
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"avatar_data"]]) {
                entity.avatarImageData = [editInfoDictionary objectForKey:@"avatar_data"];
            }
            //One
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_front_card_data"]]) {
                entity.insuranceFrontCardData = [editInfoDictionary objectForKey:@"insurance_front_card_data"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_back_card_data"]]) {
                entity.insuranceBackCardData = [editInfoDictionary objectForKey:@"insurance_back_card_data"];
            }
            
            /////Vivek change
            //vivek zaptech
            //Two
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_front_card_data_2"]]) {
                entity.insuranceFrontCardData2 = [editInfoDictionary objectForKey:@"insurance_front_card_data_2"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_back_card_data_2"]]) {
                entity.insuranceBackCardData2 = [editInfoDictionary objectForKey:@"insurance_back_card_data_2"];
            }
            
            
            //Three
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_front_card_data_3"]]) {
                entity.insuranceFrontCardData3 = [editInfoDictionary objectForKey:@"insurance_front_card_data_3"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_back_card_data_3"]]) {
                entity.insuranceBackCardData3 = [editInfoDictionary objectForKey:@"insurance_back_card_data_3"];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_provider_id"]]) {
                entity.insuranceProviderId = [editInfoDictionary objectForKey:@"insurance_provider_id"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_provider_2_id"]]) {
                entity.insuranceProviderId2 = [editInfoDictionary objectForKey:@"insurance_provider_2_id"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"insurance_provider_3_id"]]) {
                entity.insuranceProviderId3 = [editInfoDictionary objectForKey:@"insurance_provider_3_id"];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"preferred_appointment_contact_method"]]) {
                entity.preferredAppointmentContactMethod = [editInfoDictionary objectForKey:@"preferred_appointment_contact_method"];
            }
            if ([self isNotNull:[editInfoDictionary objectForKey:@"preferred_appointment_contact_data"]]) {
                entity.preferredAppointmentContactData = [editInfoDictionary objectForKey:@"preferred_appointment_contact_data"];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"show_location"]]) {
                entity.showsLocation = [[editInfoDictionary objectForKey:@"show_location"] boolValue];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"security_question"]]) {
                entity.securityQuestion = [editInfoDictionary objectForKey:@"security_question"];
            }
            
            if ([self isNotNull:[editInfoDictionary objectForKey:@"security_answer"]]) {
                entity.securityAnswer = [editInfoDictionary objectForKey:@"security_answer"];
            }
            
            if([self isNotNull:[editInfoDictionary objectForKey:@"skip_push_notifications"]])
            {
                entity.skipPushNotifications = [editInfoDictionary objectForKey:@"skip_push_notifications"];
            }
            
            if([self isNotNull:[editInfoDictionary objectForKey:@"skip_email_notifications"]])
            {
                entity.skipEmailNotifications = [editInfoDictionary objectForKey:@"skip_email_notifications"];
            }
            
            if([self isNotNull:[editInfoDictionary objectForKey:@"favorite_channel_ids"]])
            {
                entity.channelLikeArray = [editInfoDictionary objectForKey:@"favorite_channel_ids"];
            }
            
            if([self isNotNull:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsAccessKeyId"]])
            {
                entity.awsAccessKeyId = [[NSUserDefaults standardUserDefaults] objectForKey:@"awsAccessKeyId"];
            }
            
            if([self isNotNull:[[NSUserDefaults standardUserDefaults] objectForKey:@"s3BucketName"]])
            {
                entity.s3BucketName = [[NSUserDefaults standardUserDefaults] objectForKey:@"s3BucketName"];
            }
            
            if([self isNotNull:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsSecretAccessKey"]])
            {
                entity.awsSecretAccessKey = [[NSUserDefaults standardUserDefaults] objectForKey:@"awsSecretAccessKey"];
            }
        }
        if ([self isNotNull:entity]) {
            [service updateUserProfileWithProfile:entity];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didUpdateUserProfile:(CPUserEntity*) userProfile {
    NSLog(@"didFinishedUpdatingUserProfile %@",userProfile);
    if ([caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedupdateUserProfile:)]) {
        [caller_ didFinishedupdateUserProfile:userProfile];
    }
    
}

- (void) didFailToUpdateUserProfileWithError:(NSError*) error {
    // NSLog(@"didfailtoUpdateUserProfileWithError %@",errorMsg)
    if (caller_ && [caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToUpdateUserProfileWithErrorMsg:)]) {
        [caller_ didFailToUpdateUserProfileWithErrorMsg:[error localizedDescription]];
    }
}

#pragma mark update password
-(void)updatePassword {
    TCSTART
    CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
    parameters.apiKey = apiKey;
    parameters.isDebug = YES;
    parameters.applicationURL = [NSURL URLWithString:requestURL];
    parameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    parameters.authenticationToken = auth_token;
    
    CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
    if ([self isNotNull:currentPassword] && [self isNotNull:modifiedPassword]) {
        [service changePassword:currentPassword toNewPassword:modifiedPassword];
    }
    TCEND
}
- (void) didChangePassword {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedUpdatingPassword)]) {
        [caller_ didFinishedUpdatingPassword];
    }
    TCEND
}
- (void) didFailToChangePasswordWithError:(NSError*) error {
    TCSTART
    if (caller_ && [caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didfailedToUpdatePassword:)]) {
        [caller_ didfailedToUpdatePassword:[error localizedDescription]];
    }
    TCEND
}

#pragma mark User Sign Request
- (void)signUpUserWithDetails:(NSDictionary *)details {
    @try {
        CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
        parameters.apiKey = apiKey;
        parameters.isDebug = YES;
        parameters.applicationURL = [NSURL URLWithString:requestURL];
        
        CPRegistrationRequestParameters *registerReqParameters = [[CPRegistrationRequestParameters alloc] init];
        
        if ([self isNotNull:[details objectForKey:@"username"]]) {
            registerReqParameters.userName = [details objectForKey:@"username"];
            
        }
        
        if ([self isNotNull:[details objectForKey:@"fullname"]]) {
            registerReqParameters.fullName = [details objectForKey:@"fullname"];
        }
        
        if ([self isNotNull:[details objectForKey:@"email"]]) {
            registerReqParameters.emailId = [details objectForKey:@"email"];
        }
        
        if ([self isNotNull:[details objectForKey:@"password"]]) {
            registerReqParameters.password = [details objectForKey:@"password"];
        }
        
        if ([self isNotNull:[details objectForKey:@"birth_day"]]) {
            registerReqParameters.birthDateString = [details objectForKey:@"birth_day"];
        }
        
        registerReqParameters.deviceToken = deviceToken;
        
        if ([self isNotNull:[details objectForKey:@"patientid"]]) {
            registerReqParameters.patientId = [details objectForKey:@"patientid"];
        }
        
        if ([self isNotNull:[details objectForKey:@"phone_number"]]) {
            registerReqParameters.phoneNumber = [details objectForKey:@"phone_number"];
        }
        
        if ([self isNotNull:[details objectForKey:@"address"]]) {
            registerReqParameters.address = [details objectForKey:@"address"];
        }
        
        if ([self isNotNull:[details objectForKey:@"city"]]) {
            registerReqParameters.city = [details objectForKey:@"city"];
        }
        
        if ([self isNotNull:[details objectForKey:@"state"]]) {
            registerReqParameters.state = [details objectForKey:@"state"];
        }
        
        if ([self isNotNull:[details objectForKey:@"zip_code"]]) {
            registerReqParameters.zipCode = [details objectForKey:@"zip_code"];
        }
        
        if ([self isNotNull:[details objectForKey:@"security_question"]]) {
            registerReqParameters.securityQuestion = [details objectForKey:@"security_question"];
        }
        
        if ([self isNotNull:[details objectForKey:@"security_answer"]]) {
            registerReqParameters.securityAnswer = [details objectForKey:@"security_answer"];
        }
        
        
        CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
        [service registerNewUserWithRegistrationRequestParameters:registerReqParameters];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark ForgotPassword Request
-(void)emailNewPassword {
    @try {
        
        CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
        parameters.apiKey = apiKey;
        parameters.isDebug = YES;
        parameters.applicationURL = [NSURL URLWithString:requestURL];
        CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
        [service mailNewPasswordToEmailId:emailAddress];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didMailNewPassword:(NSDictionary *)result {
    if ([caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedMailingNewPassword:)]) {
        [caller_ didFinishedMailingNewPassword:result];
    }
    
}
- (void) didFailToMailNewPasswordWithError:(NSError*) error {
    if (caller_ && [caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didfailedToMailNewPassword:)]) {
        [caller_ didfailedToMailNewPassword:[error localizedDescription]];
    }
}

- (void)verifySecurityQuestionAnswer:(NSString *)answer {
    TCSTART
    CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
    parameters.apiKey = apiKey;
    parameters.isDebug = YES;
    parameters.applicationURL = [NSURL URLWithString:requestURL];
    CPUserProfileService *service = [[CPUserProfileService alloc] initWithCommonParameters:parameters withDelegate:self];
    [service verifySecurityAnswer:answer toEmailId:emailAddress];
    TCEND
}
- (void)didVerifySecurityAnswer {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didVerifySecurityQuestionAnswer)]) {
        [caller_ didVerifySecurityQuestionAnswer];
    }
    TCEND
}
- (void)didFailToVerifySecurityAnswerWithError:(NSError *)error {
    TCSTART
    if (caller_ && [caller_ conformsToProtocol:@protocol(ProfileServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToVerifySecurityQuestionAnswerWithError:)]) {
        [caller_ didFailedToVerifySecurityQuestionAnswerWithError:[error localizedDescription]];
    }
    TCEND
}
@end
