//
//  ProfileController.h
//  ChatterPlug
//
//  Created by Pankaj yadav on 30/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol ProfileServiceDelegate <NSObject>

@optional
-(void)didFinishedLoadingProfileInfo:(NSDictionary *)results;
-(void)didFailToLoadProfileInfoWithError:(NSString *)errorMsg;

/** update user profile
 */
-(void)didFinishedupdateUserProfile:(CPUserEntity *)entity;
-(void)didFailToUpdateUserProfileWithErrorMsg:(NSString *)errorMsg;

//updating password
-(void)didFinishedUpdatingPassword;
-(void)didfailedToUpdatePassword:(NSString *)errorMsg;

//ForgotPassword
-(void)didFinishedMailingNewPassword:(NSDictionary *)result;
-(void)didfailedToMailNewPassword:(NSString *)errorMsg;

//VerifySecurityAnswer
- (void)didVerifySecurityQuestionAnswer;
- (void)didFailedToVerifySecurityQuestionAnswerWithError:(NSString *)errorMsg;
@end

@interface ProfileService : NSObject<ProfileServiceDelegate,CPUserProfileServiceDelegate>

{
    id caller_;
    NSString *requestURL;       //set the host URL
    NSString *auth_token;       //Set the auth_token of the user
    NSString *deviceToken;
    NSString *apiKey;
    NSString *password;
    NSString *emailAddress;
    NSString *fullName;
    //set the user id
    NSString *user_id;
    NSMutableDictionary *editInfoDictionary;
    NSString *currentPassword;
    NSString *modifiedPassword;
}
@property(nonatomic,  strong) NSMutableDictionary *editInfoDictionary;
@property (nonatomic, strong) NSString *requestURL;
@property (nonatomic, strong) NSString *auth_token;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *fullName;
@property (nonatomic, strong) NSString *deviceToken;
@property (nonatomic, strong) NSString *apiKey;
@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *emailAddress;
@property (nonatomic, strong) NSString *user_id;
@property (nonatomic, strong) NSString *currentPassword;
@property (nonatomic, strong) NSString *modifiedPassword;

- (id)initWithCaller:(id)caller;
- (void)authenticateUser;
- (void)getProfileInfo;
- (void)updateUserProfile;
- (void)updatePassword;
- (void)emailNewPassword;
- (void)verifySecurityQuestionAnswer:(NSString *)answer;
- (void)signUpUserWithDetails:(NSDictionary *)details;
@end
