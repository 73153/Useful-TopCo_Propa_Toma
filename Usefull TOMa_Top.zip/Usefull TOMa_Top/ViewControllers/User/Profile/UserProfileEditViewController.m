//
//  EditView.m
//  ChatterPlug
//
//  Created by Pankaj yadav on 16/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UserProfileEditViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ChatterPlugViewController.h"
#import "NSObject+PE.h"
#import "ProfileService.h"
#import "MainViewController.h"
#import "ChangePasswordViewController.h"

#import "AppDelegate.h"
#import "LoginViewController.h"

#import "UICustomSwitch.h"
#import "ChangeSecurityQuestionViewController.h"
#import "ImageViewController.h"
#import "NotificationPreferenceButton.h"
#import "UIViewOverlayAnimation.h"
#import "Base64.h"
#import "MPImageView.h"
typedef enum
{
    ProfileSectionEditInfo,       //0
    ProfileSectionAvatar,         //1
    ProfileSectionInsurance,      //2
    ProfileSectionContactMethod,  //3
    ProfileSectionNotifications,  //4
    ProfileSectionAbout,          //5
    ProfileSectionCount           //For use as a .length
} ProfileSection;


@implementation UserProfileEditViewController

@synthesize profiledatamodel,frontCard,frontCard2,frontCard3,backCard,backCard2,backCard3;
@synthesize popover,selectedIndex;
- (id)initWithCaller:(id)caller
{
    self = [super init];
    if (self) {
        // Custom initialization
        caller_ = caller;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark - View lifecycle
- (void)viewDidLoad {
    @try {
        [super viewDidLoad];
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        newAvatarImage = nil;
        
        UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
        image.image = [UIImage imageNamed:@"bg"];
        [self.view addSubview:image];
        //[self setProfileAvatarImageURL];
        /** Notification Preferences
         */
        
        notificationArray = [NSArray arrayWithArray:profiledatamodel.notificationPreferences];
        
        //MM_TODO: change "memorialhealthsystem_title" in the array below to the appropriate tomah image
        headerSecName_Arr = [NSArray arrayWithObjects:@"accountinfo_title",@"profile_title",@"insurance_title",@"preferredContactMethod_title",@"notifications_title",@"tomahMemorial_Title", nil];
        NSArray* firstSectionLabel_Array = [NSArray arrayWithObjects:@"Name",@"Email",@"Address",@"City",@"State",@"Zip code",@"Phone",@"Birthdate",@"Gender",@"Patient ID", nil];
        NSArray* firstSectionplaceHolder_array = [NSArray arrayWithObjects:@"Enter First Name",@"Enter Email", nil];
        NSArray * secondSectionLabel_Array = [NSArray arrayWithObjects:@"Password",@"Security", nil];
        NSArray *fourthSectionLabel_Array = [[NSArray alloc]initWithObjects:@"About Tomah Memorial Hospital",@"PatientConnecter's Privacy Policy",@"PatientConnecter's Terms of Use",nil];
        
        
        usStatesArray= [[NSArray alloc] initWithObjects:@"AL",@"AK", @"AZ",@"AR",@"CA",@"CO",@"CT",@"DE",@"FL",@"GA",@"HI",@"ID",@"IL",@"IN",@"IA",@"KS",@"KY",@"LA",@"ME",@"MD",@"MA",@"MI",@"MN",@"MS",@"MO",@"MT",@"NE",@"NV",@"NH",@"NJ",@"NM",@"NY",@"NC",@"ND",@"OH",@"OK",@"OR",@"PA",@"RI",@"SC",@"SD",@"TN",@"TX",@"UT",@"VT",@"VA",@"WA",@"WV",@"WI",@"WY", nil];
        
        
        arrayofLeftLabel_Dictionary = [[NSMutableDictionary alloc]init];
        [arrayofLeftLabel_Dictionary  setObject:firstSectionLabel_Array forKey:@"firstSectionLabel_Array"];
        [arrayofLeftLabel_Dictionary setObject:firstSectionplaceHolder_array forKey:@"firstSectionplaceHolder_array"];
        [arrayofLeftLabel_Dictionary setObject:secondSectionLabel_Array forKey:@"secondSectionLabel_Array"];
        [arrayofLeftLabel_Dictionary setObject:fourthSectionLabel_Array forKey:@"fourthSectionLabel_Array"];
        
        UILabel *headerLabel =[[UILabel alloc] initWithFrame:CGRectMake((appDelegate.window.frame.size.width - 300)/2,13 ,300,45)];
        headerLabel.text = @"MY PROFILE";
        headerLabel.textColor=[UIColor whiteColor];
        headerLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        headerLabel.backgroundColor = [UIColor clearColor];
        headerLabel.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:headerLabel];
        
        UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        saveBtn.frame = CGRectMake(appDelegate.window.frame.size.width - 100, 10, 95, 48);
        [saveBtn setBackgroundImage:[UIImage imageNamed:@"save"] forState:UIControlStateNormal];
        saveBtn.layer.cornerRadius = 5.0;
        saveBtn.layer.masksToBounds = YES;
        [saveBtn addTarget:self action:@selector(saveAction) forControlEvents:UIControlEventTouchUpInside];
        //[saveBtn setHidden:YES];
        [self.view addSubview:saveBtn];
        
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancelBtn.frame = CGRectMake(5,10, 95, 48);
        [cancelBtn setBackgroundImage:[UIImage imageNamed:@"cancel"] forState:UIControlStateNormal];
        cancelBtn.layer.cornerRadius = 5.0;
        
        [cancelBtn addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
        //[cancelBtn setHidden:YES];
        [self.view addSubview:cancelBtn];
        
        UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
        line_ImgView.image = [UIImage imageNamed:@"line"];
        line_ImgView.tag = 4;
        [self.view addSubview:line_ImgView];
        
        CGFloat tableViewOriginX;
        CGFloat tableFooterViewHeight;
        CGRect logoutButtonFrame;
        if (!iPad) {
            if(isiPhone6) {
                headerLabel.frame = CGRectMake((appDelegate.window.frame.size.width-200)/2,5,200,30);
                saveBtn.frame = CGRectMake(appDelegate.window.frame.size.width-65, 7, 60, isiPhone6PLUS?32:30);
                cancelBtn.frame = CGRectMake(5, 7, 64, 30);
                tableViewOriginX = -2.5;
                tableFooterViewHeight = 60;
                logoutButtonFrame = CGRectMake((appDelegate.window.frame.size.width-273)/2, 10, 273, 45);
            }
            else {
                headerLabel.frame = CGRectMake(60,5,200,30);
                saveBtn.frame = CGRectMake(265, 7, 50, 30);
                cancelBtn.frame = CGRectMake(5, 7, 64, 30);
                tableViewOriginX = -2.5;
                tableFooterViewHeight = 60;
                logoutButtonFrame = CGRectMake((325-273)/2, 10, 273, 45);
            }
        } else {
            tableViewOriginX = -30;
            tableFooterViewHeight = 80;
            logoutButtonFrame = CGRectMake((728-355)/2 + 50, 10, 355, 60);
        }
        
        if (CURRENT_DEVICE_VERSION >= 7.0) {
            tableViewOriginX = 5;
        }
        
        /////////creating and adding table view to the view
        editTable = [[UITableView alloc]initWithFrame:CGRectMake(tableViewOriginX, line_ImgView.frame.origin.y + line_ImgView.frame.size.height, appDelegate.window.frame.size.width + (-2 * tableViewOriginX), self.view.frame.size.height - (line_ImgView.frame.origin.y + line_ImgView.frame.size.height)) style:UITableViewStyleGrouped];
        
        editTable.delegate = self;
        editTable.dataSource = self;
        editTable.backgroundView = nil;
        editTable.backgroundColor = [UIColor clearColor];
        
        if (CURRENT_DEVICE_VERSION < 7.0) {
            editTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        } else {
            editTable.separatorStyle = UITableViewCellSeparatorStyleNone;
            if (iPad) {
                logoutButtonFrame = CGRectMake((758-355)/2, 10, 355, 60);
            } else {
                logoutButtonFrame = CGRectMake((appDelegate.window.frame.size.width-10-273)/2, 10, 273, 45);
            }
            editTable.frame = CGRectMake(editTable.frame.origin.x, editTable.frame.origin.y, editTable.frame.size.width, editTable.frame.size.height -20);
        }
        
        UIView *tableFooter_View = [[UIView alloc]initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, tableFooterViewHeight)];
        editTable.tableFooterView = tableFooter_View;
        
        //    /////////creating  Logout button
        //UIButton *logoutButton = [[UIButton alloc]init];//WithFrame:CGRectMake(5, 415, 35, 15)];
        UIButton *logoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [logoutButton setBackgroundImage:[UIImage imageNamed:@"logout"] forState:UIControlStateNormal];
        logoutButton.layer.cornerRadius = 5.0f;
        logoutButton.layer.masksToBounds = YES;
        logoutButton.frame = logoutButtonFrame;
        logoutButton.backgroundColor = [UIColor clearColor];
        [logoutButton addTarget:self action:@selector(logoutTheUser:) forControlEvents:UIControlEventTouchUpInside];
        [tableFooter_View addSubview:logoutButton];
        [self.view addSubview:editTable];
        
        profiledatamodel.aryInsuranceCards = [[NSMutableArray alloc] initWithCapacity:6];
        
        for(int i = 1; i<7; i++) [profiledatamodel.aryInsuranceCards addObject: [NSNull null]];
        
        
        insuranceProvidersArray = [[NSArray alloc] initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"insuranceProviders"]];
        //Adding the preferredContact Methods from business info
        if([[NSUserDefaults standardUserDefaults] objectForKey:@"appointmentContactMethods"])
            preferredContactsArray = (NSArray*)[[NSUserDefaults standardUserDefaults] objectForKey:@"appointmentContactMethods"];
        else
            preferredContactsArray =nil;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
    NSInteger noofRow = 0;
    
    if([self isNotNull:profiledatamodel.insuranceFrontCardUrl])
        noofRow=2;
    if ([self isNotNull:profiledatamodel.insuranceBackCardUrl])
        noofRow=3;
    if( [self isNotNull:profiledatamodel.insuranceFrontTwoCardUrl])
        noofRow=5;
    if ([self isNotNull:profiledatamodel.insuranceBackTwoCardUrl])
        noofRow=6;
    if([self isNotNull:profiledatamodel.insuranceFrontThreeCardUrl])
        noofRow=8;
    if([self isNotNull:profiledatamodel.insuranceBackThreeCardUrl])
        noofRow=9;
    
    if(noofRow>9)
        noofRow=0;
    if (noofRow <= 0)
        noOfInsurancePic = 3;
    else
        noOfInsurancePic = noofRow;
    
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)reloadData {
    [editTable reloadData];
}

//remove the edit view by poping it from the stack.
- (void)cancelAction {
    @try {
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)rewardButtonAction:(id)sender {
    
    NSLog(@"Reward Button Clicked.");
#define CUSTOM_TABBAR_HEIGHT 65
    BusinessRewardsViewController *rewardsViewController = [[BusinessRewardsViewController alloc] initWithFrame:CGRectMake(appDelegate.window.frame.origin.x, appDelegate.window.frame.origin.y, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 10)];
    [self.navigationController pushViewController:rewardsViewController animated:YES];
}

- (void)logoutTheUser:(id)sender {
    
    @try {
        //  NSLog(@"Log out the user");
        //remove the user sign-in/sign-up response which is saved at user standard defaults with the key "userProfile".
        
        [appDelegate clearDatabaseAndRemoveAllObjectsFromDefaults];
        
        //get the database file and delete all entities in coredata.
        NSString *databaseFilePath = [[appDelegate getApplicationDocumentsDirectory] stringByAppendingPathComponent: @"MemorialHealthSystem.sqlite"];
        [appDelegate deleteDatabaseAtFilePath:databaseFilePath];
        
        //create the login screen and add it to window.
        [appDelegate createAndSetLogingViewControllerToWindow];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)setProfileAvatarImageURL {
    TCSTART
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)] == YES && [[UIScreen mainScreen] scale] == 2.00) {
        // RETINA DISPLAY
        if([profiledatamodel.avatarImageUrlDictionary objectForKey:@"profile_retina"])
            profiledatamodel.avatarImageUrl = [profiledatamodel.avatarImageUrlDictionary objectForKey:@"profile_retina"];
    } else {
        if([profiledatamodel.avatarImageUrlDictionary objectForKey:@"profile_normal"])
            profiledatamodel.avatarImageUrl = [profiledatamodel.avatarImageUrlDictionary objectForKey:@"profile_normal"];
    }
    NSLog(@"PostProfileImage:%@",profiledatamodel.avatarImageUrl);
    TCEND
}

- (BOOL)validateInput {
    TCSTART
    if ([self isNull:profiledatamodel.full_name]) {
        [appDelegate showErrorMsg:@"fullname cannot be empty"];
        return NO;
    } else if ([self isNull:profiledatamodel.userEmail]) {
        [appDelegate showErrorMsg:@"Email cannot be empty"];
        return NO;
    } else if ([self isNotNull:profiledatamodel.userEmail] && ![appDelegate validateEmailWithString:profiledatamodel.userEmail]) {
        [appDelegate showErrorMsg:@"Please enter valid email address."];
        return NO;
    }
    return YES;
    TCEND
}

- (void)saveAction {
    @try {
        //Setting the status
        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:@"firstLaunch"];
        
        NSMutableDictionary *editInfoDict = [[NSMutableDictionary alloc]init];
        if ([self validateInput]) {
            
            [editInfoDict setObject:profiledatamodel.full_name?:@"" forKey:@"full_name"];
            
            [editInfoDict setObject:profiledatamodel.userEmail forKey:@"email"];
            
            //            [editInfoDict setObject:profiledatamodel.userName?:@"" forKey:@"username"];
            [editInfoDict setObject:profiledatamodel.address?:@"" forKey:@"address"];
            //            [editInfoDict setObject:profiledatamodel.city?:@"" forKey:@"city"];
            //            [editInfoDict setObject:profiledatamodel.state?:@"" forKey:@"state"];
            [editInfoDict setObject:profiledatamodel.phoneNo?:@"" forKey:@"phone_number"];
            //        if([self isNotNull:profiledatamodel.zipCode]) {
            [editInfoDict setObject:profiledatamodel.zipCode?:@"" forKey:@"zip_code"];
            //        }
            [editInfoDict setObject:profiledatamodel.securityQuestion?:@"" forKey:@"security_question"];
            [editInfoDict setObject:profiledatamodel.securityAnswer?:@"" forKey:@"security_answer"];
            [editInfoDict setObject:profiledatamodel.patientID?:@"" forKey:@"patient_id"];
            if([self isNotNull:profiledatamodel.gender]) {
                [editInfoDict setObject:profiledatamodel.gender forKey:@"gender"];
            }
            
            if([self isNotNull:profiledatamodel.birthDay]) {
                [editInfoDict setObject:profiledatamodel.birthDay forKey:@"birth_day"];
            }
            
            if([self isNotNull:profiledatamodel.avatarImageData]) {
                [editInfoDict setObject:profiledatamodel.avatarImageData forKey:@"avatar_data"];
            }
            
            //    FRONT CARD
            if([self isNotNull:profiledatamodel.insuranceFrontCardData]){
                [editInfoDict setObject:profiledatamodel.insuranceFrontCardData forKey:@"insurance_front_card_data"];
            }
            if([self isNotNull:profiledatamodel.insuranceFrontCardTwoData]){
                [editInfoDict setObject:profiledatamodel.insuranceFrontCardTwoData forKey:@"insurance_front_card_data_2"];
            }
            if([self isNotNull:profiledatamodel.insuranceFrontCardThreeData]){
                [editInfoDict setObject:profiledatamodel.insuranceFrontCardThreeData forKey:@"insurance_front_card_data_3"];
            }
            
            
            //    BACK CARD
            
            if([self isNotNull:profiledatamodel.insuranceBackCardData]){
                [editInfoDict setObject:profiledatamodel.insuranceBackCardData forKey:@"insurance_back_card_data"];
            }
            if([self isNotNull:profiledatamodel.insuranceBackCardTwoData]){
                [editInfoDict setObject:profiledatamodel.insuranceBackCardTwoData forKey:@"insurance_back_card_data_2"];
            }
            if([self isNotNull:profiledatamodel.insuranceBackCardThreeData]){
                [editInfoDict setObject:profiledatamodel.insuranceBackCardThreeData forKey:@"insurance_back_card_data_3"];
            }
            
            /*
             UIImageView *image;
             NSData *imageData;
             for (int i=0; i<6; i++) {
             
             if(![[profiledatamodel.aryInsuranceCards objectAtIndex:i] isEqual:[NSNull null]]){
             image = [profiledatamodel.aryInsuranceCards objectAtIndex:i];
             imageData= UIImageJPEGRepresentation(image.image,0.1);
             
             if(i==0 && [self isNotNull:imageData] && isfrontCardChaged){
             profiledatamodel.insuranceFrontCardData = imageData;
             [editInfoDict setObject:imageData forKey:@"insurance_front_card_data"];
             }
             else if(i==1 && [self isNotNull:imageData] && isbackCardChaged){
             profiledatamodel.insuranceFrontCardTwoData = imageData;
             
             [editInfoDict setObject:imageData forKey:@"insurance_back_card_data"];
             }
             else if(i==2 && [self isNotNull:imageData] && isfrontCard2Chaged){
             profiledatamodel.insuranceFrontCardThreeData = imageData;
             
             [editInfoDict setObject:imageData forKey:@"insurance_front_card_data_2"];
             }
             else if(i==3 && [self isNotNull:imageData] && isbackCard2Chaged){
             profiledatamodel.insuranceBackCardData = imageData;
             
             [editInfoDict setObject:imageData forKey:@"insurance_back_card_data_2"];
             }
             else if(i==4 && [self isNotNull:imageData] && isfrontCard3Chaged){
             profiledatamodel.insuranceBackCardTwoData = imageData;
             
             [editInfoDict setObject:imageData forKey:@"insurance_front_card_data_3"];
             }
             else if(i==5 && [self isNotNull:imageData] && isbackCard3Chaged){
             profiledatamodel.insuranceBackCardThreeData = imageData;
             [editInfoDict setObject:imageData forKey:@"insurance_back_card_data_3"];
             }
             }
             }*/
            NSString *avatarTimeStamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
            if([self isNotNull:avatarTimeStamp]){
                [editInfoDict setObject:avatarTimeStamp forKey:@"insuranceAvatarImageTimeStamp"];
            }
            
            
            if([self isNotNull:profiledatamodel.insurance_provider_id]) {
                [editInfoDict setObject:profiledatamodel.insurance_provider_id forKey:@"insurance_provider_id"];
            }
            
            if([self isNotNull:profiledatamodel.insurance_provider_id2]) {
                [editInfoDict setObject:profiledatamodel.insurance_provider_id2 forKey:@"insurance_provider_2_id"];
            }
            if([self isNotNull:profiledatamodel.insurance_provider_id3]) {
                [editInfoDict setObject:profiledatamodel.insurance_provider_id3 forKey:@"insurance_provider_3_id"];
            }
            if ([self isNotNull:profiledatamodel.isShowLocation]) {
                [editInfoDict setObject:profiledatamodel.isShowLocation forKey:@"show_location"];
            }
            
            if([self isNotNull:profiledatamodel.preferredAppointmentContactMethod]) {
                [editInfoDict setObject:profiledatamodel.preferredAppointmentContactMethod forKey:@"preferred_appointment_contact_method"];
            }
            
            if([self isNotNull:profiledatamodel.preferredAppointmentContactData]) {
                [editInfoDict setObject:profiledatamodel.preferredAppointmentContactData forKey:@"preferred_appointment_contact_data"];
            }
            NSMutableArray *skipPushArray,*doPushArray,*skipEmailArray,*doEmailArray,
            *doLikeArray;
            skipPushArray=[[NSMutableArray alloc] init];
            doPushArray=[[NSMutableArray alloc] init];
            skipEmailArray=[[NSMutableArray alloc] init];
            doEmailArray=[[NSMutableArray alloc] init];
            doLikeArray=[[NSMutableArray alloc] init];
            
            for(NotificationDetails *notify in notificationArray)
            {
                NSLog(@"ID->%@:%@:%@",notify.notificationPreferenceId,notify.pushNotificationStatus?@"YES":@"NO", notify.mailNotificationStatus?@"YES":@"NO");
                if(notify.pushNotificationStatus == YES)
                {
                    [doPushArray addObject:notify.notificationPreferenceId];
                }
                else if(notify.pushNotificationStatus == NO)
                {
                    [skipPushArray addObject:notify.notificationPreferenceId];
                }
                if(notify.mailNotificationStatus == YES)
                {
                    [doEmailArray addObject:notify.notificationPreferenceId];
                }
                else if(notify.mailNotificationStatus == NO)
                {
                    [skipEmailArray addObject:notify.notificationPreferenceId];
                }
                if(notify.notificationEnabled == YES)
                {
                    [doLikeArray addObject:notify.notificationPreferenceId];
                }
            }
            
            [editInfoDict setObject:skipPushArray forKey:@"skip_push_notifications"];
            [editInfoDict setObject:skipEmailArray forKey:@"skip_email_notifications"];
            [editInfoDict setObject:doLikeArray forKey:@"favorite_channel_ids"];
            //            [editInfoDict setObject:doPushArray forKey:@"do_send_push_notification_for"];
            //            [editInfoDict setObject:doEmailArray forKey:@"do_send_email_notification_for"];
            
            if ([caller_ isKindOfClass:[MainViewController class]]) {
                [appDelegate showActivityIndicatorInView:appDelegate.window];
            }
            [appDelegate updateUserInformation:editInfoDict withCallbackObject:caller_];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark -
#pragma mark Table view data source
- (void)configureCell:(ELCTextfieldCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    @try {
        switch (indexPath.section) {
            case 0:
                cell.leftLabel.text = [[arrayofLeftLabel_Dictionary objectForKey:@"firstSectionLabel_Array"] objectAtIndex:indexPath.row];
                break;
            case 1: {
                cell.leftLabel.text = [[arrayofLeftLabel_Dictionary objectForKey:@"secondSectionLabel_Array"] objectAtIndex:indexPath.row];
                if (indexPath.row == 0) {
                    cell.rightTextField.secureTextEntry  = YES;
                }
                break;
            }
            default:
                break;
        }
        cell.indexPath = indexPath;
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark ELCTextFieldCellDelegate Methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath {
    TCSTART
    cellTextFieldRef = _textField;
    [editTable scrollToRowAtIndexPath:_indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    TCEND
}

- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    @try {
        if(indexPath.section == ProfileSectionEditInfo)
        {
            [cellTextFieldRef resignFirstResponder];
        }
        /*
         if (indexPath.row < 6 && indexPath.section == ProfileSectionEditInfo&&indexPath.row!=2) {
         NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row+1 inSection:indexPath.section];
         [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:path] rightTextField] becomeFirstResponder];
         [editTable scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionTop animated:YES];
         }
         else if(indexPath.row==2&&indexPath.section==0){
         //            [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
         //
         //            [self initialiseStatesPickerView];
         NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row+3 inSection:indexPath.section];
         [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:path] rightTextField] becomeFirstResponder];
         [editTable scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionTop animated:YES];
         }
         else if(indexPath.row >= 6 && indexPath.section == ProfileSectionEditInfo){
         [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
         if (indexPath.row == 6) {
         [self configureTheDatePicker];
         }
         }
         */
        if (indexPath.section == ProfileSectionAvatar && indexPath.row == 0) {
            [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
        }
        
        if (indexPath.section == ProfileSectionContactMethod && indexPath.row == 1) {
            [[(ELCTextfieldCell*)[editTable cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
            
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateTextLabelAtIndexPath:(NSIndexPath*)indexPath string:(NSString*)string {
    
    @try {
        
        if(indexPath.section == ProfileSectionEditInfo) {
            if(indexPath.row == 0) {
                profiledatamodel.full_name = string;
            }  else if(indexPath.row == 1) {
                NSString *lowerCaseUserMailId=[string lowercaseString];
                profiledatamodel.userEmail = lowerCaseUserMailId;
            } else if (indexPath.row == 2) {
                //profiledatamodel.userName = string;
                profiledatamodel.address = string;
            } else if (indexPath.row == 3) {
                //profiledatamodel.address = string;
            }
            //			else if (indexPath.row == 4) {
            //                profiledatamodel.city = string;
            //            }
            //            else if (indexPath.row == 5) {
            //                profiledatamodel.state = string;
            //            }
            else if (indexPath.row == 5) {
                profiledatamodel.zipCode = string;
            } else if (indexPath.row == 6) {
                profiledatamodel.phoneNo = string;
            }
        }else if(indexPath.section == ProfileSectionContactMethod){
            if (indexPath.row == 1) {
                profiledatamodel.preferredAppointmentContactData = string;
            }
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark
#pragma TableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return ProfileSectionCount;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == ProfileSectionInsurance) {
        if (noOfInsurancePic < 9 )
            return 50.0;
    }
    return 0.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section == ProfileSectionEditInfo) {
        return 1;
    }
    if (iPad) {
        if(section == ProfileSectionInsurance || section == ProfileSectionContactMethod || section == ProfileSectionNotifications || section == ProfileSectionAbout) {
            if (section == ProfileSectionInsurance|| section == ProfileSectionContactMethod || section == ProfileSectionNotifications || section == ProfileSectionAbout) {
                return 80.0;
            }
            return 65.0;
        } else {
            return 180;
        }
    } else {
        if(section == ProfileSectionInsurance || section == ProfileSectionContactMethod || section == ProfileSectionNotifications || section == ProfileSectionAbout) {
            if (section == ProfileSectionInsurance|| section == ProfileSectionContactMethod || section == ProfileSectionNotifications || section == ProfileSectionAbout) {
                return 75.0;
            }
            return 60.0;
        } else {
            return 160;
        }
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == ProfileSectionEditInfo) {
        return 10;
    } else if(section == ProfileSectionAvatar) {
        return 2;
    } else if(section == ProfileSectionInsurance) {
        return noOfInsurancePic;
    } else if(section == ProfileSectionContactMethod){
        //        if ([self isNotNull:profiledatamodel.preferredAppointmentContactMethod]&&[profiledatamodel.preferredAppointmentContactMethod isEqualToString:@"Letter to Address"]) {
        //            return 1;
        //        }
        return 1;
    }
    else if(section == ProfileSectionNotifications) {
        if([notificationArray count] > 0) {
            return [notificationArray count];
        } else {
            return 1;
        }
    }
    else if(section == ProfileSectionAbout) {
        return 3;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        if(section == ProfileSectionEditInfo){
            return [[UIView alloc] initWithFrame:CGRectZero];
        }
        UIView *headerView = [[UIView alloc] init];
        UIImage *headerImg = [UIImage imageNamed:[headerSecName_Arr objectAtIndex:section]];
        
        //        if (section == ProfileSectionInsurance) {
        headerView.frame = CGRectMake(0, 0, headerImg.size.width, headerImg.size.height);
        //        }else{
        //            headerView.frame = CGRectMake(0, 0.0, headerImg.size.width, headerImg.size.height);
        //        }
        
        
        headerView.backgroundColor = [UIColor clearColor];
        
        CGRect headerImgViewRect;
        CGRect titleLabelRect;
        CGRect changeAvatarImgRect;
        CGRect avatarBtnRect;
        if (CURRENT_DEVICE_VERSION < 7.0) {
            if (iPad) {
                if (section == ProfileSectionContactMethod||section == ProfileSectionAbout || section == ProfileSectionNotifications) {
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 460)/2, 20, 500, 55);
                }else{
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 460)/2, 5, 500, 55);
                }
                //                if (section!=3) {
                titleLabelRect = CGRectMake(30, 30, 768,30);
                //                }else{
                //                titleLabelRect = CGRectMake(30, 60, 768,30);
                //                }
                
                
                changeAvatarImgRect = CGRectMake(10, 5, 65, 65);
                avatarBtnRect = CGRectMake(40, 100, 745, 75);
            } else {
                if (section == ProfileSectionContactMethod || section == ProfileSectionAbout || section == ProfileSectionNotifications) {
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 297)/2, 30, 297, 30);
                    
                }else{
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 297)/2, 15, 297, 30);
                    
                }
                
                //                if (section !=3) {
                titleLabelRect = CGRectMake(0, 43, 320, 30);
                //                }else{
                //                titleLabelRect = CGRectMake(0, 13, 320, 30);
                //                }
                changeAvatarImgRect = CGRectMake(10, 7, 50, 50);
                avatarBtnRect = CGRectMake(10, 80, 305, 65);
            }
        } else {
            if (iPad) {
                if (section== 4 ||section == ProfileSectionAbout || section == ProfileSectionNotifications) {
                    headerImgViewRect = CGRectMake((748 - 500)/2, 20, 500, 55);
                }else{
                    headerImgViewRect = CGRectMake((748 - 500)/2, 5, 500, 55);
                }
                
                titleLabelRect = CGRectMake(3, 60, 748,30);
                changeAvatarImgRect = CGRectMake(10, 5, 65, 65);
                avatarBtnRect = CGRectMake(3, 100, 755, 75);
            } else {
                if (section == ProfileSectionContactMethod||section == ProfileSectionAbout || section == ProfileSectionNotifications) {
                    headerImgViewRect = CGRectMake((310 - 297)/2, 30, appDelegate.window.frame.size.width-33, 30);
                }else{
                    headerImgViewRect = CGRectMake((310 - 297)/2, 15, appDelegate.window.frame.size.width-33, 30);
                }
                
                titleLabelRect = CGRectMake(5, 43, appDelegate.window.frame.size.width-30, 30);
                changeAvatarImgRect = CGRectMake(10, 7, 50, 50);
                if(isiPhone6){
                    avatarBtnRect = CGRectMake(0, 80, appDelegate.window.frame.size.width-10, 65);
                }
                else
                    avatarBtnRect = CGRectMake(0, 80, 310, 65);
            }
        }
        
        //        if (section != 3) {
        UIImageView *headerImgView = [[UIImageView alloc]initWithFrame:headerImgViewRect];
        headerImgView.image = headerImg;
        
        [headerView addSubview:headerImgView];
        
        headerImgView = nil;
        //        }
        if(section == ProfileSectionAvatar) {
            
            UILabel *titlelabel = [[UILabel alloc] initWithFrame: titleLabelRect];
            titlelabel.textAlignment = NSTextAlignmentCenter;
            titlelabel.textColor = [UIColor grayColor];
            if (iPad) {
                titlelabel.font = [UIFont fontWithName:titleFontName size:22];
            } else {
                titlelabel.font = [UIFont fontWithName:titleFontName size:11];
            }
            
            titlelabel.numberOfLines = 2;
            titlelabel.lineBreakMode = NSLineBreakByWordWrapping;
            titlelabel.backgroundColor = [UIColor clearColor];
            //            titlelabel.text = @"     Mobile app users must be atleast 13 years of age";
            titlelabel.text = @"Mobile app users must be at least 13 years of age";
            [headerView addSubview:titlelabel];
            
            UIImageView *changeAvatarImage = [[UIImageView alloc]initWithFrame:changeAvatarImgRect];
            //            changeAvatarImage.backgroundColor = [UIColor whiteColor];
            if(newAvatarImage) {
                changeAvatarImage.image = newAvatarImage;
            } else {
                if ([self isNotNull:profiledatamodel.avatarImageUrl]) {
                    if([profiledatamodel.avatarImageUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.avatarImageUrl rangeOfString:@"https://"].location != NSNotFound)
                    {
                        [changeAvatarImage setImageWithURL:[NSURL URLWithString:profiledatamodel.avatarImageUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
                        //[changeAvatarImage setImageWithURL:[NSURL URLWithString:profiledatamodel.avatarImageUrl]];
                    } else {
                        changeAvatarImage.image = [UIImage imageNamed:@"default-avatar-user"];
                    }
                } else {
                    changeAvatarImage.image = [UIImage imageNamed:@"default-avatar-user"];
                }
            }
            /////////
            changeAvatarImage.layer.cornerRadius = 4.0;
            changeAvatarImage.layer.masksToBounds = YES;
            UIButton * avatarButton = [UIButton buttonWithType:UIButtonTypeCustom];
            avatarButton.frame = avatarBtnRect;
            [avatarButton setBackgroundImage:[UIImage imageNamed:@"change_avatar"] forState:UIControlStateNormal];
            [avatarButton addTarget:self action:@selector(changeAvatarAction:  withEvent:) forControlEvents:UIControlEventTouchUpInside];
            [avatarButton setEnabled:TRUE];
            //
            UIButton * cardBtn = nil;
            //
            cardBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            cardBtn.frame = changeAvatarImgRect;
            
            [cardBtn addTarget:self action:@selector(avatarClicked: withEvent:) forControlEvents:UIControlEventTouchUpInside];
            [cardBtn setEnabled:TRUE];
            cardBtn.tag = 7;
            
            //
            
            //            [avatarButton addSubview:changeImage];
            //            [avatarButton addSubview:cardBtn];
            //            [avatarButton addSubview:textLbl];
            
            //
            
            [avatarButton addSubview:changeAvatarImage];
            //TODO
            [avatarButton addSubview:cardBtn];
            
            [headerView addSubview:avatarButton];
        }
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)insertRowsAtIndexPaths:(NSArray *)indexPaths withRowAnimation:(UITableViewRowAnimation)animation;
{
    [editTable reloadData];
}

-(void)btnAction
{
    if (noOfInsurancePic <=3)
        noOfInsurancePic = 6;
    else
        noOfInsurancePic = 9;
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%ld",(long)noOfInsurancePic] forKey:@"noOfInsurance"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [editTable reloadData];
}

//ProfileSectionInsurance
- (UIView *) tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *viewFooter;
    if (section == ProfileSectionInsurance) {
        if (noOfInsurancePic < 9 ) {
            viewFooter = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
            UIButton *btnAdd = [[UIButton alloc] initWithFrame:CGRectMake(self
                                                                          .view.frame.size.width- 100, 0, 100, 50)];
            [btnAdd setTitle:@"ADD" forState:UIControlStateNormal];
            [btnAdd addTarget:self action:@selector(btnAction) forControlEvents:UIControlEventTouchUpInside];
            [viewFooter addSubview:btnAdd];
            return viewFooter;
        }
    }
    return nil;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == ProfileSectionInsurance)
    {
        if (isiPhone6PLUS) {
            return 75;
        }
        return (iPad?75:65);
    }
    else if(indexPath.section == ProfileSectionNotifications) {
        if([notificationArray count] > 0) {
            
            NotificationDetails *notificaDetails = (NotificationDetails*)[notificationArray objectAtIndex:indexPath.row];
            
            return [self getCellHeightForNotificationDetails:notificaDetails];
        }
    }
    
    if (isiPhone6PLUS) {
        return 70;
    }
    else
        return (iPad?70:50);
}

- (CGFloat)getCellHeightForNotificationDetails:(NotificationDetails *)notificationDetails {
    TCSTART
    float height;
    if (isiPhone6PLUS) {
        height = 70;
    }else
        height = (iPad ? 70 : 50);
    CGSize size =  [notificationDetails.notificationPreference sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?16.0f:notificationTextFontSize] constrainedToSize:CGSizeMake(iPad?590:200,54444) lineBreakMode:NSLineBreakByWordWrapping];
    if(size.height > (height - 10))
        if (isiPhone6PLUS) {
            return size.height +30;
        }
        else
            return size.height + 10;
        else
            return height;
    TCEND
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        //        CGRect cellBgFrame;
        CGRect genderSwitchRect;
        CGRect leftLabelFrame;
        CGRect rightLabelFrame;
        CGFloat cellHeight;
        if (indexPath.section == ProfileSectionInsurance) {
            if (isiPhone6PLUS) {
                cellHeight = 75;
            }
            else
                cellHeight = (iPad?75:65);
        } else {
            if (isiPhone6PLUS) {
                cellHeight = 70;
            }
            else
                cellHeight = (iPad?70:50);
        }
        if (iPad) {
            genderSwitchRect = CGRectMake(250, 17.5, 88, 35);
            leftLabelFrame = CGRectMake(10, 0, 200, 70);
            rightLabelFrame = CGRectMake(250, 0, 541, 70);
        } else {
            if(isiPhone6PLUS) {
                genderSwitchRect = CGRectMake(205, 5, 88, 60);
                leftLabelFrame = CGRectMake(10, 15, 150, 33);
                rightLabelFrame = CGRectMake(130, 15, 150, 33);
            }
            else
            {
                genderSwitchRect = CGRectMake(205, 9.0, 88, 31);
                leftLabelFrame = CGRectMake(10, 5, 150, 33);
                rightLabelFrame = CGRectMake(130, 5, 150, 33);
            }
        }
        
        ProfileDataModel *localProfiledatamodel = profiledatamodel;
        //////for first section of edit ui
        if (indexPath.section == ProfileSectionEditInfo) {
            if (indexPath.row < 7) { //initialize the ELCTextfieldCell to have the left side label and right side textfield
                //                UIImageView*   cellBgView = nil;
                NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
                ELCTextfieldCell *cell = (ELCTextfieldCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                
                if (cell == nil) {
                    cell = [[ELCTextfieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                }
                
                
                [self configureCell:cell atIndexPath:indexPath];
                
                switch (indexPath.row) {
                    case 0:
                    {
                        if ([self isNotNull:localProfiledatamodel.full_name]) {
                            cell.rightTextField.text = localProfiledatamodel.full_name;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                    }
                        break;
                    case 1:
                    {
                        if ([self isNotNull:localProfiledatamodel.userEmail]) {
                            cell.rightTextField.text = localProfiledatamodel.userEmail;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                        cell.rightTextField.keyboardType = UIKeyboardTypeEmailAddress;
                    }
                        break;
                    case 2:
                    {
                        if ([self isNotNull:localProfiledatamodel.address]) {
                            cell.rightTextField.text = localProfiledatamodel.address;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                    }
                        break;
                    case 3:
                    {
                        
                        if ([self isNotNull:localProfiledatamodel.city]) {
                            cell.rightTextField.text = localProfiledatamodel.city;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                        //					cell.rightTextField.editing = FALSE;
                        cell.rightTextField.enabled = FALSE;
                        cell.rightTextField.textColor = [UIColor grayColor];
                    }
                        break;
                    case 4:
                    {
                        
                        if ([self isNotNull:localProfiledatamodel.state]) {
                            cell.rightTextField.text = localProfiledatamodel.state;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                        //					cell.rightTextField.editing = FALSE;
                        cell.rightTextField.enabled = FALSE;
                        cell.rightTextField.textColor = [UIColor grayColor];
                    }
                        break;
                    case 5:
                    {
                        
                        if ([self isNotNull:localProfiledatamodel.zipCode]) {
                            cell.rightTextField.text = localProfiledatamodel.zipCode;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                    }
                        break;
                    case 6:
                    {
                        
                        if ([self isNotNull:localProfiledatamodel.phoneNo]) {
                            cell.rightTextField.text = localProfiledatamodel.phoneNo;
                        } else {
                            cell.rightTextField.text = @"";
                        }
                        cell.rightTextField.returnKeyType = UIReturnKeyNext;
                    }
                        break;
                        
                    default:
                        break;
                }
                cell.rightTextField.returnKeyType=UIReturnKeyDone;
                
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH ];
                }
                cell.backgroundColor = [UIColor clearColor];
                //                []
                return cell;
            }
            if (indexPath.row > 6) { // show the date & gender by creating a new cell which is of UITableCell
                
                NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                UILabel *leftLabel = nil;
                UILabel *rightLabel = nil;
                //                UIImageView *cellBgView = nil;
                //UISlider *genderSlider = nil;
                UICustomSwitch *genderSwitch = nil;
                
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                    //                    cellBgView = [[UIImageView alloc]initWithFrame:cellBgFrame];
                    //                    [cell.backgroundView addSubview:cellBgView];
                    //                    cellBgView.tag = 2;
                    
                    
                    genderSwitch = [UICustomSwitch switchWithLeftText:@"" andRight:@""];
                    genderSwitch.frame = genderSwitchRect;
                    [genderSwitch setThumbImage:[UIImage imageNamed:@"sliderThumb" ] forState:UIControlStateNormal];
                    [genderSwitch setMinimumTrackImage:[[UIImage imageNamed:@"male"]resizableImageWithCapInsets:UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)] forState:UIControlStateNormal];
                    [genderSwitch setMaximumTrackImage:[[UIImage imageNamed:@"female"]resizableImageWithCapInsets:UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)] forState:UIControlStateNormal];
                    genderSwitch.tag = -5;
                    [genderSwitch addTarget:self action:@selector(switchFlipped:) forControlEvents:UIControlEventValueChanged];
                    [cell.contentView addSubview:genderSwitch];
                    
                    leftLabel  = [[UILabel alloc]initWithFrame:leftLabelFrame];
                    leftLabel.backgroundColor = [UIColor clearColor];
                    leftLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                    leftLabel.textColor = [UIColor grayColor];
                    leftLabel.textAlignment = NSTextAlignmentLeft;
                    [leftLabel setTag:3];
                    [cell.contentView addSubview:leftLabel];
                    
                    rightLabel = [[UILabel alloc]initWithFrame:rightLabelFrame];
                    rightLabel.backgroundColor =[UIColor clearColor];
                    rightLabel.textColor = [UIColor whiteColor];
                    rightLabel.textAlignment = NSTextAlignmentLeft;
                    rightLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
                    rightLabel.tag = 4;
                    [cell.contentView addSubview:rightLabel ];
                }
                
                if (!genderSwitch)
                    genderSwitch = (UICustomSwitch *)[cell.contentView viewWithTag:-5];
                //                if (!cellBgView)
                //                    cellBgView = (UIImageView *)[cell.backgroundView viewWithTag:2];
                if (!leftLabel)
                    leftLabel = (UILabel*)[cell viewWithTag:3];
                if (!rightLabel)
                    rightLabel = (UILabel *)[cell.contentView viewWithTag:4];
                
                genderSwitch.hidden = YES;
                
                if(indexPath.row == 7) {
                    if ([self isNotNull:localProfiledatamodel.birthDay]) {
                        rightLabel.text = localProfiledatamodel.birthDay;
                    } else {
                        rightLabel.text = @"";
                    }
                }
                
                if(indexPath.row == 8) {
                    genderSwitch.hidden = NO;
                    
                    if ([self isNotNull:localProfiledatamodel.gender] && [localProfiledatamodel.gender  isEqualToString:@"M"]) {
                        genderSwitch.value = 1;
                    } else {
                        genderSwitch.value = 0;
                    }
                }
                
                if (indexPath.row == 9) {
                    if ( [self isNotNull:localProfiledatamodel.patientID]) {
                        rightLabel.text = localProfiledatamodel.patientID;
                    } else {
                        rightLabel.text = @"";
                    }
                }
                
                leftLabel.text = [[arrayofLeftLabel_Dictionary objectForKey:@"firstSectionLabel_Array"] objectAtIndex:indexPath.row];
                
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
                }
                return cell;
            }
        }
        /////for second section of UI which consists of
        if (indexPath.section == ProfileSectionAvatar) {
            
            NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
            ELCTextfieldCell *cell = (ELCTextfieldCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[ELCTextfieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate addBackgroundViewToTheCell:cell];
                }
            }
            
            [self configureCell:cell atIndexPath:indexPath];
            
            if (indexPath.row == 0) {
                if ([self isNotNull:localProfiledatamodel.passwordStr]) {
                    cell.rightTextField.text = localProfiledatamodel.passwordStr;
                } else {
                    cell.rightTextField.text = @"";
                }
                
            } else {
                cell.rightTextField.text = @"";
            }
            cell.rightTextField.enabled = NO;
            if (iPad) {
                cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
            } else {
                cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
            }
            if(iPhone && CURRENT_DEVICE_VERSION >= 8.0 && isiPhone6PLUS) {
                CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
                cell.accessoryView=nil;
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
                [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                [cell.contentView addSubview:accessoryimgView];
                
            }
            cell.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
            }
            return cell;
        }
        if (indexPath.section == ProfileSectionInsurance) {
            
            if (indexPath.row == 0 || indexPath.row==3 || indexPath.row==6) {
                NSString *CellIdentifier = @"Select Insurance";
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                UILabel *providerLabel = nil;
                
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                    providerLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, CELL_CONTENT_WIDTH, cellHeight)];
                    providerLabel.backgroundColor =[UIColor clearColor];
                    providerLabel.textColor = [UIColor whiteColor];
                    providerLabel.textAlignment = NSTextAlignmentLeft;
                    providerLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
                    providerLabel.tag = indexPath.row+4;
                    //                    [cell.backgroundView:[UIImage imageNamed:@"AddCard"] forState:UIControlStateNormal];
                    //                    cell.backgroundView =[[UIImageView alloc] initWithImage:[ [UIImage imageNamed:@"AddCard"] stretchableImageWithLeftCapWidth:0.0 topCapHeight:5.0] ];
                    //cell.backgroundView =[[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"AddCard"] stretchableImageWithLeftCapWidth:0.0 topCapHeight:5.0]];
                    
                    [cell.contentView addSubview:providerLabel];
                }
                
                if (!providerLabel)
                    providerLabel = (UILabel *)[cell.contentView viewWithTag:indexPath.row+4];
                
                if(indexPath.row == 0 && providerLabel.tag==4) {
                    if ([self isNotNull:[self getInsuranceProviderName:0]]) {
                        providerLabel.text = [self getInsuranceProviderName:0];
                        providerLabel.textColor = [UIColor whiteColor];
                    }
                    else {
                        providerLabel.text = @"Select insurance provider ";
                        providerLabel.textColor = [UIColor lightGrayColor];
                    }
                    
                }
                else if(indexPath.row==3 && providerLabel.tag==7) {
                    if ([self isNotNull:[self getInsuranceProviderName:1]]) {
                        providerLabel.text = [self getInsuranceProviderName:1];
                        providerLabel.textColor = [UIColor whiteColor];
                    }
                    else {
                        providerLabel.text = @"Select insurance provider #2";
                        providerLabel.textColor = [UIColor lightGrayColor];
                    }
                }
                else {
                    if ([self isNotNull:[self getInsuranceProviderName:2]]) {
                        providerLabel.text = [self getInsuranceProviderName:2];
                        providerLabel.textColor = [UIColor whiteColor];
                    }
                    else {
                        providerLabel.text = @"Select insurance provider #3";
                        providerLabel.textColor = [UIColor lightGrayColor];
                    }
                }
                
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
                }
                if (iPad) {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
                } else {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
                }
                if(iPhone && CURRENT_DEVICE_VERSION >= 8.0 && isiPhone6PLUS) {
                    CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
                    cell.accessoryView=nil;
                    UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
                    [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                    [cell.contentView addSubview:accessoryimgView];
                }
                return cell;
            } else {
                NSString *CellIdentifier = @"Insurance";
                UIImageView *changeImage = nil;
                UIButton * avatarButton = nil;
                UIButton * cardBtn = nil;
                UIButton * imageButton = nil;
                
                UILabel * textLbl = nil;
                CGRect changeAvatarImgRect;
                CGRect avatarBtnRect;
                CGRect txtLblRect;
                CGRect imageButtonRect;
                if (CURRENT_DEVICE_VERSION < 7.0) {
                    if (iPad) {
                        changeAvatarImgRect = CGRectMake(10, 5, 65, 65);
                        avatarBtnRect = CGRectMake(40, 0, 745, 77);
                        txtLblRect = CGRectMake((700 - 250)-10, 22.5, 250, 30);
                    }                    else {
                        changeAvatarImgRect = CGRectMake(10, 7.5, 50, 50);
                        avatarBtnRect = CGRectMake(10, 0, 305, 66);
                        txtLblRect = CGRectMake((280-150)-5, 17.5, 150, 30);
                    }
                } else {
                    if (iPad) {
                        changeAvatarImgRect = CGRectMake(10, 5, 65, 65);
                        avatarBtnRect = CGRectMake(3, 0, 755, 77);
                        txtLblRect = CGRectMake((700 - 250)-10, 22.5, 250, 30);
                        imageButtonRect = CGRectMake(10, 5, 65, 65);
                        
                    }
                    else {
                        changeAvatarImgRect = CGRectMake(10, 12.5, 50, 50);
                        imageButtonRect = CGRectMake(10, 12.5, 50, 50);
                        avatarBtnRect = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, 66);
                        txtLblRect = CGRectMake(((appDelegate.window.frame.size.width-40)-150)-2, 17.5, 150, 30);
                        if(isiPhone6) {
                            txtLblRect = CGRectMake(((appDelegate.window.frame.size.width-40)-150)-2-6, 17.5, 150, 30);
                        }
                        if (isiPhone6PLUS) {
                            changeAvatarImgRect = CGRectMake(10, 5, 65, 65);
                            avatarBtnRect = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, 75);
                            txtLblRect = CGRectMake(((appDelegate.window.frame.size.width-40)-150)-60, 20.0, 200, 30);
                            imageButtonRect =CGRectMake(10, 5, 65, 65);
                        }
                    }
                }
                
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    //                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    //                    [appDelegate addBackgroundViewToTheCell:cell];
                    //                }
                    changeImage = [[UIImageView alloc] init];
                    changeImage.frame = changeAvatarImgRect;
                    changeImage.layer.cornerRadius = 4.0;
                    changeImage.tag = indexPath.row+8888;
                    changeImage.layer.masksToBounds = YES;
                    
                    textLbl = [[UILabel alloc] initWithFrame:txtLblRect];
                    textLbl.textAlignment = NSTextAlignmentRight;
                    textLbl.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                    textLbl.backgroundColor = [UIColor clearColor];
                    textLbl.textColor = [UIColor lightGrayColor];
                    textLbl.tag = 3;
                    
                    avatarButton = [UIButton buttonWithType:UIButtonTypeCustom];
                    avatarButton.frame = avatarBtnRect;
                    [avatarButton setBackgroundImage:[UIImage imageNamed:@"AddCard"] forState:UIControlStateNormal];
                    [avatarButton addTarget:self action:@selector(changeAvatarAction: withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [avatarButton setEnabled:TRUE];
                    avatarButton.tag = indexPath.row+5001;
                    
                    //
                    cardBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                    cardBtn.frame = changeAvatarImgRect;
                    
                    [cardBtn addTarget:self action:@selector(avatarClicked: withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [cardBtn setEnabled:TRUE];
                    cardBtn.tag = 5;
                    
                    //Image button change
                    imageButton = [UIButton buttonWithType:UIButtonTypeCustom];
                    imageButton.frame = imageButtonRect;
                    if(iPad)
                        [imageButton setBackgroundImage:nil forState:UIControlStateNormal];
                    else
                        [imageButton setBackgroundImage:[UIImage imageNamed:@"AddCard"] forState:UIControlStateNormal];
                    [imageButton addTarget:self action:@selector(viewCardImage:) forControlEvents:UIControlEventTouchUpInside];
                    imageButton.tag = indexPath.row+8001;
                    if(imageButton.hidden==true)
                        imageButton.hidden=false;
                    [avatarButton addSubview:cardBtn];
                    [avatarButton addSubview:changeImage];
                    
                    CALayer *layer = imageButton.layer;
                    layer.backgroundColor = [[UIColor clearColor] CGColor];
                    imageButton.opaque=YES;
                    [avatarButton addSubview:imageButton];
                    [avatarButton addSubview:textLbl];
                    [cell addSubview:avatarButton];
                }
                NSInteger localSelectedIndexPath = selectedIndex;
                if ([self isNull:avatarButton]) {
                    avatarButton = (UIButton *)[cell viewWithTag:indexPath.row+5001];
                }
                if ([self isNull:changeImage] && localSelectedIndexPath == indexPath.row) {
                    changeImage = (UIImageView *)[avatarButton viewWithTag:indexPath.row+8888];
                }
                if(changeImage.hidden==true)
                    changeImage.hidden=false;
                if ([self isNotNull:cardBtn]) {
                    cardBtn = (UIButton *)[avatarButton viewWithTag:5];
                }
                if (!textLbl) {
                    textLbl = (UILabel *)[avatarButton viewWithTag:3];
                }
                UIImageView *imageView;
                if (indexPath.row == 1 || indexPath.row == 4 || indexPath.row ==7) {
                    textLbl.text = @"Change Card Front";
                    
                    if(indexPath.row == 1 )
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-1];
                    else if(indexPath.row == 4)
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-2];
                    else if(indexPath.row == 7)
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-3];
                    
                    
                    if(indexPath.row == 1 && [self isNotNull:localProfiledatamodel.insuranceFrontCardData]){
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardData];
                    }
                    else if(indexPath.row == 4 && [self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData]){
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardTwoData];
                    }
                    else if(indexPath.row == 7 && [self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData])
                    {
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardThreeData];
                    }
                    
                    if(imageView!=nil && !([imageView isEqual:[NSNull null]])){
                        changeImage.image = imageView.image;
                        if(indexPath.row == 1 && localSelectedIndexPath==1)
                            frontCard=changeImage.image;
                        if(indexPath.row == 4 && localSelectedIndexPath==4)
                            frontCard2=changeImage.image;
                        if(indexPath.row == 7 && localSelectedIndexPath==7)
                            frontCard3=changeImage.image;
                    }
                    else if ([self isNotNull:localProfiledatamodel.insuranceFrontCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceFrontTwoCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceFrontThreeCardUrl]) {
                        NSString *thumbUrl;
                        if(indexPath.row == 1 && localProfiledatamodel.insuranceFrontCardUrl)
                        {
                            thumbUrl = localProfiledatamodel.insuranceFrontCardUrl;
                            // thumbUrl = [thumbUrl stringByReplacingOccurrencesOfString:@"retina"
                            // withString:@"thumb"];
                        }
                        if(indexPath.row == 4 && localProfiledatamodel.insuranceFrontTwoCardUrl)
                            thumbUrl = localProfiledatamodel.insuranceFrontTwoCardUrl;
                        if(indexPath.row == 7 && localProfiledatamodel.insuranceFrontThreeCardUrl)
                            thumbUrl = localProfiledatamodel.insuranceFrontThreeCardUrl;
                        
                        if([self isNotNull:thumbUrl]){
                            thumbUrl = [thumbUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                           withString:@"retina_thumb"];
                            
                            [changeImage setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
                            
                            if(indexPath.row == 1 ){
                                frontCard=changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-1 withObject:changeImage];
                            }
                            else if(indexPath.row == 4){
                                frontCard2 = changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-2 withObject:changeImage];
                            }
                            else if(indexPath.row == 7)
                            {
                                frontCard3 = changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-3 withObject:changeImage];
                            }
                        }
                        else
                        {
                            changeImage.image = [UIImage imageNamed:@"InsuranceFrontCard"];
                        }
                    }
                    else {
                        changeImage.image = [UIImage imageNamed:@"InsuranceFrontCard"];
                    }
                }
                if (indexPath.row == 2 || indexPath.row == 5 || indexPath.row ==8){
                    textLbl.text = @"Change Card Back";
                    UIImageView *imageView;
                    if(indexPath.row == 2 )
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-1];
                    else if(indexPath.row == 5)
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-2];
                    else if(indexPath.row == 8)
                        imageView = [localProfiledatamodel.aryInsuranceCards objectAtIndex:indexPath.row-3];
                    
                    
                    if(indexPath.row == 1 && [self isNotNull:localProfiledatamodel.insuranceBackCardData]){
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardData];
                    }
                    else if(indexPath.row == 4 && [self isNotNull:localProfiledatamodel.insuranceBackCardTwoData]){
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardTwoData];
                    }
                    else if(indexPath.row == 7 && [self isNotNull:localProfiledatamodel. insuranceBackCardThreeData])
                    {
                        imageView.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardThreeData];
                    }
                    
                    if(imageView!=nil && !([imageView isEqual:[NSNull null]])){
                        changeImage.image = imageView.image;
                        if(indexPath.row == 2 && localSelectedIndexPath==2)
                            backCard=changeImage.image;
                        else if(indexPath.row == 5 && localSelectedIndexPath==5)
                            backCard2=changeImage.image;
                        else if(indexPath.row == 8 && localSelectedIndexPath==8)
                            backCard3=changeImage.image;
                    }
                    else if ([self isNotNull:localProfiledatamodel.insuranceBackCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceBackTwoCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceBackThreeCardUrl] ) {
                        
                        NSString *thumbUrl;
                        if(indexPath.row == 2 && localProfiledatamodel.insuranceBackCardUrl)
                            thumbUrl = localProfiledatamodel.insuranceBackCardUrl;
                        if(indexPath.row == 5 && localProfiledatamodel.insuranceBackTwoCardUrl)
                            thumbUrl = localProfiledatamodel.insuranceBackTwoCardUrl;
                        if(indexPath.row == 8 && localProfiledatamodel.insuranceBackThreeCardUrl)
                            thumbUrl = localProfiledatamodel.insuranceBackThreeCardUrl;
                        
                        if([self isNotNull:thumbUrl]){
                            thumbUrl = [thumbUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                           withString:@"retina_thumb"];
                            [changeImage setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
                            
                            if(indexPath.row == 2 ){
                                backCard=changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-1 withObject:changeImage];
                            }
                            else if(indexPath.row == 5){
                                backCard2=changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-2 withObject:changeImage];
                            }
                            else if(indexPath.row == 8){
                                backCard3=changeImage.image;
                                [localProfiledatamodel.aryInsuranceCards replaceObjectAtIndex:indexPath.row-3 withObject:changeImage];
                            }
                            
                        }
                        else{
                            changeImage.image = [UIImage imageNamed:@"InsuranceBackCard"];
                        }
                    }
                    else {
                        changeImage.image = [UIImage imageNamed:@"InsuranceBackCard"];
                    }
                }
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                cell.backgroundView.backgroundColor = [UIColor clearColor];
                return cell;
            }
        }
        if (indexPath.section == ProfileSectionContactMethod) {
            if (indexPath.row == 0) {
                NSString *CellIdentifier = @"Select Preferred Contact Method";
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                UILabel *providerLabel = nil;
                
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                    providerLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, CELL_CONTENT_WIDTH, cellHeight)];
                    providerLabel.backgroundColor =[UIColor clearColor];
                    providerLabel.textColor = [UIColor whiteColor];
                    providerLabel.textAlignment = NSTextAlignmentLeft;
                    providerLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
                    providerLabel.tag = 4;
                    [cell.contentView addSubview:providerLabel ];
                }
                
                if (!providerLabel)
                    providerLabel = (UILabel *)[cell.contentView viewWithTag:4];
                
                //                if(indexPath.row == 0) {
                if ([self isNotNull:localProfiledatamodel.preferredAppointmentContactMethod]) {
                    providerLabel.text = localProfiledatamodel.preferredAppointmentContactMethod;
                    providerLabel.textColor = [UIColor whiteColor];
                } else {
                    providerLabel.text = @"Select Preferred Contact Method";
                    providerLabel.textColor = [UIColor lightGrayColor];
                }
                //                }
                
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
                }
                if (iPad) {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                } else {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
                }
                if(iPhone && CURRENT_DEVICE_VERSION >= 8.0 && isiPhone6PLUS) {
                    CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
                    cell.accessoryView=nil;
                    UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
                    [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                    [cell.contentView addSubview:accessoryimgView];
                }
                return cell;
            } else if(indexPath.row > 0) {
                NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
                ELCTextfieldCell *cell = (ELCTextfieldCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                //                cell.hideLeftLabel =TRUE;
                //                cel.rightTextField.frame = rightLabelFrame;
                if (cell == nil) {
                    cell = [[ELCTextfieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                }
                cell.leftLabel.hidden = YES;
                cell.indexPath = indexPath;
                cell.delegate = self;
                
                if ([self isNotNull:localProfiledatamodel.preferredAppointmentContactMethod]) {
                    if ([localProfiledatamodel.preferredAppointmentContactMethod isEqualToString:[preferredContactsArray objectAtIndex:0] ]) {
                        //                        cell.leftLabel.text = @"Email Address";
                        cell.rightTextField.keyboardType = UIKeyboardTypeEmailAddress;
                    }else if ([localProfiledatamodel.preferredAppointmentContactMethod isEqualToString:[preferredContactsArray objectAtIndex:1] ]) {
                        //                        cell.leftLabel.text = @"Phone";
                        cell.rightTextField.keyboardType = UIKeyboardTypeNamePhonePad;
                    }
                    else if ([localProfiledatamodel.preferredAppointmentContactMethod isEqualToString:[preferredContactsArray objectAtIndex:2] ]) {
                        //                        cell.leftLabel.text = @"Phone";
                        cell.rightTextField.keyboardType = UIKeyboardTypeNamePhonePad;
                    } else if ([localProfiledatamodel.preferredAppointmentContactMethod isEqualToString:[preferredContactsArray objectAtIndex:3] ]) {
                        //                        cell.leftLabel.text = @"Address";
                        cell.rightTextField.keyboardType = UIKeyboardTypeDefault;
                    }
                }
                
                if ([self isNotNull:localProfiledatamodel.preferredAppointmentContactData]) {
                    cell.rightTextField.text = localProfiledatamodel.preferredAppointmentContactData;
                } else {
                    cell.rightTextField.text = @"";
                }
                
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH ];
                }
                cell.leftLabel.text = nil;
                if (iPad) {
                    cell.rightTextField.frame =  CGRectMake(10, 0, 600, 70);
                } else {
                    cell.rightTextField.frame =  CGRectMake(5, 5, appDelegate.window.frame.size.width-40, 33);
                }
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                return cell;
            }
        }
        if(indexPath.section == ProfileSectionAbout) {
            
            UILabel *leftLabel = nil;
            //            UIImageView *cellBgView = nil;
            
            NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate addBackgroundViewToTheCell:cell];
                }
                leftLabel  = [[UILabel alloc]init];
                leftLabel.backgroundColor = [UIColor clearColor];
                leftLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                leftLabel.textColor = [UIColor grayColor];
                leftLabel.textAlignment = NSTextAlignmentLeft;
                [leftLabel setTag:14];
                [cell.contentView addSubview:leftLabel];
                if (iPad) {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                }
                else {
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
                }
                if(iPhone && CURRENT_DEVICE_VERSION >= 8.0 && isiPhone6PLUS) {
                    CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
                    cell.accessoryView=nil;
                    UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
                    [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                    [cell.contentView addSubview:accessoryimgView];
                }
            }
            
            if(!leftLabel)
                leftLabel = (UILabel *)[cell.contentView viewWithTag:14];
            
            //Chatterplug Info
            if (indexPath.section == ProfileSectionAbout && [self isNotNull:arrayofLeftLabel_Dictionary] && [arrayofLeftLabel_Dictionary isKindOfClass:[NSDictionary class]] && [self isNotNull:[arrayofLeftLabel_Dictionary objectForKey:@"fourthSectionLabel_Array"]] && [[arrayofLeftLabel_Dictionary objectForKey:@"fourthSectionLabel_Array"] count] > indexPath.row) {
                
                if (iPad) {
                    leftLabel.frame =  CGRectMake(10, 0, 600, 70);
                } else {
                    if (isiPhone6PLUS) {
                        leftLabel.frame = CGRectMake(7, 17, appDelegate.window.frame.size.width-40, 33);
                    }
                    else
                        leftLabel.frame =  CGRectMake(5, 5, appDelegate.window.frame.size.width-40, 33);
                }
                
                leftLabel.text = [[arrayofLeftLabel_Dictionary objectForKey:@"fourthSectionLabel_Array"] objectAtIndex:indexPath.row];
            }
            
            cell.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
            }
            return cell;
        }
        
        if(indexPath.section == ProfileSectionNotifications) {
            
            UILabel *leftLabel = nil;
            NotificationPreferenceButton *likeButton = nil;
            NotificationPreferenceButton *notificationButton = nil;
            NotificationPreferenceButton *mailButton = nil;
            
            NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    [appDelegate addBackgroundViewToTheCell:cell];
                }
                leftLabel  = [[UILabel alloc]init];
                leftLabel.backgroundColor = [UIColor clearColor];
                leftLabel.lineBreakMode = NSLineBreakByWordWrapping;
                leftLabel.numberOfLines = 0;
                leftLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?16.0f:notificationTextFontSize];
                leftLabel.textColor = [UIColor grayColor];
                leftLabel.textAlignment = NSTextAlignmentLeft;
                [leftLabel setTag:1];
                [cell.contentView addSubview:leftLabel];
                
                likeButton = [NotificationPreferenceButton buttonWithType:UIButtonTypeCustom];
                likeButton.tag = 2;
                likeButton.type = 1;
                [likeButton addTarget:self action:@selector(notificationPrefBtnClicked: withEvent:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:likeButton];
                
                notificationButton = [NotificationPreferenceButton buttonWithType:UIButtonTypeCustom];
                notificationButton.tag = 3;
                notificationButton.type = 2;
                [notificationButton addTarget:self action:@selector(notificationPrefBtnClicked: withEvent:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:notificationButton];
                
                mailButton = [NotificationPreferenceButton buttonWithType:UIButtonTypeCustom];
                mailButton.tag = 4;
                mailButton.type = 3;
                [mailButton addTarget:self action:@selector(notificationPrefBtnClicked: withEvent:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:mailButton];
            }
            if (isiPhone6PLUS) {
                cellHeight = 70;
            }
            else
                cellHeight = (iPad?70:50);
            if(!leftLabel)
                leftLabel = (UILabel *)[cell.contentView viewWithTag:1];
            if(!likeButton)
                likeButton = (NotificationPreferenceButton *)[cell.contentView viewWithTag:2];
            if(!notificationButton)
                notificationButton = (NotificationPreferenceButton *)[cell.contentView viewWithTag:3];
            if(!mailButton)
                mailButton  = (NotificationPreferenceButton *)[cell.contentView viewWithTag:4];
            
            if (notificationArray.count > 0) {
                notificationButton.hidden = NO;
                mailButton.hidden = NO;
                likeButton.hidden = NO;
                
                notificationButton.indexPath = indexPath;
                mailButton.indexPath = indexPath;
                likeButton.indexPath = indexPath;
                
                NotificationDetails *notificaDetails = (NotificationDetails*)[notificationArray objectAtIndex:indexPath.row];
                cellHeight = [self getCellHeightForNotificationDetails:notificaDetails];
                leftLabel.text = notificaDetails.notificationPreference;
                if (iPad) {
                    leftLabel.frame = CGRectMake(10, 5, 590, cellHeight-10);
                    likeButton.frame = CGRectMake(leftLabel.frame.origin.x + leftLabel.frame.size.width,(cellHeight-45)/2,45,45);
                    notificationButton.frame = CGRectMake(likeButton.frame.size.width + likeButton.frame.origin.x + 5, (cellHeight-45)/2, 45, 45);
                    mailButton.frame = CGRectMake(notificationButton.frame.size.width + notificationButton.frame.origin.x + 5, (cellHeight-45)/2, 45, 45);
                } else {
                    if(isiPhone6) {
                        if(appDelegate.window.frame.size.width > 375) {
                            leftLabel.frame = CGRectMake(5, 5, 303, cellHeight-10);
                        }
                        else
                            leftLabel.frame = CGRectMake(5, 5, 263, cellHeight-10);
                    }
                    else {
                        leftLabel.frame = CGRectMake(5, 5, 200, cellHeight-10);
                    }
                    likeButton.frame = CGRectMake(leftLabel.frame.origin.x + leftLabel.frame.size.width+5,(cellHeight-25)/2,25,25);
                    notificationButton.frame = CGRectMake(likeButton.frame.size.width + likeButton.frame.origin.x + 5, (cellHeight-25)/2, 25, 25);
                    mailButton.frame = CGRectMake(notificationButton.frame.size.width + notificationButton.frame.origin.x + 5, (cellHeight-25)/2, 25, 25);
                }
                
                
                if (notificaDetails.pushNotificationStatus) {
                    [notificationButton setImage:[UIImage imageNamed:@"PushSelect"] forState:UIControlStateNormal];
                } else {
                    [notificationButton setImage:[UIImage imageNamed:@"PushUnselect"] forState:UIControlStateNormal];
                }
                
                if (notificaDetails.mailNotificationStatus) {
                    [mailButton setImage:[UIImage imageNamed:@"EmailSelect"] forState:UIControlStateNormal];
                } else {
                    [mailButton setImage:[UIImage imageNamed:@"EmailUnselect"] forState:UIControlStateNormal];
                }
                
                if (notificaDetails.notificationEnabled) {
                    [likeButton setImage:[UIImage imageNamed:@"LikeSelect"] forState:UIControlStateNormal];
                } else {
                    [likeButton setImage:[UIImage imageNamed:@"LikeUnselect"] forState:UIControlStateNormal];
                    [notificationButton setImage:[UIImage imageNamed:@"PushUnselect"] forState:UIControlStateNormal];
                    [mailButton setImage:[UIImage imageNamed:@"EmailUnselect"] forState:UIControlStateNormal];
                    
                }
                
            } else {
                leftLabel.text = @"No Notification Preferences.";
                notificationButton.hidden = YES;
                mailButton.hidden = YES;
                likeButton.hidden = YES;
                if (iPad) {
                    leftLabel.frame =  CGRectMake(10, 0, 590, 70);
                } else {
                    leftLabel.frame =  CGRectMake(5, 0, 200, 50);
                }
            }
            cell.backgroundColor = [UIColor clearColor];
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:HEADER_WIDTH];
            }
            return cell;
        }
        return nil;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark
#pragma mark TableView delegate methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if(indexPath.section == ProfileSectionEditInfo) {
            if(indexPath.row == 7) {
                [cellTextFieldRef resignFirstResponder];
                [self configureTheDatePicker];
            }
            //			if (indexPath.row == 4) {
            //                [cellTextFieldRef resignFirstResponder];
            //                [self initialiseStatesPickerView];
            //            }
        } else if(indexPath.section == ProfileSectionAvatar) {
            if (indexPath.row == 0) {
                ELCTextfieldCell *cell = (ELCTextfieldCell *)[editTable cellForRowAtIndexPath:indexPath];
                UITextField *passwordTextField = nil;
                if([self isNotNull:cell]) {
                    passwordTextField = cell.rightTextField;
                }
                
                ChangePasswordViewController *changePasswordVC = [[ChangePasswordViewController alloc]initWithProfile:profiledatamodel withPasswordLabel:passwordTextField];
                [self.navigationController pushViewController:changePasswordVC animated:YES];
            } else if(indexPath.row == 1) {
                [self gotoChangeSecurityViewController];
            }
        } else if (indexPath.section == ProfileSectionInsurance) {
            [cellTextFieldRef resignFirstResponder];
            if (indexPath.row == 0 ){
                if([self isNotNull:insurancePickerDisplayView])
                    [insurancePickerDisplayView removeFromSuperview];
                [self initialisePickerView:0];
                return;
            }
            else if(indexPath.row==3 ){
                if([self isNotNull:insurancePickerDisplayView])
                    [insurancePickerDisplayView removeFromSuperview];
                [self initialisePickerView:1];
                return;
                
            }
            else if(indexPath.row==6){
                if([self isNotNull:insurancePickerDisplayView])
                    [insurancePickerDisplayView removeFromSuperview];
                [self initialisePickerView:2];
                return;
                
            }
            
        }else if(indexPath.section == ProfileSectionContactMethod){
            if(indexPath.row == 0){
                if([preferredContactsArray count] > 0)
                {
                    [cellTextFieldRef resignFirstResponder];
                    [self initialisePickerViewWithContactMethods];
                }
            }
        }else if(indexPath.section == ProfileSectionAbout) { //chatterplug privacy policy,terms of use.
            
            ChatterPlugViewController *chatterPlugViewContr;
            if(indexPath.row == 0) {
                //                chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://ruralaco.com/"];
                chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://www.tomahhospital.org/content/detail.cfm?pageID=54"];
                chatterPlugViewContr.titleStr = @"Tomah Memorial Hospital";
            } else if(indexPath.row == 1) {
                chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://chatterplug.com/privacy_policy"];
                chatterPlugViewContr.titleStr = @"Privacy Policy";
            } else if(indexPath.row == 2) {
                //                chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:@"http://chatterplug.com/terms_of_use"];
                chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:[NSString stringWithFormat:@"%@/terms_and_conditions",APP_URL]];
                chatterPlugViewContr.titleStr = @"Terms of Use";
            }
            
            [self.navigationController pushViewController:chatterPlugViewContr animated:YES];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)gotoChangeSecurityViewController {
    TCSTART
    ChangeSecurityQuestionViewController *changeSecurityQuestionsVC;
    changeSecurityQuestionsVC = [[ChangeSecurityQuestionViewController alloc] initWithFrame:self.view.frame profileDataModal:profiledatamodel andCaller:self];
    [self.navigationController pushViewController:changeSecurityQuestionsVC animated:YES];
    TCEND
}

- (void)selectedSecurityQuestion:(NSString *)question {
    TCSTART
    profiledatamodel.securityQuestion = question;
    [self reloadData];
    TCEND
}

#pragma mark Notification Prefreences Button clicked

- (void)notificationPrefBtnClicked:(NotificationPreferenceButton *)sender  withEvent:(UIEvent *)event {
    TCSTART
    NSIndexPath *indexPath = [self getIndexPathForEvent:event];
    NotificationDetails *notificaDetails = (NotificationDetails*)[notificationArray objectAtIndex:indexPath.row];
    if (sender.type == 1) {
        if (notificaDetails.notificationEnabled) {
            notificaDetails.notificationEnabled = NO;
            notificaDetails.pushNotificationStatus = NO;
            notificaDetails.mailNotificationStatus = NO;
        } else {
            notificaDetails.notificationEnabled = YES;
            notificaDetails.pushNotificationStatus = YES;
            notificaDetails.mailNotificationStatus = YES;
        }
        [editTable reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationNone];
    } else if (sender.type == 2 && notificaDetails.notificationEnabled) {
        if (notificaDetails.pushNotificationStatus)
            notificaDetails.pushNotificationStatus = NO;
        else
            notificaDetails.pushNotificationStatus = YES;
        
        //        if (!notificaDetails.pushNotificationStatus && !notificaDetails.mailNotificationStatus)
        //            notificaDetails.notificationEnabled = NO;
        [editTable reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationNone];
    } else if (sender.type == 3 && notificaDetails.notificationEnabled) {
        if (notificaDetails.mailNotificationStatus)
            notificaDetails.mailNotificationStatus = NO;
        else
            notificaDetails.mailNotificationStatus = YES;
        
        //        if (!notificaDetails.pushNotificationStatus && !notificaDetails.mailNotificationStatus)
        //            notificaDetails.notificationEnabled = NO;
        [editTable reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationNone];
    }
    TCEND
}

#pragma mark Table ScrollView Methods
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
    @try {
        if([self isNotNull:photoPopUp_View]) {
            
            [photoPopUp_View removeFromSuperview];
            photoPopUp_View = nil;
        }
        
        if([self isNotNull:cellTextFieldRef]) {
            [cellTextFieldRef resignFirstResponder];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Preview Avatar
-(void)viewCardImage:(UIButton *)sender
{
    @try {
        NSInteger btnTag = [sender tag];
        if(btnTag==8002 || btnTag==8003)
            btnTag = btnTag - 8001;
        else if (btnTag==8005 || btnTag==8006)
            btnTag=btnTag-8002;
        else
            btnTag=btnTag-8003;
        
        ProfileDataModel *localProfiledatamodel = profiledatamodel;
        
        imageFullView = [[UIViewController alloc]init];
        
        imageFullView.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, self.view.frame.size.height - ((CURRENT_DEVICE_VERSION < 7.0)?0:20));
        UIImageView *imgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Survey-Pop-Up"]];
        imgView.frame = CGRectMake(0, imageFullView.view.frame.origin.y, imageFullView.view.frame.size.width, imageFullView.view.frame.size.height);
        
        [imageFullView.view addSubview:imgView];
        
        CGFloat gap;
        if (iPad) {
            titleLabel =[[UILabel alloc] initWithFrame:CGRectMake((appDelegate.window.frame.size.width - 300)/2,5 ,500,50)];
            [titleLabel setCenter:CGPointMake(imageFullView.view.center.x, 20)];
            gap = 10;
        } else {
            titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, 320,30)];
            [titleLabel setCenter:CGPointMake(imageFullView.view.center.x, 15)];
            gap = 0;
        }
        
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        [imageFullView.view addSubview:titleLabel];
        
        UIImageView *toplineIamge = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
        toplineIamge.frame = CGRectMake(0, titleLabel.frame.origin.y + titleLabel.frame.size.height, imageFullView.view.frame.size.width, 13);
        [imageFullView.view addSubview:toplineIamge];
        
        //
        UIImageView *changeImage = [[UIImageView alloc] init];
        //    cardImageView.frame = CGRectMake(imageFullView.view.frame.origin.x + 5, toplineIamge.frame.origin.y + toplineIamge.frame.size.height, imageFullView.view.frame.size.width - 10, imageFullView.view.frame.size.height - (toplineIamge.frame.origin.y + toplineIamge.frame.size.height + 10));
        changeImage.frame = CGRectMake((self.view.frame.size.width-269)/2,(self.view.frame.size.height-324)/2, 269, 324);
        [imageFullView.view addSubview:changeImage];
        
        UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        closeButton.frame = CGRectMake(imageFullView.view.frame.size.width - (35 + gap), gap, 35, 35);
        [closeButton setImage:[UIImage imageNamed:@"Survey-Close"] forState:UIControlStateNormal];
        [closeButton addTarget:self action:@selector(closeImageView:) forControlEvents:UIControlEventTouchUpInside];
        closeButton.tag = -5000;
        [imageFullView.view addSubview:closeButton];
        
        if (btnTag == 1 || btnTag == 3 || btnTag == 5) {
            
            if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardData];
                titleLabel.text = @"Insurance Card Front 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardTwoData];
                titleLabel.text = @"Insurance Card Front 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardThreeData];
                titleLabel.text = @"Insurance Card Front 3";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardData];
                titleLabel.text = @"Insurance Card Back 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardTwoData];
                titleLabel.text = @"Insurance Card Back 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardThreeData];
                titleLabel.text = @"Insurance Card Back 3";            }
            
            else if ([self isNotNull:localProfiledatamodel.insuranceFrontCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceFrontTwoCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceFrontThreeCardUrl]) {
                NSString *thumbUrl;
                if(btnTag == 1 && localProfiledatamodel.insuranceFrontCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceFrontCardUrl;
                    titleLabel.text = @"Insurance Card Front 1";            }
                if(btnTag == 3 && localProfiledatamodel.insuranceFrontTwoCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceFrontTwoCardUrl;
                    titleLabel.text = @"Insurance Card Front 2";            }
                if(btnTag == 5 && localProfiledatamodel.insuranceFrontThreeCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceFrontThreeCardUrl;
                    titleLabel.text = @"Insurance Card Front 3";            }
                
                if([self isNotNull:thumbUrl]){
                    thumbUrl = [thumbUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"retina_thumb"];
                    
                    [changeImage setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
                }
                else{
                    if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 1";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 2";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 3";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 1";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 2";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 3";            }
                }
            }
        }
        else if (btnTag == 2 || btnTag == 4 || btnTag ==6){
            
            if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardData];
                titleLabel.text = @"Insurance Card Front 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardTwoData];
                titleLabel.text = @"Insurance Card Front 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardThreeData];
                titleLabel.text = @"Insurance Card Front 3";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardData];
                titleLabel.text = @"Insurance Card Back 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardTwoData];
                titleLabel.text = @"Insurance Card Back 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardThreeData];
                titleLabel.text = @"Insurance Card Back 3";            }
            
            else if ([self isNotNull:localProfiledatamodel.insuranceBackCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceBackTwoCardUrl]  || [self isNotNull:localProfiledatamodel.insuranceBackThreeCardUrl] ) {
                NSString *thumbUrl;
                if(btnTag == 2 && localProfiledatamodel.insuranceBackCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceBackCardUrl;
                    titleLabel.text = @"Insurance Card Back 1";            }
                if(btnTag == 4 && localProfiledatamodel.insuranceBackTwoCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceBackTwoCardUrl;
                    titleLabel.text = @"Insurance Card Back 2";            }
                if(btnTag == 6 && localProfiledatamodel.insuranceBackThreeCardUrl){
                    thumbUrl = localProfiledatamodel.insuranceBackThreeCardUrl;
                    titleLabel.text = @"Insurance Card Back 3";            }
                
                if([self isNotNull:thumbUrl]){
                    thumbUrl = [thumbUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"retina_thumb"];
                    [changeImage setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
                }else{
                    
                    if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 1";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 2";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                        changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                        titleLabel.text = @"Insurance Card Front 3";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 1";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 2";            }
                    else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                        changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                        titleLabel.text = @"Insurance Card Back 3";            }
                }
            }
        }
        else
        {
            if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardData];
                titleLabel.text = @"Insurance Card Front 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardTwoData];
                titleLabel.text = @"Insurance Card Front 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceFrontCardThreeData];
                titleLabel.text = @"Insurance Card Front 3";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardData];
                titleLabel.text = @"Insurance Card Back 1";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardTwoData];
                titleLabel.text = @"Insurance Card Back 2";            }
            else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                changeImage.image = [UIImage imageWithData:localProfiledatamodel.insuranceBackCardThreeData];
                titleLabel.text = @"Insurance Card Back 3";            }
            else
            {
                if([self isNotNull:localProfiledatamodel.insuranceFrontCardData] && btnTag==1){
                    changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                    titleLabel.text = @"Insurance Card Front 1";            }
                else if([self isNotNull:localProfiledatamodel.insuranceFrontCardTwoData] && btnTag==3){
                    changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                    titleLabel.text = @"Insurance Card Front 2";            }
                else if([self isNotNull:localProfiledatamodel.insuranceFrontCardThreeData] && btnTag==5){
                    changeImage.image = [UIImage imageNamed:@"insuranceFrontCardPreview"];
                    titleLabel.text = @"Insurance Card Front 3";            }
                else if([self isNotNull:localProfiledatamodel.insuranceBackCardData] && btnTag==2){
                    changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                    titleLabel.text = @"Insurance Card Back 1";            }
                else if([self isNotNull:localProfiledatamodel.insuranceBackCardTwoData] && btnTag==4){
                    changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                    titleLabel.text = @"Insurance Card Back 2";            }
                else if([self isNotNull:localProfiledatamodel.insuranceBackCardThreeData] && btnTag==6){
                    changeImage.image = [UIImage imageNamed:@"insuranceBackCardPreview"];
                    titleLabel.text = @"Insurance Card Back 3";            }
            }
        }
        
        if([self isNotNull:changeImage]){
            
            [imageFullView.view addSubview:closeButton];
            [self.view addSubview:imageFullView.view];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    @finally {
        
    }
    
    //    UIImageView *cardImage = [profiledatamodel.aryInsuranceCards objectAtIndex:btnTag];
    //    UIViewOverlayAnimation *overlayAnimation = [[UIViewOverlayAnimation alloc] initWithFrame:  CGRectMake((self.view.frame.size.width-269)/2,(self.view.frame.size.height-324)/2, 269, 324) cardImage:cardImage.image];
    //    [overlayAnimation showInView:self.view];
}




-(void)changeAvatarAction:(UIButton *)sender  withEvent:(UIEvent *)event {
    @try {
        //        UIButton *btn = (UIButton *)sender;
        if([self isNotNull:cellTextFieldRef]) {
            [cellTextFieldRef resignFirstResponder];
        }
        
        NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
        selectedIndex = indexPath.row;
        
        if (indexPath.section == ProfileSectionInsurance) {
            if (indexPath.row == 1 || indexPath.row == 4 || indexPath.row == 7) {
                changeAvatarReqFor = @"Front";
                
            } else if(indexPath.row == 2 || indexPath.row == 5 || indexPath.row == 8){
                changeAvatarReqFor = @"Back";
            }
        } else {
            changeAvatarReqFor = @"Profile";
        }
        
        CGRect photoPopupRect = [editTable rectForRowAtIndexPath:indexPath];
        if (indexPath.section == ProfileSectionInsurance) {
            CGFloat originY = photoPopupRect.origin.y ;
            originY = originY + (iPad ? 70 : 85);
            photoPopupRect = CGRectMake(photoPopupRect.origin.x, originY, photoPopupRect.size.width, photoPopupRect.size.height);
        }
        [editTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        [photoPopUp_View removeFromSuperview];
        if (!photoPopUp_View) {
            photoPopUp_View = [[UIView alloc]init];
            if (iPad) {
                photoPopUp_View.frame = CGRectMake(photoPopupRect.origin.x + ((CURRENT_DEVICE_VERSION < 7.0)?50:10), photoPopupRect.origin.y, 427, 208);
            } else {
                photoPopUp_View.frame = CGRectMake(((CURRENT_DEVICE_VERSION < 7.0)?2:0), photoPopupRect.origin.y - 25, appDelegate.window.frame.size.width-10, 150);
            }
        } else if (photoPopUp_View) {
            for (UIView *subView in [photoPopUp_View subviews]) {
                [subView removeFromSuperview];
            }
        }
        
        photoPopUp_View.backgroundColor = [UIColor clearColor];
        [editTable addSubview:photoPopUp_View];
        
        //photoOptions
        UIImageView *photoOption_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"plug_photoOptions"]];
        [photoPopUp_View addSubview:photoOption_ImgView];
        
        UIButton *takePhotoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        takePhotoBtn.frame = CGRectMake(18, 28, 390, 55);
        [photoPopUp_View addSubview:takePhotoBtn];
        takePhotoBtn.selected = UIButtonTypeInfoDark;
        [takePhotoBtn setImage:[UIImage imageNamed:@"takephoto"] forState:UIControlStateNormal];
        
        takePhotoBtn.backgroundColor = [UIColor clearColor];
        [takePhotoBtn addTarget:self action:@selector(takeNewPhoto:) forControlEvents:UIControlEventTouchUpInside];
        [photoPopUp_View bringSubviewToFront:takePhotoBtn];
        
        UIButton *chooseFrmLibraryBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        chooseFrmLibraryBtn.frame = CGRectMake(18, 134, 390, 55);
        [photoPopUp_View addSubview:chooseFrmLibraryBtn];
        chooseFrmLibraryBtn.selected = UIButtonTypeInfoDark;
        [chooseFrmLibraryBtn setImage:[UIImage imageNamed:@"pickfromlibrary"] forState:UIControlStateNormal];
        chooseFrmLibraryBtn.backgroundColor = [UIColor clearColor];
        [chooseFrmLibraryBtn addTarget:self action:@selector(chooseFromLibrary:) forControlEvents:UIControlEventTouchUpInside];
        
        if (!iPad) {
            takePhotoBtn.frame = CGRectMake(23, 30, 270, 38);
            chooseFrmLibraryBtn.frame = CGRectMake(23, takePhotoBtn.frame.origin.y + takePhotoBtn.frame.size.height + 35, 270, 38);
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)avatarClicked:(UIButton *)sender  withEvent:(UIEvent *)event {
    NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
    if (indexPath.section==1 && indexPath.row==0) {
        //        ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.avatarImageUrl andAvatar:newAvatarImage andTitleText:@"Avatar" andImagePlaceHolder:@"default-avatar-user" andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width-20, appDelegate.window.frame.size.height)];
        //
        //        float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
        //        if (osVersion >= 5.0) {
        //            [self presentViewController:imageViewVC animated:YES completion:nil];
        //        } else {
        //            [self presentModalViewController: imageViewVC animated: YES];
        //        }
        [self avatarClickedBackup:sender withEvent:event];
        //TODOD TO
        
        
    } else if (indexPath.section==3 && indexPath.row==1) {
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceFrontCardUrl andAvatar:frontCard andTitleText:@"Insurance Card Front" andImagePlaceHolder:@"insuranceFrontCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }else if(indexPath.section==3 && indexPath.row==2){
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceBackCardUrl andAvatar:backCard andTitleText:@"Insurance Card Back" andImagePlaceHolder:@"insuranceBackCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
            
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }
    else if (indexPath.section==3 && indexPath.row==3) {
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceFrontTwoCardUrl andAvatar:frontCard2 andTitleText:@"Insurance Card Front" andImagePlaceHolder:@"insuranceFrontCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }else if(indexPath.section==3 && indexPath.row==4){
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceBackTwoCardUrl andAvatar:backCard2 andTitleText:@"Insurance Card Back" andImagePlaceHolder:@"insuranceBackCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
            
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }
    else if (indexPath.section==3 && indexPath.row==5) {
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceFrontThreeCardUrl andAvatar:frontCard3 andTitleText:@"Insurance Card Front" andImagePlaceHolder:@"insuranceFrontCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }else if(indexPath.section==3 && indexPath.row==6){
        if(CURRENT_DEVICE_VERSION < 8.0)
        {
            ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:profiledatamodel.insuranceBackThreeCardUrl andAvatar:backCard3 andTitleText:@"Insurance Card Back" andImagePlaceHolder:@"insuranceBackCardPreview"  andIndexPath:indexPath andViewFrame:CGRectMake(0, 0, appDelegate.window.frame.size.height, appDelegate.window.frame.size.width -20)];
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:imageViewVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: imageViewVC animated: YES];
                [self presentViewController:imageViewVC animated:YES completion:^{
                    //code
                }];
            }
            
        }
        else  {
            [self avatarClickedBackup:sender withEvent:event];
        }
        
    }
}

-(void)avatarClicked1:(UIButton *)sender  withEvent:(UIEvent *)event {
    
    appDelegate.landscapeSupport = TRUE;
    
    
    NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
    
    TCSTART
    NSLog(@"width: %f, height: %f",appDelegate.window.frame.size.width,appDelegate.window.frame.size.height);
    
    imageFullView = [[UIViewController alloc]init];
    imageFullView.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, self.view.frame.size.height - ((CURRENT_DEVICE_VERSION < 7.0)?0:20));
    
    UIImageView *imgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Survey-Pop-Up"]];
    imgView.frame = CGRectMake(0, imageFullView.view.frame.origin.y, imageFullView.view.frame.size.width, imageFullView.view.frame.size.height);
    
    [imageFullView.view addSubview:imgView];
    
    
    //TODO FROM
    
    //    ImageViewController *imageViewVC = [[ImageViewController alloc] initWithCaller:self andAvatarUrl:@"" andAvatar:newAvatarImage andTitleText:@"" andImagePlaceHolder:@""];
    
    //    detailVC.caller = self;
    //    detailVC.detailTitleStr = dataModel.messageTitle;
    //    [self.navigationController pushViewController:imageViewVC animated:YES];
    
    
    //TODO TO
    
    CGFloat gap;
    if (iPad) {
        titleLabel =[[UILabel alloc] initWithFrame:CGRectMake((appDelegate.window.frame.size.width - 300)/2,5 ,500,50)];
        [titleLabel setCenter:CGPointMake(imageFullView.view.center.x, 50)];
        gap = 10;
    } else {
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, 320,30)];
        gap = 0;
        [titleLabel setCenter:CGPointMake(imageFullView.view.center.x, 20)];
    }
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"Image Preview";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [imageFullView.view addSubview:titleLabel];
    
    UIImageView *toplineIamge = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
    toplineIamge.frame = CGRectMake(0, titleLabel.frame.origin.y + titleLabel.frame.size.height, imageFullView.view.frame.size.width, 13);
    [imageFullView.view addSubview:toplineIamge];
    
    UIImageView *cardImageView = [[UIImageView alloc]init];
    //    cardImageView.frame = CGRectMake(imageFullView.view.frame.origin.x + 5, toplineIamge.frame.origin.y + toplineIamge.frame.size.height, imageFullView.view.frame.size.width - 10, imageFullView.view.frame.size.height - (toplineIamge.frame.origin.y + toplineIamge.frame.size.height + 10));
    cardImageView.frame = CGRectMake((self.view.frame.size.width-269)/2,(self.view.frame.size.height-324)/2, 269, 324);
    [imageFullView.view addSubview:cardImageView];
    
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    closeButton.frame = CGRectMake(imageFullView.view.frame.size.width - (35 + gap), gap, 35, 35);
    [closeButton setImage:[UIImage imageNamed:@"Survey-Close"] forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(closeImageView:) forControlEvents:UIControlEventTouchUpInside];
    closeButton.tag = -5000;
    [imageFullView.view addSubview:closeButton];
    
    NSLog(@"section: %ld, row: %ld",(long)indexPath.section,(long)indexPath.row);
    
    if (indexPath.section==1 && indexPath.row==0) {
        if(newAvatarImage) {
            [cardImageView setImage:newAvatarImage];
        } else if([profiledatamodel.avatarImageUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.avatarImageUrl rangeOfString:@"https://"].location != NSNotFound) {
            NSString *previewUrl = profiledatamodel.avatarImageUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"profile"
                                                               withString:@"profile_large"];
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
        }else{
            [cardImageView setImageWithURL:[NSURL URLWithString:profiledatamodel.avatarImageUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
        }
        titleLabel.text = @"Avatar";
    }else
        if (indexPath.section==3 && indexPath.row==1) {
            if(frontCard) {
                [cardImageView setImage:frontCard];
            } else if([profiledatamodel.insuranceFrontCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontCardUrl rangeOfString:@"https://"].location != NSNotFound) {
                NSString *previewUrl = profiledatamodel.insuranceFrontCardUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"standard"];
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Front";
        }else if(indexPath.section==3 && indexPath.row==2){
            if(backCard) {
                [cardImageView setImage:backCard];
            } else if([profiledatamodel.insuranceBackCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackCardUrl rangeOfString:@"https://"].location != NSNotFound) {
                NSString *previewUrl = profiledatamodel.insuranceBackCardUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"standard"];
                
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Back";
        }
    if (indexPath.section==3 && indexPath.row==3) {
        if(frontCard2) {
            [cardImageView setImage:frontCard2];
        } else if([profiledatamodel.insuranceFrontTwoCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontTwoCardUrl rangeOfString:@"https://"].location != NSNotFound) {
            NSString *previewUrl = profiledatamodel.insuranceFrontTwoCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Front";
    }else if(indexPath.section==3 && indexPath.row==4){
        if(backCard2) {
            [cardImageView setImage:backCard2];
        } else if([profiledatamodel.insuranceBackTwoCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackTwoCardUrl rangeOfString:@"https://"].location != NSNotFound) {
            NSString *previewUrl = profiledatamodel.insuranceBackTwoCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Back";
    }
    if (indexPath.section==3 && indexPath.row==5) {
        if(frontCard3) {
            [cardImageView setImage:frontCard3];
        } else if([profiledatamodel.insuranceFrontThreeCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontThreeCardUrl rangeOfString:@"https://"].location != NSNotFound) {
            NSString *previewUrl = profiledatamodel.insuranceFrontThreeCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Front";
    }else if(indexPath.section==3 && indexPath.row==6){
        if(backCard3) {
            [cardImageView setImage:backCard3];
        } else if([profiledatamodel.insuranceBackThreeCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackThreeCardUrl rangeOfString:@"https://"].location != NSNotFound) {
            NSString *previewUrl = profiledatamodel.insuranceBackThreeCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Back";
    }
    [self.view addSubview:imageFullView.view];
    
    TCEND
}

//-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
////- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOr‌​ientation {
//    return UIInterfaceOrientationLandscapeLeft;
////}
//}
-(void)avatarClickedBackup:(UIButton *)sender  withEvent:(UIEvent *)event {
    
    NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
    
    TCSTART
    //    if ([self isNull:imageFullView]) {
    imageFullView = [[UIViewController alloc]init];
    
    imageFullView.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, self.view.frame.size.height - ((CURRENT_DEVICE_VERSION < 7.0)?0:20));
    UIImageView *imgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Survey-Pop-Up"]];
    imgView.frame = CGRectMake(0, imageFullView.view.frame.origin.y, imageFullView.view.frame.size.width, imageFullView.view.frame.size.height);
    [imageFullView.view addSubview:imgView];
    
    CGFloat gap;
    if (iPad) {
        titleLabel =[[UILabel alloc] initWithFrame:CGRectMake((appDelegate.window.frame.size.width - 300)/2,5 ,300,50)];
        gap = 10;
    } else {
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, appDelegate.window.frame.size.width,30)];
        gap = 0;
    }
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"Image Preview";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [imageFullView.view addSubview:titleLabel];
    
    UIImageView *toplineIamge = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
    toplineIamge.frame = CGRectMake(0, titleLabel.frame.origin.y + titleLabel.frame.size.height, imageFullView.view.frame.size.width, 13);
    [imageFullView.view addSubview:toplineIamge];
    
    //
    UIImageView *cardImageView = [[UIImageView alloc]init];
    cardImageView.frame = CGRectMake(imageFullView.view.frame.origin.x + 5, toplineIamge.frame.origin.y + toplineIamge.frame.size.height, imageFullView.view.frame.size.width - 10, imageFullView.view.frame.size.height - (toplineIamge.frame.origin.y + toplineIamge.frame.size.height + 10));
    [imageFullView.view addSubview:cardImageView];
    
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    closeButton.frame = CGRectMake(imageFullView.view.frame.size.width - (35 + gap), gap, 35, 35);
    [closeButton setImage:[UIImage imageNamed:@"Survey-Close"] forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(closeImageView:) forControlEvents:UIControlEventTouchUpInside];
    closeButton.tag = -5000;
    [imageFullView.view addSubview:closeButton];
    
    NSLog(@"section: %ld, row: %ld",(long)indexPath.section,(long)indexPath.row);
    
    if (indexPath.section==1 && indexPath.row==0) {
        if(newAvatarImage) {
            [cardImageView setImage:newAvatarImage];
        } else if([self isNotNull:profiledatamodel.avatarImageUrl]&&([profiledatamodel.avatarImageUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.avatarImageUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = profiledatamodel.avatarImageUrl;
            
            //previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"profile" withString:@"profile_large"];
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"defaultAvatarPreview"]];
        }else{
            //            [cardImageView setImageWithURL:[NSURL URLWithString:profiledatamodel.avatarImageUrl] placeholderImage:[UIImage imageNamed:@"defaultAvatarPreview"]];
            [cardImageView setImage:[UIImage imageNamed:@"defaultAvatarPreview"]];
        }
        titleLabel.text = @"Avatar";
    }else
        if (indexPath.section==3 && indexPath.row==1) {
            if(frontCard) {
                [cardImageView setImage:frontCard];
            } else if([self isNotNull:profiledatamodel.insuranceFrontCardUrl]&&([profiledatamodel.insuranceFrontCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
                NSString *previewUrl = profiledatamodel.insuranceFrontCardUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"standard"];
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
            }else{
                [cardImageView setImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Front";
        }else if(indexPath.section==3 && indexPath.row==2){
            if(backCard) {
                [cardImageView setImage:backCard];
            } else if([self isNotNull:profiledatamodel.insuranceBackCardUrl] && ([profiledatamodel.insuranceBackCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
                NSString *previewUrl = profiledatamodel.insuranceBackCardUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"standard"];
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
            }else{
                [cardImageView setImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Back";
        }
    if (indexPath.section==3 && indexPath.row==3) {
        if(frontCard2) {
            [cardImageView setImage:frontCard2];
        } else if([self isNotNull:profiledatamodel.insuranceFrontTwoCardUrl]&&([profiledatamodel.insuranceFrontTwoCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontTwoCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = profiledatamodel.insuranceFrontTwoCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }else{
            [cardImageView setImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Front";
    }else if(indexPath.section==3 && indexPath.row==4){
        if(backCard2) {
            [cardImageView setImage:backCard2];
        } else if([self isNotNull:profiledatamodel.insuranceBackTwoCardUrl] && ([profiledatamodel.insuranceBackTwoCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackTwoCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = profiledatamodel.insuranceBackTwoCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }else{
            [cardImageView setImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Back";
    }
    
    if (indexPath.section==3 && indexPath.row==5) {
        if(frontCard3) {
            [cardImageView setImage:frontCard3];
        } else if([self isNotNull:profiledatamodel.insuranceFrontThreeCardUrl]&&([profiledatamodel.insuranceFrontThreeCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceFrontThreeCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = profiledatamodel.insuranceFrontThreeCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }else{
            [cardImageView setImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Front";
    }else if(indexPath.section==3 && indexPath.row==6){
        if(backCard3) {
            [cardImageView setImage:backCard3];
        } else if([self isNotNull:profiledatamodel.insuranceBackThreeCardUrl] && ([profiledatamodel.insuranceBackThreeCardUrl rangeOfString:@"http://"].location != NSNotFound || [profiledatamodel.insuranceBackThreeCardUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = profiledatamodel.insuranceBackThreeCardUrl;
            
            previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                               withString:@"standard"];
            
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }else{
            [cardImageView setImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
        }
        titleLabel.text = @"Insurance Card Back";
    }
    
    [self.view addSubview:imageFullView.view];
    
    TCEND
}
//-downloadImageWithURL
-(void)closeImageView:(id)sender{
    
    @try {
        [imageFullView.view removeFromSuperview];
        imageFullView=nil;
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
-(void)animateTransition:(NSNumber *)duration {
    
    @try {
        //self.view.userInteractionEnabled=NO;
        [[appDelegate window] addSubview:imageFullView.view];
        if ((imageFullView.view.hidden == false) && ([duration floatValue] == TIME_FOR_EXPANDING)) {
            imageFullView.view.frame = CGRectMake(0,22, appDelegate.window.frame.size.width - 10, appDelegate.window.frame.size.height - 44);
            imageFullView.view.transform = CGAffineTransformMakeScale(SCALED_DOWN_AMOUNT, SCALED_DOWN_AMOUNT);
        }
        imageFullView.view.hidden = false;
        if ([duration floatValue] == TIME_FOR_SHRINKING) {
            [UIView beginAnimations:@"animationShrink" context:NULL];
            [UIView setAnimationDuration:[duration floatValue]];
            imageFullView.view.transform = CGAffineTransformMakeScale(SCALED_DOWN_AMOUNT, SCALED_DOWN_AMOUNT);
        }
        else {
            [UIView beginAnimations:@"animationExpand" context:NULL];
            [UIView setAnimationDuration:[duration floatValue]];
            imageFullView.view.transform = CGAffineTransformMakeScale(1, 1);
        }
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)animationDidStop:(NSString *)animationID finished:(BOOL)finished context:(void *)context {
    
    @try {
        self.view.userInteractionEnabled=YES;
        if ([animationID isEqualToString:@"animationExpand"]) {
            
        } else {
            imageFullView.view.hidden = true;
            //                appDelegate.landscapeSupport = FALSE;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (NSIndexPath *)getIndexPathForEvent:(UIEvent *)event {
    
    NSIndexPath *indexPath = nil;
    @try {
        NSSet *allTouches = [event allTouches];
        CGPoint likeLocationPoint = [[allTouches anyObject]locationInView:editTable];
        indexPath = [editTable indexPathForRowAtPoint:likeLocationPoint];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
    return indexPath;
}

- (void)takeNewPhoto:(id)sender {
    [self openCamera];
}


-(void)mailButtonAction:(UIButton*)sender
{
    NSLog(@"mailButtonClicked %li",(long)sender.tag);
}

-(void)notificationButtonAction:(UIButton*)sender
{
    NSLog(@"NotificationButtonClicked %li",(long)sender.tag);
}

- (void)chooseFromLibrary:(id)sender {
    @try {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            isImgSourceTypeCamera = NO;
            
            UIImagePickerController* imagePickerController = [[UIImagePickerController alloc] init];
            imagePickerController.delegate = self;
            imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            
            if (!iPad) {
                [self presentViewController:imagePickerController animated:YES completion:^{
                    //code
                    
                    NSIndexPath *indexPath;
                    if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame) {
                        if (selectedIndex == 1)
                            indexPath = [NSIndexPath indexPathForRow:1 inSection:2];
                        else if (selectedIndex == 4)
                            indexPath = [NSIndexPath indexPathForRow:4 inSection:2];
                        else if (selectedIndex == 7)
                            indexPath = [NSIndexPath indexPathForRow:7 inSection:2];
                        
                    } else if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame) {
                        if (selectedIndex == 2)
                            indexPath = [NSIndexPath indexPathForRow:2 inSection:2];
                        else if (selectedIndex == 5)
                            indexPath = [NSIndexPath indexPathForRow:5 inSection:2];
                        
                        else if (selectedIndex == 8)
                            indexPath = [NSIndexPath indexPathForRow:8 inSection:2];
                        
                    } else {
                        indexPath = [NSIndexPath indexPathForRow:0 inSection:1];
                    }
                    
                }];
            } else {
                if ([self isNull:self.popover]) {
                    self.popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
                } else {
                    self.popover.contentViewController = imagePickerController;
                }
                self.popover.delegate = self;
                NSIndexPath *indexPath;
                if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame) {
                    if (selectedIndex == 1)
                        indexPath = [NSIndexPath indexPathForRow:1 inSection:2];
                    else if (selectedIndex == 4)
                        indexPath = [NSIndexPath indexPathForRow:4 inSection:2];
                    else if (selectedIndex == 7)
                        indexPath = [NSIndexPath indexPathForRow:7 inSection:2];
                    
                } else if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame) {
                    if (selectedIndex == 2)
                        indexPath = [NSIndexPath indexPathForRow:2 inSection:2];
                    else if (selectedIndex == 5)
                        indexPath = [NSIndexPath indexPathForRow:5 inSection:2];
                    
                    else if (selectedIndex == 8)
                        indexPath = [NSIndexPath indexPathForRow:8 inSection:2];
                    
                } else {
                    indexPath = [NSIndexPath indexPathForRow:0 inSection:1];
                }
                
                CGRect photoPopupRect = [editTable rectForRowAtIndexPath:indexPath];
                if (indexPath.section == ProfileSectionInsurance) {
                    CGFloat originY = photoPopupRect.origin.y;
                    originY = originY + (iPad ? 70 : 80);
                    photoPopupRect = CGRectMake(photoPopupRect.origin.x, originY, photoPopupRect.size.width, photoPopupRect.size.height);
                }
                
                [self.popover presentPopoverFromRect:CGRectMake(photoPopupRect.origin.x, photoPopupRect.origin.y, 1, 1) inView:editTable permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
            }
        }
        else{
            UIAlertView *camerAlert = [[UIAlertView alloc]initWithTitle:@"Message" message:@"Your device doesn't support camera or it is damaged" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil , nil];
            [camerAlert show];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (CURRENT_DEVICE_VERSION < 7.0f) {
        viewController.contentSizeForViewInPopover = CGSizeMake(748, 800);
    } else {
        viewController.preferredContentSize = CGSizeMake(748, 800);
    }
}

- (void)useCurrentPicture:(id)sender {
    @try {
        [addConfirmationView removeFromSuperview];
        addConfirmationView = nil;
        
        [photoPopUp_View removeFromSuperview];
        photoPopUp_View = nil;
        
        [editTable reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)tryAgain:(id)sender {
    
    @try {
        if([self isNotNull:addConfirmationView]) {
            [addConfirmationView removeFromSuperview];
        }
        
        if(isImgSourceTypeCamera) {
            [self openCamera];
        } else {
            [self chooseFromLibrary:nil];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)cancelCapturedPictureOrVideo:(id)sender {
    TCSTART
    [addConfirmationView removeFromSuperview];
    
    //    if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame) {
    //        frontCard = nil;
    //    }else if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame) {
    //        backCard = nil;
    //    }else{
    //        newAvatarImage = nil;
    //    }
    TCEND
}

- (void)removeCapturedPhotoOrVideo:(id)sender {
    @try {
        [photoPopUp_View removeFromSuperview];
        [preview_imgView removeFromSuperview];
        
        if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame) {
            frontCard = nil;
        }else if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame) {
            backCard = nil;
        }else{
            newAvatarImage = nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)openCamera {
    
    @try {
        //Check whether camera is available or not
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            isImgSourceTypeCamera = YES;
            UIImagePickerController *picker=[[UIImagePickerController alloc]init];
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            picker.delegate = self;
            
            [self.navigationController presentViewController:picker animated:YES completion:nil];
            
        }
        else{
            
            UIAlertView *camerAlert = [[UIAlertView alloc]initWithTitle:@"Message" message:@"Your device doesn't support camera or it is damaged" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil , nil];
            [camerAlert show];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark ImagePicker Delegate methods.
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    //[self dismissModalViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:^{
        //code
    }];
}

//camera delegate method called when you click on use photo button in camera view.
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        
        if (!addConfirmationView) {
            addConfirmationView = [[UIView alloc]initWithFrame:CGRectMake(appDelegate.window.frame.origin.x, appDelegate.window.frame.origin.y + 20, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height)];
        }
        
        addConfirmationView.backgroundColor = [UIColor clearColor];
        [appDelegate.window addSubview:addConfirmationView];
        [appDelegate.window bringSubviewToFront:addConfirmationView];
        
        UIImageView *addConfirmationImgBGView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
        addConfirmationImgBGView.frame = addConfirmationView.frame;
        addConfirmationImgBGView.center = CGPointMake(addConfirmationView.frame.size.width/2, addConfirmationView.frame.size.height/2);
        [addConfirmationView addSubview:addConfirmationImgBGView];
        
        UIImageView *previewImgView = [[UIImageView alloc]init];
        previewImgView.frame = CGRectMake(34, 32, 700, 700);
        previewImgView.layer.cornerRadius = 5.0f;
        previewImgView.layer.masksToBounds = YES;
        //        previewImgView.backgroundColor = [UIColor clearColor];
        [addConfirmationView addSubview:previewImgView];
        
        UIButton *use_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        use_btn.frame = CGRectMake(184, 757, 400, 55);
        use_btn.backgroundColor = [UIColor clearColor];
        [use_btn addTarget:self action:@selector(useCurrentPicture:) forControlEvents:UIControlEventTouchUpInside];
        [addConfirmationView addSubview:use_btn];
        
        UIButton *tryAgain_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        tryAgain_btn.frame = CGRectMake(184, 840, 400, 55);
        tryAgain_btn.backgroundColor = [UIColor clearColor];
        [tryAgain_btn addTarget:self action:@selector(tryAgain:) forControlEvents:UIControlEventTouchUpInside];
        [tryAgain_btn setImage:[UIImage imageNamed:@"tryagain"] forState:UIControlStateNormal];
        [addConfirmationView addSubview:tryAgain_btn];
        
        UIButton *cancel_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancel_btn.frame = CGRectMake(184, 919, 400, 55);
        cancel_btn.backgroundColor = [UIColor clearColor];
        cancel_btn.layer.cornerRadius = 5.0f;
        cancel_btn.layer.masksToBounds = YES;
        [cancel_btn addTarget:self action:@selector(cancelCapturedPictureOrVideo:) forControlEvents:UIControlEventTouchUpInside];
        [cancel_btn setImage:[UIImage imageNamed:@"cancelcapturedimage"] forState:UIControlStateNormal];
        
        if (!iPad) {
            previewImgView.frame = CGRectMake(10, 7, 300, 300);
            use_btn.frame = CGRectMake(20, 319, 280, 36);
            tryAgain_btn.frame = CGRectMake(20, 365, 280, 36);
            cancel_btn.frame = CGRectMake(20, 411, 280, 36);
        }
        
        [addConfirmationView addSubview:cancel_btn];
        NSData *imageData;
        
        NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
        if ([mediaType isEqualToString:@"public.image"]){
            
            CGSize newimageSize = CGSizeMake(0,0);
            UIImage *rawImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
            
            CGSize imgsize = rawImage.size;
            NSLog(@"photo size: width %f, height %f",imgsize.width,imgsize.height);
            //TODO SIZE
            if (imgsize.width <= 1024 && imgsize.height <= 1024) {
                newimageSize.width = imgsize.width;
                newimageSize.height = imgsize.height;
                
            } else {
                if (imgsize.width > imgsize.height) {
                    newimageSize.width = 1024;
                    newimageSize.height = (imgsize.height / imgsize.width)*1024;
                    newimageSize.height = ceil(newimageSize.height);
                }else{
                    newimageSize.height = 1024;
                    newimageSize.width = (imgsize.width / imgsize.height)*1024;
                    newimageSize.width = ceil(newimageSize.width);
                }
            }
            NSLog(@"Image width: %f height %f",newimageSize.width,newimageSize.height);
            NSLog(@"changeAvatarReqFor: %@",changeAvatarReqFor);
            
            NSString *nowTimestamp;
            UIImage *newImage;
            if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame && [self isNotNull:rawImage]) {
                if (selectedIndex == 1){
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceFrontCardData=imageData;
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    frontCard=previewImgView.image;
                    previewImgView.tag = 5001;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:0 withObject:previewImgView];
                    
                }
                else if (selectedIndex == 4){
                    
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceFrontCardTwoData=imageData;
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    frontCard2=previewImgView.image;
                    
                    previewImgView.tag = 5003;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:2 withObject:previewImgView];
                    
                }
                else if (selectedIndex == 7){
                    
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceFrontCardThreeData=imageData;
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    frontCard3=previewImgView.image;
                    
                    previewImgView.tag = 5005;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:4 withObject:previewImgView];
                    
                }
                
            }
            else if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame  && [self isNotNull:rawImage]) {
                if (selectedIndex == 2){
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceBackCardData=imageData;
                    
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    backCard=previewImgView.image;
                    
                    previewImgView.tag = 5002;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:1 withObject:previewImgView];
                    
                }
                else if (selectedIndex == 5){
                    
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceBackCardTwoData=imageData;
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    backCard2=previewImgView.image;
                    
                    previewImgView.tag = 5004;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:3 withObject:previewImgView];
                    
                }
                else if (selectedIndex == 8){
                    
                    newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                    imageData = UIImagePNGRepresentation(newImage);
                    profiledatamodel.insuranceBackCardThreeData=imageData;
                    previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                    backCard3=previewImgView.image;
                    
                    previewImgView.tag = 5006;
                    nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
                    [profiledatamodel.aryInsuranceCards replaceObjectAtIndex:5 withObject:previewImgView];
                    
                }
            }
            else {
                newImage = [self imageWithImage:rawImage scaledToSize:newimageSize];
                imageData = UIImagePNGRepresentation(newImage);
                profiledatamodel.avatarImageData = imageData;
                previewImgView = [self setImageOnCard:previewImgView cardImage:newImage];
                newAvatarImage = previewImgView.image;
                nowTimestamp = [NSString stringWithFormat:@"%.Lf",ceill([[NSDate date] timeIntervalSince1970])];
            }
            [use_btn setImage:[UIImage imageNamed:@"UserThisPhoto"] forState:UIControlStateNormal];
            
            //set tag to 5001 if captured is image.
        }
        
        //[picker dismissModalViewControllerAnimated:YES];//dismissing the camera view controller.
        [picker dismissViewControllerAnimated:YES completion:^{
            //code
        }];
        [self.popover dismissPopoverAnimated:YES];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(UIImageView*)setImageOnCard:(UIImageView*)previewImgView cardImage:(UIImage*)cardImage
{
    //    if ([changeAvatarReqFor caseInsensitiveCompare:@"front"] == NSOrderedSame) {
    //FrontCard
    UIImage *croppedFrontImage = nil;
    if ([self isNotNull:frontCard]) {
        if (cardImage.size.width >= 600 && cardImage.size.height >= 600) {
            croppedFrontImage = [appDelegate getImageByCroppingImage:cardImage toRect:CGRectMake(0, 0, 600, 600)];
        } else if(cardImage.size.width < 300 && cardImage.size.height < 300) {
            croppedFrontImage = cardImage;
        } else {
            croppedFrontImage = [appDelegate getImageByCroppingImage:cardImage toRect:CGRectMake(0, 0, 300, 300)];
        }
        //            previewImgView.image = croppedFrontImage;
        [previewImgView setImage:croppedFrontImage];
    }
    return previewImgView;
    //    }else     if ([changeAvatarReqFor caseInsensitiveCompare:@"back"] == NSOrderedSame) {
    //        //BackCard
    //        UIImage *croppedBackImage = nil;
    //        if ([self isNotNull:backCard]) {
    //            if (backCard.size.width >= 600 && backCard.size.height >= 600) {
    //                croppedBackImage = [appDelegate getImageByCroppingImage:backCard toRect:CGRectMake(0, 0, 600, 600)];
    //            } else if(backCard.size.width < 300 && backCard.size.height < 300) {
    //                croppedBackImage = backCard;
    //            } else {
    //                croppedBackImage = [appDelegate getImageByCroppingImage:backCard toRect:CGRectMake(0, 0, 300, 300)];
    //            }
    //            [previewImgView setImage:croppedBackImage];
    //        }
    //    }else{
    //        //Profile
    //        UIImage *croppedImage = nil;
    //        if ([self isNotNull:newAvatarImage]) {
    //            if (newAvatarImage.size.width >= 600 && newAvatarImage.size.height >= 600) {
    //                croppedImage = [appDelegate getImageByCroppingImage:newAvatarImage toRect:CGRectMake(0, 0, 600, 600)];
    //            } else if(newAvatarImage.size.width < 300 && newAvatarImage.size.height < 300) {
    //                croppedImage = newAvatarImage;
    //            } else {
    //                croppedImage = [appDelegate getImageByCroppingImage:newAvatarImage toRect:CGRectMake(0, 0, 300, 300)];
    //            }
    //            [previewImgView setImage:croppedImage];
    //        }
    //    }
}

//Resize the image
- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSize:(CGSize)targetSize {
    @try {
        UIImage *newImage = nil;
        
        CGFloat targetWidth = targetSize.width;
        CGFloat targetHeight = targetSize.height;
        
        //   CGFloat scaleFactor = 0.0;
        CGFloat scaledWidth = targetWidth;
        CGFloat scaledHeight = targetHeight;
        
        CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
        
        // this is actually the interesting part:
        
        UIGraphicsBeginImageContext(targetSize);
        
        CGRect thumbnailRect = CGRectZero;
        thumbnailRect.origin = thumbnailPoint;
        thumbnailRect.size.width  = scaledWidth;
        thumbnailRect.size.height = scaledHeight;
        
        [sourceImage drawInRect:thumbnailRect];
        
        newImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        if(newImage == nil) NSLog(@"could not scale image");
        
        return newImage ;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Select Switch Flipped
-(void)switchFlipped:(UICustomSwitch*)switchView {
    //	NSLog(@"switchFlipped=%f  on:%@",switchView.value, (switchView.on?@"Y":@"N"));
    if (switchView.on) {
        profiledatamodel.gender = @"M";
        NSLog(@"Male Selected");
    } else {
        profiledatamodel.gender = @"F";
        NSLog(@"Female Selected");
    }
}

#pragma mark Show Gender or Show Location Slider
-(void)showLocationswitchFlipped:(UICustomSwitch*)switchView {
    if (switchView.on) {
        profiledatamodel.isShowLocation = [NSNumber numberWithBool:YES];
    } else {
        profiledatamodel.isShowLocation = [NSNumber numberWithBool:NO];
    }
}

- (void)configureTheDatePicker {
    
    TCSTART
    NSDateFormatter *FormatDate = [[NSDateFormatter alloc] init];
    
    [FormatDate setLocale: [[NSLocale alloc]
                            initWithLocaleIdentifier:@"en_US"]];
    [FormatDate setDateFormat:@"yyyy-MM-dd"];
    if (iPad) {
        pickerViewDateView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, 1024)];
        pickerViewDateView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, 788, appDelegate.window.frame.size.width, 216)];
        theDatePicker.datePickerMode = UIDatePickerModeDate;
        if ([self isNotNull:profiledatamodel.birthDay]) {
            theDatePicker.date = [FormatDate dateFromString:profiledatamodel.birthDay];
        }
        
        //[theDatePicker release];
        [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDateInProfile:) forControlEvents:UIControlEventValueChanged];
        theDatePicker.backgroundColor = [UIColor whiteColor];
        UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 744, appDelegate.window.frame.size.width, 44)];
        pickerToolbar.barStyle=UIBarStyleBlackOpaque;
        [pickerToolbar sizeToFit];
        NSMutableArray *barItems = [[NSMutableArray alloc] init];
        UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
        [barItems addObject:flexSpace];
        
        [pickerToolbar setItems:barItems animated:YES];
        [pickerViewDateView addSubview:pickerToolbar];
        [pickerViewDateView addSubview:theDatePicker];
        [self.view addSubview:pickerViewDateView];
    } else {
        if(isiPhone6 || CURRENT_DEVICE_VERSION >= 8.0) {
            pickerViewDateView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height)];
            pickerViewDateView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
            UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, appDelegate.window.frame.size.height-216, appDelegate.window.frame.size.width, 216)];
            theDatePicker.datePickerMode = UIDatePickerModeDate;
            if ([self isNotNull:profiledatamodel.birthDay]) {
                theDatePicker.date = [FormatDate dateFromString:profiledatamodel.birthDay];
            }
            
            //[theDatePicker release];
            [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDateInProfile:) forControlEvents:UIControlEventValueChanged];
            theDatePicker.backgroundColor = [UIColor whiteColor];
            UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, appDelegate.window.frame.size.height-216-44, appDelegate.window.frame.size.width, 44)];
            pickerToolbar.barStyle=UIBarStyleBlackOpaque;
            [pickerToolbar sizeToFit];
            NSMutableArray *barItems = [[NSMutableArray alloc] init];
            UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
            [barItems addObject:flexSpace];
            
            [pickerToolbar setItems:barItems animated:YES];
            [pickerViewDateView addSubview:pickerToolbar];
            [pickerViewDateView addSubview:theDatePicker];
            [self.view addSubview:pickerViewDateView];
        }
        else {
            pickerViewDateActionSheet = [[UIActionSheet alloc] initWithTitle:@"How many?"
                                                                    delegate:self
                                                           cancelButtonTitle:nil
                                                      destructiveButtonTitle:nil
                                                           otherButtonTitles:nil];
            
            UIDatePicker *theDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0, 44.0, 0.0, 0.0)];
            theDatePicker.datePickerMode = UIDatePickerModeDate;
            if ([self isNotNull:profiledatamodel.birthDay]) {
                theDatePicker.date = [FormatDate dateFromString:profiledatamodel.birthDay];
            }
            theDatePicker.backgroundColor = [UIColor whiteColor];
            [theDatePicker addTarget:self action:@selector(reloadTableWithSelectedDateInProfile:) forControlEvents:UIControlEventValueChanged];
            
            UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
            pickerToolbar.barStyle=UIBarStyleBlackOpaque;
            [pickerToolbar sizeToFit];
            NSMutableArray *barItems = [[NSMutableArray alloc] init];
            UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(DatePickerDoneClick)];
            [barItems addObject:flexSpace];
            
            [pickerToolbar setItems:barItems animated:YES];
            [pickerViewDateActionSheet addSubview:pickerToolbar];
            [pickerViewDateActionSheet addSubview:theDatePicker];
            [pickerViewDateActionSheet  showInView:appDelegate.window];
            [pickerViewDateActionSheet setBounds:CGRectMake(0,0,320, 464)];
            
            //move the table up to show the birthday day which is selected by the user.
            //            editTable.contentInset = UIEdgeInsetsMake(0.0, 0.0f, 310, 0.0f);
            //            [editTable setContentOffset:CGPointMake(editTable.contentOffset.x, 310) animated:YES];
            NSIndexPath *indexPath = [editTable indexPathForSelectedRow];
            [editTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
    }
    TCEND
}

- (void)DatePickerCancelSelected:(id)sender{
    [self DatePickerDoneClick];
}

#pragma mark
#pragma mark DatePicker Related
-(void)reloadTableWithSelectedDateInProfile:(id)sender{
    
    @try {
        datePicker = (UIDatePicker *)sender;
        NSDateFormatter *FormatDate = [[NSDateFormatter alloc] init];
        
        [FormatDate setLocale: [[NSLocale alloc]
                                initWithLocaleIdentifier:@"en_US"]];
        [FormatDate setDateFormat:@"yyyy-MM-dd"];
        profiledatamodel.birthDay = [FormatDate stringFromDate:datePicker.date];
        
        [editTable reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)DatePickerDoneClick {
    @try {
        if (iPad) {
            [pickerViewDateView removeFromSuperview];
            pickerViewDateView = nil;
        } else {
            if(isiPhone6 || CURRENT_DEVICE_VERSION >= 8.0) {
                [pickerViewDateView removeFromSuperview];
                pickerViewDateView = nil;
            }
            else {
                [pickerViewDateActionSheet dismissWithClickedButtonIndex:0 animated:YES];
                pickerViewDateActionSheet = nil;
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (NSString *)getInsuranceProviderName:(NSInteger)providerId {
    TCSTART
    NSString *providerName;
    NSInteger localProviderId = providerId;
    for (NSDictionary *dict in insuranceProvidersArray) {
        if(localProviderId==0){
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id intValue]) {
                return [dict objectForKey:@"name"];
            }
        }
        else if (localProviderId==1)
        {
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id2 intValue]) {
                return [dict objectForKey:@"name"];
            }
        }
        else
        {
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id3 intValue]) {
                return [dict objectForKey:@"name"];
            }
        }
    }
    return providerName;
    TCEND
}

- (int)getSelectedInsuranceProviderIndex:(NSInteger)selectedInsurance {
    TCSTART
    //    NSString *providerName;
    //    for (NSDictionary *dict in insuranceProvidersArray) {
    NSInteger localSelectedInsurance = selectedInsurance;
    for (int i=0;i<insuranceProvidersArray.count;i++) {
        NSDictionary *dict = [insuranceProvidersArray objectAtIndex:i];
        if(localSelectedInsurance==0){
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id intValue]) {
                return i;
            }
        }
        else if(localSelectedInsurance==1){
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id2 intValue]) {
                return i;
            }
        }
        else{
            if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.insurance_provider_id3 intValue]) {
                return i;
            }
        }
    }
    return 0;
    TCEND
}

//- (NSString *)getPreferredContactMethodName {
//    TCSTART
//    NSString *methodName;
//    for (NSDictionary *dict in insuranceProvidersArray) {
//        if ([[dict objectForKey:@"id"] intValue] == [profiledatamodel.preferredAppointmentContactMethod ]) {
//            return [dict objectForKey:@"name"];
//        }
//    }
//    return methodName;
//    TCEND
//}
#pragma mark Insurance provider / contact method PickerView
#pragma mark pickerView Datasource and delgate methods
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag==25) {
        //This is for Preferred contact method
        return [preferredContactsArray count];
    }else if(pickerView.tag ==27){
        //States
        return [usStatesArray count];
    }else{
        //This is for Providers
        return [insuranceProvidersArray count];
    }
    
}


-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 25) {
        return [preferredContactsArray objectAtIndex:row];
    }else if (pickerView.tag == 27){
        return [usStatesArray objectAtIndex:row];
    }else{
        NSDictionary *insuranceProvider;
        insuranceProvider = [insuranceProvidersArray objectAtIndex:row];
        
        return [insuranceProvider objectForKey:@"name"];
    }
    
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    TCSTART
    if (pickerView.tag == 25) {
        profiledatamodel.preferredAppointmentContactMethod = [preferredContactsArray objectAtIndex:row];
        
    }else if(pickerView.tag == 27){
        //        [regDict setObject:[usStatesArray objectAtIndex:row] forKey:@"state"];
        profiledatamodel.state = [usStatesArray objectAtIndex:row];
        [editTable reloadData];
    }else if(pickerView.tag == 6666){
        NSDictionary *insuranceProvider;
        insuranceProvider = [insuranceProvidersArray objectAtIndex:row];
        profiledatamodel.insurance_provider_id = [[insuranceProvider objectForKey:@"id"] stringValue];
    }
    else if (pickerView.tag==6667){
        NSDictionary *insuranceProvider;
        insuranceProvider = [insuranceProvidersArray objectAtIndex:row];
        profiledatamodel.insurance_provider_id2 = [[insuranceProvider objectForKey:@"id"] stringValue];
    }
    else if (pickerView.tag==6668){
        NSDictionary *insuranceProvider;
        insuranceProvider = [insuranceProvidersArray objectAtIndex:row];
        profiledatamodel.insurance_provider_id3 = [[insuranceProvider objectForKey:@"id"] stringValue];
    }
    
    [editTable reloadData];
    TCEND
}


#pragma mark toolbar done clicked
- (IBAction)toolbarDoneSelected:(id)sender {
    
    UIBarButtonItem *pickerView = (UIBarButtonItem *)sender;
    NSLog(@"UIPicker view tag: %ld in toolbarDoneSelected method", (long)pickerView.tag);
    if (pickerView.tag == 25) {
        preferredContactMethodView.hidden = YES;
        if ([self isNotNull:previousSelectedAppointmentMethod]) {
            if ([previousSelectedAppointmentMethod isEqualToString:profiledatamodel.preferredAppointmentContactMethod]) {
            }else{
                profiledatamodel.preferredAppointmentContactData = @"";
            }
        }else{
            profiledatamodel.preferredAppointmentContactData = @"";
        }
        previousSelectedAppointmentMethod = profiledatamodel.preferredAppointmentContactMethod;
        
    }else if(pickerView.tag ==27){
        statesView.hidden = YES;
    }else{
        [insurancePickerDisplayView removeFromSuperview];
        insurancePickerDisplayView=nil;
    }
    [editTable reloadData];
    
}

- (void)initialisePickerView:(NSInteger)selectInsurance {
    TCSTART
    if ([self isNull:insurancePickerDisplayView]) {
        insurancePickerDisplayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, 1024)];
        insurancePickerDisplayView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        
        insurancePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - 216, appDelegate.window.frame.size.width, 216)];
        [insurancePickerDisplayView addSubview:insurancePickerView];
        insurancePickerView.delegate = self;
        insurancePickerView.dataSource = self;
        insurancePickerView.showsSelectionIndicator = YES;
        insurancePickerView.backgroundColor = [UIColor whiteColor];
        int selectedState;
        
        if(selectInsurance==0){
            insurancePickerView.tag = 6666;
            selectedState = [self getSelectedInsuranceProviderIndex:0];
            
        }
        else if(selectInsurance==1){
            insurancePickerView.tag = 6667;
            selectedState = [self getSelectedInsuranceProviderIndex:1];
            
        }
        else if(selectInsurance==2){
            insurancePickerView.tag = 6668;
            selectedState = [self getSelectedInsuranceProviderIndex:2];
        }
        
        if (selectedState!=-1&& selectedState<insuranceProvidersArray.count) {
            [insurancePickerView selectRow:selectedState inComponent:0 animated:NO];
        }
        
        toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (216 + 44), appDelegate.window.frame.size.width, 44)];
        [toolBar setBarStyle:UIBarStyleBlack];
        
        UIBarButtonItem *leftBarbutton = [[UIBarButtonItem alloc] initWithTitle:@"Select insurance provider:" style:UIBarButtonItemStylePlain target:nil action:nil];
        //    if (!iPad) {
        leftBarbutton.width = (iPad?450:245);
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, leftBarbutton.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
        txtLabel.textAlignment = NSTextAlignmentLeft;
        txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        txtLabel.text = @"Select insurance provider:";
        leftBarbutton.customView = txtLabel;
        //    }
        
        UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *rightbutton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(toolbarDoneSelected:)];
        toolBar.items = [NSArray arrayWithObjects:leftBarbutton,flexibleSpace,rightbutton, nil];
        
        [insurancePickerDisplayView addSubview:toolBar];
        
        [self.view addSubview:insurancePickerDisplayView];
    } else {
        insurancePickerDisplayView.hidden = NO;
        [insurancePickerView reloadAllComponents];
    }
    NSIndexPath *indexPath = [editTable indexPathForSelectedRow];
    [editTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    TCEND
}

- (void)initialisePickerViewWithContactMethods {
    TCSTART
    if ([self isNull:preferredContactMethodView]) {
        //
        //        UIView  *preferredContactMethodView;
        //        UIPickerView *preferredContactPickerView;
        //        UIToolbar *preferredContactToolBar;
        //        NSArray *preferredContactsArray;
        //
        preferredContactMethodView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, 1024)];
        preferredContactMethodView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        
        preferredContactPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - 216, appDelegate.window.frame.size.width, 216)];
        [preferredContactMethodView addSubview:preferredContactPickerView];
        preferredContactPickerView.delegate = self;
        preferredContactPickerView.dataSource = self;
        preferredContactPickerView.tag = 25;
        preferredContactPickerView.showsSelectionIndicator = YES;
        preferredContactPickerView.backgroundColor = [UIColor whiteColor];
        
        int selectedState = [preferredContactsArray indexOfObject:profiledatamodel.preferredAppointmentContactMethod];
        //
        if (selectedState!=-1&& selectedState<preferredContactsArray.count) {
            [preferredContactPickerView selectRow:selectedState inComponent:0 animated:NO];
        }
        if ([self isNull:profiledatamodel.preferredAppointmentContactMethod]) {
            profiledatamodel.preferredAppointmentContactMethod = [preferredContactsArray objectAtIndex:0];
        }
        
        preferredContactToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (216 + 44), appDelegate.window.frame.size.width, 44)];
        [preferredContactToolBar setBarStyle:UIBarStyleBlack];
        
        UIBarButtonItem *leftBarbutton = [[UIBarButtonItem alloc] initWithTitle:@"Preferred contact method:" style:UIBarButtonItemStylePlain target:nil action:nil];
        //    if (!iPad) {
        leftBarbutton.width = (iPad?450:245);
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, leftBarbutton.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
        txtLabel.textAlignment = NSTextAlignmentLeft;
        txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        txtLabel.text = @"Preferred contact method:";
        leftBarbutton.customView = txtLabel;
        //    }
        
        UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *rightbutton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(toolbarDoneSelected:)];
        rightbutton.tag = 25;
        preferredContactToolBar.items = [NSArray arrayWithObjects:leftBarbutton,flexibleSpace,rightbutton, nil];
        
        [preferredContactMethodView addSubview:preferredContactToolBar];
        
        [self.view addSubview:preferredContactMethodView];
    } else {
        preferredContactMethodView.hidden = NO;
        [preferredContactPickerView reloadAllComponents];
    }
    NSIndexPath *indexPath = [editTable indexPathForSelectedRow];
    [editTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    TCEND
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if (interfaceOrientation == UIInterfaceOrientationPortrait) {
        return YES;
    } else {
        //        if (appDelegate.landscapeSupport) {
        //            return YES;
        //        }
        return NO;
    }
}

-(BOOL)shouldAutorotate {
    //    if(appDelegate.landscapeSupport){
    //        return YES;
    //    }else{
    return NO;
    //    }
    //    return YES;
    
}

//- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
//{
//    NSLog(@"Interface orientations");
//    if(appDelegate.landscapeSupport)
//        return UIInterfaceOrientationMaskLandscape;
//    return UIInterfaceOrientationMaskLandscape|UIInterfaceOrientationMaskPortrait;
//}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

//ADDING PICKER VIEW
#pragma mark US STATES
#pragma mark pickerView Datasource and delgate methods
//-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
//{
//    return 1;
//}

//-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
//{
//    return [usStatesArray count];
//
//}

//-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
//{
//    return [usStatesArray objectAtIndex:row];
//}


//-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
//{
//    TCSTART
//    [regDict setObject:[usStatesArray objectAtIndex:row] forKey:@"state"];
//    [registrationTableView reloadData];
//    TCEND
//}


#pragma mark toolbar done clicked
//- (IBAction)toolbarDoneSelected:(id)sender {
//    statesView.hidden = YES;
//    [registrationTableView reloadData];
//
//}

- (void)initialiseStatesPickerView {
    TCSTART
    if ([self isNull:statesView]) {
        statesView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, 1024)];
        statesView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        //        216
        int height;
        //        if (CURRENT_DEVICE_VERSION < 7.0) {
        //            height = 300;
        //        }else{
        height = 216;
        //        }
        //        statesPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - 216, self.view.frame.size.width, 400)];
        statesPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height -height, appDelegate.window.frame.size.width, 400)];
        
        [statesView addSubview:statesPickerView];
        statesPickerView.delegate = self;
        statesPickerView.dataSource = self;
        statesPickerView.showsSelectionIndicator = YES;
        statesPickerView.backgroundColor = [UIColor whiteColor];
        statesPickerView.tag = 27;
        
        int selectedState = [usStatesArray indexOfObject:profiledatamodel.state];
        //
        if (selectedState!=-1&& selectedState<usStatesArray.count) {
            [statesPickerView selectRow:selectedState inComponent:0 animated:NO];
        }
        
        
        //        statesToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (216 + 44), self.view.frame.size.width, 44)];
        statesToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.size.height - (height + 44), appDelegate.window.frame.size.width, 44)];
        
        [statesToolBar setBarStyle:UIBarStyleBlack];
        
        UIBarButtonItem *leftBarbutton = [[UIBarButtonItem alloc] initWithTitle:@"Select State:" style:UIBarButtonItemStylePlain target:nil action:nil];
        //    if (!iPad) {
        leftBarbutton.width = (iPad?450:245);
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, leftBarbutton.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
        txtLabel.textAlignment = NSTextAlignmentLeft;
        txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        txtLabel.text = @"Select State:";
        leftBarbutton.customView = txtLabel;
        //    }
        
        UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *rightbutton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(toolbarDoneSelected:)];
        //        rightbutton.title
        rightbutton.tag =27;
        statesToolBar.items = [NSArray arrayWithObjects:leftBarbutton,flexibleSpace,rightbutton, nil];
        
        [statesView addSubview:statesToolBar];
        
        [self.view addSubview:statesView];
    } else {
        statesView.hidden = NO;
        [statesPickerView reloadAllComponents];
    }
    NSIndexPath *indexPath = [editTable indexPathForSelectedRow];
    [editTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    
    TCEND
}


@end
