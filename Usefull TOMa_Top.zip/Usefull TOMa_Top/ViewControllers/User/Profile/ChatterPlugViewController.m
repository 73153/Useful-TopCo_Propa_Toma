//
//  DetailedChatterPludSec.m
//  ChatterPlug
//
//  Created by Pankaj yadav on 21/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ChatterPlugViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation ChatterPlugViewController

@synthesize titleStr,passwordLabelStr;

- (id)initWithUrl:(NSString *)url
{
    self = [super init];
    if (self) {
        loadURL = url;
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        isWebLoaded=NO;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        UIImageView *bg_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
        bg_ImgView.frame = self.view.bounds;
        [self.view addSubview:bg_ImgView];
        
        if (iPad) {
            titleLabel = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 500)/2,13-5,500,50)];
        } else {
            NSLog(@"MyScreen Log:%f",self.view.frame.size.width);
            titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 10-5, appDelegate.window.frame.size.width-10, 30)];
        }
        
//        titleLabel.backgroundColor = [UIColor clearColor];
//        titleLabel.font = [UIFont fontWithName:CenturyGothicFont size:CenturyGothicFontSize];
//        titleLabel.text = titleStr;
//        titleLabel.textAlignment = UITextAlignmentCenter;
//        titleLabel.textColor = [UIColor whiteColor];
        
        titleLabel.textColor=[UIColor whiteColor];
        titleLabel.text = titleStr;
        if(!iPad)
        {
        if([titleStr isEqualToString:@"Tomah Memorial Hospital"])
        {
            titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        }
        else
        {
            titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        }
        }
        else
        titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;

//        titleLabel.textColor = [appDelegate colorWithHexString:@"2977a8"];
        //Hide for Baldwin
        [self.view addSubview:titleLabel];
        
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        if (iPad) {
            backButton.frame = CGRectMake(5,10, 84, 48);
        } else {
            backButton.frame = CGRectMake(5, 7, 59, 32);
        }
        [backButton setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        backButton.layer.cornerRadius = 5.0;
        [backButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [backButton setEnabled:TRUE];
        
        UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
        line_ImgView.image = [UIImage imageNamed:@"line"];
        line_ImgView.tag = 4;
        [self.view addSubview:line_ImgView];
        
        [self.view addSubview:backButton];
        
        
        //Label for the password to be entered
        
        UILabel *lblPassword = [[UILabel alloc] initWithFrame:CGRectMake(0,line_ImgView.frame.size.height + line_ImgView.frame.origin.y, self.view.frame.size.width, 25)];
        /*important--------- */
        [lblPassword setTextAlignment:NSTextAlignmentCenter];
        lblPassword.backgroundColor=[UIColor clearColor];
        lblPassword.textColor=[UIColor lightGrayColor];
        lblPassword.userInteractionEnabled=NO;
        lblPassword.text=passwordLabelStr;
        //@"Please Enter Hospital Password - 02747";
        [self.view addSubview:lblPassword];
        

        if ([passwordLabelStr isEqualToString:@"Please Enter Hospital Password - 02747"]) {
                webView = [[UIWebView alloc] initWithFrame:CGRectMake( 0 ,30 + line_ImgView.frame.size.height + line_ImgView.frame.origin.y + 5, self.view.frame.size.width, self.view.frame.size.height - (line_ImgView.frame.size.height + line_ImgView.frame.origin.y + 5))];
        }
        else
        {
            webView = [[UIWebView alloc]initWithFrame:CGRectMake( 0 ,line_ImgView.frame.size.height + line_ImgView.frame.origin.y + 5, self.view.frame.size.width, self.view.frame.size.height - (line_ImgView.frame.size.height + line_ImgView.frame.origin.y + 5))];

        
            //74pxls is the keyboard height.
        }
            
        webView.scalesPageToFit = YES;
        webView.opaque = NO;
        webView.delegate = self;
        webView.suppressesIncrementalRendering=YES;
        webView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:webView];
         NSLog(@"WebviewUrl start: %@",loadURL);
        [self loadUrl:loadURL];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark WebView Delegate Methods
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSLog(@"shouldStartLoadWithRequest");
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView_ {
    
    @try {
        NSLog(@"webViewDidStartLoad");
        if (!isNetworkIndicator) {
            isNetworkIndicator = YES;
            [appDelegate showNetworkIndicator];
            [appDelegate showActivityIndicatorInView:webView_];
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView_ {
    @try {

        NSLog(@"webViewDidFinishLoad");

//        if (!webView_.isLoading) {
            NSLog(@"webViewDidFinishLoadCompleted");
            isNetworkIndicator = NO;
            [appDelegate hideNetworkIndicator];
            [appDelegate removeNetworkIndicatorInView:webView_];
//        }
//        if ([[webView stringByEvaluatingJavaScriptFromString:@"document.readyState"] isEqualToString:@"complete"]) {
//            NSLog(@"webViewDidFinishLoadCompleted");
//            isNetworkIndicator = NO;
//            [appDelegate hideNetworkIndicator];
//            [appDelegate removeNetworkIndicatorInView:webView_];
//        }
       
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)webView:(UIWebView *)webView_ didFailLoadWithError:(NSError *)error {
    @try {
        NSLog(@"didFailLoadWithError");
//        if(webView_.isLoading)
//        {
//            return;
//        }
//        if (error.code == NSURLErrorCancelled) {
            isNetworkIndicator = NO;
            [appDelegate hideNetworkIndicator];
            [appDelegate removeNetworkIndicatorInView:webView_];
//        }
         NSLog(@"Error:%@",error);

    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)backAction {
    @try {
        webView.delegate = nil;
        webView = nil;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView];
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)loadUrl:(NSString *)URLString {
    
    @try {
        titleLabel.text = titleStr;
            //        htmlDesc = [NSString stringWithFormat:@"<head><meta name='viewport' content='initial-scale=1.0,minimum-scale=1.0, maximum-scale=2.0'/></head><body>%@</body>",htmlDesc];

        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:URLString]]];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}
@end
