//
//  ImageViewController.m
//  Memorial
//
//  Created by Kanakachary on 19/10/13.
//
//

#import "ImageViewController.h"
#import "AppDelegate.h"
#import <UIKit/UIKit.h>

@interface ImageViewController ()

@end

@implementation ImageViewController

- (id)initWithCaller:(UIViewController *)caller andAvatarUrl:(NSString *)avatarUrl_ andAvatar:(UIImage *)avatar_ andTitleText:(NSString *)titleText_ andImagePlaceHolder:(NSString *)imagePlaceHolder_ andIndexPath:(NSIndexPath *)indexPath_ andViewFrame:(CGRect)viewFrame_
{
    self = [super init];
    if (self) {
        // Custom initialization
        caller_ = caller;
        
        avatarUrl = avatarUrl_;
        avatar = avatar_;
        titleText = titleText_;
        imagePlaceHolder = imagePlaceHolder_;
        indexPath = indexPath_;
        viewFrame = viewFrame_;
    }
    return self;
}

- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}
- (void)viewDidLoad {
    appDelegate.landscapeSupport = TRUE;
    [super viewDidLoad];
    self.view.frame=appDelegate.window.frame;
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    //    if (indexPath.section==1 && indexPath.row==0) {
    //    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
    //    }else{
    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
    //    }
    TCSTART
    
    self.view.bounds = viewFrame;
    //    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
    self.view.center = CGPointMake(viewFrame.size.height/2, viewFrame.size.width/2);
    [self.view setTransform:CGAffineTransformMakeRotation(M_PI/2)];
    self.view.backgroundColor = [UIColor blackColor];
    
    UIView *backgroundView = [[UIView alloc] init];
    backgroundView.backgroundColor = [UIColor clearColor];
    backgroundView.layer.borderColor = [UIColor whiteColor].CGColor;
    backgroundView.layer.borderWidth = 2.0f;
    backgroundView.bounds = viewFrame;
    [self.view addSubview:backgroundView];
    
    backgroundView.center = CGPointMake((viewFrame.size.height/2), viewFrame.size.width/2 - (CURRENT_DEVICE_VERSION < 7.0 ?20 : 0));
    [backgroundView setTransform:CGAffineTransformMakeRotation(M_PI/2)];
    
    UIImageView *imgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
    imgView.frame = viewFrame;
    [backgroundView addSubview:imgView];
    
    CGFloat gap;
    if (iPad) {
        titleLabel =[[UILabel alloc] initWithFrame:CGRectMake((viewFrame.size.width - 300)/2, 5 ,300,50)];
        gap = 10;
    } else {
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(2,2, viewFrame.size.width,30)];
        gap = 0;
    }
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"Image Preview";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [backgroundView addSubview:titleLabel];
    
    UIImageView *toplineIamge = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
    toplineIamge.frame = CGRectMake(0, titleLabel.frame.origin.y + titleLabel.frame.size.height, backgroundView.frame.size.height, 13);
    [backgroundView addSubview:toplineIamge];
    
    UIImageView *cardImageView = [[UIImageView alloc]init];
    cardImageView.frame = CGRectMake(0, toplineIamge.frame.origin.y + toplineIamge.frame.size.height, backgroundView.frame.size.height, backgroundView.frame.size.width - (toplineIamge.frame.origin.y + toplineIamge.frame.size.height ));
    NSLog(@"Card image view: x: %f, y: %f, width: %f,height: %f ",cardImageView.frame.origin.x,cardImageView.frame.origin.y,cardImageView.frame.size.width,cardImageView.frame.size.height);
    [backgroundView addSubview:cardImageView];
    
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    closeButton.frame = CGRectMake(backgroundView.frame.size.height - (35 + gap), gap, 35, 35);
    [closeButton setImage:[UIImage imageNamed:@"Survey-Close"] forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(closeImageView:) forControlEvents:UIControlEventTouchUpInside];
    closeButton.tag = -5000;
    [backgroundView addSubview:closeButton];
    
    if (indexPath.section==1 && indexPath.row==0) {
        if(avatar) {
            [cardImageView setImage:avatar];
        } else if([self isNotNull:avatarUrl] && ([avatarUrl rangeOfString:@"http://"].location != NSNotFound || [avatarUrl rangeOfString:@"https://"].location != NSNotFound)) {
            NSString *previewUrl = avatarUrl;
            
            //previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"profile" withString:@"profile_large"];
            [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
        }else{
            [cardImageView setImage:[UIImage imageNamed:@"default-avatar-user"]];
        }
        titleLabel.text = @"Avatar";
    }else
        if (indexPath.section==2 && indexPath.row==1) {
            if(avatar) {
                [cardImageView setImage:avatar];
            } else if([self isNotNull:avatarUrl]&&([avatarUrl rangeOfString:@"http://"].location != NSNotFound || [avatarUrl rangeOfString:@"https://"].location != NSNotFound)) {
                NSString *previewUrl = avatarUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"original"];
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
            }else{
                [cardImageView setImage:[UIImage imageNamed:@"insuranceFrontCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Front";
        }else if(indexPath.section==2 && indexPath.row==2){
            if(avatar) {
                [cardImageView setImage:avatar];
            } else if([self isNotNull:avatarUrl]&&([avatarUrl rangeOfString:@"http://"].location != NSNotFound || [avatarUrl rangeOfString:@"https://"].location != NSNotFound)) {
                NSString *previewUrl = avatarUrl;
                
                previewUrl = [previewUrl stringByReplacingOccurrencesOfString:@"retina"
                                                                   withString:@"standard"];
                
                [cardImageView setImageWithURL:[NSURL URLWithString:previewUrl] placeholderImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
            }else{
                [cardImageView setImage:[UIImage imageNamed:@"insuranceBackCardPreview"]];
            }
            titleLabel.text = @"Insurance Card Back";
        }
    TCEND
}


//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)shouldAutorotate {
    return NO;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return NO;
}

-(void)closeImageView:(id)sender{
    
    @try {
        //        if (indexPath.section==1 && indexPath.row==0) {
        //        }else{
      
        [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:NO];
        //        }
        float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
        if (osVersion >= 5.0) {
            [self dismissViewControllerAnimated:NO completion:nil];
        } else {
            [self dismissModalViewControllerAnimated:NO];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
@end
