//
//  ImageViewController.h
//  Memorial
//
//  Created by Kanakachary on 19/10/13.
//
//

#import <UIKit/UIKit.h>
#import "Base64.h"
#import "ProfileDataModel.h"

@class AppDelegate;

@interface ImageViewController : UIViewController{
    id caller_;
    UILabel *titleLabel;
    AppDelegate *appDelegate;
    NSString *avatarUrl;
    UIImage *avatar;
    NSString *titleText;
    NSString *imagePlaceHolder;
    NSIndexPath *indexPath;
    UIView *imageFullView;
    CGRect viewFrame;
}
- (id)initWithCaller:(UIViewController *)caller andAvatarUrl:(NSString *)avatarUrl_ andAvatar:(UIImage *)avatar_ andTitleText:(NSString *)titleText_ andImagePlaceHolder:(NSString *)imagePlaceHolder_ andIndexPath:(NSIndexPath *)indexPath_ andViewFrame:(CGRect)viewFrame_;

@end
