//
//  DetailedChatterPludSec.h
//  ChatterPlug
//
//  Created by Pankaj yadav on 21/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ChatterPlugViewController : UIViewController <UIWebViewDelegate>
{
    NSString *titleStr;
    UIWebView *webView;
    AppDelegate *appDelegate;
    BOOL isNetworkIndicator;
    UILabel *titleLabel;
    NSString *passwordLabelStr;
    NSString *loadURL;
    BOOL isWebLoaded;
}

@property(nonatomic,strong)NSString *titleStr;
@property(nonatomic,strong)NSString *passwordLabelStr;

- (id)initWithUrl:(NSString *)url;
@end
