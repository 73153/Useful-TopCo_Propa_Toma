//
//  ChangeSecurityQuestionViewController.m
//  Memorial
//
//  Created by Aruna on 20/09/13.
//
//

#import "ChangeSecurityQuestionViewController.h"
#import "SecurityQuestionsViewController.h"

@interface ChangeSecurityQuestionViewController ()

@end

@implementation ChangeSecurityQuestionViewController

- (id)initWithFrame:(CGRect)frame profileDataModal:(ProfileDataModel *)profileDataModal andCaller:(id)caller
{
    self = [super init];
    if (self) {
        userProfile = profileDataModal;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        self.view.frame = frame;
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    self.view.frame=appDelegate.window.frame;
    securityDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:userProfile.securityQuestion?:@"",@"securityQuestion", nil];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    image.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:image];
    
    UILabel *label;
    if (iPad) {
        label = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 300)/2,13 ,300,45)];
    } else {
        label = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 205)/2,5 ,205,30)];
    }
    label.backgroundColor = [UIColor clearColor];
    label.text = @"SECURITY QUESTION";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    [self.view addSubview:label];
    
    UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (iPad) {
        saveBtn.frame = CGRectMake(self.view.frame.size.width - 100, 10, 95, 48);
    } else {
        saveBtn.frame = CGRectMake(self.view.frame.size.width-50-5, 5, 50, 30);
    }
    
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"save"] forState:UIControlStateNormal];
    saveBtn.layer.cornerRadius = 5.0;
    saveBtn.layer.masksToBounds = YES;
    [saveBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    //[saveBtn setHidden:YES];
    [self.view addSubview:saveBtn];
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (iPad) {
        cancelBtn.frame = CGRectMake(5,10, 95, 48);
    } else {
        cancelBtn.frame = CGRectMake(5, 7, 64, 30);
    }
    [cancelBtn setBackgroundImage:[UIImage imageNamed:@"cancel"] forState:UIControlStateNormal];
    cancelBtn.layer.cornerRadius = 5.0;
    [cancelBtn addTarget:self action:@selector(cancelAction:) forControlEvents:UIControlEventTouchUpInside];
    //[cancelBtn setHidden:YES];
    [self.view addSubview:cancelBtn];
    
    UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
    line_ImgView.image = [UIImage imageNamed:@"line"];
    [self.view addSubview:line_ImgView];
    
    [self initialiseTableViewAndAddToView];
    TCEND
	// Do any additional setup after loading the view.
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)saveAction:(id)sender {
    TCSTART
    if ([self validateInput]) {
//        userProfile.securityQuestion = [securityDict objectForKey:@"securityQuestion"];
//        userProfile.securityAnswer = [securityDict objectForKey:@"answer"];
        [self saveSecurityQstnAnswer];
//        [self.navigationController popViewControllerAnimated:YES];
    }
    TCEND
}

- (void)saveSecurityQstnAnswer {
    @try {
        NSMutableDictionary *editInfoDict = [[NSMutableDictionary alloc]init];
        if ([self validateInput]) {
            
//            [editInfoDict setObject:userProfile.securityQuestion?:@"" forKey:@"security_question"];
//            [editInfoDict setObject:userProfile.securityAnswer?:@"" forKey:@"security_answer"];

            [editInfoDict setObject:[securityDict objectForKey:@"securityQuestion"]?:@"" forKey:@"security_question"];
            [editInfoDict setObject:[securityDict objectForKey:@"answer"]?:@"" forKey:@"security_answer"];
            if([self isNotNull:userProfile.birthDay]) {
                [editInfoDict setObject:userProfile.birthDay forKey:@"birth_day"];
            }
            
//            if ([caller_ isKindOfClass:[MainViewController class]]) {
                [appDelegate showActivityIndicatorInView:appDelegate.window];
//            }
            [appDelegate updateUserInformation:editInfoDict withCallbackObject:self];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark UpdateProfile Request Delegate Methods.
- (void) didFinishedupdateUserProfile:(CPUserEntity*) profile {
    @try {
        NSLog(@"didFinishedUpdatingUserProfile %@",profile);
        [appDelegate showSuccessMsg:@"Security credentials updated successfully"];
        appDelegate.isGetUserProfileRequestInProgress = NO;
        NSDictionary *userDict = [NSDictionary dictionaryWithObjectsAndKeys:profile,@"user",appDelegate.userProfileDataModel.authToken,@"authToken", nil];
        
        ProfileDataModel *dataModal = [appDelegate parseProfileInfo:userDict];
        
        if([self isNotNull:dataModal]) {
            appDelegate.userProfileDataModel = dataModal;
        }
        userProfile.securityQuestion = [securityDict objectForKey:@"securityQuestion"];
        userProfile.securityAnswer = [securityDict objectForKey:@"answer"];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    }
}

- (void) didFailToUpdateUserProfileWithErrorMsg:(NSString*) error {
    TCSTART
    appDelegate.isGetUserProfileRequestInProgress = NO;
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    if ([error rangeOfString:@"is in use by another user" options:NSCaseInsensitiveSearch].location != NSNotFound) {
        [appDelegate showErrorMsg:@"Email is in use by other user"];
    } else {
        [appDelegate showErrorMsg:error];
    }
    TCEND
}

- (BOOL)validateInput {
    TCSTART
    BOOL isValid = TRUE;
    
    NSString *question = [securityDict objectForKey:@"securityQuestion"];
    if (question.length > 0) {
        question = [appDelegate removingLastSpecialCharecter:question];
    }
    if (isValid && question.length <= 0) {
        isValid = FALSE;
        [appDelegate showErrorMsg:@"Please select security question"];
    }
    
    if (isValid) {
        NSString *currentAnswer = [securityDict objectForKey:@"current"];
        if (currentAnswer.length > 0) {
            currentAnswer = [appDelegate removingLastSpecialCharecter:currentAnswer];
        }
        if (isValid && currentAnswer.length <= 0) {
            isValid = FALSE;
            [appDelegate showErrorMsg:@"Please enter current answer"];
            return FALSE;
        }
        if ([userProfile.securityAnswer isEqualToString:currentAnswer]) {
            
        } else{
            [appDelegate showErrorMsg:@"You entered the wrong current answer"];
            return FALSE;
        }
    }
    
    if (isValid) {
        //Answer
        NSString *answer = [securityDict objectForKey:@"answer"];
        if (answer.length > 0) {
            answer = [appDelegate removingLastSpecialCharecter:answer];
        }
        if (isValid && answer.length <= 0) {
            isValid = FALSE;
            [appDelegate showErrorMsg:@"Please enter new answer"];
        }
        
        //Confirm answer
        NSString *confiemAnswer = [securityDict objectForKey:@"confirm"];
        if (confiemAnswer.length > 0) {
            confiemAnswer = [appDelegate removingLastSpecialCharecter:confiemAnswer];
        }
        if (isValid) {
            if (isValid && confiemAnswer.length <= 0) {
                isValid = FALSE;
                [appDelegate showErrorMsg:@"Please enter confirm answer"];
            }
        }
        
        if (isValid && ![answer isEqualToString:confiemAnswer]) {
            isValid = FALSE;
            [appDelegate showErrorMsg:@"Answers do not match."];
        }
    }
    return isValid;
    TCEND
}
- (void)cancelAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)initialiseTableViewAndAddToView {
    TCSTART
    if (iPad) {
        changeSecQueTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, self.view.frame.size.height - 90) style:UITableViewStyleGrouped];
    } else {
        changeSecQueTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, self.view.frame.size.height - 60) style:UITableViewStyleGrouped];
    }
    
    changeSecQueTableView.delegate = self;
    changeSecQueTableView.dataSource = self;
    changeSecQueTableView.backgroundView = nil;
    changeSecQueTableView.backgroundColor = [UIColor clearColor];
    if (CURRENT_DEVICE_VERSION < 7.0) {
        changeSecQueTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {
        changeSecQueTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    [self.view addSubview:changeSecQueTableView];
    TCEND
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1.0f;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0 || section == 1) {
        return 1;
    } else {
        return 2;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return (iPad?110:90);
    } else {
        return (iPad?70:50);
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if (indexPath.section == 1 || indexPath.section == 2) {
        NSString *CellIdentifier = [NSString stringWithFormat:@"cell%d%d",indexPath.section,indexPath.row];
        ELCTextfieldCell *cell = (ELCTextfieldCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[ELCTextfieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
        }
        cell.leftLabel = nil;
        cell.rightTextField.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
 
        [self configureCell:cell atIndexPath:indexPath];
        if (indexPath.section == 1) {
            if ([self isNotNull:[securityDict objectForKey:@"current"]]) {
                cell.rightTextField.text = [securityDict objectForKey:@"current"];
            } else {
                cell.rightTextField.placeholder = @"Current answer";
//TODO
//                [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"Current answer" andSpacing:[NSNumber numberWithInt:2]];
            }
            cell.rightTextField.returnKeyType = UIReturnKeyNext;
            
        } else {
            if (indexPath.row == 0) {
                if ([self isNotNull:[securityDict objectForKey:@"answer"]]) {
                    cell.rightTextField.text = [securityDict objectForKey:@"answer"];
                } else {
                    cell.rightTextField.placeholder = @"New answer";
//TODO
//                    [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"New answer" andSpacing:[NSNumber numberWithInt:2]];

                }
                cell.rightTextField.returnKeyType = UIReturnKeyNext;
            } else {
                if ([self isNotNull:[securityDict objectForKey:@"confirm"]]) {
                    cell.rightTextField.text = [securityDict objectForKey:@"confirm"];
                } else {
                    cell.rightTextField.placeholder = @"Confirm answer";;
//TODO
//                    [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"Confirm answer" andSpacing:[NSNumber numberWithInt:2]];

                }
                cell.rightTextField.returnKeyType = UIReturnKeyDone;
            }
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell1:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?70:50) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
        [cell.rightTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
        return cell;
    } else {
        NSString *CellIdentifier = @"SecurityQuestion";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
            
            cell.textLabel.backgroundColor = [UIColor clearColor];
//            cell.textLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
            cell.textLabel.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
            
            cell.textLabel.textColor = [UIColor grayColor];
            cell.textLabel.textAlignment = NSTextAlignmentLeft;
            
            cell.detailTextLabel.backgroundColor = [UIColor clearColor];
            cell.detailTextLabel.textColor = [UIColor lightGrayColor];
            cell.detailTextLabel.textAlignment = NSTextAlignmentLeft;
            cell.detailTextLabel.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
            cell.detailTextLabel.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
            cell.detailTextLabel.numberOfLines = 0;
            [cell.contentView addSubview:cell.detailTextLabel];
        }
//        cell.textLabel.frame = CGRectMake(5, 0, cell.textLabel.frame.size.width, 20);
//        cell.detailTextLabel.frame = CGRectMake(5, 30, cell.detailTextLabel.frame.size.width, cell.detailTextLabel.frame.size.height);
//        cell.textLabel.text = @"Change security question";
        
            //TODO
        [appDelegate setLabelSpacing1:cell.textLabel andText:@"Change security question" andSpacing:[NSNumber numberWithInt:2]];
        if ([self isNotNull:[securityDict objectForKey:@"securityQuestion"]]) {
//            cell.detailTextLabel.text = [securityDict objectForKey:@"securityQuestion"];
            [appDelegate setLabelSpacing1:cell.detailTextLabel andText:[securityDict objectForKey:@"securityQuestion"] andSpacing:[NSNumber numberWithInt:1]];
            
        } else {
            cell.detailTextLabel.text = @"";
        }
        
        if (iPad) {
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
        } else {
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
        }
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell1:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?110:90) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
        return cell;
    }
    TCEND
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0) {
        [self gotoSecurityQuestionsViewController];
    }
}

- (void)gotoSecurityQuestionsViewController {
    TCSTART
    SecurityQuestionsViewController *securityQuestionsVC;
    if (iPad) {
        securityQuestionsVC = [[SecurityQuestionsViewController alloc] initWithNibName:@"SecurityQuestionsViewController~iPad" bundle:nil SelectedSecurityQuestion:userProfile.securityQuestion?:@"" withFrame:self.view.frame withCaller:self];
    } else {
        securityQuestionsVC = [[SecurityQuestionsViewController alloc] initWithNibName:@"SecurityQuestionsViewController~iPhone" bundle:nil SelectedSecurityQuestion:userProfile.securityQuestion?:@"" withFrame:self.view.frame withCaller:self];
    }
    [self.navigationController pushViewController:securityQuestionsVC animated:YES];
    TCEND
}

- (void)selectedSecurityQuestion:(NSString *)question {
    TCSTART
    [securityDict setObject:question forKey:@"securityQuestion"];
    [changeSecQueTableView reloadData];
    TCEND
}
#pragma mark -
#pragma mark Table view data source
- (void)configureCell:(ELCTextfieldCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    @try {
         cell.leftLabel.text = @"";
        if (indexPath.section == 1) {
//            cell.leftLabel.text = @"Current";
            [appDelegate setLabelSpacing:cell.leftLabel andText:@"Current" andSpacing:[NSNumber numberWithInt:2]];
        } else {
            switch (indexPath.row) {
                case 0:
//                    cell.leftLabel.text = @"New";
                            [appDelegate setLabelSpacing:cell.leftLabel  andText:@"New" andSpacing:[NSNumber numberWithInt:2]];
                    break;
                case 1: {
//                    cell.leftLabel.text = @"Confirm";
                            [appDelegate setLabelSpacing:cell.leftLabel andText:@"Confirm" andSpacing:[NSNumber numberWithInt:2]];
                    break;
                }
                default:
                    break;
            }
        }
        
//        NSMutableAttributedString *attributedString;
//        attributedString = [[NSMutableAttributedString alloc] initWithString:@"Please"];
//        [attributedString addAttribute:NSKernAttributeName value:@3 range:NSMakeRange(0, 4)];
//        [cell.leftLabel setAttributedText:attributedString];
        
        cell.rightTextField.secureTextEntry  = YES;
        cell.indexPath = indexPath;
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.leftLabel.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
//        cell.leftLabel.adjustsFontSizeToFitWidth = YES;
        cell.leftLabel.adjustsLetterSpacingToFitWidth = YES;
//        [self test:cell.leftLabel];
//        cell.leftLabel
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark ELCTextFieldCellDelegate Methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath {
    TCSTART
    
    if (_indexPath.row >= 0 && _indexPath.section == 2) {
        changeSecQueTableView.contentInset = UIEdgeInsetsMake(0.0, 0.0f, 100, 0.0f);
        [changeSecQueTableView setContentOffset:CGPointMake(changeSecQueTableView.contentOffset.x, 100) animated:YES];
    }
    //    cellTextFieldRef = _textField;
    
    TCEND
}

- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    @try {
        if (indexPath.row == 0 && indexPath.section == 2) {
            NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row+1 inSection:indexPath.section];
            [[(ELCTextfieldCell*)[changeSecQueTableView cellForRowAtIndexPath:path] rightTextField] becomeFirstResponder];
        } else if(indexPath.row == 1 && indexPath.section == 2) {
            [[(ELCTextfieldCell*)[changeSecQueTableView cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
            
            changeSecQueTableView.contentInset = UIEdgeInsetsMake(0.0, 0.0f, 0.0f, 0.0f);
            [changeSecQueTableView setContentOffset:CGPointMake(changeSecQueTableView.contentOffset.x, 0.0f) animated:YES];
        } else if (indexPath.row == 0 && indexPath.section == 1) {
            NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:indexPath.section+1];
            CGRect indexPahtRect = [changeSecQueTableView rectForRowAtIndexPath:path];
            [[(ELCTextfieldCell*)[changeSecQueTableView cellForRowAtIndexPath:path] rightTextField] becomeFirstResponder];
            [changeSecQueTableView scrollRectToVisible:indexPahtRect animated:YES];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateTextLabelAtIndexPath:(NSIndexPath*)indexPath string:(NSString*)string {
    
    @try {
        if(indexPath.section == 2) {
            if(indexPath.row == 0) {
                [securityDict setObject:string?:@"" forKey:@"answer"];
            }  else if(indexPath.row == 1) {
                [securityDict setObject:string?:@"" forKey:@"confirm"];
            }
        } else if (indexPath.section == 1) {
            [securityDict setObject:string?:@"" forKey:@"current"];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
