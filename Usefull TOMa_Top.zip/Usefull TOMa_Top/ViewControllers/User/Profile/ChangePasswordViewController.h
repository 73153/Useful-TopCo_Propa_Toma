//
//  ChangePasswordViewController.h
//  ChatterPlug
//
//  Created by aruna on 1/19/13.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProfileDataModel.h"
#import "AppDelegate.h"

@interface ChangePasswordViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, ELCTextFieldDelegate,UITextFieldDelegate> {
    
    ProfileDataModel *userProfile;
    UITextField *passwordField;
    AppDelegate *appDelegate;
    UITableView *changePasswordTableView;
    
    UITextField *currentPswdTextField;
    UITextField *newPswdTextField;
    UITextField *confrimationPswdTextField;
    NSMutableDictionary *securityDict;
//    NSIndexPath *currentPwdIndexPath;
//    NSIndexPath *newPwdIndexPath;
//    NSIndexPath *confirmPwdIndexPath;
}

//-(void)setChangePasswordFileds;
- (id)initWithProfile:(ProfileDataModel *)password withPasswordLabel:(UITextField *)pswdLabel;
-(BOOL)verifyPassWord:(UITextField *)textField;

@end
