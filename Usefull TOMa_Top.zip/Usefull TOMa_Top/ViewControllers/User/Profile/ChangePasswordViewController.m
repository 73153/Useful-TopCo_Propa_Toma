//
//  ChangePasswordViewController.m
//  ChatterPlug
//
//  Created by aruna on 1/19/13.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ChangePasswordViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ShowAlert.h"

@implementation ChangePasswordViewController

- (id)initWithProfile:(ProfileDataModel *)profileModel withPasswordLabel:(UITextField *)pswdField
{
    self = [super init];
    if (self) {
        //Custom initialization
        userProfile = profileModel;
        passwordField = pswdField;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame=appDelegate.window.frame;
        // Do any additional setup after loading the view from its nib.
        self.navigationController.navigationBar.hidden = YES;
        securityDict = [[NSMutableDictionary alloc]init];

//        [self initialiseTableViewAndAddToView ];
    }
    @catch (NSException *exception) {
           NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)initialiseTableViewAndAddToView {
    TCSTART
    if (iPad) {
        changePasswordTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, self.view.frame.size.height - 90) style:UITableViewStyleGrouped];
    } else {
        changePasswordTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, self.view.frame.size.height - 60) style:UITableViewStyleGrouped];
    }
    
    changePasswordTableView.delegate = self;
    changePasswordTableView.dataSource = self;
    changePasswordTableView.backgroundView = nil;
    changePasswordTableView.backgroundColor = [UIColor clearColor];
    if (CURRENT_DEVICE_VERSION < 7.0) {
        changePasswordTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {
        changePasswordTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    [self.view addSubview:changePasswordTableView];
    TCEND
}
- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    [super viewWillAppear:YES];
    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    image.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:image];
    
    UILabel *label;
    if (iPad) {
        label = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 300)/2,13 ,300,45)];
    } else {
        label = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 205)/2,5 ,205,30)];
    }
    label.backgroundColor = [UIColor clearColor];
    label.text = @"CHANGE PASSWORD";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    [self.view addSubview:label];
    
    UIButton *saveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (iPad) {
        saveBtn.frame = CGRectMake(self.view.frame.size.width - 100, 10, 95, 48);
    } else {
        saveBtn.frame = CGRectMake(self.view.frame.size.width-50-5, 5, 50, 30);
    }
    
    [saveBtn setBackgroundImage:[UIImage imageNamed:@"save"] forState:UIControlStateNormal];
    saveBtn.layer.cornerRadius = 5.0;
    saveBtn.layer.masksToBounds = YES;
    [saveBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    //[saveBtn setHidden:YES];
    [self.view addSubview:saveBtn];
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    if (iPad) {
        cancelBtn.frame = CGRectMake(5,10, 95, 48);
    } else {
        cancelBtn.frame = CGRectMake(5, 7, 64, 30);
    }
    [cancelBtn setBackgroundImage:[UIImage imageNamed:@"cancel"] forState:UIControlStateNormal];
    cancelBtn.layer.cornerRadius = 5.0;
    [cancelBtn addTarget:self action:@selector(cancelAction:) forControlEvents:UIControlEventTouchUpInside];
    //[cancelBtn setHidden:YES];
    [self.view addSubview:cancelBtn];
    
    UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
    line_ImgView.image = [UIImage imageNamed:@"line"];
    [self.view addSubview:line_ImgView];
    
//    [self setChangePasswordFileds];
    [self initialiseTableViewAndAddToView];
    
    TCEND
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1.0f;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    } else {
        return 2;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (indexPath.section == 0) {
//        return (iPad?110:90);
//    } else {
        return (iPad?70:50);
//    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if (indexPath.section == 0 || indexPath.section == 1) {
        NSString *CellIdentifier = [NSString stringWithFormat:@"cell%d%d",indexPath.section,indexPath.row];
        ELCTextfieldCell *cell = (ELCTextfieldCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            cell = [[ELCTextfieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
        }
        cell.leftLabel = nil;
//        cell.rightTextField.placeholder =@"Current password";
        cell.rightTextField.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
        
        [self configureCell:cell atIndexPath:indexPath];
        if (indexPath.section == 0) {
            if ([self isNotNull:[securityDict objectForKey:@"current"]]) {
                cell.rightTextField.text = [securityDict objectForKey:@"current"];
            } else {
                cell.rightTextField.placeholder = @"Current password";
                    //TODO
//                [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"Current password" andSpacing:[NSNumber numberWithInt:2]];
            }
            cell.rightTextField.returnKeyType = UIReturnKeyNext;
            cell.rightTextField.tag = 3;
            currentPswdTextField = cell.rightTextField;
            
        } else {
            if (indexPath.row == 0) {
                if ([self isNotNull:[securityDict objectForKey:@"answer"]]) {
                    cell.rightTextField.text = [securityDict objectForKey:@"answer"];
                } else {
                        cell.rightTextField.placeholder = @"New password";
                        //TODO
//                    [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"New password" andSpacing:[NSNumber numberWithInt:2]];

                }
                cell.rightTextField.tag = 4;
                cell.rightTextField.returnKeyType = UIReturnKeyNext;
                newPswdTextField = cell.rightTextField;
            } else {
                if ([self isNotNull:[securityDict objectForKey:@"confirm"]]) {
                    cell.rightTextField.text = [securityDict objectForKey:@"confirm"];
                } else {
                    cell.rightTextField.placeholder = @"Confirm password";
                        //TODO
//                    [appDelegate setTextFieldSpacing:cell.rightTextField andText:@"Confirm password" andSpacing:[NSNumber numberWithInt:2]];
                    
                }
                cell.rightTextField.tag = 5;
                cell.rightTextField.returnKeyType = UIReturnKeyDone;
                confrimationPswdTextField = cell.rightTextField;
            }
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell1:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?70:50) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
        [cell.rightTextField setValue:[UIColor lightGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
        return cell;
    }
    TCEND
}
- (void)configureCell:(ELCTextfieldCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    @try {
        cell.leftLabel.text = @"";
        if (indexPath.section == 0) {
                //            cell.leftLabel.text = @"Current";
            [appDelegate setLabelSpacing:cell.leftLabel andText:@"Current" andSpacing:[NSNumber numberWithInt:2]];
        } else {
            switch (indexPath.row) {
                case 0:
                        //                    cell.leftLabel.text = @"New";
                    [appDelegate setLabelSpacing:cell.leftLabel  andText:@"New" andSpacing:[NSNumber numberWithInt:2]];
                    break;
                case 1: {
                        //                    cell.leftLabel.text = @"Confirm";
                    [appDelegate setLabelSpacing:cell.leftLabel andText:@"Confirm" andSpacing:[NSNumber numberWithInt:2]];
                    break;
                }
                default:
                    break;
            }
        }
        cell.rightTextField.secureTextEntry  = YES;
        cell.indexPath = indexPath;
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.leftLabel.font = [UIFont fontWithName:changeSecurityQstnFont size:changeSecurityQstnFontSize];
            //        cell.leftLabel.adjustsFontSizeToFitWidth = YES;
        cell.leftLabel.adjustsLetterSpacingToFitWidth = YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)setChangePasswordFileds {
    @try {
        UIImageView *changePswdBG;
        if (iPad) {
            changePswdBG = [[UIImageView alloc]initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, 350)];
        } else {
            changePswdBG = [[UIImageView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, 165)];
        }
        changePswdBG.image = [UIImage imageNamed:@"changepswdBG"];
        [self.view addSubview:changePswdBG];
        
        UITextField *changePswdTextField = nil;
        for(int i = 0; i < 3; i++) {
            
            changePswdTextField = [[UITextField alloc] init];
            if (iPad) {
                if(i == 0) {
                    changePswdTextField.frame = CGRectMake(self.view.frame.size.width/2 - 3, 105, self.view.frame.size.width/2 - 10, 80);
                    //                changePswdTextField.backgroundColor = [UIColor redColor];
                } else {
                    changePswdTextField.frame = CGRectMake(self.view.frame.size.width/2 - 3, 150 + (i * 80), self.view.frame.size.width/2 - 10, 80);
                    if (i == 2) {
                        changePswdTextField.frame = CGRectMake(self.view.frame.size.width/2 - 3, 150 + (i * 85), self.view.frame.size.width/2 - 10, 80);
                    }
                }
            } else {
                if(i == 0) {
                    changePswdTextField.frame = CGRectMake(self.view.frame.size.width/2 - 3, 63, 150, 30);
                } else {
                    changePswdTextField.frame = CGRectMake(self.view.frame.size.width/2 - 3, 80 + (i * 45), self.view.frame.size.width/2 - 10, 30);
                }
            }
            
            changePswdTextField.tag = i + 3;
            changePswdTextField.backgroundColor = [UIColor clearColor];
            changePswdTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
            [changePswdTextField setDelegate:self];
            [changePswdTextField setFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize]];
            changePswdTextField.secureTextEntry = YES;
            changePswdTextField.textColor = [UIColor whiteColor];
            if (i == 2) {
                [changePswdTextField setReturnKeyType:UIReturnKeyDone];
            } else {
                [changePswdTextField setReturnKeyType:UIReturnKeyNext];
            }
            
            [self.view addSubview:changePswdTextField]; 
        }
        changePswdTextField = (UITextField *)[self.view viewWithTag:3];
        [changePswdTextField becomeFirstResponder];
    }
    @catch (NSException *exception) {
           NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)saveAction:(id)sender{
    
    @try {
        BOOL isPasswordVerified;
//        UITextField *currentPswdTextField = nil;
//        UITextField *newPswdTextField = nil;
//        UITextField *confrimationPswdTextField = nil;

//        NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
//        ELCTextfieldCell *cell = (ELCTextfieldCell *)[editTable cellForRowAtIndexPath:indexPath];

        
        
        //check for current password matches the entered password 
//        currentPswdTextField = (UITextField *)[self.view viewWithTag:3];
        isPasswordVerified = [self verifyPassWord:currentPswdTextField];
        
        //isPasswordVerified = YES;
        //check for the current password matched with the password that we have success and check for new password pharse.
        if(isPasswordVerified) {
            
//            newPswdTextField = (UITextField *)[self.view viewWithTag:4];
            isPasswordVerified = [self verifyPassWord:newPswdTextField];
        }
        
//        isPasswordVerified = YES;
        //check for the new password phrase matched the required password crietieria and check for the confirmation password phrase matches the newpassword phrase.
        if(isPasswordVerified) {
            
//            confrimationPswdTextField = (UITextField *)[self.view viewWithTag:5];
            isPasswordVerified = [self verifyPassWord:confrimationPswdTextField];
        }
        
        
        //finally check for both passwords mathces or not and set the new password to the user profile page.
        if(isPasswordVerified) {
            
//            UITextField *confrimationPswdTextField = (UITextField *)[self.view viewWithTag:5];
            userProfile.passwordStr = confrimationPswdTextField.text;
            
            [appDelegate changePassword:currentPswdTextField.text withNewPassword:confrimationPswdTextField.text];
            
            if(passwordField) {
                passwordField.text = userProfile.passwordStr;
            }
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    @catch (NSException *exception) {
          NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)cancelAction:(id)sender {
    
    @try {
        //set the text field and its delegate to nil otherwise when view is dissapearing textfiled delegate method shouldreturn will call a method verify password and an alert is thrown.
        UITextField *pswdTextField = (UITextField *)[self.view viewWithTag:3];
        pswdTextField.delegate = nil;
        pswdTextField = nil;
        
        pswdTextField = (UITextField *)[self.view viewWithTag:4];
        pswdTextField.delegate = nil;
        pswdTextField = nil;
        
        pswdTextField = (UITextField *)[self.view viewWithTag:5];
        pswdTextField.delegate = nil;
        pswdTextField = nil;
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark TextField Delegate Methods
-(void)textFieldDidBeginEditing:(UITextField *)textField {
    @try {
        textField.rightView = nil;
        textField.rightViewMode = UITextFieldViewModeNever;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//- (BOOL)textFieldShouldReturn:(UITextField *)textField {
//    
//    @try {
//        if (textField.tag == 3) {
//            UITextField *newPswdTextField = (UITextField *)[self.view viewWithTag:4];
//            [newPswdTextField becomeFirstResponder];
//        } else if (textField.tag == 4) {
//           UITextField *confirmPswdTextField = (UITextField *)[self.view viewWithTag:5];
//            [confirmPswdTextField becomeFirstResponder];
//        } else {
//            [textField resignFirstResponder];
//        }
//        
//        return YES;
//    }
//    @catch (NSException *exception) {
//         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
//    }
//    @finally {
//    }
//}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
   TCSTART
    if (textField.tag == 4) {
        
        NSInteger passwordStrength = [appDelegate checkPasswordStrength:textField.text];
        [appDelegate showPasswordStrength:passwordStrength forTextField:textField];
    }
   
    return YES;
    TCEND
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
    @try {
        return YES;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)verifyPassWord:(UITextField *)textField {
    
    @try {
        if(textField.tag == 3) {
            
            if(textField.text.length > 0) {
                return YES;

            } else {
                //show alert 
                textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cancelBtn"]];
                textField.rightViewMode = UITextFieldViewModeAlways;
                ShowAlert *showAlert = [[ShowAlert alloc]init];
                [showAlert showError:@"Required field cannot be left blank"];
            }
        } 
        
        if(textField.tag == 4) {
            if(textField.text.length >= 8) {
                
                textField.rightViewMode = UITextFieldViewModeAlways;
                textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"saveBtn"]];
                return YES;
            } else {
                //show alert
                ShowAlert *showAlert = [[ShowAlert alloc]init];
                [showAlert showError:@"Must have at least 8 characters"];
                textField.rightViewMode = UITextFieldViewModeAlways;
                textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cancelBtn"]];
                return NO;
            }
        } 
        
        if(textField.tag == 5) {
            UITextField *newPassWordField = (UITextField *)[self.view viewWithTag:4];
            if (textField.text.length > 0) {
                if ([textField.text isEqualToString:newPassWordField.text]) {
                    
                    textField.rightViewMode = UITextFieldViewModeAlways;
                    textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"saveBtn"]];
                    return YES;
                } else {
                    //show alert
                    ShowAlert *showAlert = [[ShowAlert alloc]init];
                    [showAlert showError:@"Passwords do not match."];
                    textField.rightViewMode = UITextFieldViewModeAlways;
                    textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cancelBtn"]];
                    return NO;
                }
            } else {
                // show alert
                ShowAlert *showAlert = [[ShowAlert alloc]init];
                [showAlert showError:@"Must have at least 8 characters"];
                textField.rightViewMode = UITextFieldViewModeAlways;
                textField.rightView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cancelBtn"]];
                return NO;
            }
        }
        return NO;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    @try {
        if (indexPath.row == 1 && indexPath.section == 1) {
            NSIndexPath *path = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section];
            [[(ELCTextfieldCell*)[changePasswordTableView cellForRowAtIndexPath:path] rightTextField] resignFirstResponder];
        }else {
            
            NSIndexPath *path;
            if (indexPath.section==0) {
                path= [NSIndexPath indexPathForRow:0 inSection:indexPath.section+1];
            }else{
                path= [NSIndexPath indexPathForRow:1 inSection:indexPath.section];
            }
            CGRect indexPahtRect = [changePasswordTableView rectForRowAtIndexPath:path];
            [[(ELCTextfieldCell*)[changePasswordTableView cellForRowAtIndexPath:path] rightTextField] becomeFirstResponder];
            [changePasswordTableView scrollRectToVisible:indexPahtRect animated:YES];
            
        }

    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateTextLabelAtIndexPath:(NSIndexPath*)indexPath string:(NSString*)string {
    
    @try {
            //NSIndexPath *indexPath = [self getIndexPathForEvent:event];// get the indexpath
//        ELCTextfieldCell *cell = (ELCTextfieldCell *)[changePasswordTableView cellForRowAtIndexPath:indexPath];
//        UITextField *textField = cell.rightTextField;
//
//        if (cell.rightTextField.tag == 4) {
//            NSInteger passwordStrength = [appDelegate checkPasswordStrength:textField.text];
//            [appDelegate showPasswordStrength:passwordStrength forTextField:textField];
//        }
            //
        if(indexPath.section == 0) {
            [securityDict setObject:string?:@"" forKey:@"current"];
        } else if (indexPath.section == 1) {

            if(indexPath.row == 0) {
                [securityDict setObject:string?:@"" forKey:@"answer"];
            }  else if(indexPath.row == 1) {
                [securityDict setObject:string?:@"" forKey:@"confirm"];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//#pragma mark ELCTextFieldCellDelegate Methods
//- (BOOL)textFieldShouldReturn:(UITextField *)textField {
//    [textField resignFirstResponder];
//    return NO;
//}

-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath {
    TCSTART
    @try {
//        ELCTextfieldCell *cell = (ELCTextfieldCell *)[changePasswordTableView cellForRowAtIndexPath:_indexPath];
        UITextField *textField = _textField;
        

        textField.rightView = nil;
        textField.rightViewMode = UITextFieldViewModeNever;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
//    if (_indexPath.row >= 0 && _indexPath.section == 1) {
//        changePasswordTableView.contentInset = UIEdgeInsetsMake(0.0, 0.0f, 100, 0.0f);
//        [changePasswordTableView setContentOffset:CGPointMake(changePasswordTableView.contentOffset.x, 100) animated:YES];
//    }

    
    TCEND
}



@end
