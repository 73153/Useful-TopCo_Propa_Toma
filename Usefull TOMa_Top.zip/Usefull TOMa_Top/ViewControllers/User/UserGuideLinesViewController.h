//
//  UserGuideLinesViewController.h
//  Health Demo
//
//  Created by Aruna on 23/07/14.
//
//

#import <UIKit/UIKit.h>

@interface UserGuideLinesViewController : UIViewController<UIWebViewDelegate,NSURLConnectionDelegate> {
    IBOutlet UIWebView *guidelinesWebView;
    BOOL isNetworkIndicator;
    BOOL _authenticated;
    NSURLConnection *_urlConnection;
    NSMutableURLRequest *requestM;
}

@end
