//
//  NotificationPreferenceButton.m
//  Health Demo
//
//  Created by Aruna on 21/07/14.
//
//

#import "NotificationPreferenceButton.h"

@implementation NotificationPreferenceButton
@synthesize indexPath,type;
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
