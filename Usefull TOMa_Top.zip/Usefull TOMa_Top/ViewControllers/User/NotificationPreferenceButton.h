//
//  NotificationPreferenceButton.h
//  Health Demo
//
//  Created by Aruna on 21/07/14.
//
//

#import <UIKit/UIKit.h>

@interface NotificationPreferenceButton : UIButton

@property (nonatomic, retain) NSIndexPath *indexPath;

/** Type 1 for heartsymbol(like), 2 for push & 3 for Email
 */
@property (nonatomic, readwrite) int type;
@end
