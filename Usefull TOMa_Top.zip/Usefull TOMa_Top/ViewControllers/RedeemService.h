//
//  LocationController.h
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol RedeemServiceDelegate <NSObject>

@optional

//can redeem special
- (void)didFinishedGettingCanRedeemSpecialResponse:(BOOL) canRedeem;
- (void)didFailCanRedeemSpecialWithErrorMsg:(NSString *) error;

//redeem special
- (void)didFinishedGettingRedeemSpecialResponse:(BOOL) canRedeemAgain;
- (void)didFailRedeemSpecialWithErrorMsg:(NSString *) error;

@end

@interface RedeemService : NSObject<RedeemServiceDelegate,CPLocationSpecialsServiceDelegate>
{
    id caller_;
   
    NSString *requestURL;       //set the host URL
    NSString *auth_token;       //Set the auth_token of the user
    NSString *loc_id;          //Set the location id to get the info about a locaion.
    NSString *review_id;        //Set review id to send a like
    NSString *privateMessageId;
    NSString *user_id;          //Set user_id to get the user activities through live feed
    NSString *broadCast_id;      //set to send a comment for on a business
    NSString *comment_id;       //set to delete the comment.
    NSString *specialId;         //to share the special
    NSArray *sharingOutletIdArray; //consists of sharingoutletattributes of facebook & twitter.
    NSString *apiKey;
    NSArray *coordinates;
    NSInteger reviewRadius;
    NSIndexPath *likeReviewIndexPath;
    NSIndexPath *deleteReviewIndexPath;
    NSIndexPath *postCommentIndexPath;
    NSIndexPath *deleteCommentIndexPath;
}

@property (nonatomic, strong) NSString *broadCast_id;
@property (nonatomic, strong) NSString *review_id;
@property (nonatomic, strong) NSString *privateMessageId;
@property (nonatomic, strong) NSString *requestURL;
@property (nonatomic, strong) NSString *auth_token;
@property (nonatomic, strong) NSString *loc_id;
@property (nonatomic, strong) NSString *user_id;
@property (nonatomic, strong) NSString *comment_id;
@property (nonatomic, strong) NSString *specialId;
@property (nonatomic, strong) NSArray *sharingOutletIdArray;
@property (nonatomic, strong) NSString *apiKey;
@property (nonatomic, strong) NSArray *coordinates;
@property (nonatomic, readwrite) NSInteger reviewRadius;

-(id)initWithCaller:(id)caller;


- (void)canRedeemSpecial;
- (void)redeemSpecial;
@end
