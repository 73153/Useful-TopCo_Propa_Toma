//
//  DetailsView.h
//  LocationInfo
//
//  Created by shiva on 12/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EventsInfoViewController.h"
#import "StreamDataModel.h"
#import "AppDelegate.h"
#import "MapView.h"

@class EventsInfoViewController;
@interface EventsDetailsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    
    NSInteger btnTag;
    UIButton *selectedMenu_Btn;
    
    BOOL isMapSelected;
    BOOL isContactSelected;
    EventsInfoViewController *tabbarMainVC;
    
    NSMutableArray *contactMArray;
    NSMutableArray *detailsMArray;
    
    NSArray *btnName_Arry;
    UIViewController *mapFullVC;
    
    UITableView *detailsTableView;

    StreamDataModel *streamInfoModel;
    
    CGRect vcFrame;
    
    AppDelegate *appDelegate;
    UIView *tableHeaderView;
    float verticalContentOffset;
}

@property(nonatomic, strong)  StreamDataModel *streamInfoModel;
@property (strong, nonatomic) UITableView *detailsTableView;
@property(strong, nonatomic)  EventsInfoViewController *tabbarMainVC;
@property(strong,nonatomic)   UIViewController *mapFullVC;

-(UITableViewCell *)configureTableCellToShowMap:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
-(UITableViewCell *)configureTableCellToShowContactInfo:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
-(UITableViewCell *)configureTableCellToShowDetailInfo:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
-(UILabel *)createTitleLbl;
-(UILabel *)createSummaryLbl;
-(UIImageView *)createCellThumbIcon;
- (id)initWithFrame:(CGRect)frame andHeader:(UIView *)headerview_;
-(void)showBusinessLocationAdress:(id)sender;
-(void)zoomOutMapView:(id)sender;
-(void)reloadTable;
-(void)setLocationTabButtonsStatus:(BOOL)enabled;

@end
