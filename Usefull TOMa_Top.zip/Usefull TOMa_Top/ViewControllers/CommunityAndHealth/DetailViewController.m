//
//  DetailViewController.m
//  MemorialHealthSystem
//
//  Created by Aruna on 06/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "DetailViewController.h"
#import "MyHistoryNRecentActivityViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize caller;
@synthesize blogURL;
@synthesize detailTitleStr;
@synthesize historyReloadCheck;

- (id)initWithFrame:(CGRect)frame andViewType:(CPMessageType)viewType_ HTMLDescription:(NSString *)htmlDesc_ {
    
    @try {
        self = [super init];
        if (self) {
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            viewFrame = frame;
            viewType = viewType_;
            htmlDesc = htmlDesc_;
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    //history reload check
    if(historyReloadCheck == YES)
    {
        NSArray *VCArray=[self.navigationController viewControllers];
        for(UIViewController *viewController in VCArray)
        {
            if([viewController isKindOfClass:[MyHistoryNRecentActivityViewController class]])
            {
                MyHistoryNRecentActivityViewController *historyViewController=(MyHistoryNRecentActivityViewController*)viewController;
                historyViewController.reloadCheck=YES;
            }
        }
    }
    self.view.frame = viewFrame;
    TCEND
}

- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    [super viewWillAppear:YES];
    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    image.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:image];
    
//    [appDelegate returnHeaderViewTocaller:self sectionHeaderImgName:nil];
    
    UIView *headerView = [appDelegate returnHeaderViewTocaller:self sectionHeaderImgName:nil];
    [self.view addSubview:headerView];
    
    //if ([self isNotNull:viewType]) {
    UIView *detailBackgroundLabel;
    UIImageView *thumbNailImageview;
    UILabel *titlelabel;
    UILabel *lineLabel;
    if (iPad) {
        detailBackgroundLabel = [[UIView alloc] initWithFrame:CGRectMake(10, 100, 748, 80)];
        thumbNailImageview = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 60, 60)];
        titlelabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 10, 748 - 90, 60)];
        lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 79, 748, 1)];
    } else {
        detailBackgroundLabel = [[UIView alloc] initWithFrame:CGRectMake(10, 60, appDelegate.window.frame.size.width-20, 60)];
        thumbNailImageview = [[UIImageView alloc] initWithFrame:CGRectMake(10, 5, 50, 50)];
        titlelabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, appDelegate.window.frame.size.width-120, 40)];
        lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 59, appDelegate.window.frame.size.width-20, 1)];
    }
    detailBackgroundLabel.backgroundColor = [UIColor whiteColor];
    
    if (viewType == CPMessageTypeEvents) {
        thumbNailImageview.image = [UIImage imageNamed:@"EventsPlaceHolder"];
    } else if (viewType == CPMessageTypeReferences) {
        thumbNailImageview.image = [UIImage imageNamed:@"ReferencesPlaceHolder"];
    } else if (viewType == CPMessageTypeNews) {
        thumbNailImageview.image = [UIImage imageNamed:@"NewsPlaceHolder"];
    } else if (viewType == CPMessageReminder) {
        thumbNailImageview.image = [UIImage imageNamed:@"ReminderPlaceHolder"];
    } else {
        thumbNailImageview.image = [UIImage imageNamed:@"default-avatar-business"];
    }
    [detailBackgroundLabel addSubview:thumbNailImageview];

    titlelabel.text = detailTitleStr;
    titlelabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
    titlelabel.backgroundColor = [UIColor clearColor];
    titlelabel.lineBreakMode = NSLineBreakByWordWrapping;
    titlelabel.numberOfLines = 0;
    titlelabel.textColor = [UIColor blackColor];
    titlelabel.textAlignment = NSTextAlignmentLeft;
    [detailBackgroundLabel addSubview:titlelabel];
    
    lineLabel.backgroundColor = [UIColor lightGrayColor];
    [detailBackgroundLabel addSubview:lineLabel];
    
    [self.view addSubview:detailBackgroundLabel];
    
    [appDelegate setMaskTo:detailBackgroundLabel byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight withRadii:CGSizeMake(7.0, 7.0)];
    //}
    
    [self addWebViewandLoadHTMLDataInWebview];
    TCEND
}
//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)addWebViewandLoadHTMLDataInWebview {
    TCSTART
    CGFloat originY;
    if (iPad) {
        originY = 180;
    } else {
        originY = 120;
    }
    
    webView = [[UIWebView alloc]initWithFrame:CGRectMake(10, originY, self.view.frame.size.width - 20, self.view.frame.size.height - (originY + 10 + ((CURRENT_DEVICE_VERSION < 7.0)?0:20)))];
    [appDelegate setMaskTo:webView byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(7.0, 7.0)];
    webView.scalesPageToFit = YES;
    
    webView.delegate = self;

    [self.view addSubview:webView];
    
    if ([self isNull:htmlDesc] && [self isNotNull:blogURL]) {
        [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:blogURL]]];
        webView.opaque = NO;
        webView.backgroundColor = [UIColor clearColor];
    } else {
//        htmlDesc = [NSString stringWithFormat:@"<body STYLE=\"font-family: HelveticaNeue;font-size: 35\">%@</body>",htmlDesc];
//        htmlDesc = [NSString stringWithFormat:@"<body STYLE=\"font-family: HelveticaNeue;font-size: 35\">%@</body>",htmlDesc];
//        htmlDesc = [NSString stringWithFormat:@"<head><meta name='viewport' content='initial-scale=1.0,minimum-scale=1.0, maximum-scale=2.0'/></head><body>%@</body>",htmlDesc];
//        htmlDesc = [NSString stringWithFormat:@"<body>%@</body>",htmlDesc];
        [webView loadHTMLString:htmlDesc baseURL:nil];
    }
    TCEND
}

#pragma mark WebView Delegate Methods
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
//    NSLog(@"clicked");
    return YES;
}
-(void)webViewDidStartLoad:(UIWebView *)webView_ {
    
    @try {
        if (!isNetworkIndicator) {
            isNetworkIndicator = YES;
            [appDelegate showNetworkIndicator];
            [appDelegate showActivityIndicatorInView:webView_];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webViewDidFinishLoad:(UIWebView *)webView_ {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webView:(UIWebView *)webView_ didFailLoadWithError:(NSError *)error {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
        if (error.code == NSURLErrorCancelled){
            return;
//        }return; // this is Error -999
                                                       // error handling for "real" errors here
//        [appDelegate showErrorMsg:[error localizedDescription]];
    }
//        [appDelegate showErrorMsg:[error localizedDescription]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)gotoMainPage {
    webView.delegate = nil;
    webView = nil;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

//-(BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType{
//
//}
@end
