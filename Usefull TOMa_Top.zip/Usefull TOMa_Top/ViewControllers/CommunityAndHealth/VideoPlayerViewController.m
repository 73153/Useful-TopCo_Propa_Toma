//
//  VideoPlayerViewController.m
//  iDreamMedia
//
//  Created by Aruna on 10/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "VideoPlayerViewController.h"
#import "NSObject+PE.h"
#import <math.h>

@implementation VideoPlayerViewController
@synthesize mpviewController;
@synthesize interval;
- (id)initWithURL:(NSString *)URLString andFrame:(CGRect)frame andMediaType:(NSString *)mediaType_
{
    self = [super init];
    
    if (self) {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        UrlString = URLString;
        mediaType = mediaType_;
        
        
        // On iOS 4.0+ only, listen for background notification
        if(UIApplicationWillResignActiveNotification != nil) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
        }
        
        // On iOS 4.0+ only, listen for foreground notification
        if(UIApplicationDidBecomeActiveNotification != nil) {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        }
        
    }
    viewFrame = frame;
    
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    state = 1;
    if (mpviewController.moviePlayer) {
        interval = [mpviewController.moviePlayer currentPlaybackTime];
        NSLog(@"Interval:%f",interval);
        [mpviewController.moviePlayer pause];
    }
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
    state = 0;
    if (mpviewController.moviePlayer) {
        [mpviewController.moviePlayer play];
        [self performSelector:@selector(setPlayBackTime) withObject:nil afterDelay:5];
        NSLog(@"Interval:%f",interval);
    }
}
#pragma mark - View lifecycle
- (void)setPlayBackTime {
    [mpviewController.moviePlayer setCurrentPlaybackTime:interval];
}
#pragma mark - View lifecycle

- (void)viewDidLoad {
    @try {
        [super viewDidLoad];
        [self.view setBackgroundColor:[UIColor clearColor]];
        
        NSLog(@"ViewFrame:%f %f",viewFrame.size.width,viewFrame.size.height);
        
        //Buffering view
        loadingView = [[UIView alloc] init];//WithFrame:[[UIScreen mainScreen] bounds]];
        //        loadingView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"iDreamMedia_Landscape"]];
        loadingView.backgroundColor = [UIColor blackColor];
        if ([mediaType isEqualToString:@"Audio"]) {
            loadingView.frame = viewFrame;
            
        } else {
            loadingView.bounds = viewFrame;
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }
        
//        loadingView.frame = viewFrame;
        
        if (![mediaType isEqualToString:@"Audio"]) {
            [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
            loadingView.center = CGPointMake(viewFrame.size.height/2, viewFrame.size.width/2);
            [loadingView setTransform:CGAffineTransformMakeRotation(M_PI/2)];
        }
        
        cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
        if (iPad) {
            cancelButton.frame = CGRectMake(20, 30, 95, 45);
        } else {
            cancelButton.frame = CGRectMake(10, 20, 75, 25);
        }
        
        [cancelButton setBackgroundColor:[UIColor clearColor]];
        [cancelButton setBackgroundImage:[UIImage imageNamed:@"cancel"] forState:UIControlStateNormal];
        [cancelButton addTarget:self action:@selector(cancelLoadingOfVideo) forControlEvents:UIControlEventTouchUpInside];
        
        [loadingView addSubview:cancelButton];
        
        if (iPad) {
            loadingWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake((viewFrame.size.width/2)-30, (viewFrame.size.height/2)-32.5, 65, 65)];
            loadingWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        } else {
            loadingWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake((viewFrame.size.width/2)-20, (viewFrame.size.height/2)-22.5, 45, 45)];
            loadingWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        }
        
        [loadingWheel startAnimating];
        if ([mediaType isEqualToString:@"Audio"]) {
            loadingWheel.center = loadingView.center;
        }
        
        
        [loadingView addSubview:loadingWheel];
        [self.view addSubview:loadingView];
        
        [self playingVideo:UrlString];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    @try {
        [super viewWillAppear:animated];
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
        NSLog(@"ViewWillAppear");
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)viewDidAppear:(BOOL)animated {
    @try {
        [super viewDidAppear:animated];
        NSLog(@"FrameinVideoplayer:%f %f",self.view.frame.size.width,self.view.frame.size.height);
        NSLog(@"ViewDidAppear");
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

//initializing MPMoviePlayercontroller and adding Notifications
- (void)playingVideo:(NSString *)URLString {
    
    @try {
        
        mpviewController = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:URLString]];
        [mpviewController.moviePlayer prepareToPlay];
        
        [mpviewController.moviePlayer.view setFrame:viewFrame];
        
        if (mpviewController.moviePlayer) {
            NSLog(@"Alloc");
        }
        
        //this notification method calls after video ended...
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlayBackComplete:) name:MPMoviePlayerPlaybackDidFinishNotification object:mpviewController.moviePlayer];
        
        
        //this is for checking whether loding is done or not.if loding is done it calls movieplayerloadstatechanged...
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayerLoadStateChanged:)
                                                     name:MPMoviePlayerLoadStateDidChangeNotification
                                                   object:mpviewController.moviePlayer];
        
        /*Checking device version*/
        
        float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
        
        if(osVersion >= 4.0) {//Case for Osversions higher to 4.0
            mpviewController.moviePlayer.shouldAutoplay = YES;
            [mpviewController.moviePlayer setControlStyle:MPMovieControlStyleFullscreen];
            [mpviewController.moviePlayer setFullscreen:YES];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//- (void)handleEnteredBackground:(NSNotification *)notification {
//    state = 1;
//    [mpviewController.moviePlayer pause];
//}

#pragma mark MPMoviePlayerPlaybackDidFinishNotification
- (void)moviePlayBackComplete:(NSNotification *)notification {
    @try {
        NSDictionary *userInfo = [notification userInfo];
        
        NSError *error = [userInfo objectForKey:@"error"];
        NSLog(@"PlayerError:%@",error);
        [mpviewController.moviePlayer pause];
        if(state == 0) {
            [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:mpviewController.moviePlayer];
            NSDictionary *userInfo = [notification userInfo];
            
            [mpviewController.moviePlayer pause];
            
            if (userInfo != nil) {
                [mpviewController.moviePlayer stop];
                [mpviewController.moviePlayer.view removeFromSuperview];
                mpviewController = nil;
                
                float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
                if (osVersion >= 5.0) {
                    [self dismissViewControllerAnimated:YES completion:nil];
                } else {
                    //[self dismissModalViewControllerAnimated:YES];
                    [self dismissViewControllerAnimated:YES completion:^{
                        //code
                    }];
                }
//                [self dismissModalViewControllerAnimated:YES];
                //if(CURRENT_DEVICE_VERSION < 8.0)
                [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationPortrait animated:NO];
            }
        }
        if (error) {
            if (![appDelegate connectedToNetwork]) {
                [appDelegate showErrorMsg:@"Your internet connection appears to be offline."];
            } else {
                [appDelegate showErrorMsg:@"Unsupported format"];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)moviePlayerScalingModeChanged:(NSNotification*)notification {
	MPMoviePlayerController *scalingnotification = [notification object];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerScalingModeDidChangeNotification object:scalingnotification];
}


#pragma mark MPMoviePlayerLoadStateDidChangeNotification
-(void)moviePlayerLoadStateChanged:(NSNotification *)notification {
    @try {
        if ([[notification object] loadState] == MPMovieLoadStateUnknown)
            return;
        
        NSDictionary *userInfo = [notification userInfo];
        
        NSError *error = [userInfo objectForKey:@"error"];
        NSLog(@"Error:%@",error);
        
        if (!error) {
            // Remove observer
            [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:[notification object]];
            [loadingView removeFromSuperview];
            loadingView = nil;
            
            if (![mediaType isEqualToString:@"Audio"]) {
                [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
            }
            
            self.view.bounds = viewFrame;
            
            if (![mediaType isEqualToString:@"Audio"]) {
                [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeRight animated:NO];
                self.view.center = CGPointMake(viewFrame.size.height/2, viewFrame.size.width/2);
                [self.view setTransform:CGAffineTransformMakeRotation(M_PI/2)];
            }
            [mpviewController.moviePlayer play];
            
            [self.view addSubview:mpviewController.moviePlayer.view];
            
            NSLog(@"FrameinVideoplayer:%f %f",self.view.frame.size.width,self.view.frame.size.height);
            NSLog(@"videoplayer frame:%f %f",mpviewController.moviePlayer.view.frame.size.width,mpviewController.moviePlayer.view.frame.size.height);
        } else {
            [self moviePlayBackComplete:nil];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

//cancel videoloading
- (void)cancelLoadingOfVideo {
    TCSTART
    [mpviewController.moviePlayer stop];
    [mpviewController.moviePlayer.view removeFromSuperview];
    mpviewController = nil;
    //    float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
    //    if (osVersion >= 5.0) {
    //        [self dismissViewControllerAnimated:YES completion:nil];
    //    } else {
    //        [self dismissModalViewControllerAnimated:YES];
    //    }
    float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (osVersion >= 5.0) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:^{
            //code
        }];
    }
    TCEND
//    [self dismissModalViewControllerAnimated:YES];
}

- (void)viewDidUnload {
    //    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
    //    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //    if ([mediaType isEqualToString:@"Audio"]) {
    //        return (interfaceOrientation == UIInterfaceOrientationPortrait);
    //    } else {
    //        return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft);
    //    }
    //    return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return NO;
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
//    if ([mediaType isEqualToString:@"Audio"]) {
//        return UIInterfaceOrientationPortrait;
//    } else {
//        return UIInterfaceOrientationLandscapeLeft;
//    }
//}
- (NSUInteger)supportedInterfaceOrientations {
    //    if ([mediaType isEqualToString:@"Audio"]) {
    //        return UIInterfaceOrientationMaskPortrait;
    //    } else {
    //        return UIInterfaceOrientationMaskLandscapeLeft;
    //    }
    
    return UIInterfaceOrientationMaskPortrait;
}

- (void)viewWillDisappear:(BOOL)animated {
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

- (void)viewDidDisappear:(BOOL)animated {
    @try {
        //        [mpviewController.moviePlayer pause];
        //        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:mpviewController.moviePlayer];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

@end
