//
//  VideoPlayerViewController.h
//  iDreamMedia
//
//  Created by Aruna on 10/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <MediaPlayer/MediaPlayer.h>
#import <MediaPlayer/MPMoviePlayerViewController.h>

@interface VideoPlayerViewController : UIViewController {
    /** for playing video
     */
 //   MPMoviePlayerController *mediaPlayer;
    MPMoviePlayerViewController *mpviewController;
    
    /** while buffering video this splashVideoImageview will be displayed...
     */
    UIImageView *splahVideoImgView;
    
    /** Loding activityindicator displaying on splashvideoimageview..
     */
    UIActivityIndicatorView *loadingWheel;
    
    /** cancelButton is an instance of UIButton. This cancels movie downloading.
     */
    UIButton *cancelButton;
    
    /** URLString is an instance of nsstring and this have videourl sent from another viewcontroller
     */
    NSString *UrlString;

    /** Before playing the video this view will be dispalyed like buffering view.and it contains cancelButton to cancel the video loading.after video load state change this view will remove from videoplayerviewcontroller,mediaPlayer view will added.
     */
    UIView *loadingView;
    
    /** appDelegate is a AppDelegate instance which is a controller for the app.
     */
    AppDelegate *appDelegate;
    
    NSString *mediaType;
    
    int state;
    NSTimeInterval interval;
    
    CGRect viewFrame;
    
}
@property NSTimeInterval interval;
@property (nonatomic, retain)   MPMoviePlayerViewController *mpviewController;
/** initialising this class with this method ,and this URLString is video url to be played and setting the frame this viewcontroller view should be displayed in landscape.
 */
- (id)initWithURL:(NSString *)URLString andFrame:(CGRect)frame andMediaType:(NSString *)mediaType_;

/** initializing MPMoviePlayercontroller and add notifications to MPMoviePlayerController
 */
- (void)playingVideo:(NSString *)URLString;

@end
