//
//  MediaViewController.m
//  MemorialHealthSystem
//
//  Created by Aruna on 25/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "HealthAndCommunityViewController.h"
#import "MessageDataModel.h"
#import "Reachability.h"
#import "LocationInfoViewController.h"
#import "DetailViewController.h"
#import "VideoPlayerViewController.h"
#import "VideoViewController.h"
#import "XCDYouTubeKit.h"
#import "MPMoviePlayerController+BackgroundPlayback.h"
@interface HealthAndCommunityViewController ()<YTPlayerViewDelegate>
{
    BOOL isVideoPlaying;
}
@end

@implementation HealthAndCommunityViewController

//- (id)initWithFrame:(CGRect)frame headerView:(UIView *)headerView_ andChannelId:(NSString *)channelId_ {
//
//    @try {
//        self = [super init];
//        if (self) {
//            appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//            headerView = headerView_;
//            channelId = channelId_;
//            viewFrame = frame;
//        }
//        return self;
//    }
//    @catch (NSException *exception) {
//        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
//    }
//    @finally {
//    }
//}

- (id)initWithFrame:(CGRect)frame {
    
    @try {
        self = [super init];
        if (self) {
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            viewFrame = frame;
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewDidLoad {
    TCSTART
    [super viewDidLoad];
    self.view.frame = viewFrame;
    eventsArray = [[NSArray alloc] init];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    image.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:image];
    
    [self.view addSubview:[appDelegate returnHeaderViewTocaller:self sectionHeaderImgName:nil]];
    [self initialiseAndAddEventsAndcommunityButtonsToTheView];
    isVideoPlaying=false;
    CGFloat originX;
    if (iPad) {
        originX = -30;
    } else {
        originX = -2.5;
    }
    
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        originX = 5;
    }
    resourceVerticalContentOffset=0;
    newsVerticalContentOffset=0;
    UIButton *communityButtonRef = (UIButton *)[self.view viewWithTag:-12];
    healthNCommunityTable = [[UITableView alloc] initWithFrame:CGRectMake(originX, communityButtonRef.frame.origin.y + communityButtonRef.frame.size.height + HEADER_MARGIN_HEIGHT, self.view.frame.size.width + (2 * -originX), self.view.frame.size.height - (communityButtonRef.frame.origin.y + communityButtonRef.frame.size.height + HEADER_MARGIN_HEIGHT)) style:UITableViewStyleGrouped];
    
    healthNCommunityTable.delegate = self;
    healthNCommunityTable.dataSource = self;
    healthNCommunityTable.showsVerticalScrollIndicator = YES;
    [self.view addSubview:healthNCommunityTable];
    healthNCommunityTable.backgroundView = nil;
    healthNCommunityTable.backgroundColor = [UIColor clearColor];
    if (CURRENT_DEVICE_VERSION < 7.0) {
        healthNCommunityTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {
        healthNCommunityTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    
    
    [self getMessagesOfType:CPMessageTypeReferences isRequestForRefresh:NO];
    requestType = @"health";
    
    refreshView = [[RefreshView alloc] initWithFrame:
                   CGRectMake(self.view.frame.origin.x,-healthNCommunityTable.bounds.size.height,
                              self.view.frame.size.width, healthNCommunityTable.bounds.size.height)];
    [healthNCommunityTable addSubview:refreshView];
    TCEND
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)initialiseAndAddEventsAndcommunityButtonsToTheView {
    TCSTART
    CGFloat originY;
    if (iPad) {
        originY = 85;
    } else {
        originY = 55;
    }
    
    healthButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [healthButton setImage:[UIImage imageNamed:@"health_f"] forState:UIControlStateNormal];
    [healthButton addTarget:self action:@selector(getHealthList) forControlEvents:UIControlEventTouchUpInside];
    if (iPad) {
        healthButton.frame = CGRectMake(5 + 10, originY, 360, 60);
    } else {
        healthButton.frame = CGRectMake(5, originY, (appDelegate.window.frame.size.width-20)/2, 32);
    }
    healthButton.layer.cornerRadius = 5.0f;
    healthButton.layer.masksToBounds = YES;
    healthButton.tag = -11;
    [self.view addSubview:healthButton];
    
    communityButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [communityButton setImage:[UIImage imageNamed:@"community"] forState:UIControlStateNormal];
    [communityButton addTarget:self action:@selector(getCommunityList) forControlEvents:UIControlEventTouchUpInside];
    if (iPad) {
        communityButton.frame = CGRectMake(5 + 10 + healthButton.frame.origin.x + healthButton.frame.size.width + 5, originY, 360, 60);
    } else {
        communityButton.frame = CGRectMake(5 + 5 + healthButton.frame.origin.x + healthButton.frame.size.width, originY, (appDelegate.window.frame.size.width-20)/2, 32);
    }
    communityButton.layer.cornerRadius = 5.0f;
    communityButton.layer.masksToBounds = YES;
    communityButton.tag = -12;
    if(isiPhone6PLUS) {
        healthButton.frame=CGRectMake(healthButton.frame.origin.x, healthButton.frame.origin.y, healthButton.frame.size.width, healthButton.frame.size.height+7);
        communityButton.frame=CGRectMake(communityButton.frame.origin.x, communityButton.frame.origin.y, communityButton.frame.size.width, communityButton.frame.size.height+7);
    }
    [self.view addSubview:communityButton];
    
    TCEND
}
- (void)getCommunityList {
    TCSTART
    requestType = @"community";
    UIButton *healthBtn = (UIButton *)[self.view viewWithTag:-11];
    [healthBtn setImage:[UIImage imageNamed:@"health"] forState:UIControlStateNormal];
    
    UIButton *communityBtn = (UIButton *)[self.view viewWithTag:-12];
    [communityBtn setImage:[UIImage imageNamed:@"community_f"] forState:UIControlStateNormal];
    resourceVerticalContentOffset=healthNCommunityTable.contentOffset.y;
    [self getMessagesOfType:CPMessageTypeNews isRequestForRefresh:NO];
    TCEND
}

- (void)getHealthList {
    TCSTART
    requestType = @"health";
    UIButton *healthBtn = (UIButton *)[self.view viewWithTag:-11];
    [healthBtn setImage:[UIImage imageNamed:@"health_f"] forState:UIControlStateNormal];
    
    UIButton *communityBtn = (UIButton *)[self.view viewWithTag:-12];
    [communityBtn setImage:[UIImage imageNamed:@"community"] forState:UIControlStateNormal];
    newsVerticalContentOffset=healthNCommunityTable.contentOffset.y;
    [self getMessagesOfType:CPMessageTypeReferences isRequestForRefresh:NO];
    TCEND
}

- (void)getMessagesOfTypeForRefresh:(CPMessageType)messageType isRequestForRefresh:(BOOL)refresh {
    TCSTART
    
    // if ([self isNotNull:channelId]) {
    if (!refresh) {
        [appDelegate showActivityIndicatorInView:self.view];
    }
    [appDelegate showNetworkIndicator];
    [appDelegate getMessagesOfType:messageType andCaller:self];
    //}
    TCEND
}

- (void)getMessagesOfType:(CPMessageType)messageType isRequestForRefresh:(BOOL)refresh {
    TCSTART
    if(messageType == CPMessageTypeNews)
    {
        if([newsArray count] == 0)
        {
            // if ([self isNotNull:channelId]) {
            if (!refresh) {
                [appDelegate showActivityIndicatorInView:self.view];
            }
            [appDelegate showNetworkIndicator];
            [appDelegate getMessagesOfType:messageType andCaller:self];
            //}
        }
        else
        {
            eventsArray = newsArray;
            [healthNCommunityTable reloadData];
            [healthNCommunityTable setContentOffset:CGPointMake(0, newsVerticalContentOffset)];
        }
    }
    else if(messageType == CPMessageTypeReferences)
    {
        if([resourceArray count] == 0)
        {
            // if ([self isNotNull:channelId]) {
            if (!refresh) {
                [appDelegate showActivityIndicatorInView:self.view];
            }
            [appDelegate showNetworkIndicator];
            [appDelegate getMessagesOfType:messageType andCaller:self];
            //}
        }
        else
        {
            eventsArray = resourceArray;
            [healthNCommunityTable reloadData];
            [healthNCommunityTable setContentOffset:CGPointMake(0, resourceVerticalContentOffset)];
        }
    }
    TCEND
}

-(void)didFinishedGettingMessages:(NSArray *)results {
    TCSTART
    if([requestType isEqualToString:@"community"])
    {
        newsArray=results;
        newsVerticalContentOffset=0;
    }
    else if([requestType isEqualToString:@"health"])
    {
        resourceArray=results;
        resourceVerticalContentOffset=0;
    }
    [communityButton setEnabled:YES];
    [healthButton setEnabled:YES];
    eventsArray = results;
    [healthNCommunityTable reloadData];
    [healthNCommunityTable setContentOffset:CGPointMake(0,0)];
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [self dataSourceDidFinishLoadingNewData];
    TCEND
}

-(void)didFailedToGetMessagesWithError:(NSString *)errorMsg {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [self dataSourceDidFinishLoadingNewData];
    if ([appDelegate connectedToNetwork]) {
        
    }else{
        [appDelegate showErrorMsg:@"Internet connection appears to be offline"];
    }
    TCEND
    
}

- (void)gotoMainPage {
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return eventsArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TCSTART
    MessageDataModel *dataModal = [eventsArray objectAtIndex:indexPath.row];
    CGSize nameSize;
    if ([self isNotNull:dataModal.messageTitle]) {
        nameSize = [dataModal.messageTitle sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    }
    CGSize descrptionSize = [dataModal.description sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    CGFloat gaps;
    CGFloat heightOfTheRow;
    if (iPad) {
        gaps = 30;
        heightOfTheRow = 74;
    }else if (isiPhone6PLUS)
    {
        gaps = 20;
        heightOfTheRow = 56;
    }
    else {
        gaps = 15;
        heightOfTheRow = 46;
    }
    if (nameSize.height + descrptionSize.height + gaps > heightOfTheRow) {
        return nameSize.height + descrptionSize.height + gaps;
    } else {
        return heightOfTheRow;
    }
    TCEND
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 1.0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    @try {
        UIView *header = [[UIView alloc] init];
        header.frame = CGRectMake(0.0, 0.0, 0.0, 0.0);
        header.backgroundColor = [UIColor clearColor];
        return header;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        //static NSString *user_messageCell = @"messageCell";
        static NSString *CellIndentifier = @"Cell";
        UITableViewCell *cell = nil;
        UIImageView *avtar = nil;
        UILabel *name = nil;
        UILabel *descrption = nil;
        
        CGFloat diff;
        CGFloat accessoryWidth;
        CGFloat rowHeight;
        CGFloat avtarImgWidhtNHeight;
        if (iPad) {
            diff = 10;
            accessoryWidth = 30;
            rowHeight = 74;
            avtarImgWidhtNHeight = 54;
        }else if (isiPhone6PLUS)
        {
            diff = 7;
            accessoryWidth = 30;
            rowHeight = 56;
            avtarImgWidhtNHeight = 46;
        }else {
            diff = 5;
            accessoryWidth = 20;
            rowHeight = 46;
            avtarImgWidhtNHeight = 36;
        }
        
        cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
        //initialize cell and its subviews instances once and use them when table scrolling through their instances retrieved based on "Tag" value
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIndentifier];
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]] ;
            
            avtar = [[UIImageView alloc]initWithFrame:CGRectMake(diff, diff, avtarImgWidhtNHeight, avtarImgWidhtNHeight)];
            [avtar setBackgroundColor:[UIColor clearColor]];
            [avtar.layer setBorderColor:[[UIColor clearColor]CGColor]];
            [avtar.layer setBorderWidth:1.0f];
            avtar.layer.cornerRadius = 5.0;
            avtar.layer.masksToBounds = YES;
            [avtar setTag:1];
            [cell.contentView addSubview:avtar];
            
            name = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff ,diff-3, CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + diff + accessoryWidth),40)];
            name.backgroundColor = [UIColor clearColor];
            name.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
            [name setTag:2];
            name.numberOfLines = 0;
            name.lineBreakMode = NSLineBreakByWordWrapping;
            name.textAlignment = NSTextAlignmentLeft;
            name.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:name];
            
            descrption = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff ,diff - 3, CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + diff + accessoryWidth),40)];
            descrption.backgroundColor = [UIColor clearColor];
            descrption.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
            [descrption setTag:3];
            descrption.numberOfLines = 0;
            descrption.lineBreakMode = NSLineBreakByWordWrapping;
            descrption.textAlignment = NSTextAlignmentLeft;
            descrption.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:descrption];
        }
        
        if (!avtar) {
            avtar = (UIImageView *)[cell.contentView viewWithTag:1];
        }
        if (!name)
            name = (UILabel *)[cell.contentView viewWithTag:2];
        if (!descrption) {
            descrption = (UILabel *)[cell.contentView viewWithTag:3];
        }
        
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
            UIView *sectionHeaderview = (UIView *)[cell viewWithTag:-1000];
            [sectionHeaderview removeFromSuperview];
            [appDelegate addBackgroundViewToTheCell:cell];
        }
        
        //get the Like data for a row
        MessageDataModel *dataModel = [eventsArray objectAtIndex:indexPath.row];
        
        //check if Like data for a row is not null
        if ([self isNotNull:dataModel]) {
            
            if (dataModel.messageType == CPMessageTypeEvents) {
                avtar.image = [UIImage imageNamed:@"EventsPlaceHolder"];
            } else if (dataModel.messageType == CPMessageTypeReferences) {
                avtar.image = [UIImage imageNamed:@"ReferencesPlaceHolder"];
            } else if (dataModel.messageType == CPMessageTypeNews) {
                avtar.image = [UIImage imageNamed:@"NewsPlaceHolder"];
            } else if (dataModel.messageType == CPMessageTypeAudio) {
                avtar.image = [UIImage imageNamed:@"AudioPlaceHolder"];
            } else if (dataModel.messageType == CPMessageTypeVideo) {
                avtar.image = [UIImage imageNamed:@"VideoPlaceHolder"];
            }else if (dataModel.messageType == CPMessageReminder) {
                avtar.image = [UIImage imageNamed:@"ReminderPlaceHolder"];
            } else {
                avtar.image = [UIImage imageNamed:@"default-avatar-business"];
            }
            
            //Display the name of a business or user
            if ([self isNotNull:dataModel.messageTitle]) {
                name.text = dataModel.messageTitle;
            } else {
                name.text = @"";
            }
            //
            CGSize nameSize = [dataModel.messageTitle sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            name.frame = CGRectMake(name.frame.origin.x, name.frame.origin.y, name.frame.size.width, nameSize.height);
            
            if ([self isNotNull:dataModel.description]) {
                descrption.text = dataModel.description;
            } else {
                descrption.text = @"";
                if ((nameSize.height + (diff * 2)) < rowHeight) {
                    name.frame = CGRectMake(name.frame.origin.x, name.frame.origin.y, name.frame.size.width, rowHeight - (name.frame.origin.y * 2));
                }
            }
            CGSize descrptionSize = [dataModel.description sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            descrption.frame = CGRectMake(descrption.frame.origin.x, name.frame.origin.y + name.frame.size.height + diff, descrption.frame.size.width, descrptionSize.height);
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                CGFloat cellHeight;
                if (rowHeight > (nameSize.height + descrptionSize.height + (diff * 3))) {
                    cellHeight = rowHeight;
                } else {
                    cellHeight = (nameSize.height + descrptionSize.height + (diff * 3));
                }
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:cellHeight andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        //        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        if(iPhone && CURRENT_DEVICE_VERSION >= 8.0) {
            CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
            cell.accessoryView=nil;
            if([cell.contentView viewWithTag:9]) {
                //[[cell.contentView viewWithTag:9] removeFromSuperview];
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                [[cell.contentView viewWithTag:9] setFrame:CGRectMake(appDelegate.window.frame.size.width-(5)-22,(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                
            } else {
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                accessoryimgView.tag=9;
                [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22,(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                [cell.contentView addSubview:accessoryimgView];
            }
        }else
        {
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
        }
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    
    MessageDataModel *dataModel = [eventsArray objectAtIndex:indexPath.row];
    if (dataModel.messageType == CPMessageTypeAudio || dataModel.messageType == CPMessageTypeVideo) {
        if ([appDelegate connectedToNetwork]) {
            CGRect playerViewFrame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height);
            
            VideoPlayerViewController *videoPlayerVC = nil;
            
            if([self isNotNull:dataModel.audioURL] || [self isNotNull:dataModel.videoURL]){
                if (dataModel.messageType == CPMessageTypeAudio) {
                    videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:dataModel.audioURL andFrame:playerViewFrame andMediaType:@"Audio"];
                    [videoPlayerVC.view setFrame:playerViewFrame];
                    
                    [videoPlayerVC.mpviewController.moviePlayer play];
                    [self presentMoviePlayerViewControllerAnimated:videoPlayerVC.mpviewController];
                    
                }
                else if (dataModel.messageType == CPMessageTypeVideo){
                    NSString *videoIdForPlaying = dataModel.videoURL;
                    
                    if ([videoIdForPlaying rangeOfString:@"https://youtu.be"].location == NSNotFound) {
                        videoPlayerVC = [[VideoPlayerViewController alloc] init];
                        [videoPlayerVC.view setFrame:playerViewFrame];
                        [videoPlayerVC playingVideo:dataModel.videoURL];
                        [self presentMoviePlayerViewControllerAnimated:videoPlayerVC.mpviewController];
                    } else {
                        
                        videoIdForPlaying = (videoIdForPlaying.length > 15) ? [videoIdForPlaying substringFromIndex:17] : videoIdForPlaying;
                        
                        XCDYouTubeVideoPlayerViewController *videoPlayerViewController = [[XCDYouTubeVideoPlayerViewController alloc] initWithVideoIdentifier:videoIdForPlaying];
                        [videoPlayerViewController.moviePlayer play];
                        videoPlayerViewController.preferredVideoQualities =  @[ @(XCDYouTubeVideoQualityMedium360), @(XCDYouTubeVideoQualitySmall240) ];
                        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlayerPlaybackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:videoPlayerViewController.moviePlayer];
                        
                        [self presentMoviePlayerViewControllerAnimated:videoPlayerViewController];
                        
                        return;
                        
                        /*self.playerView = [[YTPlayerView alloc] initWithFrame:self.view.frame];
                         self.playerView.hidden=false;
                         self.playerView.backgroundColor = [UIColor blackColor];
                         self.playerView.delegate=self;
                         
                         
                         UIView *darkblackView = [[UIView alloc] initWithFrame:self.view.frame];
                         darkblackView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f];
                         [self.view addSubview:darkblackView];
                         darkblackView.tag=999999;
                         
                         isVideoPlaying=true;
                         if(videoIdForPlaying.length>0)
                         [self.playerView loadWithVideoId:videoIdForPlaying];
                         CGRect frame;
                         
                         frame = CGRectMake(0, (iPad?135:80), appDelegate.window.frame.size.width, (iPad?(appDelegate.window.frame.size.height-135):(appDelegate.window.frame.size.height-80)));
                         
                         self.playerView.frame = frame;
                         self.playerView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
                         
                         VideoViewController *videoVC = [[VideoViewController alloc] init];
                         
                         UIView *headeView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, (iPad?135:80))];
                         headeView.backgroundColor = [UIColor clearColor];
                         
                         UILabel *headerLabel;
                         if (iPad) {
                         headerLabel =[[UILabel alloc] initWithFrame:CGRectMake((appDelegate.window.frame.size.width - 768)/2,13 ,768,45)];
                         } else {
                         headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10,10, appDelegate.window.frame.size.width-20,25)];
                         }
                         //headerLabel.text = @"Memorial Health System";
                         headerLabel.text = @"Tomah Memorial Hospital";
                         //    headerLabel.textColor = [self colorWithHexString:@"2977a8"];
                         //    headerLabel.textColor = [UIColor whiteColor];
                         //    headerLabel.font = [UIFont fontWithName:CenturyGothicFont size:CenturyGothicFontSize];
                         //    headerLabel.backgroundColor = [UIColor clearColor];
                         
                         //
                         headerLabel.textColor=[UIColor whiteColor];
                         headerLabel.font = [UIFont fontWithName:headerTitleFontName size:isiPhone6?(headerTitleFontSize):headerTitleNewFontSize];
                         headerLabel.backgroundColor = [UIColor clearColor];
                         headerLabel.textAlignment = NSTextAlignmentCenter;
                         
                         //
                         //    headerLabel.textAlignment = UITextAlignmentCenter;
                         //Hide for Baldwin
                         [headeView addSubview:headerLabel];
                         
                         UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                         [backBtn setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
                         if (iPad) {
                         backBtn.frame = CGRectMake(10, 10, 84, 48);
                         } else {
                         backBtn.frame = CGRectMake(5, 7, 59, 32);
                         }
                         
                         [backBtn addTarget:self action:@selector(backButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                         [headeView addSubview:backBtn];
                         
                         UIImageView *lineImgView = [[UIImageView alloc] initWithFrame:LINEIMAGE_FRAME];
                         lineImgView.image = [UIImage imageNamed:@"line"];
                         [headeView addSubview:lineImgView];
                         
                         UIImageView *viewImage = [[UIImageView alloc] initWithImage:nil];
                         if (iPad) {
                         viewImage.frame = CGRectMake((appDelegate.window.frame.size.width - 500)/2, lineImgView.frame.origin.y + lineImgView.frame.size.height + 5, 500, 52);
                         } else {
                         viewImage.frame = CGRectMake((appDelegate.window.frame.size.width - 297)/2, lineImgView.frame.origin.y + lineImgView.frame.size.height , 297, 30);
                         }
                         viewImage.tag = 3;
                         [headeView addSubview:viewImage];
                         
                         [videoVC.view  addSubview:headeView];
                         
                         [videoVC.view  addSubview:self.playerView];
                         //videoVC.navigationController.navigationBarHidden=false;
                         [self.navigationController pushViewController:videoVC animated:YES];*/
                        
                        //                        UIButton *closeButton= [[UIButton alloc] init];
                        //                        [closeButton setFrame:CGRectMake(width/2, height-50, 50, 50)];
                        //                        [closeButton setBackgroundColor:[UIColor whiteColor]];
                        //                        [closeButton setTitle:@"[ * Close * ]" forState:UIControlStateNormal];
                        //                        closeButton.titleLabel.textColor = [UIColor blackColor];
                        //                        [closeButton addTarget:self action:@selector(closeApp) forControlEvents:UIControlEventTouchUpInside];
                        //                        [self.view addSubview:closeButton];
                    }
                    return;
                }
            }
            /*if (dataModel.messageType == CPMessageTypeAudio) {
             if ([self isNotNull:dataModel.audioURL]) {
             videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:dataModel.audioURL andFrame:playerViewFrame andMediaType:@"Audio"];
             
             [videoPlayerVC.view setFrame:CGRectMake(0,0, 320, 350)];
             }
             
             } else {
             if ([self isNotNull:dataModel.videoURL]) {
             if(CURRENT_DEVICE_VERSION < 8.0){
             
             NSString *videoIdForPlaying = dataModel.videoURL;
             
             videoIdForPlaying = (videoIdForPlaying.length > 15) ? [videoIdForPlaying substringFromIndex:17] : videoIdForPlaying;
             
             self.playerView = [[YTPlayerView alloc] initWithFrame:CGRectMake((self.view.frame.size.width-269)/2,(self.view.frame.size.height-324)/2, 269, 324)];
             self.playerView.hidden=false;
             self.playerView.delegate=self;
             [self.playerView playVideo];
             UIView *darkblackView = [[UIView alloc] initWithFrame:self.view.frame];
             darkblackView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f];
             [self.view addSubview:darkblackView];
             darkblackView.tag=999999;
             isVideoPlaying=true;
             if(videoIdForPlaying.length>0)
             [self.playerView loadWithVideoId:videoIdForPlaying];
             [self.view addSubview:self.playerView];                        //                        videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:dataModel.videoURL andFrame:CGRectMake(0, 0, playerViewFrame.size.height, playerViewFrame.size.width) andMediaType:@"Video"];
             return;
             
             }
             else {
             
             }
             }
             }*/
            //            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            //            if (osVersion >= 5.0) {
            //                //                [self presentViewController:videoPlayerVC animated:YES completion:nil];
            //            } else {
            //                //[self presentModalViewController: videoPlayerVC animated: YES];
            //                //                [self presentViewController:videoPlayerVC animated:YES completion:^{
            //                //                    //code
            //                //                }];
            //            }
            
        } else {
            [appDelegate showErrorMsg:@"Internet connection appears to be offline"];
        }
    } else {
        if ([self isNotNull:dataModel.description_html]) {
            DetailViewController *detailVC = [[DetailViewController alloc] initWithFrame:self.view.frame andViewType:dataModel.messageType HTMLDescription:dataModel.description_html];
            detailVC.caller = self;
            detailVC.detailTitleStr = dataModel.messageTitle;
            [self.navigationController pushViewController:detailVC animated:YES];
        }
    }
    
    TCEND
}

-(void)backButtonPressed:(id)sender
{
    self.playerView.hidden=true;
    [self.playerView stopVideo];
    [self.playerView removeFromSuperview];
    UIView *view = [self.view viewWithTag:999999];
    if(view!=nil)
        [view removeFromSuperview];
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark YT player delegate

-(void)closeApp{
    self.playerView.hidden=true;
    [self.playerView stopVideo];
    [self.playerView removeFromSuperview];
    UIView *view = [self.view viewWithTag:999999];
    if(view!=nil)
        [view removeFromSuperview];
}

- (void)playerView:(YTPlayerView *)playerView didChangeToState:(YTPlayerState)state{
    
    if(state==kYTPlayerStateEnded || state==kYTPlayerStatePaused || state==kYTPlayerStateStop)
    {
        if(iPad){
            self.playerView.hidden=true;
            [self.playerView stopVideo];
            [self.playerView removeFromSuperview];
            UIView *view = [self.view viewWithTag:999999];
            if(view!=nil)
                [view removeFromSuperview];
            
            [self.navigationController popViewControllerAnimated:YES];
            return;
        }
        if(self.playerView){
            self.playerView.hidden=true;
            [self.playerView stopVideo];
            [self.playerView removeFromSuperview];
            UIView *view = [self.view viewWithTag:999999];
            if(view!=nil)
                [view removeFromSuperview];
        }
    }
    
}


#pragma mark touches

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    if(isVideoPlaying)
    {
        if(iPad){
            [self.navigationController popViewControllerAnimated:YES];
            return;
        }
        isVideoPlaying=false;
        [[self.view viewWithTag:999999] removeFromSuperview];
        self.playerView.hidden=true;
        [self.playerView stopVideo];
        [self.playerView removeFromSuperview];
    }
}


#pragma mark TableScrollView Delegate Methods
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // NSLog(@"scrollViewWillBeginDragging");
    if (!reloading)
    {
        checkForRefresh = YES;  //  only check offset when dragging
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    @try {
        // NSLog(@"scrollViewDidScroll");
        if (reloading) return;
        
        if (checkForRefresh) {
            if (refreshView.isFlipped && scrollView.contentOffset.y > -45.0f && scrollView.contentOffset.y < 0.0f && !reloading) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kPullToReloadStatus];
                
            } else if (!refreshView.isFlipped && scrollView.contentOffset.y < -45.0f) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kReleaseToReloadStatus];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Load images for all onscreen rows when scrolling is finished
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    @try {
        if (reloading) return;
        
        if (scrollView.contentOffset.y <= -45.0f) {
            [self showReloadAnimationAnimated:YES];
            [self netWorkCallForViewRefresh];
        }
        checkForRefresh = NO;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
}

- (void) showReloadAnimationAnimated:(BOOL)animated {
    @try {
        reloading = YES;
        [refreshView toggleActivityView:YES];
        
        if (animated) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            healthNCommunityTable.contentInset = UIEdgeInsetsMake(40.0f, 0.0f, 0.0f,
                                                                  0.0f);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)dataSourceDidFinishLoadingNewData {
    @try {
        reloading = NO;
        [refreshView flipImageAnimated:NO];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        [healthNCommunityTable setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
        [refreshView setStatus:kPullToReloadStatus];
        [refreshView toggleActivityView:NO];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)netWorkCallForViewRefresh {
    @try {
        if ([requestType rangeOfString:@"health" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            [self getMessagesOfTypeForRefresh:CPMessageTypeReferences isRequestForRefresh:YES];
            [communityButton setEnabled:NO];
        } else {
            [self getMessagesOfTypeForRefresh:CPMessageTypeNews isRequestForRefresh:YES];
            [healthButton setEnabled:NO];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark - Notifications

- (void) moviePlayerPlaybackDidFinish:(NSNotification *)notification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:notification.object];
    MPMovieFinishReason finishReason = [notification.userInfo[MPMoviePlayerPlaybackDidFinishReasonUserInfoKey] integerValue];
    if (finishReason == MPMovieFinishReasonPlaybackError)
    {
        NSString *title = NSLocalizedString(@"Video Playback Error", @"Full screen video error alert - title");
        NSError *error = notification.userInfo[XCDMoviePlayerPlaybackDidFinishErrorUserInfoKey];
        NSString *message = [NSString stringWithFormat:@"%@\n%@ (%@)", error.localizedDescription, error.domain, @(error.code)];
        NSString *cancelButtonTitle = NSLocalizedString(@"OK", @"Full screen video error alert - cancel button");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:cancelButtonTitle otherButtonTitles:nil];
        [alertView show];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}
@end
