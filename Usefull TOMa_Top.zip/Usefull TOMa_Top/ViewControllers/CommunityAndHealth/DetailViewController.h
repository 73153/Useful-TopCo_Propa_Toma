//
//  DetailViewController.h
//  MemorialHealthSystem
//
//  Created by Aruna on 06/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface DetailViewController : UIViewController<UIWebViewDelegate>  {
    AppDelegate *appDelegate;
    CGRect viewFrame;
    
    id caller;
    CPMessageType viewType;
    
    NSString *htmlDesc;
    
    BOOL isNetworkIndicator;
    UIWebView *webView;
    
    NSString *blogURL;
    
    NSString *detailTitleStr;
}
@property (nonatomic , strong) id caller;
@property (nonatomic, strong) NSString *detailTitleStr;
@property (nonatomic, readwrite) BOOL historyReloadCheck;

@property (nonatomic, strong) NSString *blogURL;
- (id)initWithFrame:(CGRect)frame andViewType:(CPMessageType)viewType_ HTMLDescription:(NSString *)htmlDesc_;

@end
