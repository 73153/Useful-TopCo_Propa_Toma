//
//  MediaViewController.h
//  MemorialHealthSystem
//
//  Created by Aruna on 25/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MessageService.h"
#import "RefreshView.h"
#import "YTPlayerView.h"

@interface HealthAndCommunityViewController : UIViewController<MessageServiceDelegate,UITableViewDelegate,UITableViewDataSource> {
    
    AppDelegate *appDelegate;
    id caller;
      
    UITableView *healthNCommunityTable;
    NSArray *eventsArray;
    NSArray *newsArray;
    NSArray *resourceArray;
    UIButton *healthButton;
    UIButton *communityButton;
    
    float resourceVerticalContentOffset;
    float newsVerticalContentOffset;
    CGRect viewFrame;
   
    RefreshView *refreshView;
    BOOL checkForRefresh;
	BOOL reloading;
    NSString *requestType;
}
@property(nonatomic, strong)YTPlayerView *playerView;
@property (weak, nonatomic) UIWebView *webviewVideo;

- (id)initWithFrame:(CGRect)frame;
@end
