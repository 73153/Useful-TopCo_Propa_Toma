//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import "BusinessReward.h"


@implementation BusinessReward

@dynamic businessRedeemsArray;
@dynamic imageURL;
@dynamic redeemptionListArray;
@dynamic rewardDescription;
@dynamic rewardEndDate;
@dynamic rewardId;
@dynamic rewardStartDate;
@dynamic rewardTitle;
@dynamic repeatably_redeemable;
@dynamic canRedeem;

@end
