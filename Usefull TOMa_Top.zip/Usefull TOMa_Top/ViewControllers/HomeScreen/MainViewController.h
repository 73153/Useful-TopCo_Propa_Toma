//
//  MainViewController.h
//  MemorialHealthSystem
//
//  Created by Aruna on 13/06/13.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ProfileService.h"
#import "VideoPlayerViewController.h"
#import "UserProfileEditViewController.h"
#import "MapView.h"
@class  SurveyView;

@class UserProfileEditViewController;

@interface MainViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, ProfileServiceDelegate,CPUserProfileServiceDelegate, MapViewDelegate,StreamServiceDelegate> {
    
    IBOutlet UIImageView *backgroungImgView;
    IBOutlet UITableView *homeScreenTableView;
    IBOutlet UILabel *HeaderLabel;
    NSArray *menuListArray;
    AppDelegate *appDelegate;
    
    BOOL isFirstTime;
    BOOL profileSelected;
	UserProfileEditViewController *userProfileEditVC;
    SurveyView *surveyView;
}

@end
