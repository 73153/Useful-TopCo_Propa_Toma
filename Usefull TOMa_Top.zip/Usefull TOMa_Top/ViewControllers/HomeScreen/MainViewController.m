//
//  MainViewController.m
//  MemorialHealthSystem
//
//  Created by Aruna on 13/06/13.
//
//

#import "MainViewController.h"
#import "StreamService.h"
#import "HealthAndCommunityViewController.h"
#import "MyHistoryNRecentActivityViewController.h"
#import "ChatterPlugViewController.h"
#import "ProviderLocationsViewController.h"
#import "InteractViewController.h"
#import "CommentViewController.h"
#import "DetailViewController.h"
#import "HealthTrackerViewController.h"
#import "ProviderEventsViewController.h"

@interface MainViewController () {
    ChatterPlugViewController *chatterPlugViewContr;
}

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    }
    return self;
}


- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    self.view.frame=appDelegate.window.frame;
    [self registerForNotifications];
    if ([[UIScreen mainScreen] bounds].size.height == 568.0f)
    {
        backgroungImgView.image = [UIImage imageNamed:@"Tomah-Menu_5"];
        HeaderLabel.frame = CGRectMake(HeaderLabel.frame.origin.x, HeaderLabel.frame.origin.y - 5, HeaderLabel.frame.size.width, HeaderLabel.frame.size.height);
    } //    HeaderLabel.font = [UIFont fontWithName:CenturyGothicFont size:CenturyGothicFontSize];
    //    HeaderLabel.textColor = [UIColor whiteColor];
    
    //
    HeaderLabel.textColor=[UIColor whiteColor];
    HeaderLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    HeaderLabel.backgroundColor = [UIColor clearColor];
    HeaderLabel.textAlignment = NSTextAlignmentCenter;
    [HeaderLabel setHidden:YES];
    //
    if(iPad){
        homeScreenTableView.frame = CGRectMake(5, homeScreenTableView.frame.origin.y+4, self.view.frame.size.width-10 , homeScreenTableView.frame.size.height-28);
        
    }else{
        homeScreenTableView.frame = CGRectMake(5, homeScreenTableView.frame.origin.y-12, self.view.frame.size.width-10 , homeScreenTableView.frame.size.height-12);
    }
    
    
    NSLog(@"Height %f:%f",homeScreenTableView.frame.size.height,homeScreenTableView.frame.origin.y);
    homeScreenTableView.backgroundView = nil;
    homeScreenTableView.backgroundColor = [UIColor clearColor];
    homeScreenTableView.separatorColor = [UIColor colorWithRed:0.42f green:0.43f blue:0.47f alpha:1.0f];
    homeScreenTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    //homeScreenTableView.bounces=NO;
    //homeScreenTableView.bouncesZoom=NO;
    if ([homeScreenTableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        [homeScreenTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    menuListArray = [[NSArray alloc] initWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:@"Contact Us - ",@"title",@"Communicate securely with your provider",@"description",@"menucontact",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"History - ",@"title",@"Recent communication & news",@"description",@"menuhistory",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"My Record - ",@"title",@"View your health records",@"description",@"menurecord",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Pre-Registration - ",@"title",@"Reduce time on paperwork",@"description",@"fitbit",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Info - ",@"title",@"Health education, local news & events",@"description",@"menuinfo",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Events - ",@"title",@"View upcoming events",@"description",@"class",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Locations - ",@"title",@"Find a Doctor",@"description",@"menulocation",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"My Profile - ",@"title",@"Edit your app profile",@"description",@"menuprofile",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Pay My Bill - ",@"title",@"Online bill payments",@"description",@"paybill",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Patient Channel - ",@"title",@"Patient education programs",@"description",@"instructor",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Newborn Channel - ",@"title",@"New parents education",@"description",@"motherAndChild",@"icon", nil],
                     
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Heart Care Channel - ",@"title",@"Cardiac care education",@"description",@"Tomah-Menu-Icons-Heart",@"icon", nil],
                     [NSDictionary dictionaryWithObjectsAndKeys:@"Make a Donation - ",@"title",@"Click here to donate",@"description",@"Gift_Icon_Dark",@"icon", nil],nil];
    //,[NSDictionary dictionaryWithObjectsAndKeys:@"Events - ",@"title",@"View upcoming events",@"description",@"class",@"icon", nil]
    //menuListArray = [[NSArray alloc] initWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:@"Contact Us - ",@"title",@"Communicate securely with your provider",@"description",@"menucontact",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"History - ",@"title",@"Recent communication & news",@"description",@"menuhistory",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"Info - ",@"title",@"Health education, local news & events",@"description",@"menuinfo",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"Locations - ",@"title",@"Find a Doctor",@"description",@"menulocation",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"Family Health Manager - ",@"title",@"View my health info",@"description",@"family",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"My Profile - ",@"title",@"Edit your app profile",@"description",@"menuprofile",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"Classes & Events - ",@"title",@"Find an event near you",@"description",@"class",@"icon", nil],[NSDictionary dictionaryWithObjectsAndKeys:@"Pay My Bill - ",@"title",@"Online bill payments",@"description",@"paybill",@"icon", nil], nil];
    
    isFirstTime = YES;
    
    if(appDelegate.notificationInfo != nil)
    {
        [self removeAllRecentActivityEntities];
        NSDictionary *notificationDictionary=appDelegate.notificationInfo;
        [self  sendPushNotification:notificationDictionary];
    }
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"sessionOutUserId"];
    
    TCEND
}

-(void)viewDidUnload
{
    [self unregisterForNotifications];
}


//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

-(void)unregisterForNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"notify" object:nil];
}

- (void)registerForNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"notify" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(notificationHandler:)
                                                 name:@"notify" object:nil];
}

/*** Your custom method called on notification ***/
-(void)notificationHandler:(NSNotification*)notification
{
    if([notification userInfo])
    {
        @try {
            [self removeAllRecentActivityEntities];
            //    [[NSNotificationCenter defaultCenter] postNotificationName:@"notifyData" object:nil userInfo:[notification userInfo]];
            NSDictionary *notificationDictionary=[notification userInfo];
            //[self performSelector:@selector(sendPushNotification:) withObject:notificationDictionary afterDelay:2.0f];
            [self  sendPushNotification:notificationDictionary];
        }
        @catch (NSException *exception) {
            MyHistoryNRecentActivityViewController *myhistoryVC = [[MyHistoryNRecentActivityViewController alloc] initWithFrame:self.view.frame];
            [self.navigationController pushViewController:myhistoryVC animated:NO];
        }
        @finally {
            
        }
        
    }
}

-(void)sendPushNotification:(NSDictionary*)notificationDictionary
{
    @try {
        appDelegate.notificationInfo=nil;
        NSString *eventType=[notificationDictionary objectForKey:@"event_type"];
        NSInteger eventId=[[notificationDictionary objectForKey:@"event_id"] integerValue];
        [appDelegate getStreamDataForEvent:eventType  withEventId:eventId showActivityIndicator:YES requestForRefresh:NO caller:self];
    }
    @catch (NSException *exception) {
        MyHistoryNRecentActivityViewController *myhistoryVC = [[MyHistoryNRecentActivityViewController alloc] initWithFrame:self.view.frame];
        [self.navigationController pushViewController:myhistoryVC animated:NO];
    }
    @finally {
        
    }
}

#pragma mark refresh Stream request delegate methods

- (void)didFinishedStreamRequest:(NSDictionary *)results {
    @try {
        //TODO KANAK
        //NSLog(@"didFinishedNotificationsRequest %@",results);
        if ([self isNotNull:results] && [results objectForKey:@"success"]) {
            [self getAllEntitiesOfRecentActivity];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToGetStreamResponse {
    //    [streamTable dataSourceDidFinishLoadingNewData];
    NSLog(@"In Fail");
    [appDelegate hideNetworkIndicator];
    UIViewController *currentViewController = self.navigationController.visibleViewController;
    if(![currentViewController isKindOfClass:[MyHistoryNRecentActivityViewController class]])
    {
        MyHistoryNRecentActivityViewController *myhistoryVC = [[MyHistoryNRecentActivityViewController alloc] initWithFrame:self.view.frame];
        [self.navigationController pushViewController:myhistoryVC animated:NO];
    }
}

- (void)getAllEntitiesOfRecentActivity {
    TCSTART
    NSLog(@"Data:%@",[appDelegate executeAndReturnAllEntitiesWithEntityForName:@"RecentActivity"]);
    
    NSArray *arr=[NSArray arrayWithArray:[appDelegate executeAndReturnAllEntitiesWithEntityForName:@"RecentActivity"]];
    RecentActivity *recentActivity=[arr firstObject];
    //[self makeSurveyQuestionsRequestWithSurveyId:@"313"];
    UIViewController *currentViewController = self.navigationController.visibleViewController;
    if (([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"Reminder"] == NSOrderedSame)) {
        
        CPMessageType cpMessageType;
        
        if ([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeNews;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeEvents;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeReferences;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeCommunity;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeHealth;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeVideo;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
            cpMessageType = CPMessageTypeAudio;
        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Reminder"] == NSOrderedSame) {
            cpMessageType = CPMessageReminder;
        }
        
        if([currentViewController isKindOfClass:[DetailViewController class]] || [currentViewController isKindOfClass:[CommentViewController class]])
        {
            [self.navigationController popViewControllerAnimated:NO];
        }
        DetailViewController *detailVC = [[DetailViewController alloc] initWithFrame:self.view.frame andViewType:cpMessageType HTMLDescription:recentActivity.descriptionHtml];
        detailVC.historyReloadCheck=YES;
        detailVC.caller = self;
        detailVC.detailTitleStr = recentActivity.title;
        [self.navigationController pushViewController:detailVC animated:YES];
        
    }
    else if (([recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame) || ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame))
    {
        
        if([currentViewController isKindOfClass:[DetailViewController class]] || [currentViewController isKindOfClass:[CommentViewController class]])
        {
            [self.navigationController popViewControllerAnimated:NO];
        }
        [self.navigationController popToViewController:self animated:NO];
        CGRect playerViewFrame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height);
        if ([appDelegate connectedToNetwork]) {
            VideoPlayerViewController *videoPlayerVC = nil;
            if ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
                if ([self isNotNull:recentActivity.audioUrl]) {
                    videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:recentActivity.audioUrl andFrame:playerViewFrame andMediaType:@"Audio"];
                }
            } else {
                if ([self isNotNull:recentActivity.videoUrl]) {
                    videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:recentActivity.videoUrl andFrame:CGRectMake(0, 0, playerViewFrame.size.height, playerViewFrame.size.width) andMediaType:@"Video"];
                }
            }
            float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
            if (osVersion >= 5.0) {
                [self presentViewController:videoPlayerVC animated:YES completion:nil];
            } else {
                //[self presentModalViewController: videoPlayerVC animated: YES];
                [self presentViewController:videoPlayerVC animated:YES completion:^{
                    //code
                }];
            }
            
        } else {
            [appDelegate showErrorMsg:@"Internet connection appears to be offline"];
        }
        
    }
    else if ([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) {
        if([currentViewController isKindOfClass:[DetailViewController class]] || [currentViewController isKindOfClass:[CommentViewController class]])
        {
            [self.navigationController popViewControllerAnimated:NO];
        }
        [self.navigationController popToViewController:self animated:NO];
        [surveyView removeFromSuperview];
        [self makeSurveyQuestionsRequestWithSurveyId:recentActivity.surveyId];
    }
    else if ([recentActivity.eventType caseInsensitiveCompare:@"review"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"privatemessage"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame)
    {
        if([currentViewController isKindOfClass:[CommentViewController class]] || [currentViewController isKindOfClass:[DetailViewController class]])
        {
            [self.navigationController popViewControllerAnimated:NO];
        }
        CommentViewController *commentVC = [[CommentViewController alloc]initWithNavigationCaller:self andLivefeedIndexPath:nil];
        commentVC.historyReloadCheck=YES;
        CGFloat headerHeight;
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            headerHeight = [self reviewRPrivateMessageRBroadCastHeightOfRecentActivity:recentActivity];
        } else {
            headerHeight = [self getheightForHeaderForRecentActivity:recentActivity];
        }
        commentVC.sectionHeght_float = headerHeight;
        [commentVC setRecentActivity:recentActivity];
        [self.navigationController pushViewController:commentVC animated:YES];
        self.navigationController.navigationBar.hidden = YES;
    }
    else{
        if(![currentViewController isKindOfClass:[MyHistoryNRecentActivityViewController class]]){
            MyHistoryNRecentActivityViewController *myhistoryVC = [[MyHistoryNRecentActivityViewController alloc] initWithFrame:self.view.frame];
            [self.navigationController pushViewController:myhistoryVC animated:NO];
        }
    }
    TCEND
}

#pragma mark surveys related
- (void)makeSurveyQuestionsRequestWithSurveyId:(NSString *)surveyId {
    TCSTART
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken] && [self isNotNull:surveyId]) {
        [appDelegate showActivityIndicatorInView:self.view];
        [appDelegate showNetworkIndicator];
        [appDelegate getSurveyQuestionsWithSurveyId:surveyId andchannel_Id:@"-1" withCaller:self];
    }
    TCEND
}

- (void)didReceiveSurveyQuestionsWithEvent:(CPSurveyEvent *)event {
    TCSTART
    if ([self isNotNull:event]) {
        if (event.prompts.count > 0) {
            NSMutableArray *questionsArray = [[NSMutableArray alloc] init];
            for (CPSurveyPrompt *prompt in event.prompts) {
                NSMutableDictionary *questionDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:prompt.text,@"text",[prompt.promptId stringValue],@"id",prompt.responseType,@"responseType", nil];
                [questionsArray addObject:questionDict];
            }
            surveyView = [[SurveyView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - ((CURRENT_DEVICE_VERSION < 7.0)?0:20)) andQuestionsArray:questionsArray andCaller:self andPhysiciansArray:[appDelegate getPhysicians] isPrimarysurvey:NO];
            surveyView.location_id = @"-1";
            surveyView.survey_id = [event.surveyId stringValue];
            [self.view addSubview:surveyView];
        }
    } else {
        [appDelegate showErrorMsg:@"No surveys are avaliable"];
    }
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
    TCEND
}

- (void)didFailToReceiveSurveyQuestionsWithErrorMsg:(NSString *)error {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:error];
    TCEND
}

#pragma mark Post survey delegate methods
- (void)didReceiveSurveyPostResponseWithEvent:(CPSurveyEvent *)event {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate hideNetworkIndicator];
    if ([self isNotNull:surveyView] && [surveyView respondsToSelector:@selector(displyImDoneScreen)]) {
        [surveyView displyImDoneScreen];
    }
    surveyView = nil;
    TCEND
}

- (void)didFailToReceiveSurveyPostResponseWithErrorMsg:(NSString *)error {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:error];
    TCEND
}


-(CGFloat)getheightForHeaderForRecentActivity:(RecentActivity*)recentActivity {
    
    @try {
        
        //        if ([recentActivity.rowHeight floatValue] > 0.0) {
        //            return [recentActivity.rowHeight floatValue];
        //        } else {
        int rowHeight;
        if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame) {
            
            CGFloat diff;
            CGFloat dateLabelHeight;
            CGFloat textLayerWidth;
            CGFloat nameHeight;
            if (iPad) {
                diff = 10;
                dateLabelHeight = 30;
                textLayerWidth = 660;
                nameHeight = 30;
            } else {
                diff = 5;
                dateLabelHeight = 20;
                textLayerWidth = 255;
                nameHeight = 20;
            }
            
            NSMutableAttributedString *mAttrbtdStr = [self createAttributedStringForEntity:recentActivity];
            CGSize size = [appDelegate getFrameSizeForAttributedString:mAttrbtdStr withWidth:textLayerWidth];
            recentActivity.attributedStringHeight = [NSNumber numberWithFloat:size.height];
            rowHeight = size.height + nameHeight + (diff * 3) + dateLabelHeight;
        }else if([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame){
            //
            //            MessageDataModel *dataModal = [eventsArray objectAtIndex:indexPath.row];
            CGSize nameSize;
            if ([self isNotNull:recentActivity.title]) {
                nameSize = [recentActivity.title sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            }
            CGSize descptnSize = [recentActivity.descriptionMsg sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            CGFloat gaps;
            CGFloat heightOfTheRow;
            if (iPad) {
                gaps = 30;
                heightOfTheRow = 74;
            } else {
                gaps = 15;
                heightOfTheRow = 46;
            }
            if (nameSize.height + descptnSize.height + gaps > heightOfTheRow) {
                //                return nameSize.height + descptnSize.height + gaps;
                rowHeight =nameSize.height + descptnSize.height + gaps;
            } else {
                //                return heightOfTheRow;
                rowHeight = heightOfTheRow;
            }
            //
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) {
            if (iPad) {
                rowHeight = 65;
            } else {
                rowHeight = 55;
            }
        } else {
            rowHeight = [self reviewRPrivateMessageRBroadCastHeightOfRecentActivity:recentActivity];
        }
        
        if ([self isNotNull:recentActivity.starsCount] && recentActivity.starsCount.intValue > 0) {
            rowHeight = rowHeight + CELL_RATEIMAGEVIEWHEIGHT;
        }
        recentActivity.rowHeight = [NSNumber numberWithFloat:rowHeight];
        [appDelegate saveContext];
        return rowHeight;
        //        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat)reviewRPrivateMessageRBroadCastHeightOfRecentActivity:(RecentActivity *)recentActivity {
    TCSTART
    CGFloat reviewerNameHeight = 0.0f;
    CGFloat reviewStrHeight = 0.0f;
    CGFloat photoHeight = 0.0f;
    CGFloat diff;
    if (iPad) {
        diff = 20;
    } else {
        diff = 10;
    }
    NSString *name = nil;
    NSString *review = nil;
    if ([self isNotNull:recentActivity]) {
        review = recentActivity.reviewText;
        name = recentActivity.locationName;
        if ([self isNotNull:name])
            //replace appDelegate with self.locationDelegate for static libraries
            reviewerNameHeight = [appDelegate getStringHeight:name withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff + 30) withFontSize:titleFontSize withFontName:titleFontName];
        if ([self isNotNull:review])
            reviewStrHeight = [appDelegate getStringHeight:review withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff) withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
        
        if ([self isNotNull:recentActivity.photoUrlString]) {
            photoHeight = CELL_PLUGPHOTOHEIGHT;
        }
    }
    
    if (reviewerNameHeight == 0.0f)
        reviewerNameHeight = 15.0f;
    
    if (photoHeight > 0.0f)
        photoHeight += 5.0f;
    
    if ([recentActivity.starsCount intValue] > 0) {
        reviewStrHeight += 5.0f;
    }
    
    if ([recentActivity.starsCount intValue] <= 0 && reviewStrHeight == 0) {
        reviewStrHeight = (HEADER_MARGIN * 3);
    }
    
    if (iPad) {
        return reviewerNameHeight + reviewStrHeight + photoHeight + 30.0f + 50.0f;//"50" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    } else {
        return reviewerNameHeight + reviewStrHeight + photoHeight  + 25.0f + 30.0f;//"25" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    }
    TCEND
}

#pragma mark Table Cell Data Support
- (NSMutableAttributedString *)createAttributedStringForEntity:(RecentActivity *)recentActivity
{
    //@autoreleasepool {
    @try {
        NSMutableString *rowString = [[NSMutableString alloc]init];
        NSMutableArray *boldRangesMutableArray = [[NSMutableArray alloc]init];
        NSRange boldStrRange  = NSMakeRange(0, 0);
        NSRange boldStr2Range = NSMakeRange(0, 0);
        NSRange boldStr3Range = NSMakeRange(0, 0);
        
        
        if ([recentActivity.eventType caseInsensitiveCompare:@"Special"] == NSOrderedSame && [self isNotNull:recentActivity.rankNamesArray] && [recentActivity.rankNamesArray count] > 0) {
            
            //append the formated string
            [rowString appendString:[NSString stringWithFormat:@"Posted a new Reward for %@: \"%@\"",[recentActivity.rankNamesArray  objectAtIndex:0],recentActivity.specialTilte]];
            //get the range
            if ([self isNotNull:[recentActivity.rankNamesArray objectAtIndex:0]]) {
                boldStrRange = [rowString rangeOfString:[recentActivity.rankNamesArray objectAtIndex:0]];
            }
            if ([self isNotNull:recentActivity.specialTilte]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.specialTilte];
            }
        }
        
        
        //User Activities----------
        
        else if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame && [self isNotNull:recentActivity.locationName]) {
            [rowString appendString:[NSString stringWithFormat:@"Favorited %@",recentActivity.locationName ?: @""]];
            boldStrRange = [rowString rangeOfString:recentActivity.locationName];
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"Like"] == NSOrderedSame) {
            if ([self isNull:recentActivity.otherUserId] || [self isNull:recentActivity.userId]) {
                if ([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Liked message from %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                } else if ([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.userName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        if ([self isNotNull:recentActivity.userName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.userName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
            //            if ([self isNotNull:recentActivity.likableText]) {
            //                boldStr3Range = [rowString rangeOfString:recentActivity.likableText];
            //            }
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            if ([self isNull:recentActivity.userId] || [self isNull:recentActivity.otherUserId]) {
                if([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                    if ([self isNotNull:recentActivity.locationName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.locationName]];
                    }
                } else if([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                        if ([self isNotNull:recentActivity.otherUserName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                    
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"" ,recentActivity.locationName ?: @""]];
                    
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Userrank"] == NSOrderedSame) {
            if ([self isNotNull:recentActivity.rankName]) {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    [rowString appendString:[NSString stringWithFormat:@"%@ earned %@ rank at %@",recentActivity.otherUserName,recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                } else {
                    [rowString appendString:[NSString stringWithFormat:@"You earned %@ rank at %@",recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                }
                
                boldStrRange = [rowString rangeOfString:recentActivity.rankName];
                
                if ([self isNotNull:recentActivity.locationName]) {
                    boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
                }
            }
            //                }
            //            }
        }
        
        if(boldStrRange.location != NSNotFound && boldStrRange.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStrRange]];
        }
        
        if(boldStr2Range.location != NSNotFound && boldStr2Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr2Range]];
        }
        
        if(boldStr3Range.location != NSNotFound && boldStr3Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr3Range]];
        }
        
        if([self isNotNull:rowString]) {
            return [appDelegate getAttributedStringForString:rowString withBoldRanges:boldRangesMutableArray WithBoldFontName:titleFontName withNormalFontName:descriptionTextFontName];
        } else {
            return nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    chatterPlugViewContr = nil;
    profileSelected = NO;
    if ([self isNotNull:appDelegate.userProfileDataModel.userId] && isFirstTime) {
        isFirstTime = NO;
        [appDelegate getUserProfile:appDelegate.userProfileDataModel.userId withCallbackObject:self];
    }
    
    [homeScreenTableView reloadData];
    
    appDelegate.mapView.mapDelegate = self;
    appDelegate.mapView.stopUpdatingLocationInfo = NO;
    [appDelegate.mapView.locationManager startUpdatingLocation];
    TCEND
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return menuListArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TCSTART
    if (iPad) {
        return 70.0f;
    }
    else if (isiPhone6PLUS)
    {
        return 50.0f;
    }
    else {
        return 40.0f;
    }
    TCEND
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1.0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    TCSTART
    UIView *header = [[UIView alloc] init];
    header.frame = CGRectMake(0.0, 0.0, 0.0, 0.0);
    header.backgroundColor = [UIColor clearColor];
    return header;
    TCEND
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1.0;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    TCSTART
    UIView *footer = [[UIView alloc] init];
    footer.frame = CGRectMake(0.0, 0.0, 0.0, 0.0);
    footer.backgroundColor = [UIColor clearColor];
    return footer;
    TCEND
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        //static NSString *user_messageCell = @"messageCell";
        static NSString *CellIndentifier = @"Cell";
        UITableViewCell *cell = nil;
        UIImageView *iconImgView = nil;
        UIImageView *accessoryImgView = nil;
        UILabel *title = nil;
        UILabel *descrption = nil;
        
        CGFloat diff;
        CGFloat iconImgHeight;
        CGFloat titleLblWidht;
        CGFloat descLblWidth;
        CGFloat iconImgSpace;
        if (iPad) {
            diff = 10;
            iconImgHeight = 50;
            titleLblWidht = 260;
            descLblWidth = 400;
            iconImgSpace = 8;
        }else if (isiPhone6PLUS)
        {
            diff = 5;
            iconImgHeight = 40;
            titleLblWidht = 185;
            descLblWidth  = 210;
            iconImgSpace = 5;
        }
        else {
            diff = 5;
            iconImgHeight = 30;
            titleLblWidht = 150;
            descLblWidth = 175;
            iconImgSpace = 2;
        }
        
        cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
        //initialize cell and its subviews instances once and use them when table scrolling through their instances retrieved based on "Tag" value
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIndentifier];
            
            iconImgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, diff, iconImgHeight, iconImgHeight)];
            [iconImgView setTag:1];
            [cell.contentView addSubview:iconImgView];
            
            
            
            title = [[UILabel alloc]initWithFrame:CGRectMake(iconImgView.frame.origin.x + iconImgView.frame.size.width ,diff * 2, titleLblWidht,iconImgHeight)];
            title.backgroundColor = [UIColor clearColor];
            title.font = [UIFont fontWithName:titleFontName size:menuTitleTextFontSize];
            [title setTag:2];
            title.textAlignment = NSTextAlignmentLeft;
            title.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:title];
            
            descrption = [[UILabel alloc]initWithFrame:CGRectMake(title.frame.origin.x + title.frame.size.width ,diff*2, descLblWidth,iconImgHeight)];
            descrption.backgroundColor = [UIColor clearColor];
            descrption.font = [UIFont fontWithName:descriptionTextFontName size:menuDescTextFontSize];
            [descrption setTag:3];
            descrption.textAlignment = NSTextAlignmentLeft;
            descrption.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:descrption];
            
            accessoryImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]];
            accessoryImgView.tag = 4;
            [cell.contentView addSubview:accessoryImgView];
            if (isiPhone6PLUS) {
                accessoryImgView.frame = CGRectMake(appDelegate.window.frame.size.width-25, 18.5, 12, 17);
            }
            else
            {
                accessoryImgView.frame = CGRectMake(appDelegate.window.frame.size.width-25, 11.5, 12, 17);
            }
            if (iPad) {
                accessoryImgView.hidden = YES;
                cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mainscreenarrow"]] ;
            }
        }
        
        if (!iconImgView) {
            iconImgView = (UIImageView *)[cell.contentView viewWithTag:1];
        }
        if (!title)
            title = (UILabel *)[cell.contentView viewWithTag:2];
        if (!descrption) {
            descrption = (UILabel *)[cell.contentView viewWithTag:3];
        }
        if (!accessoryImgView) {
            accessoryImgView = (UIImageView *)[cell.contentView viewWithTag:4];
        }
        NSDictionary *dict = [menuListArray objectAtIndex:indexPath.row];
        
        iconImgView.image = [UIImage imageNamed:[dict objectForKey:@"icon"]];
        CGSize titleSize;
        if (isiPhone6PLUS) {
            titleSize = [[dict objectForKey:@"title"] sizeWithFont:[UIFont fontWithName:titleFontName size:15.0f] constrainedToSize:CGSizeMake(titleLblWidht, iconImgHeight)];
            title.font = [UIFont fontWithName:titleFontName size:15.0f];
        }
        else
        {
            titleSize = [[dict objectForKey:@"title"] sizeWithFont:[UIFont fontWithName:titleFontName size:menuTitleTextFontSize] constrainedToSize:CGSizeMake(titleLblWidht, iconImgHeight)];
            title.font = [UIFont fontWithName:titleFontName size:menuTitleTextFontSize];
        }
        title.text = [dict objectForKey:@"title"];
        title.frame = CGRectMake(iconImgView.frame.origin.x + iconImgView.frame.size.width + iconImgSpace ,diff, titleSize.width,iconImgHeight);
        
        if (isiPhone6PLUS) {
            descrption.font = [UIFont fontWithName:descriptionTextFontName size:13.0f];
        }
        else
        {
            descrption.font = [UIFont fontWithName:descriptionTextFontName size:menuDescTextFontSize];
        }
        descrption.text = [dict objectForKey:@"description"];
        descrption.frame = CGRectMake(title.frame.origin.x + title.frame.size.width ,diff + 1, (descLblWidth + titleLblWidht) - titleSize.width,iconImgHeight);
        
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.backgroundColor = [UIColor darkGrayColor];
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)setRoundedRectToCell:(UITableViewCell *)cell andIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    //    cell.layer.cornerRadius = 0.0f;
    //    cell.layer.masksToBounds = YES;
    NSLog(@"IndexPath Row:%i",indexPath.row);
    if (indexPath.row == 0) {
        [appDelegate setMaskTo:cell byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft withRadii:CGSizeMake(5.0f, 5.0f)];
    } else if (indexPath.row == (menuListArray.count - 1)) {
        [appDelegate setMaskTo:cell byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(5.0f, 5.0f)];
    }
    else
    {
        [appDelegate setMaskTo:cell byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft | UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(0.0f, 0.0f)];
    }
    TCEND
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        cell.backgroundColor = [UIColor darkGrayColor];
        if (CURRENT_DEVICE_VERSION >= 7.0f) {
            [self setRoundedRectToCell:cell andIndexPath:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.backgroundColor = [UIColor colorWithRed:0.62f green:0.63f blue:0.67f alpha:1.0f];
    return indexPath;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.backgroundColor = [UIColor darkGrayColor];
    
    switch (indexPath.row)
    {
        case 0:
        {
            //Contact Us
            if ([appDelegate connectedToNetwork])
            {
                [self presentContactViewController];
            }
            else
            {
                [appDelegate showErrorMsg:@"Internet connection appears to be offline"];
                [tableView reloadData];
            }
        }
            break;
            
        case 1:
        {
            //History
            [self removeAllRecentActivityEntities];
            MyHistoryNRecentActivityViewController *myhistoryVC = [[MyHistoryNRecentActivityViewController alloc] initWithFrame:appDelegate.window.frame];
            [self.navigationController pushViewController:myhistoryVC animated:YES];
        }
            break;
            
        case 2:
        {
            //My Record
            [self showWebPageWithURLString:@"https://tmh.yourcarecommunity.com/"
                            andTitleString:@"My Record"
                            andLabelString:@""];
        }
            break;
            
        case 3:
        {
            //Pre-Registration
            [self showWebPageWithURLString:@"https://tomahhospital.webview.com/forms/form_submissions/new?form_id=15"
                            andTitleString:@"Pre-Registration"
                            andLabelString:@""];
        }
            break;
            
        case 4:
        {
            //Info
            HealthAndCommunityViewController *healthNCmmunityVC = [[HealthAndCommunityViewController alloc] initWithFrame:appDelegate.window.frame];
            [self.navigationController pushViewController:healthNCmmunityVC animated:YES];
            
        }
            break;
            
        case 5:
        {
            //Events
            ProviderEventsViewController *providerEventsVC;
            if (iPad)
            {
                providerEventsVC = [[ProviderEventsViewController alloc] initWithNibName:@"ProviderEventsViewController" bundle:nil];
            } else
            {
                providerEventsVC = [[ProviderEventsViewController alloc] initWithNibName:@"ProviderEventsViewController~iPhone" bundle:nil];
            }
            [self.navigationController pushViewController:providerEventsVC animated:YES];
        }
            break;
            
            
        case 6:
        {
            //Locations
            ProviderLocationsViewController *providerLocationsVC;
            if (iPad)
            {
                providerLocationsVC = [[ProviderLocationsViewController alloc] initWithNibName:@"ProviderLocationsViewController" bundle:nil];
            }
            else
            {
                providerLocationsVC = [[ProviderLocationsViewController alloc] initWithNibName:@"ProviderLocationsViewController~iPhone" bundle:nil];
            }
            [self.navigationController pushViewController:providerLocationsVC animated:YES];
        }
            break;
            
        case 7:
        {
            //My Profile
            profileSelected = YES;
            [self getUserProfile];
        }
            break;
            
        case 8:
        {
            //Pay my Bill
            [self showWebPageWithURLString:@"https://tomahhospital.webview.com/"
                            andTitleString:@"Pay My Bill"
                            andLabelString:@""];
        }
            break;
            
        case 9:
        {
            //Patient Channel
            [self showWebPageWithURLString:@"http://www.thepatientchannelnow.com/"
                            andTitleString:@"Patient Channel"
                            andLabelString:@"Please Enter Hospital Password - 02747"];
            
            
        }
            break;
            
        case 10:
        {
            //Newborn Channel
            [self showWebPageWithURLString:@"http://www.thenewbornchannelnow.com/"
                            andTitleString:@"Newborn Channel"
                            andLabelString:@"Please Enter Hospital Password - 02747"];
        }
            break;
        case 11:
        {
            //Heart Care Channel
            [self showWebPageWithURLString:@"http://www.heartcarechannelnow.com/"
                            andTitleString:@"Heart Care Channel"
                            andLabelString:@"Please Enter Hospital Password - 02747"];
        }
            break;
        case 12:
        {
            //Make a Donation
            [[UIApplication sharedApplication]openURL:[NSURL URLWithString:@"https://tomahdonation.webview.com/payment/onetime_payment"]];
        }
            break;
            
            
        default:
            break;
    }
    TCEND
}

- (void)showWebPageWithURLString:(NSString *)urlString andTitleString:(NSString *)title andLabelString:(NSString *)labelPassword
{
    chatterPlugViewContr = [[ChatterPlugViewController alloc]initWithUrl:urlString];
    chatterPlugViewContr.titleStr = title;
    chatterPlugViewContr.passwordLabelStr = labelPassword;
    [self.navigationController pushViewController:chatterPlugViewContr animated:YES];
}

- (void)getUserProfile {
    TCSTART
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken] && !appDelegate.isGetUserProfileRequestInProgress) {
        [appDelegate showActivityIndicatorInView:appDelegate.window];
        [appDelegate showNetworkIndicator];
        [appDelegate getUserProfile:appDelegate.userProfileDataModel.userId withCallbackObject:self];
    }
    TCEND
}
- (void)presentContactViewController {
    TCSTART
    InteractViewController *interActViewController;
    NSArray *physiciansArray = [appDelegate getPhysicians];
    if (iPad) {
        interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController" bundle:nil andCaller:self andPhysiciansArray:physiciansArray isFromMainView:YES];
    } else {
        interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController~iPhone" bundle:nil andCaller:self andPhysiciansArray:physiciansArray isFromMainView:YES];
    }
    
    interActViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    //[self presentModalViewController:interActViewController animated:YES];
    [self presentViewController:interActViewController animated:YES completion:^{
        //code
    }];
    [appDelegate.window bringSubviewToFront:interActViewController.view];
    TCEND
    
}
#pragma mark get profile delegate methods
- (void)didReceiveProfile:(CPUserEntity*) userProfileData withAuthenticationToken:(NSString*) authenticationToken {
    @try {
        appDelegate.isGetUserProfileRequestInProgress = NO;
        NSLog(@"userprofile presferences :%@",userProfileData.preferredAppointmentContactData);
        if([self isNotNull:userProfileData] && [self isNotNull:self]) {
            NSDictionary *userDict = [NSDictionary dictionaryWithObjectsAndKeys:userProfileData,@"user",authenticationToken,@"authToken", nil];
            ProfileDataModel *dataModal = [appDelegate parseProfileInfo:userDict];
            
            if ([self isNotNull:dataModal]) {
                appDelegate.userProfileDataModel = dataModal;
            }
            
            if (profileSelected) {
                profileSelected = NO;
                userProfileEditVC = [[UserProfileEditViewController alloc] initWithCaller:self];
                
                //Instead of passing pointer reference of profilemodel, creating new reference to it and passing b'coz any changes to profiledatamodel in editview will not effect the appdelegate profiledatamodel until saves.
                NSLog(@"userEmail in appdelegate:%@ ; %@",appDelegate.userProfileDataModel.userEmail,appDelegate.userProfileDataModel);
                NSData *data = [NSKeyedArchiver archivedDataWithRootObject:appDelegate.userProfileDataModel];
                userProfileEditVC.profiledatamodel = [NSKeyedUnarchiver unarchiveObjectWithData:data];
                NSLog(@"userEmail in appdelegate:%@ ; %@",userProfileEditVC.profiledatamodel.userEmail,userProfileEditVC.profiledatamodel);
                [self.navigationController pushViewController:userProfileEditVC animated:YES];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    }
    
}
- (void) didFailToReceiveProfileWithError:(NSError*) error {
    TCSTART
    appDelegate.isGetUserProfileRequestInProgress = NO;
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate showErrorMsg:[error localizedDescription]];
    TCEND
}

#pragma mark UpdateProfile Request Delegate Methods.
- (void) didFinishedupdateUserProfile:(CPUserEntity*) userProfile {
    @try {
        NSLog(@"didFinishedUpdatingUserProfile %@",userProfile);
        [appDelegate showSuccessMsg:@"Profile has been updated successfully"];
        appDelegate.isGetUserProfileRequestInProgress = NO;
        NSDictionary *userDict = [NSDictionary dictionaryWithObjectsAndKeys:userProfile,@"user",appDelegate.userProfileDataModel.authToken,@"authToken", nil];
        
        ProfileDataModel *dataModal = [appDelegate parseProfileInfo:userDict];
        
        if([self isNotNull:dataModal]) {
            appDelegate.userProfileDataModel = dataModal;
            
            NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dataModal];
            userProfileEditVC.profiledatamodel = [NSKeyedUnarchiver unarchiveObjectWithData:data];
            [userProfileEditVC reloadData];
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    }
}

- (void) didFailToUpdateUserProfileWithErrorMsg:(NSString*) error {
    TCSTART
    appDelegate.isGetUserProfileRequestInProgress = NO;
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    if ([error rangeOfString:@"is in use by another user" options:NSCaseInsensitiveSearch].location != NSNotFound) {
        [appDelegate showErrorMsg:@"Email is in use by other user"];
    } else {
        [appDelegate showErrorMsg:error];
    }
    TCEND
}

- (void)removeAllRecentActivityEntities {
    TCSTART
    NSDictionary *attributesDict = [[NSDictionary alloc] initWithObjectsAndKeys:@"RecentActivity",@"entityName", nil];
    
    [appDelegate removeAllObjectsInEntitityWithAttributes:attributesDict];
    TCEND
}


#pragma mark MapView Delegate methods
- (void)didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    @try {
        appDelegate.userCurrentLocation = newLocation;
        appDelegate.locationErrorMessage = nil;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
-(void)didFailedToUpdateLocationWithError:(NSError *)error {
    
    @try {
        //show an alert.
        //   NSLog(@"failed to update location with error %@",error);
        if ([error domain] == kCLErrorDomain) {
            
            // We handle CoreLocation-related errors here
            switch ([error code]) {
                    
                case kCLErrorDenied:
                    appDelegate.locationErrorMessage = @"Location services are required to use Tomah Memorial Hospital, please enable them before proceeding.";
                    break;
                case kCLErrorLocationUnknown:
                    appDelegate.locationErrorMessage = @"Unable to obtain GPS coordinates.";
                    break;
                case kCLErrorNetwork:
                    appDelegate.locationErrorMessage = @"Location network failure.";
                default:
                    break;
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [appDelegate.mapView.locationManager stopUpdatingLocation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
