//
//  LocationMainViewController.m
//  LocationInfo
//
//  Created by shiva on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>

#import "EventsInfoViewController.h"
#import <CoreLocation/CoreLocation.h>

#import "AppDelegate.h"

@implementation EventsInfoViewController

@synthesize back_Btn;
@synthesize provider_Btn;
@synthesize interact_Btn;
@synthesize details_Btn;
@synthesize favorite_Btn;
@synthesize customTab_ImgView;
@synthesize tabbarTitleLabel;
@synthesize channel_Id;
@synthesize customTabView;
@synthesize locationDataModal;
//Map
@synthesize userNewLocation = userNewLocation_;

@synthesize latitude;
@synthesize longitude;
@synthesize review_radius;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    @try {
        self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
        if (self) {
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
        
        appDelegate.mapView.mapDelegate = self;
        appDelegate.mapView.stopUpdatingLocationInfo = NO;
        [appDelegate.mapView.locationManager startUpdatingLocation];
        userNewLocation_ = appDelegate.userCurrentLocation;
        customTab_ImgView.layer.shadowRadius = 15.0f;
        customTab_ImgView.layer.shadowColor = [[UIColor blackColor]CGColor];
        customTab_ImgView.layer.shadowOpacity = 1.0f;
        accuracyGeoRadious=[[NSNumber alloc] init];
        accuracyGeoRadious=[NSNumber numberWithInt:140];
        tabbarTitleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        //        tabbarTitleLabel.numberOfLines = 0;
        //        tabbarTitleLabel.lineBreakMode = UILineBreakModeWordWrap;
        
        [self getProviders:nil];
        
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        if(isiPhone6) {
            [customTabView setFrame:CGRectMake(0,customTabView.frame.origin.y-(isiPhone6PLUS?10:0), appDelegate.window.frame.size.width, customTabView.frame.size.height+(isiPhone6PLUS?10:0))];
            [customTab_ImgView setFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, customTab_ImgView.frame.size.height)];
        }
        
        [customTab_ImgView setImage:[UIImage imageNamed:@"EventsDetailsTab"]];
        customTabView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin;
        locationManager = [[CLLocationManager alloc] init];
        locationManager.distanceFilter = kCLDistanceFilterNone;
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        locationManager.delegate = self;
        [locationManager startUpdatingLocation];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewWillAppear:(BOOL)animated {
    @try {
        [super viewWillAppear:YES];
        
        self.navigationController.navigationBar.hidden = YES;
        //self.navigationController.hidesBottomBarWhenPushed = YES;
        
        [self getLocationInfo];
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
}

- (void)getLocationInfo {
    TCSTART
    if([self isNull:locationDataModal] && [self isNotNull:providerVC] && [self isNotNull:channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.authToken]){
        [appDelegate getLocationInfo:channel_Id showIn:self];
        
        [appDelegate showActivityIndicatorInView:providerVC.view];
        [appDelegate showNetworkIndicator];
    }
    TCEND
}

- (void)didFinishedGettingLocationBusiness:(NSDictionary *)results{
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:providerVC.view];
        
        if (results != nil) {
            [self reloadData:results];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)didFailedToGetLocationBusinessWithError:(NSString *)errorMsg{
    
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:providerVC.view];
        
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (UIView *)returnTableHeaderViewForLocationSelectedTab:(NSString *)tabName pageTitle:(NSString *)pageTitle {
    @try {
        UIView *tableHeaderView;
        UIImageView *businessLogo_imageView = nil;
        UIImageView *pageHeader_imageView;
        UILabel *businessName_Lbl = nil;
        UILabel *businessAddress_Lbl = nil;
        UIButton *businessPhoneNumb_Btn = nil;
        UIButton *checkInButton = nil;
        UILabel *checkInLable = nil;
        UILabel *phoneNumberLabel = nil;
        
        
        CGFloat headerHeight;
        CGFloat diff;
        CGFloat businessNameHGT;
        CGFloat titleImageHeight;
        CGFloat heightChangeStatus=0;
        
        if (iPad) {
            diff = 10;
            businessNameHGT = 30;
            titleImageHeight = 50;
        }else if (isiPhone6PLUS)
        {
            diff = 5;
            businessNameHGT = 25;
            titleImageHeight = 30;
        }
        else {
            diff = 5;
            businessNameHGT = 20;
            titleImageHeight = 30;
        }
        
        CGSize addrSize = CGSizeMake(0.0f, 0.0f);
        if ([self isNotNull:locationDataModal.startDate]) {    //business address
            NSDateFormatter *formater = [[NSDateFormatter alloc] init];
            [formater setDateFormat:@"MMMM dd, YYYY"];
            NSString *addrStr = [formater stringFromDate:locationDataModal.startDate];
            addrSize = [addrStr sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:locationAddressSize] constrainedToSize:CGSizeMake(self.view.frame.size.width - (diff + REVIEWER_IMAGE_WIDTH + 20 + diff + (iPad?30:isiPhone6PLUS?20:18) + (diff * 2)), 40) lineBreakMode:NSLineBreakByWordWrapping];
        }
        
        headerHeight = businessNameHGT + addrSize.height + businessNameHGT + titleImageHeight + diff * 2 ;
        
        if (!tableHeaderView) {
            tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
            tableHeaderView.layer.cornerRadius = 10.0f;
            tableHeaderView.backgroundColor = [UIColor clearColor];
            
            //sectionBG_image
            businessLogo_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(diff, 0,isiPhone6PLUS?(REVIEWER_IMAGE_WIDTH + 30):(REVIEWER_IMAGE_WIDTH + 20),isiPhone6PLUS?(REVIEWER_IMAGE_HEIGHT + 30):(REVIEWER_IMAGE_HEIGHT + 20))];
            businessLogo_imageView.layer.cornerRadius = 5.0f;
            businessLogo_imageView.layer.masksToBounds = YES;
            businessLogo_imageView.tag = 1;
            [tableHeaderView addSubview:businessLogo_imageView];
            
            //show the Business Name.
            businessName_Lbl = [[UILabel alloc]init];
            [businessName_Lbl setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + 2*diff, -2, tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + (3 * diff) + 5), businessNameHGT)];
            businessName_Lbl.tag = 2;
            businessName_Lbl.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:locationNameSize];
            businessName_Lbl.backgroundColor = [UIColor clearColor];
            businessName_Lbl.textColor = [UIColor whiteColor];
            businessName_Lbl.numberOfLines = 3;
            businessName_Lbl.lineBreakMode = NSLineBreakByWordWrapping;

            CGSize size =  [locationDataModal.loc_Name sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:locationNameSize] constrainedToSize:CGSizeMake(tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + (3 * diff) + 5),54444) lineBreakMode:NSLineBreakByWordWrapping];
            if(size.width > businessNameHGT) {
                headerHeight+=iPad?15:10;
            }
            businessName_Lbl.frame=CGRectMake(businessName_Lbl.frame.origin.x, businessName_Lbl.frame.origin.y, size.width, size.height);
            [tableHeaderView addSubview:businessName_Lbl];

            //show the business Address.
            businessAddress_Lbl = [[UILabel alloc]init];
            [businessAddress_Lbl setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff-2, addrSize.width, addrSize.height)];
            
            businessAddress_Lbl.tag = 3;
            businessAddress_Lbl.numberOfLines = 0;
            businessAddress_Lbl.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?17.0f:locationAddressSize];
            businessAddress_Lbl.backgroundColor = [UIColor clearColor];
            businessAddress_Lbl.textColor = [UIColor grayColor];
            businessAddress_Lbl.textAlignment = NSTextAlignmentLeft;
            [tableHeaderView addSubview:businessAddress_Lbl];
            
            businessPhoneNumb_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [businessPhoneNumb_Btn setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff+ diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff, tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff + (iPad?25:12.5) + (2 * diff) + 20 ), businessNameHGT)];
            businessPhoneNumb_Btn.tag = 4;
            businessPhoneNumb_Btn.backgroundColor = [UIColor clearColor];
            //[businessPhoneNumb_Btn addTarget:self action:@selector(openPhoneApp:) forControlEvents:UIControlEventTouchUpInside];
            [tableHeaderView addSubview:businessPhoneNumb_Btn];
            
            //shwot the business Address.
            phoneNumberLabel = [[UILabel alloc]init];
            [phoneNumberLabel setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff+ diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff-2, tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff + (iPad?25:12.5) + (2 * diff) + 20 ), businessNameHGT)];
            phoneNumberLabel.tag = 6;
            phoneNumberLabel.numberOfLines = 0;
            phoneNumberLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?17.0f:locationAddressSize];
            phoneNumberLabel.textAlignment = NSTextAlignmentLeft;
            phoneNumberLabel.backgroundColor = [UIColor clearColor];
            phoneNumberLabel.textColor = [UIColor grayColor];
            [tableHeaderView addSubview:phoneNumberLabel];
            if((phoneNumberLabel.frame.origin.y+phoneNumberLabel.frame.size.height) < (businessLogo_imageView .frame.size.width + businessLogo_imageView.frame.origin.y)) {
                heightChangeStatus=iPad?10:5;
            }
            
            
            checkInButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [checkInButton setBackgroundImage:[UIImage imageNamed:@"CheckIn_f"] forState:UIControlStateNormal];
            checkInButton.layer.cornerRadius = 5.0f;
            checkInButton.tag=7;
            checkInButton.layer.masksToBounds = YES;
            [checkInButton addTarget:self action:@selector(checkInButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            checkInButton.backgroundColor = [UIColor clearColor];
            [tableHeaderView addSubview:checkInButton];
            
            
            checkInLable = [[UILabel alloc]init];  //For displaying the left side count like follwngs people etc...
            checkInLable.backgroundColor = [UIColor clearColor];
            checkInLable.tag=8;
            checkInLable.textAlignment = NSTextAlignmentCenter;
            checkInLable.textColor = [UIColor lightTextColor];
            checkInLable.font = [UIFont fontWithName:RewardTitleFontName size:iPad?18:13];
            checkInLable.text=@"Earn points by checking into this event.";
            [tableHeaderView addSubview:checkInLable];
            
            pageHeader_imageView = [[UIImageView alloc]init];
            [tableHeaderView addSubview:pageHeader_imageView];
            
        }
        if (!businessLogo_imageView)
            businessLogo_imageView = (UIImageView *)[tableHeaderView viewWithTag:1];
        if (!businessName_Lbl)
            businessName_Lbl = (UILabel *)[tableHeaderView viewWithTag:2];
        if (!businessAddress_Lbl)
            businessAddress_Lbl = (UILabel *)[tableHeaderView viewWithTag:3];
        if (!businessPhoneNumb_Btn)
            businessPhoneNumb_Btn = (UIButton *)[tableHeaderView viewWithTag:4];
        if (!phoneNumberLabel)
            phoneNumberLabel = (UILabel *)[tableHeaderView viewWithTag:6];
    
        headerHeight+=(iPad?(90+25):(65+20));
        if ([self isNotNull:pageTitle]) {
            if (iPad) {
                pageHeader_imageView.frame = CGRectMake((tableHeaderView.frame.size.width - 500)/2, phoneNumberLabel.frame.origin.y + phoneNumberLabel.frame.size.height + 10 + (90+25)+heightChangeStatus, 500, titleImageHeight);
            } else {
                pageHeader_imageView.frame = CGRectMake((tableHeaderView.frame.size.width - 297)/2, phoneNumberLabel.frame.origin.y + phoneNumberLabel.frame.size.height + (isiPhone6PLUS?8:5)+(65+20)+heightChangeStatus, 297, titleImageHeight);
            }
            pageHeader_imageView.image = [UIImage imageNamed:pageTitle];
        } else {
            pageHeader_imageView.frame = CGRectMake(0,0,0,0);
        }
        headerHeight=(pageHeader_imageView.frame.size.height+pageHeader_imageView.frame.origin.y+ (iPad?-10:-15));
        tableHeaderView.frame = CGRectMake(0, 0, self.view.frame.size.width, headerHeight);
        //check for null and is class dictionary and url null or not if not null download or just display the defualt img
        if ([self isNotNull:locationDataModal]) {
            
            if ([self isNotNull:locationDataModal.loc_PublicLogo_Url] && [locationDataModal.loc_PublicLogo_Url rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                [businessLogo_imageView setImageWithURL:[NSURL URLWithString:locationDataModal.loc_PublicLogo_Url] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
            } else {
                businessLogo_imageView.image = [UIImage imageNamed:@"default-avatar-business"];
            }
            if ([self isNotNull:locationDataModal.loc_Name] || [self isNotNull:locationDataModal.located_City] || [self isNotNull:locationDataModal.loc_State])       //business name
                businessName_Lbl.text = locationDataModal.loc_Name;
            

            if ([self isNotNull:locationDataModal.startDate]) {    //business address
                NSDateFormatter *formater = [[NSDateFormatter alloc] init];
                [formater setDateFormat:@"MMMM dd, YYYY"];
                NSString *result = [formater stringFromDate:locationDataModal.startDate];
                businessAddress_Lbl.text = result;
            } else {
                businessAddress_Lbl.text = @"";
            }
            if ([self isNotNull:locationDataModal.startDate]) {      //business phone number
                NSDateFormatter *formater = [[NSDateFormatter alloc] init];
                [formater setDateFormat:@"hh:mm a"];
                NSString *result = [formater stringFromDate:locationDataModal.startDate];
                phoneNumberLabel.text = result;
            } else {
                    [phoneNumberLabel setText:@""];
                   }
                float buttonHeight=iPad?60:45;
                float buttonWidth=self.view.frame.size.width-(iPad?350:(isiPhone6?100:60));
                CGFloat xOriginDiff=0;
                if (iPad) {
                    checkInButton.frame = CGRectMake((appDelegate.window.frame.size.width-buttonWidth)/2+xOriginDiff,phoneNumberLabel.frame.origin.y + phoneNumberLabel.frame.size.height + 10 + 10+heightChangeStatus, buttonWidth, buttonHeight);
                    checkInLable.frame = CGRectMake(0,checkInButton.frame.size.height+checkInButton.frame.origin.y, appDelegate.window.frame.size.width, 30);
                } else {
                    checkInButton.frame = CGRectMake((appDelegate.window.frame.size.width-buttonWidth)/2+xOriginDiff,phoneNumberLabel.frame.origin.y + phoneNumberLabel.frame.size.height + (isiPhone6PLUS?8:5) + 5+heightChangeStatus, buttonWidth, buttonHeight);
                    checkInLable.frame = CGRectMake(0,checkInButton.frame.size.height+checkInButton.frame.origin.y+5, appDelegate.window.frame.size.width, 20);
                }
            if(locationDataModal.isUserCheckedIn)
            [checkInButton setBackgroundImage:[UIImage imageNamed:@"CheckIn"] forState:UIControlStateNormal];
            
        }
        return tableHeaderView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)checkInButtonAction:(id)sender {
    if(!locationDataModal.isUserCheckedIn) {
        checkInButtonRef=sender;
        //[sender setBackgroundImage:[UIImage imageNamed:@"CheckIn"] forState:UIControlStateNormal];
        
        NSNumber *lat = [NSNumber numberWithFloat:locationManager.location.coordinate.latitude];
        NSNumber *lon = [NSNumber numberWithFloat:locationManager.location.coordinate.longitude];
        if([self isNotNull:lat] && [self isNotNull:lon]) {
            NSLog(@"Accuracy:%@",accuracyGeoRadious);
          [appDelegate checkInWithEventID:locationDataModal.channel_Id withLatitude:[lat stringValue] withLongitude:[lon stringValue] withCallbackObject:self withGeoErrorRadious:accuracyGeoRadious];
        }
        else
        [appDelegate checkInWithEventID:locationDataModal.channel_Id withLatitude:@"41.704418182373" withLongitude:@"-88.1260070800781" withCallbackObject:self withGeoErrorRadious:accuracyGeoRadious];
    }
    NSLog(@"Check In Button Clicked.");
}

#pragma mark - Delegate Methods for Events Check In.

- (void) didReceiveEventCheckIn:(NSDictionary*)checkinDictionary {
    TCSTART
    NSLog(@"Success");
    if(!locationDataModal.isUserCheckedIn) {
        locationDataModal.isUserCheckedIn=YES;
        [checkInButtonRef setBackgroundImage:[UIImage imageNamed:@"CheckIn"] forState:UIControlStateNormal];
    }
    [appDelegate hideNetworkIndicator];
    TCEND
    
}
- (void) didFailToReceiveEventCheckInWithError:(NSError*) error {
    TCSTART
    //NSLog(@"Failure");
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:[error localizedDescription]];
    TCEND
}




- (void)openPhoneApp:(id)sender {
    TCSTART
    if ([self isNotNull:locationDataModal.PhoneNo]) {
        UIAlertView *phoneCallAlertView = [[UIAlertView alloc]initWithTitle:@"Call" message:[NSString stringWithFormat:@"Do you want to call %@ at %@", locationDataModal.loc_Name?:@"",locationDataModal.PhoneNo] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Call", nil];
        [phoneCallAlertView show];
    }
    TCEND
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [appDelegate openPhoneApp:locationDataModal.PhoneNo];
    }
}

- (void)bringAllFooterIconsToFront {
    
    @try {
        [self.view bringSubviewToFront:customTabView];
        [customTabView bringSubviewToFront:customTab_ImgView];
        [customTabView bringSubviewToFront:provider_Btn];
        [customTabView bringSubviewToFront:interact_Btn];
        [customTabView bringSubviewToFront:details_Btn];
        [self.view bringSubviewToFront:favorite_Btn];
        [self.view bringSubviewToFront:back_Btn];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(IBAction)popToRootViewController:(id)sender {
    
    @try {
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
#pragma mark - TabButtons Actions & Their Configuration.

-(void)setImageForCustomTabbar:(int)tabNumber {
    
    @try {
        //[customTab_ImgView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"providerTab%d",tabNumber]]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)manageViewController:(BOOL)provider viewCont:(BOOL)plug viewCont:(BOOL)details {
    @try {
        if ([self isNotNull:providerVC] && provider) {
            providerVC.view.hidden = YES;
        }  else {
            providerVC.view.hidden = NO;
        }
        
        if (detailViewController && details) {
            detailViewController.view.hidden = YES;
        } else {
            detailViewController.view.hidden = NO;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(IBAction)getProviders:(id)sender {
    
    @try {
        [self setImageForCustomTabbar:1];
        
        if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
            [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
            hasFavourited = YES;
        } else {
            hasFavourited = NO;
        }
        
        //hide the mapview if it is in full mode in details view.
        [self checkAndRemoveMapFullView];
        
        // show the LiveFeed view and remove all other views
        [self manageViewController:NO viewCont:YES viewCont:YES];
        UIView *pageHeader = [self returnTableHeaderViewForLocationSelectedTab:@"Provider" pageTitle:@"details_title"];
        //        self.view.frame.size.width
        //        HEADER_WIDTH
        pageHeader.frame = CGRectMake(0, pageHeader.frame.origin.y, self.view.frame.size.width, pageHeader.frame.size.height);
        if (!providerVC) {
            providerVC = [[ProviderViewController alloc] initWithFrame:CGRectMake(0, (iPad?75:isiPhone6PLUS?61:51), self.view.frame.size.width, (self.view.frame.size.height - (lineSeparator.frame.size.height + lineSeparator.frame.origin.y + (iPad?87:isiPhone6PLUS?60:50)))) andTableHeaderView:pageHeader];
            
            providerVC.caller = self;
            providerVC.streamInfoModel = locationDataModal;
            [self.view addSubview:providerVC.view];
            
            [providerVC reloadData];
        }
        
        [self bringAllFooterIconsToFront];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (IBAction)getInteract:(id)sender {
    @try {
        
        [self checkAndRemoveMapFullView];
        
        [detailViewController zoomOutMapView:nil];
        
        if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
            [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
            hasFavourited = YES;
        } else {
            hasFavourited = NO;
        }
        NSArray *physiciansArray = [appDelegate getPhysicians];
        
        //locationDataModal.physiciansArray
        if (iPad) {
            interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController" bundle:nil andCaller:self andPhysiciansArray:physiciansArray isFromMainView:YES];
        } else {
            interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController~iPhone" bundle:nil andCaller:self andPhysiciansArray:physiciansArray isFromMainView:YES];
        }
        
        interActViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        if (interActViewController) {
            interActViewController.caller = self;
            
            //[self presentModalViewController:interActViewController animated:YES];
            [self presentViewController:interActViewController animated:YES completion:^{
                //code
            }];
            [appDelegate.window bringSubviewToFront:interActViewController.view];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (IBAction)setFavourite:(id)sender {
    @try {
        
        if (hasFavourited) { //delete favorite
            
            if([self isNotNull:locationDataModal.channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.userId]  && [self isNotNull:locationDataModal.favorite_idStr]) {
                [appDelegate unfavoriteBusiness:appDelegate.userProfileDataModel.userId withBusinessToUnFollowId:locationDataModal.favorite_idStr withCallbackObject:self];
            }
        } else {
            
            if([self isNotNull:locationDataModal.channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.userId]) {
                [appDelegate favoriteBusiness:appDelegate.userProfileDataModel.userId withBusinessToFollowId:locationDataModal.channel_Id withCallbackObject:self];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)getDetails:(id)sender {
    TCSTART
    [self setImageForCustomTabbar:3];
    
    if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
    } else {
        hasFavourited = NO;
    }
    
    [self manageViewController:YES viewCont:YES viewCont:NO];
    UIView *pageHeader = [self returnTableHeaderViewForLocationSelectedTab:@"Details" pageTitle:@"details_title"];
    pageHeader.frame = CGRectMake(0, pageHeader.frame.origin.y, HEADER_WIDTH, pageHeader.frame.size.height);
    if (!detailViewController) {
        detailViewController = [[EventsDetailsViewController alloc] initWithFrame:CGRectMake(0, (iPad?75:51), appDelegate.window.frame.size.width, (self.view.frame.size.height - (lineSeparator.frame.size.height + lineSeparator.frame.origin.y + (iPad?87:50)))) andHeader:pageHeader];
        [self.view addSubview:detailViewController.view];
    }
    
    detailViewController.streamInfoModel = locationDataModal;
    
    detailViewController.tabbarMainVC = self;
    
    [detailViewController reloadTable];
    [self bringAllFooterIconsToFront];
    TCEND
}

#pragma mark AddFavorite Request Delegate Methods
- (void)didFinishedCreatingfavoriteBusiness:(NSString *)businessId {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
        if ([self isNotNull:businessId]){
            locationDataModal.favorite_idStr = businessId;
            if ([self isNotNull:locationDataModal.favorite_idStr]){ //favorited
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)didFailedToCreatefavoriteBusiness:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark DeleteFavorite Request Delegate Methods
-(void)didFinishedUnfavoriteBusiness {
    @try {
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        [appDelegate hideNetworkIndicator];
        locationDataModal.favorite_idStr = nil;
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)didFailedToUnfavoriteBusinessWithError:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
        [appDelegate showErrorMsg:errorMsg];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

//=========================================END OF SHARE RELATED METHODS============================================//

//LocationInfo Response
-(void)reloadData:(NSDictionary *)results {
    
    @try {
        [appDelegate hideNetworkIndicator];
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]]) {
            locationDataModal = [results objectForKey:@"locationData"];
            
            if ([self isNotNull:locationDataModal]) {
                latitude = locationDataModal.loc_Latitude.floatValue;
                longitude = locationDataModal.loc_Longitude.floatValue;
                review_radius = locationDataModal.loc_ReviewRadius;
                //check for favorited id and change the footer icon accrodingly
                if ([self isNotNull:locationDataModal.favorite_idStr]) {
                    [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
                    hasFavourited = YES;
                } else {
                    hasFavourited = NO;
                }
                //reload the location info table header params
                //load the livefeed table
//                if ( [self isNotNull:providerVC]) { // configure and reload the live feed
//                    [providerVC.view removeFromSuperview];
//                    providerVC = nil;
//                    [self getProviders:nil];
//                }
                
                if ([self isNull:detailViewController])
                {
                    [detailViewController.view removeFromSuperview];
                    detailViewController = nil;
                    [self getDetails:nil];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark MapView Delegate methods


- (void)didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
    @try {
        appDelegate.userCurrentLocation = newLocation;
        userNewLocation_ = appDelegate.userCurrentLocation;
        appDelegate.locationErrorMessage = nil;
        accuracyGeoRadious=[NSNumber numberWithDouble:newLocation.horizontalAccuracy];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
-(void)didFailedToUpdateLocationWithError:(NSError *)error {
    
    @try {
        //show an alert.
        //   NSLog(@"failed to update location with error %@",error);
        if ([error domain] == kCLErrorDomain) {
            
            // We handle CoreLocation-related errors here
            switch ([error code]) {
                    
                case kCLErrorDenied:
                    appDelegate.locationErrorMessage = @"Location services are required to use ChatterPlug, please enable them before proceeding.";
                    break;
                case kCLErrorLocationUnknown:
                    appDelegate.locationErrorMessage = @"Unable to obtain GPS coordinates.";
                    break;
                case kCLErrorNetwork:
                    appDelegate.locationErrorMessage = @"Location network failure.";
                default:
                    break;
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)checkAndRemoveMapFullView {
    
    @try {
        if([self isNotNull:detailViewController] && detailViewController.mapFullVC.view.hidden == NO){
            [detailViewController.mapFullVC.view removeFromSuperview];
            detailViewController.mapFullVC = nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    //    NSLog(@"viewWillDisappear of LocationmainViewController");
    [appDelegate.mapView.locationManager stopUpdatingLocation];
    //    [appDelegate deleteAllImagesFromDocuments];
}
- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
