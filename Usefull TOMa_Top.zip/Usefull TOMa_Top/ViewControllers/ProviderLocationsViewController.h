//
//  ResourcesViewController.h
//  QuiltersThread
//
//  Created by Aruna on 06/06/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StreamService.h"
#import "RefreshView.h"
#import "AppDelegate.h"

@interface ProviderLocationsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,StreamServiceDelegate> {
   
    UITableView *providerLocationsTableView;
    NSMutableArray *locationsArray;
    
    RefreshView *refreshView;
    BOOL checkForRefresh;
	BOOL reloading;
    AppDelegate *appDelegate;
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;

@end
