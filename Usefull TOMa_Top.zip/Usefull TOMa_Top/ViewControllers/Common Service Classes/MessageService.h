//
//  ContentService.h
//  MemorialHealthSystem
//
//  Created by Aruna on 05/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol MessageServiceDelegate <NSObject>
// for contant data
-(void)didFinishedGettingMessages:(NSArray *)results;
-(void)didFailedToGetMessagesWithError:(NSString *)errorMsg;
@end

@interface MessageService : NSObject<CPMessagesServiceDelegate> {
    NSString *applicationUrl;
    NSString *apiKey;
    NSString *auth_token;
    NSString *user_id;
    id caller_;
}
@property (nonatomic, strong) NSString *applicationUrl;
@property (nonatomic, strong) NSString *apiKey;
@property (nonatomic, strong) NSString *auth_token;
@property (nonatomic, strong) NSString *user_id;
-(id)initWithCaller:(id)caller;

- (void)getMessageOfType:(CPMessageType)messageType;
@end
