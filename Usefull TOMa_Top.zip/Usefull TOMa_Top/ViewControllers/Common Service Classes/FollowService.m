//
//  FavoritesService.m
//  BeefOBrady
//
//  Created by Aruna on 19/01/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "FollowService.h"

#import "AppDelegate.h"

@implementation FollowService
@synthesize requestURL;
@synthesize auth_token;
@synthesize user_Id;
@synthesize apiKey;
@synthesize businessToFollowId;
@synthesize businessToUnFollowId;
@synthesize unfollowUserId;
@synthesize followUserId;

-(id)initWithCaller:(id)caller_
{
    @try {
        if (self = [super init]) {
            caller = caller_;
        }
        return  self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}



#pragma mark Check in Event 

-(void)checkInWithEventId:(NSString *)eventId withLatitude:(NSString *)latitude withLongitude:(NSString *)longitude withGeoErrorRadious:(NSString *)radious {
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;

        CPFollowService *service = [[CPFollowService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service checkInEventWithEventId:eventId withLatitude:latitude withLongitude:longitude andGeoErrorRadious:radious];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didReceiveEventCheckIn:(NSDictionary*)checkinDictionary {
    @try {
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate)] && [caller respondsToSelector:@selector(didReceiveEventCheckIn:)]) {
            [caller didReceiveEventCheckIn:checkinDictionary];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
}

- (void) didFailToReceiveEventCheckInWithError:(NSError*) error {
    @try {
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate)] && [caller respondsToSelector:@selector(didFailToReceiveEventCheckInWithError:)]) {
            [caller didFailToReceiveEventCheckInWithError:error];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
}

#pragma mark follow a business request methods ======================================================
-(void)favoriteBusiness {
    
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_Id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPFollowService *service = [[CPFollowService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service followBusinessWithBusinessId:businessToFollowId];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didFollowBusinessWithBusinessId:(NSString*) businessId {
    @try {
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate)] && [caller respondsToSelector:@selector(didFinishedCreatingfavoriteBusiness:)]) {
            [caller didFinishedCreatingfavoriteBusiness:businessId];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didFailToFollowBusinessWithError:(NSError*) error {
    @try {
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate)] && [caller respondsToSelector:@selector(didFailedToCreatefavoriteBusiness:)]) {
            [caller didFailedToCreatefavoriteBusiness:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark
#pragma mark unfollow a business request methods =============================================
-(void)unfavoriteBusiness {
    
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_Id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPFollowService *service = [[CPFollowService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service unFollowBusinessWithBusinessId:businessToUnFollowId];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didUnfollowBusiness {
    @try {
        //  NSLog(@"didFinishedUnFollowBusiness %@",results);
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate
                                                 )] && [caller respondsToSelector:@selector(didFinishedUnfavoriteBusiness)]) {
            [caller didFinishedUnfavoriteBusiness];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didFailToUnfollowBusinessWithError:(NSError*) error {
    @try {
        if ([caller conformsToProtocol:@protocol(FollowServiceDelegate)] && [caller respondsToSelector:@selector(didFailedToUnfavoriteBusinessWithError:)]) {
            [caller didFailedToUnfavoriteBusinessWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

@end
