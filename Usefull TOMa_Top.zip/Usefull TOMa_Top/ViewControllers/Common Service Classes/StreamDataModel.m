//
//  LocationDataModel.m
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "StreamDataModel.h"


@implementation StreamDataModel

@synthesize loc_Favorite_Id;
@synthesize Hours;
@synthesize loc_TotalReviewsCount;
@synthesize channel_Id;
@synthesize busines_Id;
@synthesize loc_ReviewRadius;

@synthesize hoursArray;
@synthesize favorite_idStr;
@synthesize liveFeed_Arr;
@synthesize locReviews_Arr;
@synthesize hasSpecials;
@synthesize loc_Specials_Arr;
@synthesize hasRankRewards;
@synthesize rankRewards_Arr;
@synthesize categorie_Arr;
@synthesize loc_TagList;
@synthesize loc_Summary;
@synthesize PricePoint;
@synthesize Url;
@synthesize loc_WebsiteUrl;
@synthesize loc_PublicLogo_Url;
@synthesize loc_ZipCode;
@synthesize loc_State;
@synthesize loc_Sg_Id;
@synthesize loc_Rating;
@synthesize PhoneNo;
@synthesize loc_Name;
@synthesize loc_Longitude;
@synthesize loc_Latitude;
@synthesize located_City;
@synthesize loc_Address;
@synthesize survey_id;
@synthesize surveyName;
@synthesize privateFeed;
@synthesize twitter_Url;
@synthesize facebook_Url;
@synthesize physiciansArray;
@synthesize  startDate;
@synthesize isUserCheckedIn;

@end
