//
//  ContentDataModel.h
//  MemorialHealthSystem
//
//  Created by Aruna on 05/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MessageDataModel : NSObject

@property (nonatomic, strong) NSString *channelId;
@property (nonatomic, strong) NSNumber *messageId;
@property (nonatomic, strong) NSString *videoURL;
@property (nonatomic, strong) NSString *audioURL;
@property (nonatomic, strong) NSDate   *createdAt;
@property (nonatomic, strong) NSDate   *updatedAt;
@property (nonatomic, strong) NSString *description;
@property (nonatomic, strong) NSString *description_html;
@property (nonatomic, strong) NSString *messageTitle;
@property (nonatomic, strong) NSNumber *createdByUserId;
@property (nonatomic, readwrite) CPMessageType messageType;
@property (nonatomic, strong) NSNumber *contentScreenId;

@end
