//
//  ContentService.m
//  MemorialHealthSystem
//
//  Created by Aruna on 05/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "MessageService.h"
#import "MessageDataModel.h"
@implementation MessageService
@synthesize apiKey;
@synthesize applicationUrl;
@synthesize auth_token;
@synthesize user_id;

-(id)initWithCaller:(id)caller {
    if (self = [super init]) {
        caller_ = caller;
    }
    return  self;
}

- (void)getMessageOfType:(CPMessageType)messageType {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.applicationURL = [NSURL URLWithString:applicationUrl];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    commonParameters.authenticationToken = auth_token;
    commonParameters.userId = [NSNumber numberWithInt:[user_id intValue]];
    CPMessagesService *service = [[CPMessagesService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getMessagesOfType:messageType channelId:nil];
    TCEND
}




- (void)didReceiveMessagesDataOfSpecifiedMessageType:(NSArray *) messages {
    TCSTART
    NSLog(@"In Did Receive Message Type");
    NSMutableArray *messagesArray = [[NSMutableArray alloc] init];
    if ([self isNotNull:messages] && messages.count > 0) {
        for (CPMessage *message in messages) {
            if ([self isNotNull:message]) {
                MessageDataModel *dataModel = [[MessageDataModel alloc] init];
                
                if ([self isNotNull:message.messageId]) {
                    dataModel.messageId = message.messageId;
                }
                
                if ([self isNotNull:message.title]) {
                    dataModel.messageTitle = message.title;
                }
                
                if ([self isNotNull:message.audioUrl]) {
                    dataModel.audioURL = message.audioUrl;
                }
                
                if ([self isNotNull:message.videoUrl]) {
                    dataModel.videoURL = message.videoUrl;
                }
                
                if ([self isNotNull:message.description]) {
                    
                    const char* charcterSet = [message.description UTF8String];
                    NSString *string = [NSString stringWithUTF8String:charcterSet];

//                    string = [self removingLastSpecialCharecter:string];
                    string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                    
                    dataModel.description = string;
                }
                
                if ([self isNotNull:message.description_html]) {
                    dataModel.description_html = message.description_html;
                }
                
                if ([self isNotNull:message.updatedAt]) {
                    dataModel.updatedAt = message.updatedAt;
                }
                
                if ([self isNotNull:message.createdAt]) {
                    dataModel.createdAt = message.createdAt;
                }
                
                if ([self isNotNull:message.businessEntityId]) {
                    dataModel.channelId = message.businessEntityId;
                }
                
                //if ([self isNotNull:message.messageType]) {
                    dataModel.messageType = message.messageType;
                //}
                
                if ([self isNotNull:message.createdByUserId]) {
                    dataModel.createdByUserId = message.createdByUserId;
                }
                
                if ([self isNotNull:message.contentScreenId]) {
                    dataModel.contentScreenId = message.contentScreenId;
                }
                [messagesArray addObject:dataModel];
            }
        }
    }
    if ([caller_ conformsToProtocol:@protocol(MessageServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingMessages:)]) {
        [caller_ didFinishedGettingMessages:messagesArray];
    }
    TCEND
}

-(NSString *)removingLastSpecialCharecter:(NSString *)str {
    @try {
//        int length = [str length] - 1;
        NSMutableCharacterSet *symbols = [NSMutableCharacterSet newlineCharacterSet];
        if([symbols characterIsMember:[str characterAtIndex:0]]) {
            NSRange charcterRange = NSMakeRange(0, 1);
            str = [str stringByReplacingCharactersInRange:charcterRange withString:@""];
//            str = [str substringToIndex:length];
            str = [self removingLastSpecialCharecter:str];
        } else {
            //            NSLog(@"At %@",str);
            return str;
        }
        return str;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didFailToReceiveMessagesDataOfSpecifiedMessageType:(NSError*) error {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(MessageServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToGetMessagesWithError:)]) {
        [caller_ didFailedToGetMessagesWithError:[error localizedDescription]];
    }
    TCEND
}
@end
