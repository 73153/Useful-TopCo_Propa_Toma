//
//  FavoritesService.h
//  BeefOBrady
//
//  Created by Aruna on 19/01/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol FollowServiceDelegate <NSObject>

@optional
-(void)didFinishedGettingUserFavorites:(NSDictionary *)response;
-(void)didFailedToGetUserFavorites:(NSString *)errorMsg;

-(void)didFinishedCreatingfavoriteBusiness:(NSString *)businessId;
-(void)didFailedToCreatefavoriteBusiness:(NSString *)errorMsg;

- (void) didReceiveEventCheckIn:(NSDictionary*)checkinDictionary;
- (void) didFailToReceiveEventCheckInWithError:(NSError*) error;

-(void)didFinishedUnfavoriteBusiness;
-(void)didFailedToUnfavoriteBusinessWithError:(NSString *)errorMsg;

- (void)didFollowUser;
- (void)didFailedToFollowUser:(NSString *)errorMsg;

- (void)didUnfollowUser;
- (void)didFailedToUnfollowUser:(NSString *)errorMsg;

- (void)didFinishedGettingUserFollowers:(NSDictionary *)followers;
- (void)didFailedToGetUserFollowersWithError:(NSString *)errorMsg;

- (void)didFinishedGettingUserFollowings:(NSDictionary *)followings;
- (void)didFailedToGetUserFollowingsWithError:(NSString *)errorMsg;

@end
@interface FollowService : NSObject<FollowServiceDelegate,CPUserProfileServiceDelegate,CPFollowServiceDelegate> {
    id caller;
}

@property(nonatomic,strong)    NSString *requestURL;
@property(nonatomic,strong)    NSString *auth_token;
@property(nonatomic,strong)    NSString *user_Id;
@property(nonatomic,strong)    NSString *apiKey;
@property(nonatomic,strong)    NSString *businessToFollowId;
@property(nonatomic,strong)    NSString *businessToUnFollowId;
@property(nonatomic,strong)    NSString *unfollowUserId;
@property(nonatomic,strong)    NSString *followUserId;
- (id)initWithCaller:(id)caller_;
- (void)favoriteBusiness;
- (void)unfavoriteBusiness;
- (void)checkInWithEventId:(NSString*)eventId withLatitude:(NSString*)latitude withLongitude:(NSString*)longitude withGeoErrorRadious:(NSString*)radious;

@end
