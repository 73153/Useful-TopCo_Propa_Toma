//
//  LocationDataModel.h
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StreamDataModel : NSObject
{
  
    
    NSUInteger busines_Id;
    NSString   *channel_Id;
    NSUInteger loc_TotalReviewsCount;
    NSUInteger loc_ReviewRadius;
    NSUInteger loc_Favorite_Id;

    NSString *favorite_idStr;
    NSString *loc_Address;
    NSString *located_City;
    NSString *loc_Latitude;
    NSString *loc_Longitude;
    NSString *loc_Name;
    NSString *PhoneNo;
    NSString *loc_Rating;
    NSString *loc_Sg_Id;
    NSString *loc_State;
    NSString *loc_ZipCode;
    NSString *loc_PublicLogo_Url;
    NSString *loc_WebsiteUrl;
    NSString *Url;
    NSString *PricePoint;
    NSString *loc_Summary;
    NSString *loc_TagList;
        
    NSArray *categorie_Arr;
    NSArray *rankRewards_Arr;
    BOOL    hasRankRewards;
    NSArray *loc_Specials_Arr;
    BOOL    hasSpecials;
    NSArray *locReviews_Arr;
    NSArray *liveFeed_Arr;
    NSArray *hoursArray;
    NSString *survey_id;
    NSString *surveyName;
    BOOL    privateFeed;
    
    NSString *facebook_Url;
    NSString *twitter_Url;
    
    NSArray *physiciansArray;
    
    NSDate  *startDate;
    BOOL    isUserCheckedIn;
}

@property(nonatomic,strong)     NSArray *categorie_Arr;
@property(nonatomic, strong)    NSString *survey_id;
@property(nonatomic, strong)    NSString *surveyName;

@property(nonatomic, readwrite) BOOL    privateFeed;
@property(nonatomic,strong)     NSArray *rankRewards_Arr;
@property(nonatomic,readwrite)  BOOL hasRankRewards;
@property(nonatomic,strong)     NSArray *loc_Specials_Arr;
@property(nonatomic,readwrite)  BOOL hasSpecials;
@property(nonatomic,strong)     NSArray *locReviews_Arr;
@property(nonatomic,strong)     NSArray *liveFeed_Arr;
@property(nonatomic,strong)     NSArray *hoursArray;

@property(nonatomic,readwrite)  NSUInteger busines_Id;
@property(nonatomic,strong)     NSString *channel_Id;
@property(nonatomic,readwrite)  NSUInteger loc_TotalReviewsCount;
@property(nonatomic,readwrite)  NSUInteger loc_ReviewRadius;
@property(nonatomic,readwrite)  NSUInteger Hours;
@property(nonatomic,readwrite)  NSUInteger loc_Favorite_Id;

@property(nonatomic,strong)     NSString *favorite_idStr;
@property(nonatomic,strong)     NSString *loc_Address;
@property(nonatomic,strong)     NSString *located_City;
@property(nonatomic,strong)     NSString *loc_Latitude;
@property(nonatomic,strong)     NSString *loc_Longitude;
@property(nonatomic,strong)     NSString *loc_Name;
@property(nonatomic,strong)     NSString *PhoneNo;
@property(nonatomic,strong)     NSString *loc_Rating;
@property(nonatomic,strong)     NSString *loc_Sg_Id;
@property(nonatomic,strong)     NSString *loc_State;
@property(nonatomic,strong)     NSString *loc_ZipCode;
@property(nonatomic,strong)     NSString *loc_PublicLogo_Url;
@property(nonatomic,strong)     NSString *loc_WebsiteUrl;
@property(nonatomic,strong)     NSString *Url;
@property(nonatomic,strong)     NSString *PricePoint;
@property(nonatomic,strong)     NSString *loc_Summary;
@property(nonatomic,strong)     NSString *loc_TagList;
@property (nonatomic, strong)   NSString *facebook_Url;
@property (nonatomic, strong)   NSString *twitter_Url;
@property (nonatomic, strong)   NSArray *physiciansArray;
@property (nonatomic, retain)   NSDate *startDate;
@property (nonatomic,readwrite) BOOL isUserCheckedIn;

@end
