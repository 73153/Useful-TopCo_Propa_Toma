//
//  LocationController.m
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "StreamService.h"
#import "StreamDataModel.h"
#import "Base64.h"
#import "AppDelegate.h"
@implementation StreamService

@synthesize requestURL;
@synthesize auth_token;
@synthesize channel_Id;
@synthesize review_id;
@synthesize user_id;
@synthesize broadCast_id;
@synthesize comment_id;
@synthesize specialId;
@synthesize sharingOutletIdArray;
@synthesize apiKey;
@synthesize coordinates;
@synthesize reviewRadius;
@synthesize privateMessageId;

-(id)initWithCaller:(id)caller
{
    if (self = [super init]) {
        caller_ = caller;
        appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    }
    return  self;
}

#pragma mark
#pragma LocationControllerBusiness Methods

-(void)getLocationBusinesses {
    @try {
        
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        CPLocationDataService *service = [[CPLocationDataService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service getLocationDataWithLocationId:channel_Id];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void) didReceiveLocationData:(CPBusinessEntity*) locationData {
    @try {
        StreamDataModel *locData = nil;
        if ([self isNotNull:locationData]) {
            locData = [appDelegate getStreamDataModelByBusinessEntity:locationData];
        }
        NSDictionary *locationBusinesses = nil;
        if ([self isNotNull:locData]) {
            locationBusinesses = [[NSDictionary alloc]initWithObjectsAndKeys:locData,@"locationData", nil];
        }
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingLocationBusiness:)]) {
            [caller_ didFinishedGettingLocationBusiness:locationBusinesses];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didFailToReceiveLocationDataWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToGetLocationBusinessWithError:)]) {
            [caller_ didFailedToGetLocationBusinessWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Guilds

-(void)getAllProviderLocations {
    @try {
        
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        CPLocationDataService *service = [[CPLocationDataService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service getAllShopLocations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark Events Details 
-(void)getAllEventsDetails {
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        CPLocationDataService *service = [[CPLocationDataService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service getAllEventsDetails];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void) didReceiveAllShopLocationsData:(NSArray*) allShopLocations {
    @try {
        NSMutableArray *providerLocations = [[NSMutableArray alloc] init];
        if ([self isNotNull:allShopLocations] && allShopLocations.count > 0) {
            for (CPBusinessEntity *entity in allShopLocations) {
                [providerLocations addObject:[appDelegate getStreamDataModelByBusinessEntity:entity]];
            }
        }
        NSDictionary *guildsLocationsDict = nil;
        if ([self isNotNull:providerLocations]) {
            guildsLocationsDict = [[NSDictionary alloc]initWithObjectsAndKeys:providerLocations,@"data", nil];
        }
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingAllProviderLocations:)]) {
            [caller_ didFinishedGettingAllProviderLocations:guildsLocationsDict];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didFailToReceiveAllShopLocationsDataWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToGetAllProviderLocationsWithErrorMsg:)]) {
            [caller_ didFailToGetAllProviderLocationsWithErrorMsg:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Like Related
-(void)postlikedReviewOfType:(CPEventType)eventType andIndexPath:(NSIndexPath *)indexPath {
    @try {
        
        NSNumber *eventId = [NSNumber numberWithInteger:[review_id integerValue]];
        likeReviewIndexPath = indexPath;
        
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPLikeService *service = [[CPLikeService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service likeEventWithEventId:eventId ofType:eventType];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didLikeEventWithEventId:(NSNumber*) eventId {
    @try {
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedLikedReviewRequest:)]) {
            if([self isNotNull:likeReviewIndexPath])
            {
                [caller_ didFinishedLikedReviewRequest:[NSDictionary dictionaryWithObjectsAndKeys:likeReviewIndexPath,@"indexPath",eventId,@"likable_id", nil]];
            }
            else
            {
                [caller_ didFinishedLikedReviewRequest:[NSDictionary dictionaryWithObjectsAndKeys:eventId,@"likable_id", nil]];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didFailToLikeEventWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToPostLikeWithError:)]) {
            [caller_ didFailedToPostLikeWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark DeleteReview ============================================
-(void)deleteReview:(NSIndexPath *)indexPath ofEventType:(CPEventType)eventType {
    
    @try {
        deleteReviewIndexPath = indexPath;
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPPlugService *service = [[CPPlugService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        
        [service deletePlugWithPlugEventId:[NSNumber numberWithInteger:[review_id integerValue]] andEventType:eventType];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void) didDeletePlug {
    @try {
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedDeletingReview:)]) {
            [caller_ didFinishedDeletingReview:[NSDictionary dictionaryWithObjectsAndKeys:deleteReviewIndexPath,@"indexPath", nil]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didFailToDeletePlugWithError:(NSError *)error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToDeleteReview:)]) {
            [caller_ didFailedToDeleteReview:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma mark Posting Rate & Review ==========================
-(void)postRateAndReview:(NSDictionary *)rateReviewDict {
    
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPPlugService *service = [[CPPlugService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        CPPlugData *data = [[CPPlugData alloc] init];
        
        data.review = [rateReviewDict objectForKey:@"description"];
        data.rating = [rateReviewDict objectForKey:@"rating"];
        data.pictureData = [rateReviewDict objectForKey:@"photo_data"];
        data.sharingOutlets = [rateReviewDict objectForKey:@"sharing_outlets_attributes"];
        data.coordinates  = coordinates;
        data.reviewRadius = [NSNumber numberWithInt:reviewRadius];
        
        //        [self connectionRequest:data andParameters:commonParameters];
        [service postPlugWithPlugData:data toLocationWithId:channel_Id withAWSAccessKey:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsAccessKeyId"] withAWSSecretAccessKey:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsSecretAccessKey"] withBucketName:[[NSUserDefaults standardUserDefaults] objectForKey:@"s3BucketName"]];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didPostPlug:(CPPlugEvent *)reviewPlug {
    @try {
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedPostingUsersPlug:)]) {
            [caller_ didFinishedPostingUsersPlug:[NSDictionary dictionaryWithObjectsAndKeys:reviewPlug,@"RateAndReview", nil]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didFailToPostPlugWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToPostUsersPlug:)]) {
            [caller_ didFailedToPostUsersPlug:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Posting PrivateMessage ==========================
-(void)postPrivateMessage:(NSDictionary *)rateReviewDict {
    
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPPlugService *service = [[CPPlugService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        CPPlugData *data = [[CPPlugData alloc] init];
        
        data.review = [rateReviewDict objectForKey:@"description"];
        //        NSLog(@"data: %@",data.review);
        //        NSLog(@"After substitutions: %@",[data.review substituteEmoticons]);
        //        NSLog(@"Decoded: %@",[data.review decodedString]);
        //        NSLog(@"Encoded: %@",[data.review encodedString]);
        //        NSString *DECO=@"L\\ud83d\\udc37";
        //        NSLog(@"Decoded my test sample: %@",[DECO decodedString]);
        //        NSLog(@"Decoded my test utf8: %@",[DECO decodedStringUTF8]);
        
        data.review = [data.review encodedString];
        data.communicationTypeId = [rateReviewDict objectForKey:@"communication_type_id"];
        
        if([self isNotNull:[rateReviewDict objectForKey:@"appointment_type_id"]]) {
            data.appointmentTypeId=[rateReviewDict objectForKey:@"appointment_type_id"];
        }
        if([self isNotNull:[rateReviewDict objectForKey:@"reason_type_id"]]) {
            data.reasonTypeId=[rateReviewDict objectForKey:@"reason_type_id"];
        }
        if ([self isNotNull:[rateReviewDict objectForKey:@"photo_data"]]) {
            data.pictureData = [rateReviewDict objectForKey:@"photo_data"];
        }
        
        [service postPrivateMessageWithPrivateMessageData:data toLocationWithId:channel_Id hasIncludeRequestedResponse:YES andNeedResponseForRequest:[[rateReviewDict objectForKey:@"requestedResponse"] boolValue] withAWSAccessKey:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsAccessKeyId"] withAWSSecretAccessKey:[[NSUserDefaults standardUserDefaults] objectForKey:@"awsSecretAccessKey"] withBucketName:[[NSUserDefaults standardUserDefaults] objectForKey:@"s3BucketName"]];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didPostPrivateMessage:(CPEvent *)privateMessageEvent {
    @try {
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedPostingUsersPlug:)]) {
            [caller_ didFinishedPostingUsersPlug:[NSDictionary dictionaryWithObjectsAndKeys:privateMessageEvent,@"RateAndReview", nil]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didFailToPostPrivateMessageWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToPostUsersPlug:)]) {
            [caller_ didFailedToPostUsersPlug:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma
#pragma mark Comments Related==============

#pragma mark Comment Related
- (void)postComment:(NSString *)comment withIndexPath:(NSIndexPath *)indexPath {
    @try {
        CPEventType eventType;
        NSNumber *eventId;
        if ([self isNotNull:review_id]) {
            eventType = CPEventTypeReview;
            eventId = [NSNumber numberWithInteger:[review_id integerValue]];
        } else if([self isNotNull:broadCast_id]) {
            eventType = CPEventTypeBroadcast;
            eventId = [NSNumber numberWithInteger:[broadCast_id integerValue]];
        } else if([self isNotNull:privateMessageId]) {
            eventType = CPEVentTypePrivateMessage;
            eventId = [NSNumber numberWithInteger:[privateMessageId integerValue]];
        }
        postCommentIndexPath = indexPath;
        
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPCommentService *service = [[CPCommentService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service postComment:comment forEventOfEventType:eventType withEventId:eventId forLocationId:channel_Id];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didPostComment:(CPReply*) commentReply {
    @try {
        NSDictionary *results;
        if([self isNotNull:postCommentIndexPath])
            results = [NSDictionary dictionaryWithObjectsAndKeys:commentReply,@"postCommentResponse",postCommentIndexPath,@"indexPath", nil];
        else{
            results = [NSDictionary dictionaryWithObjectsAndKeys:commentReply,@"postCommentResponse", nil];
        }
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedPostingComment:)]) {
            [caller_ didFinishedPostingComment:results];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void) didFailToPostCommentWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToPostCommentWithError:)]) {
            [caller_ didFailedToPostCommentWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark DeleteComment ============================================
-(void)deleteComment:(NSIndexPath *)indexPath ofType:(CPEventType)eventType andEventId:(NSNumber *)eventId {
    @try {
        //        CPEventType eventType;
        //        NSNumber *eventId;
        //        if ([self isNotNull:review_id]) {
        //            eventType = CPEventTypeReview;
        //            eventId = [NSNumber numberWithInteger:[review_id integerValue]];
        //        } else if([self isNotNull:broadCast_id]) {
        //            eventType = CPEventTypeBroadcast;
        //            eventId = [NSNumber numberWithInteger:[broadCast_id integerValue]];
        //        }
        deleteCommentIndexPath = indexPath;
        
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:requestURL];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPCommentService *service = [[CPCommentService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service deleteCommentWithCommentId:[NSNumber numberWithInteger:[comment_id integerValue]] forEventOfEventType:eventType withEventId:eventId];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didDeleteComment {
    @try {
        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:deleteCommentIndexPath,@"indexPath", nil];
        if (caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedDeletingComment:)]) {
            [caller_ didFinishedDeletingComment:dict];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didFailToDeleteCommentWithError:(NSError*) error {
    @try {
        if ([caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToDeleteComment:)]) {
            [caller_ didFailedToDeleteComment:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}


#pragma mark GetComments
//GetComments
- (void)getCommentsForReviewWithEventType:(CPEventType)eventType {
    TCSTART
    NSNumber *reviewId;
    if ([self isNotNull:review_id]) {
        reviewId = [NSNumber numberWithInteger:[review_id integerValue]];
    }
    
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPCommentService *service = [[CPCommentService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getCommentsForPlugforEventOfEventType:eventType withEventId:reviewId];
    //    [service getCommentsForPlugWithReviewId:reviewId broadCastId:broadcastId];
    TCEND
}
- (void)didReceivePlugComments:(NSArray*) comments {
    @try {
        if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingCommentsForReview:)]) {
            
            [caller_ didFinishedGettingCommentsForReview:[NSDictionary dictionaryWithObjectsAndKeys:comments,@"reviewcomments", nil]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void) didFailToReceivePlugCommentsWithError:(NSError*) error {
    @try {
        if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailedToGetCommentsForReview:)]) {
            
            [caller_ didFailedToGetCommentsForReview:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark get primary survey questions
- (void)getPriamrySurveyQuestions {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPSurveyService *service = [[CPSurveyService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getPrimarySurveyQuestions];
    TCEND
}

#pragma mark get survey questions
- (void)getSurveyQuestions:(NSString *)surveyId {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPSurveyService *service = [[CPSurveyService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getSurveyQuestionswithLocationId:channel_Id andSurveyId:surveyId];
    TCEND
}

- (void)didReceiveSurveyQuestions:(CPSurveyEvent *) event {
    TCSTART
    if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didReceiveSurveyQuestionsWithEvent:)]) {
        
        [caller_ didReceiveSurveyQuestionsWithEvent:event];
    }
    TCEND
}
- (void)didFailToReceiveSurveyQuestionsWithError:(NSError*) error {
    TCSTART
    if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToReceiveSurveyQuestionsWithErrorMsg:)]) {
        [caller_ didFailToReceiveSurveyQuestionsWithErrorMsg:[error localizedDescription]];
    }
    TCEND
}

#pragma mark post survey response
- (void)postSurveyResponses:(NSArray *)responseData andSurveyId:(NSString *)surveyId andPhysicianId:(NSString *)physicianId {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPSurveyService *service = [[CPSurveyService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service postSurveyResponses:responseData withSurveyId:surveyId andLocationId:channel_Id hasPhysician:YES andPhysicianId:physicianId];
    TCEND
}

- (void)didReceiveSurveyPostResponse:(CPSurveyEvent *) event {
    TCSTART
    if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didReceiveSurveyPostResponseWithEvent:)]) {
        [caller_ didReceiveSurveyPostResponseWithEvent:event];
    }
    TCEND
}
- (void)didFailToReceiveSurveyPostResponseWithError:(NSError*) error {
    TCSTART
    if(caller_ && [caller_ conformsToProtocol:@protocol(StreamServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToReceiveSurveyPostResponseWithErrorMsg:)]) {
        
        [caller_ didFailToReceiveSurveyPostResponseWithErrorMsg:[error localizedDescription]];
    }
    TCEND
}


@end
