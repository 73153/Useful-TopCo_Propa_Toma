//
//  PhysicianService.h
//  MemorialHealthSystem
//
//  Created by Aruna on 21/06/13.
//
//

#import <Foundation/Foundation.h>

@protocol PhysicianServiceDelegate <NSObject>

@optional
//physicians list
- (void)didFinishedGettingAllPhysicians:(NSArray *)results;
- (void)didFailedToGetAllPhysiciansWithError:(NSString *)errorMsg;
@end

@interface PhysicianService : NSObject<CPPhysicianServiceDelegate,PhysicianServiceDelegate>  {
    NSString *requestURL;       //set the host URL
    NSString *auth_token;
    NSString *user_id;
    NSString *apiKey;
    id caller;
}
@property (nonatomic, strong) NSString *requestURL;
@property (nonatomic, strong) NSString *auth_token;
@property (nonatomic, strong) NSString *user_id;
@property (nonatomic, strong) NSString *apiKey;
- (id)initWithCaller:(id)caller_;
- (void)getAllPhysicians;
- (void)getAllPhysiciansByLocaitonId:(NSString *)locationId;
@end
