//
//  PhysicianService.m
//  MemorialHealthSystem
//
//  Created by Aruna on 21/06/13.
//
//

#import "PhysicianService.h"

@implementation PhysicianService
@synthesize requestURL;
@synthesize user_id;
@synthesize apiKey;
@synthesize auth_token;

- (id)initWithCaller:(id)caller_ {
    if (self = [super init]) {
        caller = caller_;
    }
    return  self;
}

- (void)getAllPhysicians {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    CPPhysicianService *service = [[CPPhysicianService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getAllPhysicians];
    TCEND
}

- (void)getAllPhysiciansByLocaitonId:(NSString *)locationId {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    CPPhysicianService *service = [[CPPhysicianService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service getAllPhysiciansOfSpecifiedLocation:locationId];
    TCEND

}

- (void)didReceiveAllPhysicians:(NSArray *) physiciansArray {
    TCSTART
   // NSLog(@"PhysiciansId:%@ physiciansName:%@",[[physiciansArray objectAtIndex:0] physicianId] , [[physiciansArray objectAtIndex:0] physicianName]);
    if(caller && [caller conformsToProtocol:@protocol(PhysicianServiceDelegate)] && [caller respondsToSelector:@selector(didFinishedGettingAllPhysicians:)]) {
        [caller didFinishedGettingAllPhysicians:physiciansArray];
    }
    TCEND
}

- (void)didFailToReceiveAllPhysiciansWithError:(NSError*) error {
    TCSTART
    if(caller && [caller conformsToProtocol:@protocol(PhysicianServiceDelegate)] && [caller respondsToSelector:@selector(didFailedToGetAllPhysiciansWithError:)]) {
        [caller didFailedToGetAllPhysiciansWithError:[error localizedDescription]];
    }
    TCEND
}

@end
