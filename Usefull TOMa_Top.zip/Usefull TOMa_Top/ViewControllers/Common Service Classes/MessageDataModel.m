//
//  ContentDataModel.m
//  MemorialHealthSystem
//
//  Created by Aruna on 05/03/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "MessageDataModel.h"

@implementation MessageDataModel
@synthesize messageId;
@synthesize messageTitle;
@synthesize messageType;
@synthesize channelId;
@synthesize createdAt;
@synthesize updatedAt;
@synthesize description;
@synthesize description_html;
@synthesize videoURL;
@synthesize audioURL;
@synthesize createdByUserId;
@synthesize contentScreenId;
@end
