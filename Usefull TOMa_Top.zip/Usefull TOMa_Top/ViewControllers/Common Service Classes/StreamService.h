//
//  LocationController.h
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+PE.h"

@class AppDelegate;

@protocol StreamServiceDelegate <NSObject>

@optional
//Business Location
-(void)didFinishedGettingLocationBusiness:(NSDictionary *)results;
-(void)didFailedToGetLocationBusinessWithError:(NSString *)errorMsg;

//Like
-(void)didFinishedLikedReviewRequest:(NSDictionary *)results;
-(void)didFailedToPostLikeWithError:(NSString *)errorMsg;

//Post Comment
-(void)didFinishedPostingComment:(NSDictionary *)results;
-(void)didFailedToPostCommentWithError:(NSString *)errorMsg;

//Post Plug
-(void)didFinishedPostingUsersPlug:(NSDictionary *)results;
-(void)didFailedToPostUsersPlug:(NSString *)errorMsg;

//Delete Comment
-(void)didFinishedDeletingComment:(NSDictionary *)results;
-(void)didFailedToDeleteComment:(NSString *)errorMsg;

//Delete Review
-(void)didFinishedDeletingReview:(NSDictionary *)results;
-(void)didFailedToDeleteReview:(NSString *)errorMsg;

//GetCommentsForReviews
- (void)didFinishedGettingCommentsForReview:(NSDictionary *)results;
- (void)didFailedToGetCommentsForReview:(NSString *)errorMsg;

//Get survey questions
- (void)didReceiveSurveyQuestionsWithEvent:(CPSurveyEvent *) event;
- (void)didFailToReceiveSurveyQuestionsWithErrorMsg:(NSString *) error;

//post survey responses
- (void)didReceiveSurveyPostResponseWithEvent:(CPSurveyEvent *) event;
- (void)didFailToReceiveSurveyPostResponseWithErrorMsg:(NSString *) error;

//Provider Locations
- (void)didFinishedGettingAllProviderLocations:(NSDictionary *)results;
- (void)didFailToGetAllProviderLocationsWithErrorMsg:(NSString *)error;

@end

@interface StreamService : NSObject<StreamServiceDelegate,CPCommentServiceDelegate,CPLocationDataServiceDelegate,CPLocationLiveFeedServiceDelegate,CPPlugServiceDelegate,CPLikeServiceDelegate,CPSurveyServiceDelegate>
{
    id caller_;
    
    NSString *requestURL;       //set the host URL
    NSString *auth_token;       //Set the auth_token of the user
    NSString *channel_Id;          //Set the location id to get the info about a locaion.
    NSString *review_id;        //Set review id to send a like
    NSString *privateMessageId;
    NSString *user_id;          //Set user_id to get the user activities through live feed
    NSString *broadCast_id;      //set to send a comment for on a business
    NSString *comment_id;       //set to delete the comment.
    NSString *specialId;         //to share the special
    NSArray *sharingOutletIdArray; //consists of sharingoutletattributes of facebook & twitter.
    NSString *apiKey;
    NSArray *coordinates;
    NSInteger reviewRadius;
    NSIndexPath *likeReviewIndexPath;
    NSIndexPath *deleteReviewIndexPath;
    NSIndexPath *postCommentIndexPath;
    NSIndexPath *deleteCommentIndexPath;
    
    AppDelegate *appDelegate;
}

@property (nonatomic, strong) NSString *broadCast_id;
@property (nonatomic, strong) NSString *review_id;
@property (nonatomic, strong) NSString *privateMessageId;
@property (nonatomic, strong) NSString *requestURL;
@property (nonatomic, strong) NSString *auth_token;
@property (nonatomic, strong) NSString *channel_Id;
@property (nonatomic, strong) NSString *user_id;
@property (nonatomic, strong) NSString *comment_id;
@property (nonatomic, strong) NSString *specialId;
@property (nonatomic, strong) NSArray *sharingOutletIdArray;
@property (nonatomic, strong) NSString *apiKey;
@property (nonatomic, strong) NSArray *coordinates;
@property (nonatomic, readwrite) NSInteger reviewRadius;

-(id)initWithCaller:(id)caller;

-(void)postlikedReviewOfType:(CPEventType)eventType andIndexPath:(NSIndexPath *)indexPath;

-(void)getLocationBusinesses;

//Posting Comment
-(void)postComment:(NSString *)comment withIndexPath:(NSIndexPath *)indexPath;

//Deleting Comment
-(void)deleteComment:(NSIndexPath *)indexPath ofType:(CPEventType) eventType andEventId:(NSNumber *)eventId;

//GetComments
- (void)getCommentsForReviewWithEventType:(CPEventType)eventType;

//Posting Rate & Review (plug)
-(void)postRateAndReview:(NSDictionary *)rateReviewDict;

-(void)postPrivateMessage:(NSDictionary *)rateReviewDict;

//Deleting Review
-(void)deleteReview:(NSIndexPath *)indexPath ofEventType:(CPEventType)eventType;

//get primary survey questions
- (void)getPriamrySurveyQuestions;
//get survey questions
- (void)getSurveyQuestions:(NSString *)surveyId;

//post survey responses
- (void)postSurveyResponses:(NSArray *)responseData andSurveyId:(NSString *)surveyId andPhysicianId:(NSString *)physicianId;

-(void)getAllProviderLocations;

-(void)getAllEventsDetails;

@end
