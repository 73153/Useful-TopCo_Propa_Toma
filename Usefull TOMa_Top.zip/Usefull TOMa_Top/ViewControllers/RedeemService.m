//
//  LocationController.m
//  LocationInfo
//
//  Created by Pankaj yadav on 24/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "RedeemService.h"
#import "Base64.h"
#import "AppDelegate.h"
@implementation RedeemService

@synthesize requestURL;
@synthesize auth_token;
@synthesize loc_id;
@synthesize review_id;
@synthesize user_id;
@synthesize broadCast_id;
@synthesize comment_id;
@synthesize specialId;
@synthesize sharingOutletIdArray;
@synthesize apiKey;
@synthesize coordinates;
@synthesize reviewRadius;
@synthesize privateMessageId;

-(id)initWithCaller:(id)caller
{
    if (self = [super init]) {
        caller_ = caller;
    }
    return  self;
}


#pragma mark CanRedeemSpecial
- (void)canRedeemSpecial {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPLocationSpecialsService *service = [[CPLocationSpecialsService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service canRedeemSpecialWithSpecialId:[NSNumber numberWithInteger:[specialId integerValue]]];
    TCEND
}
- (void) didFinishedCanRedeemSpecial:(NSNumber *)canRedeem {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(RedeemServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingCanRedeemSpecialResponse:)]) {
        [caller_ didFinishedGettingCanRedeemSpecialResponse:[canRedeem boolValue]];
    }
    TCEND
}

- (void) didFailCanRedeemSpecialWithError:(NSError *)error {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(RedeemServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailCanRedeemSpecialWithErrorMsg:)]) {
        [caller_ didFailCanRedeemSpecialWithErrorMsg:[error localizedDescription]];
    }
    TCEND
}

#pragma mark redeem special
- (void)redeemSpecial {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:requestURL];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPLocationSpecialsService *service = [[CPLocationSpecialsService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service redeemSpecialWithSpecialId:[NSNumber numberWithInteger:[specialId integerValue]]];
    TCEND
}

- (void) didFinishedRedeemSpecial:(NSNumber *)canRedeemAgain {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(RedeemServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedGettingRedeemSpecialResponse:)]) {
        [caller_ didFinishedGettingRedeemSpecialResponse:[canRedeemAgain boolValue]];
    }
    TCEND
}
- (void) didFailRedeemSpecialWithError:(NSError *)error {
    TCSTART
    if ([caller_ conformsToProtocol:@protocol(RedeemServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailRedeemSpecialWithErrorMsg:)]) {
        [caller_ didFailRedeemSpecialWithErrorMsg:[error localizedDescription]];
    }
    TCEND
}




@end
