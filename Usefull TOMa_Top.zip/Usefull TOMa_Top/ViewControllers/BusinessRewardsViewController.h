//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "RefreshView.h"
#import "RedeemSpecialViewController.h"
#import "RedeemCutomButton.h"

@interface BusinessRewardsViewController :UIViewController<UITableViewDelegate,UITableViewDataSource,NSFetchedResultsControllerDelegate>{
    
    UIButton *all_ranks_btn;
    UIButton *silver_rank_btn;
    UIButton *bronze_rank_btn;
    UIButton *gold_rank_btn;
    
    CGRect vcFrame;
    
    UITableView *rank_tableView;
    
    BOOL is_rank_silver_TabSlctd;
    BOOL is_rank_bronze_TabSlctd;
    BOOL is_rank_gold_TabSlctd;
    BOOL is_rank_all_TabSlctd;
    BOOL is_rank_response_Null;
    
    NSInteger rank_pagenumber;
    
    NSInteger rank_all_count;
    NSInteger rank_silver_count;
    NSInteger rank_bronze_count;
    NSInteger rank_gold_count;
   
    NSString *rankName;
    
    AppDelegate *appDelegate;
    
    NSFetchedResultsController *fetchedResultsController;
    
    //Table refresh
    RefreshView *refreshNotificationsView;
    BOOL checkForRefresh;
	BOOL reloading;
    BOOL isRequestIsInProgress;
    
    NSMutableArray *rewardsArray;
    UIImageView *selectedDetailBG_imageView;
}

@property(nonatomic, strong)    NSString *user_id;
@property(nonatomic, readwrite) NSInteger rank_all_count;
@property(nonatomic, readwrite) NSInteger rank_silver_count;
@property(nonatomic, readwrite) NSInteger rank_bronze_count;
@property(nonatomic, readwrite) NSInteger rank_gold_count;
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;

- (id)initWithFrame:(CGRect)frame;
- (void)setImageForTopMenuBtns;
- (void)reloadData;
- (void)finishedGetBusinessRewardsRequest:(NSDictionary *)response;
- (void)failedToGetBusinessRewards;

@end
