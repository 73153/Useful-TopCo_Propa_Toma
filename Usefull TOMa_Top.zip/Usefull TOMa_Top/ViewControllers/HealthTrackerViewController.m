//
//  HealthTrackerViewController.m
//  Baldwin
//
//  Created by Jagadeesh J on 18/11/14.
//
//

#import "HealthTrackerViewController.h"

@interface HealthTrackerViewController ()

@end

@implementation HealthTrackerViewController
@synthesize tabbarTitleLabel;
@synthesize backButton;
@synthesize customTabBar;
@synthesize fitBitButton;
@synthesize runKeeperButton;
@synthesize customTabImageView;
@synthesize dataDictionary;
@synthesize lineView;
@synthesize todayButton;
@synthesize past7dayButton;
@synthesize past30dayButton;
@synthesize rowDataArray;
@synthesize compareDataDictionary;
@synthesize compareRowDataArray;
@synthesize colourArray;
@synthesize graphRangeTypeCheck;
@synthesize graphModeType;
@synthesize refreshView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    @try {
        self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
        if (self) {
            
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        }
        // On iOS 4.0+ only, listen for foreground notification
        if(&UIApplicationWillEnterForegroundNotification != nil)
        {
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark - Today Button Action
- (IBAction)todayButtonAction:(id)sender {
    
    [todayButton setImage:[UIImage imageNamed:@"today_f"] forState:UIControlStateNormal];
    [past7dayButton setImage:[UIImage imageNamed:@"past7"] forState:UIControlStateNormal];
    [past30dayButton setImage:[UIImage imageNamed:@"past30"] forState:UIControlStateNormal];
    graphRangeTypeCheck=CPGraphRangeToday;
    [self callDateRangeWithData:CPGraphRangeToday withRefresh:YES];
}

#pragma mark - Past7Days Button Action
- (IBAction)past7dayButtonAction:(id)sender {
    [todayButton setImage:[UIImage imageNamed:@"today"] forState:UIControlStateNormal];
    [past7dayButton setImage:[UIImage imageNamed:@"past7_f"] forState:UIControlStateNormal];
    [past30dayButton setImage:[UIImage imageNamed:@"past30"] forState:UIControlStateNormal];
    graphRangeTypeCheck=CPGraphRangeWeek;
    [self callDateRangeWithData:CPGraphRangeWeek withRefresh:YES];
}

#pragma mark - Past30Days Button Action
- (IBAction)past30dayButtonAction:(id)sender {
    [todayButton setImage:[UIImage imageNamed:@"today"] forState:UIControlStateNormal];
    [past7dayButton setImage:[UIImage imageNamed:@"past7"] forState:UIControlStateNormal];
    [past30dayButton setImage:[UIImage imageNamed:@"past30_f"] forState:UIControlStateNormal];
    graphRangeTypeCheck=CPGraphRangeMonth;
    [self callDateRangeWithData:CPGraphRangeMonth withRefresh:YES];
}

- (void)viewDidLoad {
    TCSTART
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    // Do any additional setup after loading the view from its nib.
    self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
    tabbarTitleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    customTabImageView.layer.shadowRadius = 15.0f;
    customTabImageView.layer.shadowColor = [[UIColor blackColor]CGColor];
    customTabImageView.layer.shadowOpacity = 1.0f;
    dataDictionary=[[NSMutableDictionary alloc] init];
    compareDataDictionary=[[NSMutableDictionary alloc] init];
    colourArray=[[NSMutableArray alloc] initWithObjects:[UIColor blueColor],[UIColor yellowColor],[UIColor greenColor],[UIColor redColor], nil];
    if(isiPhone6) {
        [customTabBar setFrame:CGRectMake(0,customTabBar.frame.origin.y, appDelegate.window.frame.size.width, customTabBar.frame.size.height)];
        [customTabImageView setFrame:CGRectMake(0, customTabImageView.frame.origin.y, appDelegate.window.frame.size.width, customTabImageView.frame.size.height)];
        [runKeeperButton setFrame:CGRectMake(runKeeperButton.frame.origin.x+10,runKeeperButton.frame.origin.y, runKeeperButton.frame.size.width, runKeeperButton.frame.size.height)];
        [fitBitButton setFrame:CGRectMake(fitBitButton.frame.origin.x-10,fitBitButton.frame.origin.y, fitBitButton.frame.size.width, fitBitButton.frame.size.height)];
    }
    customTabBar.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin;
    CGFloat originX;
    CGFloat originY;
    if (iPad) {
        originX = -30;
        originY =todayButton.frame.origin.y+todayButton.frame.size.height+1;
    } else {
        originX = -4.5;
        originY =todayButton.frame.origin.y+todayButton.frame.size.height+1;
    }
    
    if (CURRENT_DEVICE_VERSION >= 7.0)
    {
        originX = 5;
        originY = todayButton.frame.origin.y+todayButton.frame.size.height+1;
    }
    
    if(isiPhone6) {
        float buttonWidth=(appDelegate.window.frame.size.width-4*5)/3;
        todayButton.frame=CGRectMake(todayButton.frame.origin.x, todayButton.frame.origin.y,buttonWidth, todayButton.frame.size.height);
        past7dayButton.frame=CGRectMake(todayButton.frame.origin.x+buttonWidth+5, todayButton.frame.origin.y,buttonWidth, todayButton.frame.size.height);
        past30dayButton.frame=CGRectMake(past7dayButton.frame.origin.x+buttonWidth+5, todayButton.frame.origin.y,buttonWidth, todayButton.frame.size.height);
    }

    fitnessGraphsTableView = [[UITableView alloc] initWithFrame:CGRectMake(originX, originY, appDelegate.window.frame.size.width-2*originX, self.view.frame.size.height - originY - customTabBar.frame.size.height) style:UITableViewStyleGrouped];
    fitnessGraphsTableView.delegate = self;
    fitnessGraphsTableView.dataSource = self;
    fitnessGraphsTableView.showsVerticalScrollIndicator = YES;
    fitnessGraphsTableView.backgroundView = nil;
    fitnessGraphsTableView.backgroundColor = [UIColor clearColor];
    fitnessGraphsTableView.tag=9;
    
    //SetThe RunKeeperMode As Default
    isFitBitCheckStatus=NO;
    isTableContentOffset=NO;
    graphModeType=CPGraphRunkeeper;
    graphRangeTypeCheck=CPGraphRangeToday;
    [runKeeperButton setEnabled:NO];
    [fitBitButton setEnabled:YES];
    [self callDateRangeWithData:CPGraphRangeToday withRefresh:YES];
    
    refreshView = [[RefreshView alloc] initWithFrame:
                   CGRectMake(self.view.frame.origin.x,-fitnessGraphsTableView.bounds.size.height,
                              self.view.frame.size.width, fitnessGraphsTableView.bounds.size.height)];
    [fitnessGraphsTableView addSubview:refreshView];
    userSignUpWebView=[[UIWebView alloc] init];
    userSignUpWebView.frame=fitnessGraphsTableView.frame;
    [self.view addSubview:userSignUpWebView];
    userSignUpWebView.scalesPageToFit = YES;
    userSignUpWebView.delegate = self;
    //[webView setBackgroundColor:[UIColor whiteColor]];
    [self.view bringSubviewToFront:userSignUpWebView];
    [userSignUpWebView setHidden:YES];
    NSArray * fitbitLabelArray = [NSArray arrayWithObjects:@"Steps",@"Floors",@"Distance (mi)",@"Calories Burned", nil];
    NSArray * runkeeperLabelArray = [NSArray arrayWithObjects:@"Distance (mi)",@"Calories Consumed",@"Calories Burned",@"Minutes Active", nil];
    dynamicFitbitGoalData=[[CPFitbitDailyGoals alloc] init];
    dynamicRunkeeprGoalData=[[CPRunkeeperDailyGoals alloc] init];
    updateGoalTextLabelDictionary = [[NSMutableDictionary alloc]init];
    userAccount=[[NSNumber alloc] init];
    [updateGoalTextLabelDictionary  setObject:fitbitLabelArray forKey:@"fitbitLabelArray"];
    [updateGoalTextLabelDictionary setObject:runkeeperLabelArray forKey:@"runkeeperLabelArray"];
    CGFloat xOriginDiff=10;
    if (CURRENT_DEVICE_VERSION < 7.0) {
        fitnessGraphsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        userSignUpWebView.frame=CGRectMake(fitnessGraphsTableView.frame.origin.x+xOriginDiff,fitnessGraphsTableView.frame.origin.y , fitnessGraphsTableView.frame.size.width-2*xOriginDiff,fitnessGraphsTableView.frame.size.height);
    } else {
        fitnessGraphsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    TCEND
}

-(void)viewWillAppear:(BOOL)animated {
    TCSTART
    [todayButton setImage:[UIImage imageNamed:@"today_f"] forState:UIControlStateNormal];
    [past7dayButton setImage:[UIImage imageNamed:@"past7"] forState:UIControlStateNormal];
    [past30dayButton setImage:[UIImage imageNamed:@"past30"] forState:UIControlStateNormal];
    [customTabImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"fitbitTab1"]]];
    TCEND
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    //NSLog(@"app Enters Foregroung Called.");
    if(!userSignUpWebView.isHidden)
    [self callDateRangeWithData:graphRangeTypeCheck withRefresh:YES];
}

-(void)callDateRangeWithData:(CPGraphDateRange)rangeValue withRefresh:(BOOL)refreshCheck {
    if(refreshCheck) {
         [appDelegate showActivityIndicatorInView:self.view];
    }
    [appDelegate showNetworkIndicator];
    NSDateFormatter *dateformate=[[NSDateFormatter alloc]init];
    [dateformate setDateFormat:@"yyyy.MM.dd"]; // Date formater
    NSString *today = [dateformate stringFromDate:[NSDate date]];
    NSDateComponents* deltaComps = [[NSDateComponents alloc] init];
    if(rangeValue == CPGraphRangeToday) {
        [deltaComps setDay:1];
        NSDate *tomorrow = [[NSCalendar currentCalendar] dateByAddingComponents:deltaComps toDate:[NSDate date] options:0];
        [appDelegate getHealthTrackerDataWithCaller:self withStartDate:today withEndDate:[dateformate stringFromDate:tomorrow] withGraphMode:graphModeType];
    }
    else if(rangeValue == CPGraphRangeWeek) {
        [deltaComps setDay:-7];
        NSDate *lastweek = [[NSCalendar currentCalendar] dateByAddingComponents:deltaComps toDate:[NSDate date] options:0];
        [appDelegate getHealthTrackerDataWithCaller:self withStartDate:[dateformate stringFromDate:lastweek] withEndDate:today withGraphMode:graphModeType];
        
    }
    else if(rangeValue == CPGraphRangeMonth) {
        [deltaComps setDay:-30];
        NSDate *lastmonth = [[NSCalendar currentCalendar] dateByAddingComponents:deltaComps toDate:[NSDate date] options:0];
        [appDelegate getHealthTrackerDataWithCaller:self withStartDate:[dateformate stringFromDate:lastmonth] withEndDate:today withGraphMode:graphModeType];
    }

}

#pragma mark - HealthTracker Delegate Methods
- (void) didReceiveFitbitGraphData:(NSDictionary*)userFitbitData
{
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [dataDictionary removeAllObjects];
    [rowDataArray removeAllObjects];
    [compareDataDictionary removeAllObjects];
    [compareRowDataArray removeAllObjects];
    NSLog(@"Success");
    if([userFitbitData objectForKey:@"message"]) {
        [userSignUpWebView setHidden:NO];
        [fitnessGraphsTableView setHidden:YES];
        NSString *urlString=[NSString stringWithFormat:@"%@/fitbit/oauth/link?basic_layout=1&auth_token=%@",APP_URL,appDelegate.userProfileDataModel.authToken];
        NSMutableURLRequest *requestM = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
        //[userSignUpWebView stringByEvaluatingJavaScriptFromString:@"document. body.style.zoom = 2.0;"];
        [self removeCookies];
        [userSignUpWebView loadRequest:requestM];
        userSignUpWebView.opaque = NO;
        userSignUpWebView.backgroundColor = [UIColor clearColor];
    }
    else {
        [userSignUpWebView setHidden:YES];
        [fitnessGraphsTableView setHidden:NO];
        CPFitbitGraphTotals *totalData=[userFitbitData objectForKey:@"totals"];
        NSNumber *numberOfDays=totalData.dayCount;
        if([numberOfDays intValue] > 0)
        {
        
//        if(graphRangeTypeCheck == CPGraphRangeToday) numberOfDays= [NSNumber numberWithInt:1];
//        else if(graphRangeTypeCheck == CPGraphRangeWeek) numberOfDays= [NSNumber numberWithInt:7];
//        else if(graphRangeTypeCheck == CPGraphRangeMonth) numberOfDays= [NSNumber numberWithInt:30];
        NSLog(@"TotalSteps:%@",totalData.steps);
        CPFitbitDailyGoals *goalData=[userFitbitData objectForKey:@"goals"];
        dynamicFitbitGoalData=goalData;
        NSLog(@"GoalSteps:%@",goalData.steps);
        CPFitbitComparisons *compData=[userFitbitData objectForKey:@"comparisons"];
        NSLog(@"DailySteps:%@",compData.yourSteps);
        if([userFitbitData objectForKey:@"account_id"])
        userAccount=[userFitbitData objectForKey:@"account_id"];
        else
        userAccount=nil;
    
        //dataDictionary=(NSMutableDictionary*)userFitbitData;
        rowDataArray=[[NSMutableArray alloc] initWithObjects:@"Steps",@"Floors",@"Miles",@"Calories", nil];
        compareRowDataArray=[[NSMutableArray alloc] initWithObjects:@"Steps",@"Floors", nil];
        
        NSMutableDictionary *stepDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.steps,@"Goal",@([totalData.steps floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:stepDict forKey:@"Steps"];
        
        NSMutableDictionary *floorDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.floors,@"Goal",@([totalData.floors floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:floorDict forKey:@"Floors"];
        
        NSMutableDictionary *activeMinuteDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.distance,@"Goal",@([totalData.distance floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:activeMinuteDict forKey:@"Miles"];
        
        NSMutableDictionary *calorieDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.calories,@"Goal",@([totalData.calories floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:calorieDict forKey:@"Calories"];
        
        //Set Compare Data
        NSMutableDictionary *stepCompareDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:compData.yourSteps,@"your",compData.ageGroupSteps,@"ageGroup", compData.everyOneSteps,@"everyOne",nil];
        [compareDataDictionary setObject:stepCompareDict forKey:@"Steps"];
        
        NSMutableDictionary *floorCompareDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:compData.yourFloors,@"your",compData.ageGroupFloors,@"ageGroup", compData.everyOneFloors,@"everyOne",nil];
        [compareDataDictionary setObject:floorCompareDict forKey:@"Floors"];
        
        if(![self.view viewWithTag:9])
            [self.view addSubview:fitnessGraphsTableView];
        else{
            [fitnessGraphsTableView reloadData];
            [fitnessGraphsTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
        }
        }
        else {
            [fitnessGraphsTableView reloadData];
            [appDelegate showErrorMsg:@"Invalid json."];
        }
    }
    [self dataSourceDidFinishLoadingNewData];
    TCEND
}

-(void)didReceiveRunkeeperGraphData:(NSDictionary *)userRunkeeperData {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [dataDictionary removeAllObjects];
    [rowDataArray removeAllObjects];
    [compareDataDictionary removeAllObjects];
    [compareRowDataArray removeAllObjects];
    NSLog(@"RunKeeper-Success");
    if([userRunkeeperData objectForKey:@"message"]) {
        [userSignUpWebView setHidden:NO];
        [fitnessGraphsTableView setHidden:YES];
        NSString *urlString=[NSString stringWithFormat:@"%@/runkeeper/oauth/link?basic_layout=1&auth_token=%@",APP_URL,appDelegate.userProfileDataModel.authToken];
        NSMutableURLRequest *requestM = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
        [self removeCookies];
        [userSignUpWebView loadRequest:requestM];
        userSignUpWebView.opaque = NO;
        userSignUpWebView.backgroundColor = [UIColor clearColor];
    }
    else {
        
        [userSignUpWebView setHidden:YES];
        [fitnessGraphsTableView setHidden:NO];
        CPRunkeeperGraphTotals *totalData=[userRunkeeperData objectForKey:@"totals"];
        NSNumber *numberOfDays=totalData.dayCount;
        if([numberOfDays intValue] > 0)
        {
//        if(graphRangeTypeCheck == CPGraphRangeToday) numberOfDays= [NSNumber numberWithInt:1];
//        else if(graphRangeTypeCheck == CPGraphRangeWeek) numberOfDays= [NSNumber numberWithInt:7];
//        else if(graphRangeTypeCheck == CPGraphRangeMonth) numberOfDays= [NSNumber numberWithInt:30];
        
        NSLog(@"TotalSteps:%@",totalData.caloriesBurned);
        CPRunkeeperDailyGoals *goalData=[userRunkeeperData objectForKey:@"goals"];
        NSLog(@"GoalSteps:%@",goalData.caloriesBurned);
        dynamicRunkeeprGoalData=goalData;
        CPRunkeeperComparisons *compData=[userRunkeeperData objectForKey:@"comparisons"];
        NSLog(@"DailySteps:%@",compData.yourCaloriesBurned);
        if([userRunkeeperData objectForKey:@"account_id"])
        userAccount=[userRunkeeperData objectForKey:@"account_id"];
        else
        userAccount=nil;
        
        //dataDictionary=(NSMutableDictionary*)userFitbitData;
        rowDataArray=[[NSMutableArray alloc] initWithObjects:@"Miles",@"Calories Consumed",@"Calories Burned",@"Minutes Active",nil];
        compareRowDataArray=[[NSMutableArray alloc] initWithObjects:@"Calories Consumed",@"Calories Burned", nil];
        
        NSMutableDictionary *activeMinuteDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.distance,@"Goal",@([totalData.distance floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:activeMinuteDict forKey:@"Miles"];
        
        NSMutableDictionary *stepDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.caloriesConsumed,@"Goal",@([totalData.caloriesConsumed floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:stepDict forKey:@"Calories Consumed"];
        
        NSMutableDictionary *floorDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.caloriesBurned,@"Goal",@([totalData.caloriesBurned floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:floorDict forKey:@"Calories Burned"];
        
        NSMutableDictionary *activeMinutesDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:goalData.activeMinutes,@"Goal",@([totalData.activeMinutes floatValue]/[numberOfDays floatValue]),@"Achieved", nil];
        [dataDictionary setObject:activeMinutesDict forKey:@"Minutes Active"];
        
        
        //Set Compare Data
        NSMutableDictionary *stepCompareDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:compData.yourCaloriesConsumed,@"your",compData.ageGroupCaloriesConsumed,@"ageGroup", compData.everyOneCaloriesConsumed,@"everyOne",nil];
        [compareDataDictionary setObject:stepCompareDict forKey:@"Calories Consumed"];
        
        NSMutableDictionary *floorCompareDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:compData.yourCaloriesBurned,@"your",compData.ageGroupCaloriesBurned,@"ageGroup", compData.everyOneCaloriesBurned,@"everyOne",nil];
        [compareDataDictionary setObject:floorCompareDict forKey:@"Calories Burned"];
        
        if(![self.view viewWithTag:9])
            [self.view addSubview:fitnessGraphsTableView];
        else{
            [fitnessGraphsTableView reloadData];
            [fitnessGraphsTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
        }
    }
    else {
        [fitnessGraphsTableView reloadData];
        [appDelegate showErrorMsg:@"Invalid json."];
        }
    }
    [self dataSourceDidFinishLoadingNewData];
    TCEND
    
}
- (void) didFailToReceiveGraphDataWithError:(NSError*) error
{
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [self dataSourceDidFinishLoadingNewData];
    [appDelegate showErrorMsg:[error localizedDescription]];
}

#pragma mark - Tableview Delegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if(rowDataArray.count > 0)
    return 3;
    else
    return 0;
}

- (void) removeCookies {
    //[requestM setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    //[requestM setHTTPShouldHandleCookies: NO];
    NSHTTPCookie *cookie;
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (cookie in [storage cookies])
    {
        [storage deleteCookie:cookie];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == 0)
    return [dataDictionary count];
    else  if(section == 1){
    return [compareDataDictionary count];
    }
    else if (section == 2) {
        return [dataDictionary count]+1;
    }
    else {
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    if(section == 0) {
        return 1.0;
    }
    else  if(section == 1 || section == 2){
        if(iPad) {
            return 90;
        } else {
            return 65;
        }
    }
    else {
     return 0;   
    }
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        UIView *headerView;
        headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0.0, 0.0, 0.0)];
        if(section == 0) {
         headerView.backgroundColor = [UIColor clearColor];
        }
        else if(section == 1 || section == 2) {
            
            UIImage *headerImg;
            if(section == 1) {
                headerImg = [UIImage imageNamed:@"compare_title"];
            }
            else {
                headerImg = [UIImage imageNamed:@"goals_title"];
            }
            headerView.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width,iPad?55:30);
            headerView.backgroundColor = [UIColor clearColor];
            
            CGRect headerImgViewRect;
            if (CURRENT_DEVICE_VERSION < 7.0) {
                if (iPad) {
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 460)/2, 20, 500, 55);
                } else {
                    headerImgViewRect = CGRectMake((appDelegate.window.frame.size.width - 297)/2, 10, 297, 30);
                }
            } else {
                if (iPad) {
                    headerImgViewRect = CGRectMake((748 - 500)/2, 20, 500, 55);
                } else {
                    headerImgViewRect = CGRectMake((310 - 297)/2, 10, appDelegate.window.frame.size.width-33, 30);
                }
            }
            
            //        if (section != 3) {
            UIImageView *headerImgView = [[UIImageView alloc]initWithFrame:headerImgViewRect];
            headerImgView.image = headerImg;
            
            [headerView addSubview:headerImgView];
            
            headerImgView = nil;
        }
        
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0) {

            if (iPad) {
                return 105+2;
            } else {
                return 85;
            }

    }
    else if(indexPath.section == 1) {
        if (iPad) {
            return 165;
        } else {
            return 140;
        }
    } else if (indexPath.section == 2){
        if (indexPath.row == [dataDictionary count])
            return iPad?100:60;
        else
        return (iPad?70:50);
    }
    else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if(indexPath.section == 0 || indexPath.section == 1) {
        UITableViewCell *cell = nil;
        NSString *cellIdentifier;
        if(indexPath.section == 0)
            cellIdentifier = @"fitbitGraphCell";
        else if(indexPath.section == 1)
            cellIdentifier = @"runKeeperGraphCell";
        
        UILabel *detailsLabel = nil;
        UILabel *goalLabel = nil;
        UIView *graphView=nil;
        JXBarChartView *barChartView=nil;
        CGFloat diff;
        CGFloat nameOriginY;
        if (iPad) {
            diff = 10;
            nameOriginY = 2;
        } else {
            diff = 5;
            nameOriginY = 5;
        }
        
        
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] ;
            
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                //            [appDelegate addBackgroundViewToTheCell:cell];
            }
            
            //if(isFitBitCheckStatus)
            if(indexPath.section == 0)
            {
                detailsLabel = [[UILabel alloc]initWithFrame:CGRectMake(diff,diff,CELL_CONTENT_WIDTH*0.6,25)];
                detailsLabel.backgroundColor = [UIColor clearColor];
                detailsLabel.font = [UIFont fontWithName:titleFontName size:cellTitleFontSize];
                [detailsLabel setTag:1];
                detailsLabel.textColor = [UIColor lightGrayColor];
                detailsLabel.textAlignment =NSTextAlignmentLeft;
                detailsLabel.backgroundColor=[UIColor clearColor];
                detailsLabel.adjustsFontSizeToFitWidth = YES;
                [cell.contentView addSubview:detailsLabel];
                
                goalLabel = [[UILabel alloc]initWithFrame:CGRectMake(diff+detailsLabel.frame.size.width,diff,CELL_CONTENT_WIDTH*0.4,25)];
                goalLabel.backgroundColor = [UIColor clearColor];
                goalLabel.font = [UIFont fontWithName:titleFontName size:cellTitleFontSize];
                [goalLabel setTag:2];
                goalLabel.textColor = [UIColor lightGrayColor];
                goalLabel.textAlignment =NSTextAlignmentRight;
                goalLabel.backgroundColor=[UIColor clearColor];
                goalLabel.adjustsFontSizeToFitWidth = YES;
                [cell.contentView addSubview:goalLabel];
                NSDictionary *graphDict=[dataDictionary objectForKey:[rowDataArray objectAtIndex:indexPath.row]];
                float goalPoint=[(NSNumber*)[graphDict objectForKey:@"Goal"] floatValue];
                float achievedPoint=[(NSNumber*)[graphDict objectForKey:@"Achieved"] floatValue];
                float achievedPercentage;
                if(goalPoint == 0 && achievedPoint == 0) achievedPercentage=0;
                else if (goalPoint == 0 && achievedPoint > 0) achievedPercentage=100;
                else achievedPercentage= round((achievedPoint/goalPoint)*100);

                    NSString *descSubString=@"Avg ";
                    if(graphRangeTypeCheck==CPGraphRangeToday)descSubString=@"";
                    if ([[graphDict objectForKey:@"Achieved"] floatValue] == (int)[[graphDict objectForKey:@"Achieved"] floatValue]) {
                        detailsLabel.text=[NSString stringWithFormat:@"%@%@: %@",descSubString,[rowDataArray objectAtIndex:indexPath.row],[self getFormatedDecimalStringOfNumber:[graphDict objectForKey:@"Achieved"]]];
                    }
                    else {
                        if([[rowDataArray objectAtIndex:indexPath.row] isEqualToString:@"Miles"]){
                            NSString *numberString = [self getDecimalStringOfNumber:[graphDict objectForKey:@"Achieved"]];
                            detailsLabel.text=[NSString stringWithFormat:@"%@%@: %.01f",descSubString,[rowDataArray objectAtIndex:indexPath.row],[numberString floatValue]];
                        }
                        else {
                            detailsLabel.text=[NSString stringWithFormat:@"%@%@: %@",descSubString,[rowDataArray objectAtIndex:indexPath.row],[self getFormatedDecimalStringOfNumber:[NSNumber numberWithFloat:round([[graphDict objectForKey:@"Achieved"] floatValue])]]];
                        }
                    }
                
                if ([[graphDict objectForKey:@"Goal"] floatValue] == (int)[[graphDict objectForKey:@"Goal"] floatValue]) {
                    goalLabel.text=[NSString stringWithFormat:@"%.f%% of %@ Goal",achievedPercentage,[self getFormatedDecimalStringOfNumber:[graphDict objectForKey:@"Goal"]]];
                }
                else {
                    if([[rowDataArray objectAtIndex:indexPath.row] isEqualToString:@"Miles"]) {
                        NSString *numberString = [self getDecimalStringOfNumber:[graphDict objectForKey:@"Goal"] ];
                        goalLabel.text=[NSString stringWithFormat:@"%.f%% of %.01f Goal",achievedPercentage,[numberString floatValue]];
                    }
                    else {
                    goalLabel.text=[NSString stringWithFormat:@"%.f%% of %@ Goal",achievedPercentage,[self getFormatedDecimalStringOfNumber:[NSNumber numberWithFloat:round([[graphDict objectForKey:@"Goal"] floatValue])]]];
                    }
                }
                
                graphView=[self getCustomProgressiveViewWithGoalPoint:goalPoint withAcheivedPoint:achievedPoint withColor:[colourArray objectAtIndex:indexPath.row]];
                [graphView setFrame:CGRectMake(diff, goalLabel.frame.origin.y+25+2*diff, graphView.frame.size.width, graphView.frame.size.height)];
                [graphView setTag:3];
                [graphView setBackgroundColor:[UIColor clearColor]];
                [cell.contentView addSubview:graphView];
            }
            else if(indexPath.section == 1) {
                detailsLabel = [[UILabel alloc]initWithFrame:CGRectMake(diff,diff,CELL_CONTENT_WIDTH-2*diff,25)];
                detailsLabel.backgroundColor = [UIColor clearColor];
                detailsLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
                [detailsLabel setTag:1];
                detailsLabel.textColor = [UIColor lightGrayColor];
                detailsLabel.textAlignment =NSTextAlignmentCenter;
                detailsLabel.backgroundColor=[UIColor clearColor];
                [cell.contentView addSubview:detailsLabel];
                NSMutableArray *textIndicators = [[NSMutableArray alloc] initWithObjects:@"You", @"Your Age Group", @"All Others", nil];
                NSMutableArray *colorArray=[[NSMutableArray alloc] initWithObjects:[UIColor greenColor],[UIColor grayColor],[UIColor lightGrayColor], nil];
                NSDictionary *tempCompareDataDict=[compareDataDictionary objectForKey:[compareRowDataArray objectAtIndex:indexPath.row]];
                NSMutableArray *values = [[NSMutableArray alloc] initWithObjects:[tempCompareDataDict objectForKey:@"your"],[tempCompareDataDict objectForKey:@"ageGroup"],[tempCompareDataDict objectForKey:@"everyOne"], nil];
                float maxGraphRange=[self getMaxNumber:[NSArray arrayWithObjects:[tempCompareDataDict objectForKey:@"your"],[tempCompareDataDict objectForKey:@"ageGroup"],[tempCompareDataDict objectForKey:@"everyOne"], nil]];
                CGRect frame = CGRectMake(diff, detailsLabel.frame.size.height+2*diff, appDelegate.window.frame.size.width, iPad?120:100);
                barChartView = [[JXBarChartView alloc] initWithFrame:frame
                                                          startPoint:CGPointMake(0, 0)
                                                              values:values maxValue:(iPad?1.5:(isiPhone6?1.7:1.8))*maxGraphRange
                                                      textIndicators:textIndicators
                                                           textColor:[UIColor whiteColor]
                                                           barHeight:iPad?32:28
                                                         barMaxWidth:appDelegate.window.frame.size.width
                                                            gradient:nil barColorArray:colorArray];
                [barChartView setTag:4];
                [cell.contentView addSubview:barChartView];
                detailsLabel.text=[compareRowDataArray objectAtIndex:indexPath.row];
                
            }
            CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
            if(CURRENT_DEVICE_VERSION >= 7.0) {
                UIView *separateLineView=[[UIView alloc] init];
                separateLineView.tag=5;
                [separateLineView setFrame:CGRectMake(0, aHeight-1.0,appDelegate.window.frame.size.width, 1.0)];
                [separateLineView setBackgroundColor:[UIColor darkTextColor]];
                [cell.contentView addSubview:separateLineView];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor clearColor];
        }
        
        if (!detailsLabel)
            detailsLabel = (UILabel*)[cell.contentView viewWithTag:1];
        if (!goalLabel)
            goalLabel = (UILabel*)[cell.contentView viewWithTag:2];
        
        if(indexPath.section == 0) {
            if (!graphView){
                graphView = (UIView*)[cell.contentView viewWithTag:3];
                [[cell viewWithTag:3] removeFromSuperview];
                NSDictionary *graphDict=[dataDictionary objectForKey:[rowDataArray objectAtIndex:indexPath.row]];
                float goalPoint=[(NSNumber*)[graphDict objectForKey:@"Goal"] floatValue];
                float achievedPoint=[(NSNumber*)[graphDict objectForKey:@"Achieved"] floatValue];
                float achievedPercentage;
                if(goalPoint == 0 && achievedPoint == 0) achievedPercentage=0;
                else if (goalPoint == 0 && achievedPoint > 0) achievedPercentage=100;
                else achievedPercentage=round((achievedPoint/goalPoint)*100);

                
                NSString *descSubString=@"Avg ";
                if(graphRangeTypeCheck==CPGraphRangeToday)descSubString=@"";
                if ([[graphDict objectForKey:@"Achieved"] floatValue] == (int)[[graphDict objectForKey:@"Achieved"] floatValue]) {
                    detailsLabel.text=[NSString stringWithFormat:@"%@%@: %@",descSubString,[rowDataArray objectAtIndex:indexPath.row],[self getFormatedDecimalStringOfNumber:[graphDict objectForKey:@"Achieved"]]];
                }
                else {
                    if([[rowDataArray objectAtIndex:indexPath.row] isEqualToString:@"Miles"]){
                        NSString *numberString = [self getDecimalStringOfNumber:[graphDict objectForKey:@"Achieved"]];
                        //NSNumber *myNnumber=[NSNumber numberWithFloat:[numberString floatValue]];
                        detailsLabel.text=[NSString stringWithFormat:@"%@%@: %.01f",descSubString,[rowDataArray objectAtIndex:indexPath.row],[numberString floatValue]];
                    }
                    else {
                        detailsLabel.text=[NSString stringWithFormat:@"%@%@: %@",descSubString,[rowDataArray objectAtIndex:indexPath.row],[self getFormatedDecimalStringOfNumber:[NSNumber numberWithFloat:round([[graphDict objectForKey:@"Achieved"] floatValue])]]];
                    }
                }
                
                if ([[graphDict objectForKey:@"Goal"] floatValue] == (int)[[graphDict objectForKey:@"Goal"] floatValue]) {
                    goalLabel.text=[NSString stringWithFormat:@"%.f%% of %@ Goal",achievedPercentage,[self getFormatedDecimalStringOfNumber:[graphDict objectForKey:@"Goal"]]];
                }
                else {
                    if([[rowDataArray objectAtIndex:indexPath.row] isEqualToString:@"Miles"]) {
                        NSString *numberString = [self getDecimalStringOfNumber:[graphDict objectForKey:@"Goal"] ];
                        goalLabel.text=[NSString stringWithFormat:@"%.f%% of %.01f Goal",achievedPercentage,[numberString floatValue]];
                    }
                    else {
                        goalLabel.text=[NSString stringWithFormat:@"%.f%% of %@ Goal",achievedPercentage,[self getFormatedDecimalStringOfNumber:[NSNumber numberWithFloat:round([[graphDict objectForKey:@"Goal"] floatValue])]]];
                    }
                }
                
                graphView=[self getCustomProgressiveViewWithGoalPoint:goalPoint withAcheivedPoint:achievedPoint withColor:[colourArray objectAtIndex:indexPath.row]];
                [graphView setFrame:CGRectMake(diff, goalLabel.frame.origin.y+25+2*diff, graphView.frame.size.width, graphView.frame.size.height)];
                [graphView setTag:3];
                [graphView setBackgroundColor:[UIColor clearColor]];
                [cell.contentView addSubview:graphView];
            }
            
        }
        else if(indexPath.section == 1) {
            if(!barChartView) {
                barChartView=(JXBarChartView*)[cell.contentView viewWithTag:4];
                [[cell viewWithTag:4] removeFromSuperview];
                NSMutableArray *textIndicators = [[NSMutableArray alloc] initWithObjects:@"You", @"Your Age Group", @"All Others", nil];
                NSMutableArray *colorArray=[[NSMutableArray alloc] initWithObjects:[UIColor greenColor],[UIColor grayColor],[UIColor lightGrayColor], nil];
                NSDictionary *tempCompareDataDict=[compareDataDictionary objectForKey:[compareRowDataArray objectAtIndex:indexPath.row]];
                NSMutableArray *values = [[NSMutableArray alloc] initWithObjects:[tempCompareDataDict objectForKey:@"your"],[tempCompareDataDict objectForKey:@"ageGroup"],[tempCompareDataDict objectForKey:@"everyOne"], nil];
                float maxGraphRange=[self getMaxNumber:[NSArray arrayWithObjects:[tempCompareDataDict objectForKey:@"your"],[tempCompareDataDict objectForKey:@"ageGroup"],[tempCompareDataDict objectForKey:@"everyOne"], nil]];
                CGRect frame = CGRectMake(diff, detailsLabel.frame.size.height+2*diff, appDelegate.window.frame.size.width, iPad?120:100);
                barChartView = [[JXBarChartView alloc] initWithFrame:frame
                                                          startPoint:CGPointMake(0, 0)
                                                              values:values maxValue:(iPad?1.5:(isiPhone6?1.7:1.9))*maxGraphRange
                                                      textIndicators:textIndicators
                                                           textColor:[UIColor whiteColor]
                                                           barHeight:iPad?32:28
                                                         barMaxWidth:appDelegate.window.frame.size.width
                                                            gradient:nil barColorArray:colorArray];
                [barChartView setTag:4];
                [cell.contentView addSubview:barChartView];
                detailsLabel.text=[compareRowDataArray objectAtIndex:indexPath.row];
                
            }
        }
        
        return cell;
    }
    else if (indexPath.section == 2) {
        if (indexPath.row == [dataDictionary count]) {
            CGFloat xOriginDiff =0;
            if (CURRENT_DEVICE_VERSION>=7.0) {
                xOriginDiff=0;
            }
            else {
                xOriginDiff=-10;
            }
            NSString *CellIdentifier = @"SaveGoalCellIdentifier";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            CGRect cellRect = [fitnessGraphsTableView rectForRowAtIndexPath:indexPath];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    //[appDelegate addBackgroundViewToTheCell:cell];
                }
                float buttonHeight=iPad?60:45;
                float buttonWidth=cellRect.size.width-(iPad?350:(isiPhone6?100:60));
                UIButton *rewardButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [rewardButton setBackgroundImage:[UIImage imageNamed:@"saveGoals"] forState:UIControlStateNormal];
                rewardButton.layer.cornerRadius = 5.0f;
                rewardButton.layer.masksToBounds = YES;
                rewardButton.frame = CGRectMake((cellRect.size.width-buttonWidth)/2+xOriginDiff,(cellRect.size.height-buttonHeight)/2, buttonWidth, buttonHeight);
                rewardButton.backgroundColor = [UIColor clearColor];
                [rewardButton addTarget:self action:@selector(saveGoalsAction:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:rewardButton];
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell1:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?70:50) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
                [cell setBackgroundColor:[UIColor clearColor]];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
        else
        {
        //initialize the GoalTextfieldCell to have the left side label and right side textfield
                NSString *CellIdentifier = [NSString stringWithFormat:@"cell%d%d",indexPath.section,indexPath.row];
                GoalTableViewCell *cell = (GoalTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                
                if (cell == nil) {
                    cell = [[GoalTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                        [appDelegate addBackgroundViewToTheCell:cell];
                    }
                }
            [self configureCell:cell atIndexPath:indexPath];
            NSDictionary *graphDict=[dataDictionary objectForKey:[rowDataArray objectAtIndex:indexPath.row]];
            
            if ([[graphDict objectForKey:@"Goal"] floatValue] == (int)[[graphDict objectForKey:@"Goal"] floatValue]) {
                cell.rightTextField.text=[(NSNumber*)[graphDict objectForKey:@"Goal"] stringValue];
            }
            else {
                if([[rowDataArray objectAtIndex:indexPath.row] isEqualToString:@"Miles"]) {
                    NSString *numberString = [self getDecimalStringOfNumber:[graphDict objectForKey:@"Goal"]];
                    cell.rightTextField.text=[NSString stringWithFormat:@"%.01f",[numberString floatValue]];
                }
                else {
                cell.rightTextField.text=[[NSNumber numberWithFloat:round([[graphDict objectForKey:@"Goal"] floatValue])] stringValue];
                }
            }
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell1:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?70:50) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
            if([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                UIView *sectionHeaderview;
                UIView *backgroundImgView;
                UILabel *lineLabel;
                if (!sectionHeaderview) {
                    sectionHeaderview = (UIView *)[cell viewWithTag:-1000];
                }
                if (!backgroundImgView) {
                    backgroundImgView = (UIImageView *)[sectionHeaderview viewWithTag:-2000];
                    backgroundImgView.frame=CGRectMake(0, backgroundImgView.frame.origin.y, backgroundImgView.frame.size.width, backgroundImgView.frame.size.height);
                }
                if (!lineLabel) {
                    lineLabel = (UILabel *)[sectionHeaderview viewWithTag:-19999];
                    lineLabel.frame=CGRectMake(0, lineLabel.frame.origin.y, lineLabel.frame.size.width, lineLabel.frame.size.height);
                }
            }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    }

    TCEND
}

-(float)getMaxNumber:(NSArray*)aArray {
    float xmax=0.0;
    for (NSNumber *num in aArray) {
        float x = num.floatValue;
        if (x > xmax) xmax = x;
    }
    if(xmax == 0) xmax=1;
    return xmax;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    NSLog(@"Graph Row Clicked:%d",indexPath.row);
    TCEND
}

-(NSString*)getDecimalStringOfNumber:(NSNumber*)number {
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterNoStyle];
    [formatter setMaximumFractionDigits:1];
    //[formatter setRoundingMode: NSNumberFormatterRoundFloor];
    NSString *numberString = [formatter stringFromNumber:number];
    return numberString;
}

-(NSString*)getFormatedDecimalStringOfNumber:(NSNumber*)number {
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [formatter setMaximumFractionDigits:0];
    NSString *numberString = [formatter stringFromNumber:number];
    return numberString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Custom Progressive Graph
-(UIView *)getCustomProgressiveViewWithGoalPoint:(float)goalPoint withAcheivedPoint:(float)acheivedPoint withColor:(UIColor*)aColor {
    TCSTART
    //Custom Progressinve Bar
    UIView *customProgressiveView=[[UIView alloc] initWithFrame:CGRectZero];
    float goalPointWidth=22;
    float progressiveBarHeight= iPad?30:26;
    [customProgressiveView setFrame:CGRectMake(10, 10, self.view.frame.size.width-(iPad?30:20), progressiveBarHeight)];
    float acutualBarWidth=customProgressiveView.frame.size.width-goalPointWidth;
    
    UIView *achievedView=[[UIView alloc] initWithFrame:CGRectZero];
    UIView *remainingView=[[UIView alloc] initWithFrame:CGRectZero];
    UIView *goalPointView=[[UIView alloc] initWithFrame:CGRectZero];
    [customProgressiveView setBackgroundColor:[UIColor clearColor]];
    [achievedView setBackgroundColor:aColor];
    [goalPointView setBackgroundColor:aColor];
    if(iPad)
        customProgressiveView.layer.cornerRadius = 15;
    else
        customProgressiveView.layer.cornerRadius = 13;
        
    customProgressiveView.layer.masksToBounds = YES;
    float acheivedViewLenght=0;
    if(goalPoint == 0) {
        UIColor *colorOption=[UIColor blackColor];
        if(acheivedPoint > 0) {
            colorOption=aColor;
        }
        [achievedView setBackgroundColor:colorOption];
        [goalPointView setBackgroundColor:colorOption];
        acheivedViewLenght = (acutualBarWidth);
        [achievedView setFrame:CGRectMake(0, 0, acheivedViewLenght, progressiveBarHeight)];
        [customProgressiveView addSubview:achievedView];
        [remainingView setFrame:CGRectMake(achievedView.frame.size.width, 0,acutualBarWidth+achievedView.frame.size.width, progressiveBarHeight)];
        [customProgressiveView addSubview:remainingView];
        [goalPointView setFrame:CGRectMake(acutualBarWidth, 0, goalPointWidth, progressiveBarHeight)];
        [customProgressiveView addSubview:goalPointView];
        [remainingView setBackgroundColor:colorOption];
        if(acheivedPoint == goalPoint) {
            UIView *lineview=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, progressiveBarHeight)];
            [lineview setBackgroundColor:colorOption];
            [goalPointView addSubview:lineview];
        }
    }
    else if(acheivedPoint <= goalPoint) {
        acheivedViewLenght = (acutualBarWidth)*(acheivedPoint/goalPoint);
        [achievedView setFrame:CGRectMake(0, 0, acheivedViewLenght, progressiveBarHeight)];
        [customProgressiveView addSubview:achievedView];
        [remainingView setFrame:CGRectMake(achievedView.frame.size.width, 0,acutualBarWidth+achievedView.frame.size.width, progressiveBarHeight)];
        [customProgressiveView addSubview:remainingView];
        [goalPointView setFrame:CGRectMake(acutualBarWidth, 0, goalPointWidth, progressiveBarHeight)];
        [customProgressiveView addSubview:goalPointView];
        [remainingView setBackgroundColor:[UIColor blackColor]];
        if(acheivedPoint == goalPoint) {
            UIView *lineview=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, progressiveBarHeight)];
            [lineview setBackgroundColor:[UIColor blackColor]];
            [goalPointView addSubview:lineview];
        }
        UILabel *goalPointLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, goalPointWidth, progressiveBarHeight)];
        goalPointLabel.text = @"G";
        [goalPointLabel setTextAlignment:NSTextAlignmentCenter];
        [goalPointLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:11]];
        [goalPointLabel setBackgroundColor:[UIColor clearColor]];
        [goalPointView addSubview:goalPointLabel];
    }
    else {
        acheivedViewLenght = (acutualBarWidth)*(goalPoint/acheivedPoint);
        [achievedView setFrame:CGRectMake(0, 0, acheivedViewLenght, progressiveBarHeight)];
        [customProgressiveView addSubview:achievedView];
        [goalPointView setFrame:CGRectMake(achievedView.frame.size.width, 0,goalPointWidth, progressiveBarHeight)];
        UIView *lineview=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, progressiveBarHeight)];
        [lineview setBackgroundColor:[UIColor blackColor]];
        UIView *lineview2=[[UIView alloc] initWithFrame:CGRectMake(21, 0, 1, progressiveBarHeight)];
        [lineview2 setBackgroundColor:[UIColor blackColor]];
        [goalPointView addSubview:lineview];
        [goalPointView addSubview:lineview2];
        [customProgressiveView addSubview:goalPointView];
        [remainingView setFrame:CGRectMake(goalPointView.frame.origin.x+goalPointView.frame.size.width, 0,customProgressiveView.frame.size.width-(goalPointView.frame.origin.x+goalPointView.frame.size.width), progressiveBarHeight)];
        [remainingView setBackgroundColor:aColor];
        [customProgressiveView addSubview:remainingView];
        UILabel *goalPointLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, goalPointWidth, progressiveBarHeight)];
        goalPointLabel.text = @"G";
        [goalPointLabel setTextAlignment:NSTextAlignmentCenter];
        [goalPointLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:11]];
        [goalPointLabel setBackgroundColor:[UIColor clearColor]];
        [goalPointView addSubview:goalPointLabel];
    }
    return customProgressiveView;
    TCEND
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)popTheViewController:(id)sender {
    TCSTART
    [self.navigationController popViewControllerAnimated:YES];
    TCEND
}

#pragma mark - Fitbit Tab Button Action
- (IBAction)fitBitButtonAction:(id)sender {
    TCSTART
    NSLog(@"FitBit Button Clicked.");
    [runKeeperButton setEnabled:YES];
    [fitBitButton setEnabled:NO];
    [userSignUpWebView setHidden:YES];
    tabbarTitleLabel.text=@"FITBIT";
    tabbarTitleLabel.textColor=[UIColor whiteColor];
    tabbarTitleLabel.textAlignment=NSTextAlignmentCenter;
    [customTabImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"fitbitTab2"]]];
    if(graphModeType != CPGraphFitbit) {
        graphModeType=CPGraphFitbit;
        isFitBitCheckStatus=YES;
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:YES];
        //[fitnessGraphsTableView reloadData];
    }
    TCEND
}

#pragma mark - Runkeeper Tab Button Action
- (IBAction)runKeeperButtonAction:(id)sender {
    TCSTART
    NSLog(@"RunKeeper Button Clicked");
    [runKeeperButton setEnabled:NO];
    [fitBitButton setEnabled:YES];
    [userSignUpWebView setHidden:YES];
    tabbarTitleLabel.text=@"RUNKEEPER";
    tabbarTitleLabel.textColor=[UIColor whiteColor];
    tabbarTitleLabel.textAlignment=NSTextAlignmentCenter;
    [customTabImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"fitbitTab1"]]];
    if(graphModeType != CPGraphRunkeeper) {
        graphModeType=CPGraphRunkeeper;
        isFitBitCheckStatus=NO;
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:YES];
        //[fitnessGraphsTableView reloadData];
    }
    TCEND
}

-(void)saveGoalsAction:(id)sender {
    NSLog(@"In Save Goals Action.");

        [appDelegate showNetworkIndicator];
        if(graphModeType == CPGraphFitbit) {
            if([self isNotNull:userAccount]) {
                [appDelegate updateFitbitGoalsDataWithCaller:self withNewGoalsInformation:dynamicFitbitGoalData withAccountId:userAccount];
            }
            else
                [appDelegate showErrorMsg:@"No Fitbit Account found."];
        }
        else if(graphModeType == CPGraphRunkeeper) {
            if([self isNotNull:userAccount]) {
                [appDelegate updateRunkeeprGoalsDataWithCaller:self withNewGoalsInformation:dynamicRunkeeprGoalData withAccountId:userAccount];
            }
            else
                [appDelegate showErrorMsg:@"No Runkeeper Account found."];
        }
}

- (BOOL) validateTheString:(NSString*)string {
    if ( [string rangeOfCharacterFromSet: [ [NSCharacterSet characterSetWithCharactersInString:@"0123456789.,"] invertedSet] ].location == NSNotFound)
    {
        // newString consists only of the digits 0 through 9
        return YES;
    }
    else {
        return NO;
    }
}

-(BOOL)validateGoals{
    
    BOOL validationStatus=YES;
    if(graphModeType == CPGraphFitbit) {
        if(validationStatus)
            validationStatus=[self validateTheString:[dynamicFitbitGoalData.steps stringValue]];
         if(validationStatus)
             validationStatus=[self validateTheString:[dynamicFitbitGoalData.floors stringValue]];
         if(validationStatus)
             validationStatus=[self validateTheString:[dynamicFitbitGoalData.distance stringValue]];
         if(validationStatus)
             validationStatus=[self validateTheString:[dynamicFitbitGoalData.calories stringValue]];
    }
    else if(graphModeType == CPGraphRunkeeper) {
        if(validationStatus)
            validationStatus=[self validateTheString:[dynamicRunkeeprGoalData.distance stringValue]];
        if(validationStatus)
            validationStatus=[self validateTheString:[dynamicRunkeeprGoalData.caloriesConsumed stringValue]];
        if(validationStatus)
            validationStatus=[self validateTheString:[dynamicRunkeeprGoalData.caloriesBurned stringValue]];
        if(validationStatus)
            validationStatus=[self validateTheString:[dynamicRunkeeprGoalData.activeMinutes stringValue]];
    }
    return validationStatus;
}

#pragma mark - Goal Updation Delegate Methods

- (void) didUpdateUserGoalsData:(NSDictionary*)updatedData {
    TCSTART
    if([self isNotNull:updatedData]) {
        [appDelegate showSuccessMsg:@"Your goals have been updated successfully."];
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:NO];
    }
    else {
        [appDelegate showErrorMsg:@"Your goals have been updated successfully."];
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:NO];
    }
    
    TCEND
}

- (void) didFailToUpdateUserGoalsDataWithError:(NSError*) error {
    TCSTART
    [appDelegate hideNetworkIndicator];
    //[appDelegate removeNetworkIndicatorInView:self.view];
    //[self dataSourceDidFinishLoadingNewData];
    [appDelegate showErrorMsg:[error localizedDescription]];
    TCEND
}


#pragma mark TableScrollView Delegate Methods
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // NSLog(@"scrollViewWillBeginDragging");
    if (!reloading)
    {
        checkForRefresh = YES;  //  only check offset when dragging
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    @try {
        // NSLog(@"scrollViewDidScroll");
        if (reloading) return;
        
        if (checkForRefresh) {
            if (refreshView.isFlipped && scrollView.contentOffset.y > -45.0f && scrollView.contentOffset.y < 0.0f && !reloading) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kPullToReloadStatus];
                
            } else if (!refreshView.isFlipped && scrollView.contentOffset.y < -45.0f) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kReleaseToReloadStatus];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Load images for all onscreen rows when scrolling is finished
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    @try {
        if (reloading) return;
        
        if (scrollView.contentOffset.y <= -45.0f) {
            [self showReloadAnimationAnimated:YES];
            [self netWorkCallForViewRefresh];
        }
        checkForRefresh = NO;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
}

- (void) showReloadAnimationAnimated:(BOOL)animated {
    @try {
        reloading = YES;
        [refreshView toggleActivityView:YES];
        
        if (animated) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            fitnessGraphsTableView.contentInset = UIEdgeInsetsMake(40.0f, 0.0f, 0.0f,
                                                                  0.0f);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)dataSourceDidFinishLoadingNewData {
    @try {
        reloading = NO;
        [refreshView flipImageAnimated:NO];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        [fitnessGraphsTableView setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
        [refreshView setStatus:kPullToReloadStatus];
        [refreshView toggleActivityView:NO];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)netWorkCallForViewRefresh {
    @try {
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:NO];
//        if ([requestType rangeOfString:@"health" options:NSCaseInsensitiveSearch].location != NSNotFound) {
//            [self getMessagesOfTypeForRefresh:CPMessageTypeReferences isRequestForRefresh:YES];
//            [communityButton setEnabled:NO];
//        } else {
//            [self getMessagesOfTypeForRefresh:CPMessageTypeNews isRequestForRefresh:YES];
//            [healthButton setEnabled:NO];
//        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma mark WebView Delegate Methods
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *URLString = [[request URL] absoluteString];
    NSLog(@"URL Changed to:%@",URLString);
    if ([URLString rangeOfString:@"past-30-days"].location != NSNotFound) {
        // The user reached step 3!
        [userSignUpWebView setHidden:YES];
        [self callDateRangeWithData:graphRangeTypeCheck withRefresh:YES];
    }
    return YES;
}
-(void)webViewDidStartLoad:(UIWebView *)webView_ {
    
    @try {
        if (!isNetworkIndicator) {
            isNetworkIndicator = YES;
            [appDelegate showNetworkIndicator];
            [appDelegate showActivityIndicatorInView:webView_];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webViewDidFinishLoad:(UIWebView *)webView_ {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)webView:(UIWebView *)webView_ didFailLoadWithError:(NSError *)error {
    
    @try {
        isNetworkIndicator = NO;
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:webView_];
        if (error.code == NSURLErrorCancelled){
            return;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark -
#pragma mark Table view data source
- (void)configureCell:(GoalTableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    @try {
        if(indexPath.section == 2) {
            
        if(graphModeType == CPGraphFitbit)
            cell.leftLabel.text = [[updateGoalTextLabelDictionary objectForKey:@"fitbitLabelArray"] objectAtIndex:indexPath.row];
        else {
            cell.leftLabel.text = [[updateGoalTextLabelDictionary objectForKey:@"runkeeperLabelArray"] objectAtIndex:indexPath.row];
             }
            [cell.rightTextField setReturnKeyType:UIReturnKeyDone];
            cell.rightTextField.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
            cell.indexPath = indexPath;
            cell.delegate = self;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor clearColor];
                }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark GoalCellDelegate Methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

-(void)textFielddidBeginEditingWithField:(UITextField *)_textField andIndexPath:(NSIndexPath *)_indexPath {
    TCSTART
    tableOffset=CGPointMake(0, fitnessGraphsTableView.contentSize.height-fitnessGraphsTableView.frame.size.height);
    
    if(!isTableContentOffset){
        CGPoint origin = _textField.frame.origin;
        CGPoint point = [_textField.superview convertPoint:origin toView:fitnessGraphsTableView];
        NSLog(@"%f:%f:%f:%f",fitnessGraphsTableView.contentSize.height,fitnessGraphsTableView.frame.size.height,point.y,(point.y - fitnessGraphsTableView.contentOffset.y) - 20);
        isTableContentOffset=YES;
        cellTextFieldRef = _textField;
        CGPoint offset = fitnessGraphsTableView.contentOffset;
        //offset.y += iPad?350:(isiPhone6?250:100);
        offset.y = fitnessGraphsTableView.contentOffset.y+(point.y - fitnessGraphsTableView.contentOffset.y);
        [fitnessGraphsTableView setContentOffset:offset animated:YES];
    }
    TCEND
}

- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    @try {
        isTableContentOffset=NO;
        if(indexPath.section == 0)
        {
            [cellTextFieldRef resignFirstResponder];
        }
        if (indexPath.section == 2 && indexPath.row == 0) {
            [[(GoalTableViewCell*)[fitnessGraphsTableView cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
        }
        
        if (indexPath.section == 2 && indexPath.row == 1) {
            [[(GoalTableViewCell*)[fitnessGraphsTableView cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
            
        }
        
        if (indexPath.section == 2 && indexPath.row == 2) {
            [[(GoalTableViewCell*)[fitnessGraphsTableView cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
            
        }
        if (indexPath.section == 2 && indexPath.row == 3) {
            [[(GoalTableViewCell*)[fitnessGraphsTableView cellForRowAtIndexPath:indexPath] rightTextField] resignFirstResponder];
            
        }
        [fitnessGraphsTableView setContentOffset:tableOffset animated:YES];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateTextLabelAtIndexPath:(NSIndexPath*)indexPath string:(NSString*)string {
    
    @try {
        NSLog(@"UpdatedString:%@",string);
        
        if([self validateTheString:string]){
        if(graphModeType == CPGraphFitbit ) {
            //NSArray * fitbitLabelArray = [NSArray arrayWithObjects:@"Steps",@"Floors",@"Distance (mi)",@"Calories Burned", nil];
            if(indexPath.section == 2) {
                if(indexPath.row == 0) {
                    dynamicFitbitGoalData.steps = [NSNumber numberWithFloat: [string floatValue]];
                }  else if(indexPath.row == 1) {
                    dynamicFitbitGoalData.floors = [NSNumber numberWithFloat: [string floatValue]];
                } else if (indexPath.row == 2) {
                    dynamicFitbitGoalData.distance = [NSNumber numberWithFloat: [string floatValue]];
                } else if (indexPath.row == 3) {
                    dynamicFitbitGoalData.calories = [NSNumber numberWithFloat: [string floatValue]];
                }
            }
            
        }
        else if(graphModeType == CPGraphRunkeeper) {
         //NSArray * runkeeperLabelArray = [NSArray arrayWithObjects:@"Distance (mi)",@"Calories Consumed",@"Calories Burned", nil];
            if(indexPath.section == 2) {
                if(indexPath.row == 0) {
                    dynamicRunkeeprGoalData.distance = [NSNumber numberWithFloat: [string floatValue]];
                }  else if(indexPath.row == 1) {
                    dynamicRunkeeprGoalData.caloriesConsumed =[NSNumber numberWithFloat: [string floatValue]];
                } else if (indexPath.row == 2) {
                    dynamicRunkeeprGoalData.caloriesBurned = [NSNumber numberWithFloat: [string floatValue]];
                } else if (indexPath.row == 3) {
                    dynamicRunkeeprGoalData.activeMinutes = [NSNumber numberWithFloat: [string floatValue]];
                }
            }
        }
        }
        else {
            [appDelegate showErrorMsg:@"Invalid input data"];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}



//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

@end
