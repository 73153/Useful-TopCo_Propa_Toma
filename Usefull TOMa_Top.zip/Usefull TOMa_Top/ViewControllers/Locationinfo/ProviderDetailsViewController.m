//
//  RedeemSpecialViewController.m
//  ChatterPlug
//
//  Created by shiva on 3/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ProviderDetailsViewController.h"
//#import "UIImageView+WebCache.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "AppDelegate.h"

@implementation ProviderDetailsViewController
@synthesize locationDataModal;

- (id)initWithPhysician:(CPPhysician *)physicianEvent
{
    if (self = [super init]) {
        physician = physicianEvent;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    //TabBar is hidden when it was pushed with the API "hidesBottombarWhenPushed", and also we need to hide the images and labels that we created to get the given design look and feel.
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame=appDelegate.window.frame;
        NSLog(@"SelfFrame:%f",self.view.frame.size.height);
        
        UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
        image.image = [UIImage imageNamed:@"bg"];
        [self.view addSubview:image];
        //        self.view.backgroundColor = [UIColor clearColor];
        
        UILabel *titleLabel;
        if (iPad) {
            titleLabel = [[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 400)/2,13 ,400,45)];
        } else {
            titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, appDelegate.window.frame.size.width, 30)];
        }
        
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        titleLabel.text = @"PROVIDER PROFILE";
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = [UIColor whiteColor];
        [self.view addSubview:titleLabel];
        
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        if (iPad) {
            backButton.frame = CGRectMake(5,10, 84, 48);
        } else {
            backButton.frame = CGRectMake(5, 7, 59, 32);
        }
        [backButton setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        backButton.layer.cornerRadius = 5.0;
        [backButton addTarget:self action:@selector(goToMainPage:) forControlEvents:UIControlEventTouchUpInside];
        [backButton setEnabled:TRUE];
        
        UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
        line_ImgView.image = [UIImage imageNamed:@"line"];
        [self.view addSubview:line_ImgView];
        
        [self.view addSubview:backButton];
        
        UIView *headerView = [self returnHeaderViewForPhysician];
        headerView.frame = CGRectMake(headerView.frame.origin.x, line_ImgView.frame.origin.y + line_ImgView.frame.size.height, headerView.frame.size.width, headerView.frame.size.height);
        [self.view addSubview:headerView];
        
        CGFloat tableOriginX;
        if (iPad) {
            tableOriginX = -30;
        } else {
            tableOriginX = -2.5;
        }
        if (CURRENT_DEVICE_VERSION >= 7.0) {
            tableOriginX = 5;
        }
        providerDetailsTable = [[UITableView alloc]initWithFrame:CGRectMake(tableOriginX, headerView.frame.origin.y+headerView.frame.size.height, self.view.frame.size.width + (-2 * tableOriginX), self.view.frame.size.height - (headerView.frame.origin.y+headerView.frame.size.height)) style:UITableViewStyleGrouped];
        providerDetailsTable.delegate = self;
        providerDetailsTable.dataSource = self;
        providerDetailsTable.backgroundView = nil;
        providerDetailsTable.backgroundColor = [UIColor clearColor];
        providerDetailsTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        providerDetailsTable.separatorColor = [UIColor clearColor];
        [self.view addSubview:providerDetailsTable];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (UIView *)returnHeaderViewForPhysician {
    @try {
        NSLog(@"PhysicianBlock");
        UIView *tableHeaderView;
        UIImageView *businessLogo_imageView = nil;
        UILabel *businessName_Lbl = nil;
        UILabel *businessAddress_Lbl = nil;
        UIButton *businessPhoneNumb_Btn = nil;
        UIImageView *phoneIcon = nil;
        UIImageView *addressIcon = nil;
        UILabel *phoneNumberLabel = nil;
        
        
        CGFloat headerHeight;
        CGFloat diff;
        CGFloat businessNameHGT;
        
        if (iPad) {
            diff = 10;
            businessNameHGT = 30;
        }else if (isiPhone6PLUS)
        {
            diff = 5;
            businessNameHGT = 25;
        }
        else {
            diff = 5;
            businessNameHGT = 20;
        }
        
        CGSize addrSize = CGSizeMake(0.0f, 0.0f);
        if ([self isNotNull:locationDataModal.loc_Address]) {    //business address
            NSString *addrStr = [NSString stringWithFormat:@"%@, %@, %@",locationDataModal.loc_Address?:@"",locationDataModal.located_City?:@"",locationDataModal.loc_State?:@""];
            addrSize = [addrStr sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:locationAddressSize] constrainedToSize:CGSizeMake(self.view.frame.size.width - (diff + REVIEWER_IMAGE_WIDTH + 20 + diff + (iPad?30:18) + (diff * 2)), 40) lineBreakMode:NSLineBreakByWordWrapping];
        }
        
        headerHeight = businessNameHGT + addrSize.height + businessNameHGT + diff * 2;
        
        if (!tableHeaderView) {
            tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
            tableHeaderView.layer.cornerRadius = 10.0f;
            tableHeaderView.backgroundColor = [UIColor clearColor];
            
            //sectionBG_image
            businessLogo_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(diff, 0, isiPhone6PLUS?(REVIEWER_IMAGE_WIDTH + 30):(REVIEWER_IMAGE_WIDTH + 20),isiPhone6PLUS?(REVIEWER_IMAGE_HEIGHT + 30):(REVIEWER_IMAGE_HEIGHT + 20))];
            businessLogo_imageView.layer.cornerRadius = 5.0f;
            businessLogo_imageView.layer.masksToBounds = YES;
            businessLogo_imageView.tag = 1;
            [tableHeaderView addSubview:businessLogo_imageView];
            
            //show the Business Name.
            businessName_Lbl = [[UILabel alloc]init];
            [businessName_Lbl setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff + diff - 5, -2, tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + (3 * diff) + 5), businessNameHGT)];
            businessName_Lbl.tag = 2;
            businessName_Lbl.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:locationNameSize];
            businessName_Lbl.backgroundColor = [UIColor clearColor];
            businessName_Lbl.textColor = [UIColor whiteColor];
            [tableHeaderView addSubview:businessName_Lbl];
            
            addressIcon = [[UIImageView alloc]init];
            if (iPad) {
                addressIcon.frame =  CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff + ((addrSize.height - 30)/2), 25, 30);
            } else {
                addressIcon.frame = CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff + ((addrSize.height - 17.5)/2), 12.5, 17.5);
            }
            addressIcon.tag = 7;
            [tableHeaderView addSubview:addressIcon];
            
            //show the business Address.
            businessAddress_Lbl = [[UILabel alloc]init];
            [businessAddress_Lbl setFrame:CGRectMake(addressIcon.frame.origin.x + addressIcon.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff, addrSize.width, addrSize.height)];
            
            businessAddress_Lbl.tag = 3;
            businessAddress_Lbl.numberOfLines = 0;
            businessAddress_Lbl.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:locationAddressSize];
            businessAddress_Lbl.backgroundColor = [UIColor clearColor];
            businessAddress_Lbl.textColor = [UIColor grayColor];
            [tableHeaderView addSubview:businessAddress_Lbl];
            
            //shwot the business Phone Number
            //phone Image
            phoneIcon = [[UIImageView alloc]init];
            phoneIcon.tag = 5;
            if (iPad) {
                phoneIcon.frame =  CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff,25,30);
            } else {
                phoneIcon.frame = CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff,12.5,17.5);
            }
            [tableHeaderView addSubview:phoneIcon];
            
            businessPhoneNumb_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [businessPhoneNumb_Btn setFrame:CGRectMake(phoneIcon.frame.origin.x + phoneIcon.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff, tableHeaderView.frame.size.width - (phoneIcon.frame.origin.x + phoneIcon.frame.size.width + (2 * diff) + 20 ), businessNameHGT)];
            businessPhoneNumb_Btn.tag = 4;
            businessPhoneNumb_Btn.backgroundColor = [UIColor clearColor];
            [businessPhoneNumb_Btn addTarget:self action:@selector(openPhoneApp:) forControlEvents:UIControlEventTouchUpInside];
            [tableHeaderView addSubview:businessPhoneNumb_Btn];
            
            //shwot the business Address.
            phoneNumberLabel = [[UILabel alloc]init];
            [phoneNumberLabel setFrame:businessPhoneNumb_Btn.frame];
            phoneNumberLabel.tag = 6;
            phoneNumberLabel.numberOfLines = 0;
            phoneNumberLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:locationAddressSize];
            phoneNumberLabel.backgroundColor = [UIColor clearColor];
            phoneNumberLabel.textColor = [UIColor grayColor];
            [tableHeaderView addSubview:phoneNumberLabel];
            
        }
        if (!businessLogo_imageView)
            businessLogo_imageView = (UIImageView *)[tableHeaderView viewWithTag:1];
        if (!businessName_Lbl)
            businessName_Lbl = (UILabel *)[tableHeaderView viewWithTag:2];
        if (!businessAddress_Lbl)
            businessAddress_Lbl = (UILabel *)[tableHeaderView viewWithTag:3];
        if (!businessPhoneNumb_Btn)
            businessPhoneNumb_Btn = (UIButton *)[tableHeaderView viewWithTag:4];
        if (!phoneIcon)
            phoneIcon = (UIImageView *)[tableHeaderView viewWithTag:5];
        if (!phoneNumberLabel)
            phoneNumberLabel = (UILabel *)[tableHeaderView viewWithTag:6];
        if (!addressIcon)
            addressIcon = (UIImageView *)[tableHeaderView viewWithTag:7];
        
        
        tableHeaderView.frame = CGRectMake(0, 0, self.view.frame.size.width, headerHeight);
        //check for null and is class dictionary and url null or not if not null download or just display the defualt img
        if ([self isNotNull:physician]) {
            
            if ([self isNotNull:physician.physicianAvatarUrl] && [[physician.physicianAvatarUrl absoluteString] rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                NSString *thumbUrl = [appDelegate getavatarThumbURL:[physician.physicianAvatarUrl absoluteString]];
                [businessLogo_imageView setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-provider"]];
                //                [businessLogo_imageView setImageWithURL:physician.physicianAvatarUrl placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
            } else
            {
                businessLogo_imageView.image = [UIImage imageNamed:@"default-avatar-provider"];
            }
            if ([self isNotNull:physician.physicianName])       //business name
                businessName_Lbl.text = physician.physicianName;
            if ([self isNotNull:locationDataModal.loc_Address]) {    //business address
                businessAddress_Lbl.text = [NSString stringWithFormat:@"%@, %@, %@",locationDataModal.loc_Address?:@"",locationDataModal.located_City?:@"",locationDataModal.loc_State?:@""];
                addressIcon.image = [UIImage imageNamed:@"locationinfoarrow"];
            } else {
                businessAddress_Lbl.text = @"";
                addressIcon.hidden = YES;
            }
            if ([self isNotNull:locationDataModal.PhoneNo]) {      //business phone number
                
                NSString *formatedPhoneNumber = [appDelegate formatPhoneNumber:locationDataModal.PhoneNo];
                if ([self isNotNull:formatedPhoneNumber]) {
                    phoneNumberLabel.text = formatedPhoneNumber;
                    phoneIcon.image = [UIImage imageNamed:@"locationinfo_phone"];
                } else {
                    [phoneNumberLabel setText:@""];
                    phoneIcon.hidden = YES;
                }
            }
        }
        return tableHeaderView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)openPhoneApp:(id)sender {
    TCSTART
    if ([self isNotNull:locationDataModal.PhoneNo]) {
        UIAlertView *phoneCallAlertView = [[UIAlertView alloc]initWithTitle:@"Call" message:[NSString stringWithFormat:@"Do you want to call %@ at %@", locationDataModal.loc_Name?:@"",locationDataModal.PhoneNo] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Call", nil];
        [phoneCallAlertView show];
    }
    TCEND
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        //        NSLog(@"Call");
        [appDelegate openPhoneApp:locationDataModal.PhoneNo];
    }
}

-(void)goToMainPage:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
   	return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [self getSizeAtIndexPath:indexPath].height;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    if (iPad) {
        return 65.0;
    } else {
        return 40.0;
    }
    
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        
        UIView *headerView = [[UIView alloc] init];
        headerView.backgroundColor = [UIColor clearColor];
        
        UIImage *headerImg;
        if (section == 0) {
            headerImg = [UIImage imageNamed:@"speciality_title"];
        } else {
            headerImg = [UIImage imageNamed:@"moreinformation_title"];
        }
        
        CGRect imgViewRect;
        CGFloat headerViewHeight;
        
        if (iPad) {
            
            imgViewRect = CGRectMake(((CURRENT_DEVICE_VERSION < 7.0) ? 158 : (745 - 500)/2), 5, 500, 55);
            headerViewHeight = 65;
        } else {
            imgViewRect = CGRectMake(((CURRENT_DEVICE_VERSION < 7.0) ? 14 : ((appDelegate.window.frame.size.width-10) - 297)/2), 5, 297, 30);
            headerViewHeight = 40;
        }
        
        headerView.frame = CGRectMake(0, 0.0, HEADER_WIDTH, headerViewHeight);
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:imgViewRect];
        imageView.image = headerImg;
        [headerView addSubview:imageView];
        
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        UITableViewCell *cell = nil;
        NSString *cellIdentifier = @"providerCell";
        UILabel *textLabel = nil;
        
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] ;
            
            textLabel = [[UILabel alloc]init];
            textLabel.backgroundColor = [UIColor clearColor];
            textLabel.numberOfLines = 0;
            textLabel.lineBreakMode = NSLineBreakByWordWrapping;
            textLabel.textAlignment = NSTextAlignmentCenter;
            [textLabel setTag:2];
            [cell.contentView addSubview:textLabel];
        }
        
        if (!textLabel)
            textLabel = (UILabel*)[cell viewWithTag:2];
        
        if (indexPath.section == 0) {
            textLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
            textLabel.textColor = [UIColor whiteColor];
            //            textLabel.textAlignment = UITextAlignmentCenter;
            NSString *specilitiesStr = [self getSpecilitiesStr];
            
            textLabel.text = specilitiesStr;
        } else {
            textLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
            textLabel.textColor = [UIColor lightGrayColor];
            //            textLabel.textAlignment = UITextAlignmentLeft;
            textLabel.text = physician.physicianBio;
        }
        
        CGSize lableSize = [self getSizeAtIndexPath:indexPath];
        textLabel.frame = CGRectMake((iPad?10:5), 0, (iPad?718:(appDelegate.window.frame.size.width-25)), lableSize.height);
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (NSMutableString *)getSpecilitiesStr {
    TCSTART
    NSMutableString *specilitiesStr = [[NSMutableString alloc] init];
    for (int i = 0; i < physician.physicianSpecialities.count ; i++) {
        //        if (i == (physician.physicianSpecialities.count - 1)) {
        //            [specilitiesStr appendString:[NSString stringWithFormat:@"%@",[physician.physicianSpecialities objectAtIndex:i]]];
        //        } else {
        [specilitiesStr appendString:[NSString stringWithFormat:@"%@\r",[physician.physicianSpecialities objectAtIndex:i]]];
        //}
    }
    return specilitiesStr;
    TCEND
}
- (CGSize)getSizeAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    CGFloat width;
    if (iPad) {
        width = 718;
    } else {
        width = 295;
    }
    if (indexPath.section == 0) {
        NSString *string = [self getSpecilitiesStr];
        CGSize specilitiesSize = [string sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize] constrainedToSize:CGSizeMake(width, 1200) lineBreakMode:NSLineBreakByWordWrapping];
        return specilitiesSize;
    } else {
        CGSize descriptionSize = [isiPhone6PLUS?[physician.physicianBio stringByReplacingOccurrencesOfString:@"\r\n\r\n" withString:@"\r\n"]:physician.physicianBio sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize] constrainedToSize:CGSizeMake(width, 1200) lineBreakMode:NSLineBreakByWordWrapping];
        return descriptionSize;
    }
    TCEND
}
- (void)viewWillDisappear:(BOOL)animated {
    
}
@end
