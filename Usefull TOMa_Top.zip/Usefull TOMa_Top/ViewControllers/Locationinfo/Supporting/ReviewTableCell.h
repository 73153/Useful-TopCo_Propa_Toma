//
//  ReviewTableCell.h
//  LocationInfo
//
//  Created by shiva on 2/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationInfoViewController.h"
#import "AppDelegate.h"

@interface ReviewTableCell : UITableViewCell{
    AppDelegate *appDelegate;
    UIImage *rateImage;
    UIButton *btnLikeCount;
    UILabel *lineLabel;
}

@property (nonatomic, strong)UIButton *btnLikeCount;
@property (nonatomic, strong) UILabel *lineLabel;
@property(nonatomic,strong)NSString *reviewerName_str;
@property (nonatomic,strong)UIImageView *locationImgview;
@property (nonatomic, strong)UIImageView *lockImage;
@property(nonatomic,strong)NSString *reviewText_str;
@property(nonatomic,strong)NSString *reviewerAvatarUrl_str;
@property(nonatomic,strong)NSString *reviewer_Default_AvatarUrl_str;
@property(nonatomic,strong)NSString *photoUrl_str;
@property(nonatomic,strong)NSString *likeCount_str;
@property(nonatomic,strong)NSString *commentCount_str;
@property(nonatomic,strong)NSString *time_str;
@property (nonatomic, strong) NSData *photo_Data;
@property(nonatomic,strong) id <LocationMainViewDelegate>locationDelegate_;
@property(nonatomic,readwrite) CGFloat reviewerNameHeight_float;
@property(nonatomic,readwrite) CGFloat reviewTextHeight_float;
@property(nonatomic,readwrite) CGFloat photoheight_float; //photo is user uploaded picture while giving plug.
@property(nonatomic,readwrite) CGFloat rateImageViewHieght_float;
@property(nonatomic,strong) UIImage *rateImage;
@property (nonatomic, strong) UIImage *postedImage;

@property(nonatomic,readwrite) BOOL hideCommentButton;
@property (nonatomic, readwrite) BOOL isPrivatePlug;
-(void)addSubviewToTableCell:(id)caller;
-(void)setData;

@end
