//
//  CustomButton.h
//  TestApp
//
//  Created by Aruna on 01/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <UIKit/UIKit.h>
 
@interface CustomButton : UIButton {
    NSMutableDictionary *questionDict;
    int questionIndex;
}
@property (nonatomic, strong) NSMutableDictionary *questionDict;
@property (nonatomic, readwrite) int questionIndex;
@end
