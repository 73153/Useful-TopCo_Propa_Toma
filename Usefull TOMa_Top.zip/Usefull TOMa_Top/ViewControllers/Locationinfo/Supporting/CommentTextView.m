//
//  GCPlaceholderTextView.m
//  GCLibrary
//
//  Created by Guillaume Campagna on 10-11-16.
//  Copyright 2010 LittleKiwi. All rights reserved.
//

#import "CommentTextView.h"

@interface CommentTextView () 

@property (nonatomic, retain) UIColor* realTextColor;
@property (nonatomic, readonly) NSString* realText;

- (void) beginEditing:(NSNotification*) notification;
- (void) endEditing:(NSNotification*) notification;

@end

@implementation CommentTextView

@synthesize realTextColor;
@synthesize placeholder;

#pragma mark -
#pragma mark Initialisation

- (id) initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self awakeFromNib];
    }
    return self;
}

- (void)awakeFromNib {
    @try {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(beginEditing:) name:UITextViewTextDidBeginEditingNotification object:self];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(endEditing:) name:UITextViewTextDidEndEditingNotification object:self];
        
        self.realTextColor = [UIColor lightGrayColor];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark -
#pragma mark Setter/Getters

- (void) setPlaceholder:(NSString *)aPlaceholder {
    
    @try {
        if ([self.realText isEqualToString:placeholder]) {
            self.text = aPlaceholder;
        }
        
        placeholder = nil;
        placeholder = aPlaceholder;
        
        [self endEditing:nil];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (NSString *) text {
    @try {
        NSString* text = [super text];
        if ([text isEqualToString:self.placeholder]) return nil;
        return text;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) setText:(NSString *)text {
    
    @try {
        if ([text isEqualToString:@""] || text == nil) {
            super.text = self.placeholder;
        }
        else {
            super.text = text;
        }
        
        if ([text isEqualToString:self.placeholder]) {
            self.textColor = [UIColor lightGrayColor];
        }
        else {
            self.textColor = self.realTextColor;
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (NSString *) realText {
    return [super text];
}

- (void) beginEditing:(NSNotification*) notification {
    @try {
        if ([self.realText isEqualToString:self.placeholder]) {
            super.text = nil;
            self.textColor = self.realTextColor;
        }
    }
    @catch (NSException *exception) {
          NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)endEditing:(NSNotification*) notification {
    @try {
        if ([self.realText isEqualToString:@""] || self.realText == nil) {
            super.text = self.placeholder;
            self.textColor = [UIColor lightGrayColor];
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) setTextColor:(UIColor *)textColor {
    @try {
        if ([self.realText isEqualToString:self.placeholder]) {
            if ([textColor isEqual:[UIColor lightGrayColor]]) [super setTextColor:textColor];
            else self.realTextColor = textColor;
        }
        else {
            self.realTextColor = textColor;
            [super setTextColor:textColor];
        }
    }
    @catch (NSException *exception) {
          NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark -
#pragma mark Dealloc

- (void)dealloc {
    realTextColor = nil;
    placeholder = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
