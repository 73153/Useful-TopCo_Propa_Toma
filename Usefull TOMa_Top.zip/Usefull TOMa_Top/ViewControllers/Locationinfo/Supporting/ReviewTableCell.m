//
//  ReviewTableCell.m
//  LocationInfo
//
//  Created by shiva on 2/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ReviewTableCell.h"
#import <QuartzCore/QuartzCore.h>


@implementation ReviewTableCell

@synthesize btnLikeCount;
@synthesize lineLabel;

@synthesize reviewerName_str;
@synthesize reviewText_str;
@synthesize reviewerAvatarUrl_str;
@synthesize photoUrl_str;
@synthesize photo_Data;
@synthesize likeCount_str;
@synthesize commentCount_str;
@synthesize time_str;
@synthesize locationDelegate_;
@synthesize reviewerNameHeight_float;
@synthesize reviewTextHeight_float;
@synthesize photoheight_float;
@synthesize rateImageViewHieght_float;
@synthesize rateImage;
@synthesize hideCommentButton;
@synthesize reviewer_Default_AvatarUrl_str;
@synthesize locationImgview;
@synthesize postedImage;
@synthesize lockImage;
@synthesize isPrivatePlug;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        //        self.backgroundColor = [UIColor colorWithRed:(218.0f/255.0f) green:(219.0f/255.0f) blue:(224.0f/255.0f) alpha:1.0f];
    }
    return self;
}

-(void)addSubviewToTableCell:(id)caller{
    
    @try {
        //NSInteger headerHeight = reviewerNameHeight_int + reviewTextHeight_int + photoheight_int + 25.0f + 20.0f;
        // Initialization code
        UIView *sectionHeaderview = [[UIView alloc]initWithFrame:CGRectZero];
        sectionHeaderview.layer.cornerRadius = 6.0f;
        sectionHeaderview.opaque = YES;
        sectionHeaderview.tag = 1;
        sectionHeaderview.backgroundColor = [UIColor clearColor];
        
        //        sectionHeaderview.backgroundColor = [UIColor colorWithRed:(218.0f/255.0f) green:(219.0f/255.0f) blue:(224.0f/255.0f) alpha:1.0f];
        //        sectionHeaderview.backgroundColor = [UIColor clearColor];
        
        UIImageView *backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"livefeedcellbg"]];
        backgroundImgView.tag = 2000;
        backgroundImgView.layer.cornerRadius = 5.0f;
        backgroundImgView.layer.masksToBounds = YES;
        [sectionHeaderview addSubview:backgroundImgView];
        
        lineLabel = [[UILabel alloc] init];
        
        lineLabel.backgroundColor = [appDelegate colorWithHexString:@"171717"];
        [sectionHeaderview addSubview:lineLabel];
        
        //Reviewer Image
        UIImageView *user_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(HEADER_MARGIN, HEADER_MARGIN,isiPhone6PLUS?REVIEWER_IMAGE_WIDTH+10:REVIEWER_IMAGE_WIDTH,isiPhone6PLUS?REVIEWER_IMAGE_HEIGHT+10:REVIEWER_IMAGE_HEIGHT)];
        user_imageView.tag = 2;
        user_imageView.opaque = YES;
        user_imageView.layer.cornerRadius = 4.0f;
        user_imageView.layer.masksToBounds = YES;
        [sectionHeaderview addSubview:user_imageView];
        
        locationImgview = [[UIImageView alloc]init];
        locationImgview.layer.cornerRadius = 6.0f;
        locationImgview.layer.masksToBounds = YES;
        locationImgview.opaque = YES;
        locationImgview.hidden = YES;
        [sectionHeaderview addSubview:locationImgview];
        
        lockImage = [[UIImageView alloc]init];
        lockImage.layer.cornerRadius = 6.0f;
        lockImage.layer.masksToBounds = YES;
        lockImage.opaque = YES;
        lockImage.hidden = YES;
        [sectionHeaderview addSubview:lockImage];
        
        //show the ReviewerName
        UILabel *lblReviewerName = [[UILabel alloc]init];
        lblReviewerName.opaque = YES;
        lblReviewerName.tag = 3;
        lblReviewerName.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.f:titleFontSize];
        lblReviewerName.textColor = [UIColor whiteColor];
        lblReviewerName.backgroundColor = [UIColor clearColor];
        [sectionHeaderview addSubview:lblReviewerName];
        
        //shwot the Review
        UILabel *lblReview = [[UILabel alloc]init];
        lblReview.opaque = YES;
        lblReview.numberOfLines = 0;
        lblReview.tag = 4;
        lblReview.textColor = [UIColor whiteColor];
        lblReview.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.f:descriptionTextFontSize];
        lblReview.backgroundColor = [UIColor clearColor];
        [sectionHeaderview addSubview:lblReview];
        
        //reviewer uploaded Image
        UIImageView *photoImgView = [[UIImageView alloc]init];
        photoImgView.tag = 11;
        photoImgView.layer.cornerRadius = 3.0f;
        photoImgView.layer.masksToBounds = YES;
        [sectionHeaderview addSubview:photoImgView];
        
        UIImageView *lineImgView = [[UIImageView alloc]init];
        lineImgView.tag = 5;
        lineImgView.image = [UIImage imageNamed:@"line"];
        [sectionHeaderview addSubview:lineImgView];
        
        //show the LikeCount
        btnLikeCount = [UIButton buttonWithType:UIButtonTypeCustom];
        btnLikeCount.backgroundColor = [UIColor clearColor];
        btnLikeCount.tag = 6;
        btnLikeCount.opaque = YES;
        [btnLikeCount setBackgroundImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [btnLikeCount addTarget:caller action:@selector(likeReview:event:) forControlEvents:UIControlEventTouchUpInside];
        [sectionHeaderview addSubview:btnLikeCount];
        
        UILabel *lblLike = [[UILabel alloc]init];
        lblLike.tag = 7;
        lblLike.backgroundColor = [UIColor clearColor];
        lblLike.opaque = YES;
        lblLike.textAlignment = NSTextAlignmentCenter;
        lblLike.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:descriptionTextFontSize];
        [btnLikeCount addSubview:lblLike];
        
        //show the CommentCount
        UIButton *btnCommentCount = [UIButton buttonWithType:UIButtonTypeCustom];
        btnCommentCount.opaque = YES;
        btnCommentCount.backgroundColor = [UIColor clearColor];
        btnCommentCount.tag = 8;
        [btnCommentCount setBackgroundImage:[UIImage imageNamed:@"comment"] forState:UIControlStateNormal];
        [btnCommentCount addTarget:caller action:@selector(writeComment:event:) forControlEvents:UIControlEventTouchUpInside];
        [sectionHeaderview addSubview:btnCommentCount];
        
        UILabel *lblCommentCount = [[UILabel alloc]init];
        lblCommentCount.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:descriptionTextFontSize];
        lblCommentCount.opaque = YES;
        lblCommentCount.tag = 9;
        lblCommentCount.textAlignment = NSTextAlignmentCenter;
        lblCommentCount.backgroundColor = [UIColor clearColor];
        [btnCommentCount addSubview:lblCommentCount];
        
        //Show the review Time
        UILabel *lblTime = [[UILabel alloc]init];
        lblTime.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?14.0f:dateFontSize];
        lblTime.opaque = YES;
        lblTime.tag = 10;
        lblTime.backgroundColor = [UIColor clearColor];
        lblTime.textColor = [UIColor whiteColor];
        lblTime.textAlignment = NSTextAlignmentRight;
        [sectionHeaderview addSubview:lblTime];
        
        UIImageView *rateImgView = [[UIImageView alloc]init];
        rateImgView.tag = 12;
        [sectionHeaderview addSubview:rateImgView];
        rateImgView.hidden = YES;
        rateImgView = nil;
        
        postedImage = nil;
        
        [self addSubview:sectionHeaderview];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)setData {
    
    @try {
        //get the instance for all subviews added to the cell
        UIView *sectionHeaderview = (UIView *)[self viewWithTag:1];
        UIImageView *backgroundImgView = (UIImageView *)[sectionHeaderview viewWithTag:2000];
        UIImageView *user_imageView = (UIImageView *)[sectionHeaderview viewWithTag:2];
        UILabel *lblReviewerName = (UILabel *)[sectionHeaderview viewWithTag:3];
        UILabel *lblReview = (UILabel *)[sectionHeaderview viewWithTag:4];
        UIImageView *lineImgView = (UIImageView *)[sectionHeaderview viewWithTag:5];
        UILabel *lblLike = (UILabel *)[btnLikeCount viewWithTag:7];
        UIButton *btnCommentCount = (UIButton *)[sectionHeaderview viewWithTag:8];
        UILabel *lblCommentCount = (UILabel *)[btnCommentCount viewWithTag:9];
        UILabel *lblTime = (UILabel *)[sectionHeaderview viewWithTag:10];
        UIImageView *photoImgView = (UIImageView *)[sectionHeaderview viewWithTag:11];
        UIImageView *rateImgView = (UIImageView *)[sectionHeaderview viewWithTag:12];
        //        lineLabel = (UILabel *)[backgroundImgView viewWithTag:-100000];
        if (reviewerNameHeight_float == 0.0f)
            reviewerNameHeight_float =15.0f;
        //if (reviewTextHeight_float > 0.0f)
        //    reviewTextHeight_float += 5.0f;
        if (photoheight_float > 0.0f)
            photoheight_float +=5.0f;
        if (rateImageViewHieght_float > 0.0f) {
            rateImageViewHieght_float +=5.0f;
        }
        
        if (rateImageViewHieght_float == 0 && reviewTextHeight_float == 0) {
            reviewTextHeight_float = (HEADER_MARGIN * 3);
        }
        CGFloat headerHeight;
        if (iPad) {
            headerHeight = self.reviewerNameHeight_float + self.reviewTextHeight_float + self.photoheight_float + rateImageViewHieght_float + 30.0f + 50.0f;
        } else {
            headerHeight = self.reviewerNameHeight_float + self.reviewTextHeight_float + self.photoheight_float + rateImageViewHieght_float + 25.0f + 30.0f+(isiPhone6PLUS?5:0);
        }
        
        //  NSLog(@"review table cell height in reviewtablecell class is %f",headerHeight);
        if(sectionHeaderview) {
            sectionHeaderview.frame = CGRectMake(HEADER_MARGIN, 0, HEADER_WIDTH, headerHeight);
        }
        sectionHeaderview.backgroundColor = [UIColor clearColor];
        if (backgroundImgView) {
            backgroundImgView.frame = CGRectMake(0, 0, HEADER_WIDTH, headerHeight);
        }
        lineLabel.frame = CGRectMake(2, backgroundImgView.frame.size.height - 2.3, HEADER_WIDTH - 4, 1);
        if([self isNotNull:self.reviewerAvatarUrl_str] && [self.reviewerAvatarUrl_str rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound){
            
            NSString *avatar_url = [appDelegate getUserAvatarUrlString:self.reviewerAvatarUrl_str];
            [user_imageView setImageWithURL:[NSURL URLWithString:avatar_url] placeholderImage:[UIImage imageNamed:self.reviewer_Default_AvatarUrl_str]];
        }
        else {
            user_imageView.image = [UIImage imageNamed:self.reviewer_Default_AvatarUrl_str];
        }
        
        if ([self isNotNull:self.reviewerName_str] && self.reviewerName_str.length > 0) {
            lblReviewerName.text = self.reviewerName_str;
        } else {
            lblReviewerName.text = @"";
        }
        ///lblReviewerName.backgroundColor = [UIColor redColor];
        [lblReviewerName setFrame:CGRectMake(HEADER_MARGIN +(isiPhone6PLUS?REVIEWER_IMAGE_WIDTH+10:REVIEWER_IMAGE_WIDTH) + HEADER_MARGIN,5, (HEADER_WIDTH - 10) - (HEADER_MARGIN +  REVIEWER_IMAGE_WIDTH + (HEADER_MARGIN * 2)+30) , MAX(self.reviewerNameHeight_float, 0.0f))];
        
        if ([self isNotNull:self.reviewText_str] && self.reviewText_str.length > 0) {
            //lblReview.hidden = NO;
            lblReview.text = self.reviewText_str;
        } else {
            lblReview.text = @"";
            // lblReview.hidden = YES;
        }
        if (iPad) {
            [locationImgview setFrame:CGRectMake(lblReviewerName.frame.origin.x + lblReviewerName.frame.size.width + 15, 5, 20, 30)];
        } else {
            [locationImgview setFrame:CGRectMake(lblReviewerName.frame.origin.x + lblReviewerName.frame.size.width + 30, 5, 11, 18)];
        }
        
        locationImgview.image = [UIImage imageNamed:@"location"];
        
        //lblReview.backgroundColor = [UIColor blueColor];

        [lblReview setFrame:CGRectMake(HEADER_MARGIN +(isiPhone6PLUS?REVIEWER_IMAGE_WIDTH+10:REVIEWER_IMAGE_WIDTH)+ HEADER_MARGIN,lblReviewerName.frame.origin.y + lblReviewerName.frame.size.height + 5, (HEADER_WIDTH - 10) - (HEADER_MARGIN +  REVIEWER_IMAGE_WIDTH + (HEADER_MARGIN * 2)), MAX(self.reviewTextHeight_float, 0.0f))];
        
        if ([self isNotNull:rateImage]) {
            rateImgView.hidden = NO;
            rateImgView.image = rateImage;
            
        } else {
            rateImgView.hidden = YES;
        }
        
        [rateImgView setFrame:CGRectMake(HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + HEADER_MARGIN,lblReview.frame.origin.y + lblReview.frame.size.height + 5, CELL_RATEIMAGEVIEWWIDTH, self.rateImageViewHieght_float)];
        
        if ((self.photoUrl_str && self.photoUrl_str.length > 0 && [self.photoUrl_str rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound ) || [self isNotNull:self.postedImage]) {
            photoImgView.hidden = NO;
            if ([self.photoUrl_str rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound && self.photoUrl_str.length > 0) {
                [photoImgView setImageWithURL:[NSURL URLWithString:self.photoUrl_str] placeholderImage:[UIImage imageNamed:@"picture-placeholder"]];
            } else if ([self isNotNull:self.postedImage]) {
                //                [photoImgView setImage:[UIImage imageWithData:self.photo_Data]];
                [photoImgView setImage:self.postedImage];
            }
            photoImgView.frame = CGRectMake((backgroundImgView.frame.size.width - CELL_PLUGPHOTOWIDTH)/2, rateImgView.frame.origin.y + rateImgView.frame.size.height + HEADER_MARGIN, CELL_PLUGPHOTOWIDTH, CELL_PLUGPHOTOHEIGHT);
            lineImgView.frame = CGRectMake(0, photoImgView.frame.origin.y + photoImgView.frame.size.height+5, sectionHeaderview.frame.size.width, 10);
        } else {
            photoImgView.hidden = YES;
            photoImgView.frame = CGRectMake(0, rateImgView.frame.origin.y + rateImgView.frame.size.height, 0.0f, 0.0f);
            lineImgView.frame = CGRectMake(0, photoImgView.frame.origin.y + photoImgView.frame.size.height+10, sectionHeaderview.frame.size.width, 10);
        }
        
        if (iPad) {
            btnLikeCount.frame = CGRectMake(10 + 2,lineImgView.frame.origin.y + lineImgView.frame.size.height + 3, 73, 36);
            lblLike.frame = CGRectMake(35, 8, 30, 20);
            
            btnCommentCount.frame = CGRectMake(btnLikeCount.frame.origin.x + btnLikeCount.frame.size.width + 10, lineImgView.frame.origin.y +lineImgView.frame.size.height +3, 73, 36);
            lblCommentCount.frame = CGRectMake(35, 8, 30, 20);
        } else {
            lineImgView.frame = CGRectMake(-5, photoImgView.frame.origin.y + photoImgView.frame.size.height+2, sectionHeaderview.frame.size.width+10, 10);
            btnLikeCount.frame = CGRectMake(5 + 2,photoImgView.frame.origin.y + photoImgView.frame.size.height + 13, isiPhone6PLUS?60:45,isiPhone6PLUS?25:22);
            lblLike.frame = CGRectMake(isiPhone6PLUS?28:24, 3, 20,isiPhone6PLUS?18:15);
            
            btnCommentCount.frame = CGRectMake(5 + btnLikeCount.frame.size.width + 7, photoImgView.frame.origin.y +photoImgView.frame.size.height + 13, isiPhone6PLUS?60:45,isiPhone6PLUS?25:22);
            lblCommentCount.frame = CGRectMake(isiPhone6PLUS?28:24, 3, 20,isiPhone6PLUS?18:15);
            
        }
        
        lblLike.text = self.likeCount_str;
        
        lblCommentCount.text = self.commentCount_str;
        
        if (self.hideCommentButton) {
            btnCommentCount.enabled = NO;
        } else {
            btnCommentCount.enabled = YES;
        }
        
        if ([self isNotNull:self.time_str] && self.time_str.length > 0) {
            lblTime.text = self.time_str;
        } else {
            lblTime.text = @"";
        }
        
        if (isPrivatePlug) {
            if (iPad) {
                lblTime.frame = CGRectMake(sectionHeaderview.frame.size.width - (205 + 30), (lineImgView.frame.origin.y + lineImgView.frame.size.height + 13), 200, 30);
                btnCommentCount.frame = CGRectMake(btnLikeCount.frame.origin.x , lineImgView.frame.origin.y + lineImgView.frame.size.height + 3, 73, 36);
                [lockImage setFrame:CGRectMake(lblTime.frame.origin.x + lblTime.frame.size.width + 3,  (lineImgView.frame.origin.y + lineImgView.frame.size.height + 13), 21, 25)];
            } else {
                lblTime.frame = CGRectMake(appDelegate.window.frame.size.width-145, (photoImgView.frame.origin.y + photoImgView.frame.size.height + 18), 120, 18);
                btnCommentCount.frame = CGRectMake(btnLikeCount.frame.origin.x , photoImgView.frame.origin.y +photoImgView.frame.size.height + 13, isiPhone6PLUS?60:45,isiPhone6PLUS?25:22);
                [lockImage setFrame:CGRectMake(lblTime.frame.origin.x + lblTime.frame.size.width + 3,  (lblTime.frame.origin.y + 3), 9,isiPhone6PLUS?16:14)];
            }
            btnLikeCount.hidden = YES;
            lockImage.hidden = NO;
            
        } else {
            if (iPad) {
                lblTime.frame = CGRectMake(sectionHeaderview.frame.size.width - 205, (lineImgView.frame.origin.y + lineImgView.frame.size.height + 13), 200, 30);
                btnCommentCount.frame = CGRectMake(btnLikeCount.frame.origin.x + btnLikeCount.frame.size.width + 10, lineImgView.frame.origin.y +lineImgView.frame.size.height + 3, 73, 36);
            } else {
                lblTime.frame = CGRectMake(appDelegate.window.frame.size.width-140, (photoImgView.frame.origin.y + photoImgView.frame.size.height + 18), 125, 18);
                btnCommentCount.frame = CGRectMake(5 + btnLikeCount.frame.size.width + 7, photoImgView.frame.origin.y +photoImgView.frame.size.height + 13, isiPhone6PLUS?60:45,isiPhone6PLUS?25:22);
                
            }
            btnLikeCount.hidden = NO;
            lockImage.hidden = YES;
        }
        
        //[lockImage setFrame:CGRectMake(lblTime.frame.origin.x + lblTime.frame.size.width + 3,  (lineImgView.frame.origin.y + lineImgView.frame.size.height + 13), 21, 25)];
        lockImage.image = [UIImage imageNamed:@"livefeedLock"];
        
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void)willTransitionToState:(UITableViewCellStateMask)state {
    
    @try {
        [super willTransitionToState:state];
        
        if ((state & UITableViewCellStateShowingDeleteConfirmationMask) == UITableViewCellStateShowingDeleteConfirmationMask) {
            
            for (UIView *subview in self.subviews) {
                
                if ([NSStringFromClass([subview class]) isEqualToString:@"UITableViewCellDeleteConfirmationControl"]) {
                    
                    subview.hidden = YES;
                    subview.alpha = 0.0;
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)didTransitionToState:(UITableViewCellStateMask)state {
    
    @try {
        [super didTransitionToState:state];
        
        if (state == UITableViewCellStateShowingDeleteConfirmationMask || state == UITableViewCellStateDefaultMask) {
            for (UIView *subview in self.subviews) {
                
                if ([NSStringFromClass([subview class]) isEqualToString:@"UITableViewCellDeleteConfirmationControl"]) {
                    
                    UIView *deleteButtonView = (UIView *)[subview.subviews objectAtIndex:0];
                    CGRect f = deleteButtonView.frame;
                    f.origin.y -= 16;
                    deleteButtonView.frame = f;
                    
                    subview.hidden = NO;
                    
                    [UIView beginAnimations:@"anim" context:nil];
                    subview.alpha = 1.0;
                    [UIView commitAnimations];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

@end
