//
//  CommentViewController.h
//  LocationInfo
//
//  Created by shiva on 1/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StreamService.h"
#import "LocationInfoViewController.h"
#import "RecentActivityTable.h"
#import "CommentTextView.h"
#import "AppDelegate.h"
#import "RecentActivity.h"
#import "ApplicationConstants.h"

@interface CommentViewController : UIViewController<StreamServiceDelegate,UITextViewDelegate,UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate> {
    
    UIView *chatBarView;
    UILabel *statusLabel;
    id superViewRef;
    CommentTextView *cmt_TextView;
    UITableView *comment_TableView;
    UIButton *send_Btn;
    AppDelegate *appDelegate;
    
    BOOL isGetCommentsForReviewRequestInProgress;
    
    UITapGestureRecognizer *tapGesture;
    RecentActivity *selectedRecentActivity;
    NSIndexPath *liveFeedTblSlctd_IndexPath;
    
    BOOL iskeyBoardEnabled;
    BOOL historyReloadCheck;
    CGFloat chatBarMovedHeight;
}

@property(nonatomic, readwrite) CGFloat sectionHeght_float;
@property(nonatomic, readwrite) BOOL historyReloadCheck;

-(void)rearrangeTable;
- (void)scrollToBottomAnimated:(BOOL)animated;
- (void)setRecentActivity:(RecentActivity*)recentActivity;


/** initializes the CommentViewController class and returns the self.
 * navigationFromOverView argument is required to hide the tabBar when it was pushed from the OverView screen.
 to hide the tabBar we need to call self.hideBottomBarWhenPushed in init of that class other wise it won't hide, so passing of argument at the time of initialization is importent.
 */
- (id)initWithNavigationCaller:(id)caller andLivefeedIndexPath:(NSIndexPath *)indexPath;

@end
