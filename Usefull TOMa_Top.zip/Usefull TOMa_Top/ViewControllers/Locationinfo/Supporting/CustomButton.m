//
//  CustomButton.m
//  TestApp
//
//  Created by Aruna on 01/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "CustomButton.h"

@implementation CustomButton
@synthesize questionDict;
@synthesize questionIndex;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

@end
