//
//  CommentViewController.m
//  LocationInfo
//
//  Created by shiva on 1/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CommentViewController.h"

#import "ReviewTableCell.h"
#import <QuartzCore/QuartzCore.h>

@implementation CommentViewController

@synthesize sectionHeght_float;
@synthesize historyReloadCheck;

- (id)initWithNavigationCaller:(id)caller andLivefeedIndexPath:(NSIndexPath *)indexPath
{
    self = [super init];
    if (self) {
        // Custom initialization
        superViewRef = caller;
        liveFeedTblSlctd_IndexPath = indexPath;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardHideNotification) name:UIKeyboardWillHideNotification object:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    @try {
        [super viewDidLoad];
        
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        if ([self isNotNull:superViewRef] && [superViewRef isKindOfClass:[RecentActivityTable class]] && [self isNotNull:liveFeedTblSlctd_IndexPath]) {
            RecentActivityTable *streamTable = (RecentActivityTable *)superViewRef;
            selectedRecentActivity = [streamTable.locDataModel_Arr objectAtIndex:liveFeedTblSlctd_IndexPath.section];
        }
        
        [self scrollToBottomAnimated:YES];
        
        UIImageView *bg_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
        bg_ImgView.frame = self.view.bounds;
        [self.view addSubview:bg_ImgView];
        
        UILabel *headerLabel;
        if (iPad) {
            headerLabel =[[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width - 300)/2,13 ,300,45)];
        } else {
            headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, appDelegate.window.frame.size.width,25)];
        }
        
        headerLabel.text = @"COMMENTS";
        headerLabel.textColor=[UIColor whiteColor];
        headerLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        //FavouritesLabel.font = [UIFont fontWithName:@"Helvetica LT Condensed" size: 22.0];
        headerLabel.backgroundColor = [UIColor clearColor];
        headerLabel.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:headerLabel];
        
        //history reload check
        if(historyReloadCheck == YES)
        {
            NSArray *VCArray=[self.navigationController viewControllers];
            for(UIViewController *viewController in VCArray)
            {
                if([viewController isKindOfClass:[MyHistoryNRecentActivityViewController class]])
                {
                    MyHistoryNRecentActivityViewController *historyViewController=(MyHistoryNRecentActivityViewController*)viewController;
                    historyViewController.activityCheckObject=selectedRecentActivity;
                    historyViewController.reloadCheck=YES;
                }
            }
        }
        
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        //set the position of the button
        if (iPad) {
            backButton.frame = CGRectMake(5,10, 84, 48);
        } else {
            backButton.frame = CGRectMake(5,7, 59, 32);
        }
        
        //set the button's title
        [backButton setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        //listen for clicks
        [backButton addTarget:self action:@selector(popThePresentViewController:)
             forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:backButton];
        
        UIImageView *line_ImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
        line_ImgView.image = [UIImage imageNamed:@"line"];
        line_ImgView.tag = 4;
        [self.view addSubview:line_ImgView];
        
        [self configureCommentView];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

-(void)setRecentActivity:(RecentActivity *)recentActivity
{
    selectedRecentActivity=recentActivity;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (CGFloat)getHeightOfTable {
    TCSTART
    CGFloat gap;
    if (iPad) {
        gap = 10;
    } else {
        gap = 8;
    }
    CGFloat heightOfTheTable = sectionHeght_float;
    
    int repliesCnt = [self getRepliesCount];
    
    for (int i = 1; i <= repliesCnt; i ++) {
        heightOfTheTable = heightOfTheTable + [self getheightForRowInSection:[NSIndexPath indexPathForRow:i inSection:0]];
    }
    if (heightOfTheTable > (self.view.frame.size.height - (COMMENTVIEW_BAR_HEIGHT + COMMENTVIEW_TABLEORIGINY + (gap * 4)))) {
        heightOfTheTable = self.view.frame.size.height - (COMMENTVIEW_BAR_HEIGHT + COMMENTVIEW_TABLEORIGINY + (gap * 2));
    } else {
        heightOfTheTable = heightOfTheTable + (gap * 4);
    }
    return heightOfTheTable ;
    TCEND
}
- (void)configureCommentView {
    TCSTART
    CGFloat chatBarOriginX;
    CGFloat remainingViewHeight;
    CGFloat gap;
    CGRect statusLabelFrame;
    CGRect submitButtonFrame;
    if (iPad) {
        chatBarOriginX = 41;
        remainingViewHeight = 50;
        gap = 10;
        statusLabelFrame = CGRectMake(199, 12, 285, 27);
        submitButtonFrame = CGRectMake(585, 3, 95, 45);
    } else {
        chatBarOriginX = 10;
        remainingViewHeight = 32;
        gap = 5;
        statusLabelFrame = CGRectMake(50, 7, 106, 18);
        submitButtonFrame = CGRectMake(appDelegate.window.frame.size.width-100, 0, 73, 32);
    }
    
    comment_TableView = [[UITableView alloc] initWithFrame:
                         CGRectMake(1.0f, COMMENTVIEW_TABLEORIGINY, self.view.frame.size.width -2,
                                    [self getHeightOfTable]) style:UITableViewStyleGrouped];
    comment_TableView.clearsContextBeforeDrawing = NO;
    comment_TableView.delegate = self;
    comment_TableView.dataSource = self;
    //comment_TableView.contentInset = UIEdgeInsetsMake(7.0f, 0.0f, 0.0f, 0.0f);
    comment_TableView.backgroundColor = [UIColor clearColor];
    comment_TableView.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
    
    comment_TableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    comment_TableView.separatorColor = [UIColor clearColor];
    comment_TableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    comment_TableView.autoresizingMask = UIViewAutoresizingFlexibleWidth |
    UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:comment_TableView];
    
    chatBarView = [[UIView alloc] initWithFrame:CGRectMake(chatBarOriginX,comment_TableView.frame.origin.y + comment_TableView.frame.size.height + gap, COMMENTVIEW_BAR_WIDTH, COMMENTVIEW_BAR_HEIGHT)];
    chatBarView.layer.cornerRadius = 5.0f;
    chatBarView.layer.masksToBounds = YES;
    // Create chatInput.
    cmt_TextView = [[CommentTextView alloc] initWithFrame:CGRectMake(0,0, COMMENTVIEW_BAR_WIDTH, COMMENTVIEW_BAR_HEIGHT - remainingViewHeight)];
    cmt_TextView.delegate = self;
    cmt_TextView.placeholder = @"Write a comment...";
    cmt_TextView.textColor = [UIColor lightTextColor];
    cmt_TextView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    cmt_TextView.scrollEnabled = NO; // not initially
    cmt_TextView.clearsContextBeforeDrawing = NO;
    cmt_TextView.font = [UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize];
    cmt_TextView.contentOffset = (CGPoint){.x = 0, .y = 4.5};
    cmt_TextView.dataDetectorTypes = UIDataDetectorTypeAll;
    cmt_TextView.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
    cmt_TextView.textColor = [UIColor blackColor];
    [cmt_TextView setReturnKeyType:UIReturnKeyDone];
	
    //    cell.rightTextField.returnKeyType = UIReturnKeyDone;
    [chatBarView addSubview:cmt_TextView];
    
    UIView *remainingView = [[UIView alloc] initWithFrame:CGRectMake(0, cmt_TextView.frame.size.height + cmt_TextView.frame.origin.y, COMMENTVIEW_BAR_WIDTH, remainingViewHeight)];
    remainingView.backgroundColor = [UIColor colorWithRed:0.72f green:0.73f blue:0.77f alpha:1.0f];
    [chatBarView addSubview:remainingView];
    
    statusLabel = [[UILabel alloc] initWithFrame:statusLabelFrame];
    statusLabel.text = @"0 | 140 remaining";
    statusLabel.textColor = [UIColor blackColor];
    statusLabel.font = [UIFont fontWithName:descriptionTextFontName size:dateFontSize];
    statusLabel.backgroundColor = [UIColor clearColor];
    statusLabel.textAlignment = NSTextAlignmentCenter;
    [remainingView addSubview:statusLabel];
    
    // Create sendButton.
    send_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
    send_Btn.frame = submitButtonFrame;
    [send_Btn setBackgroundImage:[UIImage imageNamed:@"plug_submit"] forState:UIControlStateNormal];
    [send_Btn addTarget:self action:@selector(postComment:)
       forControlEvents:UIControlEventTouchUpInside];
    [remainingView bringSubviewToFront:send_Btn];
    [remainingView addSubview:send_Btn];
    
    [self.view addSubview:chatBarView];
    [self.view bringSubviewToFront:chatBarView];
    
    isGetCommentsForReviewRequestInProgress = YES;
    
    NSString *reviewId;
    CPEventType eventType;
    
    if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
        eventType = [self returnCPEventTypeBySpecifiedParameter:selectedRecentActivity.commentType];
        reviewId = [selectedRecentActivity.commentableId stringValue];
    } else {
        eventType = [self returnCPEventTypeBySpecifiedParameter:selectedRecentActivity.eventType];
        reviewId = [selectedRecentActivity.eventId stringValue];
    }
    //    if (repliesCount > 0) {
    [appDelegate getCommentForReview:reviewId andEventType:eventType withCallbackObject:self];
    //    }
    TCEND
}
- (CPEventType)returnCPEventTypeBySpecifiedParameter:(NSString *)eventType {
    TCSTART
    if ([eventType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
        return CPEventTypeReview;
    } else if ([eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
        return CPEventTypeBroadcast;
    } else  {
        return CPEVentTypePrivateMessage;
    }
    TCEND
}
- (int)getRepliesCount {
    TCSTART
    int repliesCnt;
    if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
        repliesCnt = [selectedRecentActivity.commentableCommentsCount intValue];
    } else {
        repliesCnt = [selectedRecentActivity.repliesCount intValue];
    }
    return repliesCnt;
    TCEND
}

- (int)getLikesCount {
    TCSTART
    return [selectedRecentActivity.likesCount intValue];
    //    int likesCnt;
    //    if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
    //        likesCnt = [selectedRecentActivity.commentableLikesCount intValue];
    //    } else {
    //        likesCnt = [selectedRecentActivity.likesCount intValue];
    //    }
    //    return likesCnt;
    TCEND
}

- (void)viewWillAppear:(BOOL)animated {
    @try {
        [super viewWillAppear:animated];
        
        if ([self isNotNull:comment_TableView]) {
            NSIndexPath *indexpath = [comment_TableView indexPathForSelectedRow];
            [comment_TableView deselectRowAtIndexPath:indexpath animated:YES];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFinishedGettingCommentsForReview:(NSDictionary *)results {
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        NSMutableArray *repliesArray = [[NSMutableArray alloc] init];
        [repliesArray addObjectsFromArray:[results objectForKey:@"reviewcomments"]];
        
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:selectedRecentActivity]) {
            selectedRecentActivity.repliesArray = repliesArray;
            selectedRecentActivity.commentableCommentsCount = [NSNumber numberWithInt:repliesArray.count];
            selectedRecentActivity.repliesCount = [NSNumber numberWithInt:repliesArray.count];
            [appDelegate saveContext];
            
            comment_TableView.frame = CGRectMake(comment_TableView.frame.origin.x, comment_TableView.frame.origin.y, comment_TableView.frame.size.width, [self getHeightOfTable]);
            
            chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, comment_TableView.frame.origin.y + comment_TableView.frame.size.height - 10, chatBarView.frame.size.width, chatBarView.frame.size.height);
            [comment_TableView reloadData];
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToGetCommentsForReview:(NSString *)errorMsg {
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:errorMsg];
}

- (void)dismissKeyboard:(id)sender {
    @try {
        [comment_TableView removeGestureRecognizer:tapGesture];
        
        if ([cmt_TextView isFirstResponder]){
            [cmt_TextView resignFirstResponder];
            [self rearrangeTable];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)popThePresentViewController:(id)sender {
    @try {
        //        if (isNavigatedFromOverView) {
        //            [appDelegate showMainTabBarItems];
        //        }
        [appDelegate hideNetworkIndicator];
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)postComment:(id)sender {
    @try {
        if ([self isNotNull:cmt_TextView] && [self isNotNull:cmt_TextView.text]) {
            if ([[cmt_TextView.text stringByTrimmingCharactersInSet:
                  [NSCharacterSet whitespaceCharacterSet]] length]>0) {
                cmt_TextView.text = [appDelegate removingLastSpecialCharecter:cmt_TextView.text];
                if ([cmt_TextView.text length]>0) {
                    
                }else{
                    [appDelegate showErrorMsg:@"Please remove special characters"];
                }
                if (cmt_TextView.text.length > 0) {
                    if([self isNotNull:liveFeedTblSlctd_IndexPath])
                    {
                        [superViewRef postComment:[cmt_TextView.text encodedString] withIndexPath:liveFeedTblSlctd_IndexPath];
                        [self.navigationController popViewControllerAnimated:YES];
                    }
                    else
                    {
                        [self postCommentWithText:[cmt_TextView.text encodedString]];
                    }
                }
                
            }else{
                [appDelegate showErrorMsg:@"Please type at least one character"];
            }
        }else{
            [appDelegate showErrorMsg:@"Please enter message"];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Comment Related Methods ======================================
- (void)postCommentWithText:(NSString *)commentText {
    
    @try {
        if ([self isNull:commentText])
            return;
        
        NSString *broadCastId = nil;
        NSString *reviewId = nil;
        NSString *privateMessageId = nil;
        RecentActivity *recentActivity = selectedRecentActivity;
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            if ([recentActivity.commentType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
                broadCastId = [recentActivity.commentableId stringValue];
            } else if ([recentActivity.commentType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
                reviewId = [recentActivity.commentableId stringValue];
            } else {
                privateMessageId = [recentActivity.commentableId stringValue];
            }
        } else if([recentActivity.eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
            broadCastId = [recentActivity.eventId stringValue];
        } else if([recentActivity.eventType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
            reviewId = [recentActivity.eventId stringValue];
        } else {
            privateMessageId = [recentActivity.eventId stringValue];
        }
        
        if (commentText.length > 0) {
            [commentText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        [appDelegate postComment:commentText onReview:reviewId onBroadCast:broadCastId onPrivateMessage:privateMessageId withIndexPath:nil withCallbackObject:self withchannel_Id:recentActivity.channel_Id];
        [comment_TableView reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Post Comment Request Delegate Methods.
- (void)didFinishedPostingComment:(NSDictionary *)results {
    @try {
        [appDelegate hideNetworkIndicator];
        //        NSLog(@"didFinishedPostingComment %@",results);
        if([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:[results objectForKey:@"postCommentResponse"]]){
            RecentActivity *recentActivity = selectedRecentActivity;
            NSArray *commentsRecentActivitiesArray;
            if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
            } else {
                commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
            }
            [self addReplyAndIncrementCommentsCountOfRecentActivitys:commentsRecentActivitiesArray andIndexPath:nil andComments:results];
            [appDelegate saveContext];
            
            comment_TableView.frame = CGRectMake(comment_TableView.frame.origin.x, comment_TableView.frame.origin.y, comment_TableView.frame.size.width, [self getHeightOfTable]);
            NSLog(@"%f:%f",comment_TableView.frame.origin.y,comment_TableView.frame.size.height);
            chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, comment_TableView.frame.origin.y + comment_TableView.frame.size.height - 10, chatBarView.frame.size.width, chatBarView.frame.size.height);
            NSLog(@"%f:%f",chatBarView.frame.origin.y,chatBarView.frame.size.height);
            //[self reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
            cmt_TextView.text=@"";
            NSLog(@"%f:%f",self.view.frame.size.width,self.view.frame.size.height);
            [comment_TableView reloadData];
            [self.navigationController popViewControllerAnimated:YES];

        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)addReplyAndIncrementCommentsCountOfRecentActivitys:(NSArray *)recentActivitysArray andIndexPath:(NSIndexPath *)indexPath andComments:(NSDictionary *)results {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            NSMutableArray *replies_array = [[NSMutableArray alloc]init];
            int repliesCount = [recentActivity.repliesCount intValue];
            
            if ([self isNotNull:[results objectForKey:@"postCommentResponse"]]) {
                [replies_array addObject:[results objectForKey:@"postCommentResponse"]];
            }
            
            if ([self isNotNull:recentActivity.repliesArray]) {
                [replies_array addObjectsFromArray:recentActivity.repliesArray];
            }
            
            if ([self isNotNull:replies_array] && replies_array.count > 0) {
                recentActivity.repliesArray = replies_array;
            }
            
            repliesCount = repliesCount + 1;
            recentActivity.repliesCount = [NSNumber numberWithInt:repliesCount];
            recentActivity.commentableCommentsCount = [NSNumber numberWithInt:repliesCount];
        }
    }
    
    TCEND
}

- (void)didFailedToPostCommentWithError:(NSString *)errorMsg {
    @try {
        [appDelegate hideNetworkIndicator];
        //  NSLog(@"didFailedToPostCommentWithError %@",errorMsg);
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}



- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    TCSTART
    //    int repliesCount = [selectedRecentActivity.repliesCount intValue];
    //    if (repliesCount > 1) {
    //        if ([superViewRef isKindOfClass:[RecentActivityTable class]]) {
    //            RecentActivityTable *table = (RecentActivityTable *)superViewRef;
    //            [table reloadData];
    //        }
    //    }
    [super viewWillDisappear:animated];
    TCEND
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    
    @try {
        if ([touch.view isKindOfClass:[UIButton class]]) {      //change it to your condition
            return NO;
        }
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat)getheightForRowInSection:(NSIndexPath *)indexPath {
    
    @try {
        CGFloat commentorNameHeight = 0;
        CGFloat commentStrHeight = 0;
        NSArray *replies_Arry = selectedRecentActivity.repliesArray;
        if ([replies_Arry isKindOfClass:[NSArray class]] && replies_Arry.count > indexPath.row - 1) {
            CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
            
            if (iPad) {
                CGFloat nameWidth = ((708)- (5 + 40 + 23 + 40));
                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                
                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                
                return commentorNameHeight + commentStrHeight + 30 + 15 ;//"30" is for shwoing the time of review and 15 for spacing.
            } else {
                CGFloat nameWidth = (280 - (5 + 25 + 10 + 5));
                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                
                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                
                
                return commentorNameHeight + commentStrHeight + 15.0f ;//"15" is for shwoing the time of review.
            }
        } else {
            return 0.0f;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)likeReview:(id)sender event:(UIEvent *)event {
    @try {
        if([self isNotNull:liveFeedTblSlctd_IndexPath]) {
            [superViewRef sendLikeRequest:liveFeedTblSlctd_IndexPath];
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            [self sendLikeRequest:selectedRecentActivity];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)sendLikeRequest:(RecentActivity *)recentActivity {
    @try {
        NSString *reviewId;
        CPEventType eventType;
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
            reviewId = [recentActivity.commentableId stringValue];
        } else {
            eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
            reviewId = [recentActivity.eventId stringValue];
        }
        [appDelegate likedReviewWithReviewId:reviewId ofType:eventType withIndexPath:nil callbackObject:self];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Like A Review Request Delegate Methods
- (void)didFinishedLikedReviewRequest:(NSDictionary *)results {
    
    [appDelegate hideNetworkIndicator];
    @try {
        //   NSLog(@"didFinishedLikedReviewRequest %@",results);
        if ([self isNotNull:results] && [self isNotNull:[results objectForKey:@"likable_id"]])
        {
            
            RecentActivity *recentActivity = selectedRecentActivity;
            NSArray *likesRecentActivitiesArray;
            if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                likesRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
            } else {
                likesRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
            }
            
            [self IncrementLikesCountOfRecentActivitys:likesRecentActivitiesArray];
            [appDelegate saveContext];
            //            [self reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
            [comment_TableView reloadData];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)IncrementLikesCountOfRecentActivitys:(NSArray *)recentActivitysArray {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            int likes_count = [recentActivity.likesCount intValue];
            likes_count++;
            NSNumber *like_count = [NSNumber numberWithInt:likes_count];
            recentActivity.likesCount = like_count;
            recentActivity.commentableLikesCount = like_count;
        }
    }
    
    TCEND
}
- (void)didFailedToPostLikeWithError:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        // Return the number of rows in the section.
        if ([self isNotNull:selectedRecentActivity] && [self isNotNull:selectedRecentActivity.repliesArray]) {
            return [selectedRecentActivity.repliesArray count] + 1;
        }
        return 1;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    // NSLog(@"heightForHeader :%f InSection %d",sectionHeght_float,section);
    return 1.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row == 0) {
        NSLog(@"review cell height is %f",sectionHeght_float);
        return sectionHeght_float;
    } else {
        NSInteger commentCellHeight = [self getheightForRowInSection:indexPath]+(iPad?0:5);
        //  NSLog(@"comment cell height is %d",commentCellHeight);
        return commentCellHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"CellCalled!");
    UITableViewCell *cell = nil;
    UIImageView *arrowImageView = nil;
    UILabel *lblCommentorName = nil;
    UILabel *lblComment = nil;
    UIImageView *userImageView = nil;
    UIImageView *lockImageview = nil;
	UILabel *commentTimeLabel =nil;
    @try {
        static NSString *MyIdentifier = @"MyIdentifier"; //For displaying comments
        static NSString *reviewIdentifier = @"reviewIdentifier";
        
        CGFloat commentorNameHeight;
        CGFloat commentStrHeight;
        NSArray *replies_Arry;
        
        int likesCount;
        NSString   *deviceName;
        
        if (indexPath.row == 0) {
            
            if ([self isNotNull:selectedRecentActivity]) {
                
                NSString *eventType = nil;
                
                ReviewTableCell *review_cell = [tableView dequeueReusableCellWithIdentifier:reviewIdentifier];
                if (review_cell == nil) {
                    review_cell = [[ReviewTableCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reviewIdentifier];
                    [review_cell addSubviewToTableCell:self];
                }
                //reset the photoUrl and its height so that previous values will be erased.
                review_cell.photoUrl_str = nil;
                review_cell.photoheight_float = 0.0f;
                
                eventType = selectedRecentActivity.eventType;
                
                if ([self isNotNull:selectedRecentActivity.reviewText]) {
                    review_cell.reviewText_str = selectedRecentActivity.reviewText;
                } else {
                    review_cell.reviewText_str = @"";
                }
                
                if ([self isNotNull:selectedRecentActivity.userAvatarUrl]) {
                    review_cell.reviewerAvatarUrl_str = selectedRecentActivity.userAvatarUrl;
                } else {
                    review_cell.reviewerAvatarUrl_str = @"";
                }
                
                deviceName = selectedRecentActivity.deviceName;
                likesCount = [selectedRecentActivity.likesCount intValue];
                review_cell.rateImage = nil;
                review_cell.locationImgview.hidden = YES;
                if ([eventType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
                    review_cell.isPrivatePlug = YES;
                } else {
                    review_cell.isPrivatePlug = NO;
                }
                
                if([eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame) {
                    
                    if ([self isNotNull:selectedRecentActivity.locationName]) {
                        review_cell.reviewerName_str = selectedRecentActivity.locationName;
                    } else {
                        review_cell.reviewerName_str = @"";
                    }
                    if ([self isNotNull:selectedRecentActivity.businessAvatarUrl]) {
                        review_cell.reviewerAvatarUrl_str = selectedRecentActivity.businessAvatarUrl;
                    } else {
                        review_cell.reviewerAvatarUrl_str = @"";
                    }
                    review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-business";
                    
                } else if([eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                    if ([self isNotNull:selectedRecentActivity.otherUserAvatarUrl]) {
                        review_cell.reviewerAvatarUrl_str = selectedRecentActivity.otherUserAvatarUrl;
                    } else {
                        review_cell.reviewerAvatarUrl_str = @"";
                    }
                    
                    if ([self isNotNull:selectedRecentActivity.otherUserName]) {
                        review_cell.reviewerName_str = selectedRecentActivity.otherUserName;
                    } else {
                        review_cell.reviewerName_str = @"";
                    }
                    
                    if ([selectedRecentActivity.commentType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame) {
                        if ([self isNotNull:selectedRecentActivity.locationName]) {
                            review_cell.reviewerName_str = selectedRecentActivity.locationName;
                        } else {
                            review_cell.reviewerName_str = @"";
                        }
                        review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-business";
                    } else {
                        review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-user";
                    }
                    if ([selectedRecentActivity.commentType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
                        review_cell.isPrivatePlug = YES;
                    } else {
                        review_cell.isPrivatePlug = NO;
                    }
                    
                } else  {
                    if ([eventType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
                        
                        if ([self isNotNull:selectedRecentActivity.starsCount] && [selectedRecentActivity.starsCount intValue] > 0) {
                            
                            review_cell.rateImage = [appDelegate getImageForRating:[selectedRecentActivity.starsCount intValue]];
                        } else {
                            review_cell.rateImage = nil;
                        }
                        
                        if ([selectedRecentActivity.onLocation boolValue]) {
                            review_cell.locationImgview.hidden = NO;
                        }
                    }
                    
                    if ([self isNotNull:selectedRecentActivity.userName]) {
                        review_cell.reviewerName_str = selectedRecentActivity.userName;
                    } else {
                        review_cell.reviewerName_str = @"";
                    }
                    
                    review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-user";
                }
                
                CGFloat diff;
                if (iPad) {
                    diff = 20;
                } else {
                    diff = 10;
                }
                
                if ([self isNotNull:review_cell.reviewerName_str] && review_cell.reviewerName_str.length > 0) {
                    review_cell.reviewerNameHeight_float = [appDelegate getStringHeight:review_cell.reviewerName_str withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff + 30) withFontSize:titleFontSize withFontName:titleFontName];
                } else {
                    review_cell.reviewerNameHeight_float = 0.0f;
                }
                if ([self isNotNull:review_cell.reviewText_str] && review_cell.reviewText_str.length > 0) {
                    
                    review_cell.reviewTextHeight_float = [appDelegate getStringHeight:review_cell.reviewText_str withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff) withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                } else {
                    review_cell.reviewTextHeight_float = 0.0f;
                }
                
                
                if ([self isNotNull:review_cell.rateImage]) {
                    review_cell.rateImageViewHieght_float = CELL_RATEIMAGEVIEWHEIGHT;
                } else {
                    review_cell.rateImageViewHieght_float = 0.0f;
                }
                // }
                review_cell.likeCount_str = [NSString stringWithFormat:@"%d",likesCount];
                
                review_cell.commentCount_str = [NSString stringWithFormat:@"%d",[self getRepliesCount]];
                
                if ([self isNotNull:selectedRecentActivity.date]) {
                    review_cell.time_str = [NSString stringWithFormat:@"%@",[appDelegate relativeDateString:selectedRecentActivity.date]];
                } else {
                    review_cell.time_str = @"";
                }
                review_cell.hideCommentButton = YES;
                
                if ([eventType caseInsensitiveCompare:@"review"] == NSOrderedSame || [eventType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
                    NSString *photoString = selectedRecentActivity.photoUrlString;
                    if ([self isNotNull:photoString] && [photoString rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                        review_cell.photoheight_float = CELL_PLUGPHOTOHEIGHT;
                        //NSString *photo_url = [appDelegate getPlugPhotoUrlString:photoString];
                        NSString *photo_url = photoString;
                        review_cell.photoUrl_str =  photo_url;
                        NSLog(@"plug photo url string is %@ for review:%@",review_cell.photoUrl_str,review_cell.reviewText_str);
                        review_cell.postedImage = nil;
                    } else {
                        review_cell.photoheight_float = 0.0;
                        review_cell.photoUrl_str = @"";
                        review_cell.postedImage = nil;
                    }
                } else {
                    review_cell.photoheight_float = 0.0;
                    review_cell.photoUrl_str = @"";
                    review_cell.postedImage = nil;
                }
                
                
                [review_cell setData];
                review_cell.backgroundColor = [UIColor clearColor];
                review_cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                int replies = [self getRepliesCount];
                if (replies > 0 && CURRENT_DEVICE_VERSION >= 7.0) {
                    review_cell.lineLabel.hidden = NO;
                } else {
                    review_cell.lineLabel.hidden = YES;
                }
                return review_cell;
            }
        } else { //comments
            cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
            UIImageView *backgroundImgView = nil;
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
                
                backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
                backgroundImgView.tag = 2000;
                backgroundImgView.frame = CGRectMake( (iPadCOMMENTCELLORIGINX) - 15, 0, 708, 50);
                [cell.contentView addSubview:backgroundImgView];
                
                arrowImageView = [[UIImageView alloc]initWithFrame:CGRectMake((iPadCOMMENTCELLORIGINX) + 0, 3, 23, 32)];
                arrowImageView.tag = 3;
                [cell.contentView addSubview:arrowImageView];
                
                //Commentor Name
                lblCommentorName = [[UILabel alloc]init];
                lblCommentorName.numberOfLines = 0;
                lblCommentorName.tag = 4;
                lblCommentorName.opaque = YES;
                lblCommentorName.textColor = [UIColor whiteColor];
                lblCommentorName.backgroundColor = [UIColor clearColor];
                lblCommentorName.font = [UIFont fontWithName:titleFontName size:titleFontSize];
                [cell.contentView addSubview:lblCommentorName];
                
                //Comment
                lblComment = [[UILabel alloc]init];
                lblComment.numberOfLines = 0;
                lblComment.opaque =  YES;
                lblComment.tag = 5;
                lblComment.backgroundColor = [UIColor clearColor];
                lblComment.textColor = [UIColor whiteColor];
                lblComment.font = [UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize];
                [cell.contentView addSubview:lblComment];
                
                //Commentor Image
                userImageView = [[UIImageView alloc]initWithFrame:CGRectMake((iPadCOMMENTCELLORIGINX) + backgroundImgView.frame.size.width - 60, 10, 40, 40)];
                userImageView.opaque = YES;
                userImageView.tag = 6;
                userImageView.layer.cornerRadius = 3.0f;
                userImageView.layer.masksToBounds = YES;
                [cell.contentView addSubview:userImageView];
                
                lockImageview = [[UIImageView alloc]init];
                lockImageview.layer.cornerRadius = 6.0f;
                lockImageview.layer.masksToBounds = YES;
                lockImageview.opaque = YES;
                lockImageview.tag = -6;
                [cell.contentView addSubview:lockImageview];
                //				if ([self isNotNull:selectedRecentActivity.date]) {
                //					review_cell.time_str = [NSString stringWithFormat:@"%@",[appDelegate relativeDateString:selectedRecentActivity.date]];
                //                } else {
                //                    review_cell.time_str = @"";
                //                }
                
				//TODO KANAK
				commentTimeLabel = [[UILabel alloc]init];
                commentTimeLabel.layer.cornerRadius = 6.0f;
                commentTimeLabel.layer.masksToBounds = YES;
                commentTimeLabel.opaque = YES;
                commentTimeLabel.tag = -77;
				commentTimeLabel.textColor = [UIColor whiteColor];
				commentTimeLabel.backgroundColor = [UIColor clearColor];
				commentTimeLabel.font = [UIFont fontWithName:descriptionTextFontName size:dateFontSize];
				commentTimeLabel.textAlignment = NSTextAlignmentRight;
                [cell.contentView addSubview:commentTimeLabel];
                //				if (<#condition#>) {
                //					<#statements#>
                //				}
                if (!iPad) {
                    backgroundImgView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + 0, 0, appDelegate.window.frame.size.width-20, 60);
                    arrowImageView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + 5, 3, 10, 10);
                    userImageView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + appDelegate.window.frame.size.width-55, 5, 23, 23);
                }
            }
            if (!arrowImageView)
                arrowImageView = (UIImageView *)[cell.contentView viewWithTag:3];
            if (!lblCommentorName)
                lblCommentorName = (UILabel *) [cell.contentView viewWithTag:4];
            if (!lblComment)
                lblComment = (UILabel *)[cell.contentView viewWithTag:5];
            if (!userImageView)
                userImageView = (UIImageView *) [cell.contentView viewWithTag:6];
			if (!lockImageview)
                lockImageview = (UIImageView *) [cell.contentView viewWithTag:-6];
            
			if (!commentTimeLabel)
                commentTimeLabel = (UILabel *) [cell.contentView viewWithTag:-77];
            
			if (!backgroundImgView) {
                backgroundImgView = (UIImageView *) [cell.contentView viewWithTag:2000];
            }
            
            replies_Arry = selectedRecentActivity.repliesArray;
            CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
            NSInteger commentCellHeight = [self getheightForRowInSection:indexPath]+(iPad?0:5);
            backgroundImgView.frame = CGRectMake(backgroundImgView.frame.origin.x, backgroundImgView.frame.origin.y, backgroundImgView.frame.size.width, commentCellHeight);
            
            if ([self isNotNull:reply]) {
                if (iPad) {
                    CGFloat nameWidth = (708- (5 + 40 + arrowImageView.frame.size.width + 40));
                    CGFloat commentNCommenterNameOriginX = (5 + arrowImageView.frame.size.width + 10);
                    
                    commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                    commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                    //}
                    lblCommentorName.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + commentNCommenterNameOriginX,5,nameWidth,MAX(commentorNameHeight, 0.0f));
                    
                    lblComment.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + commentNCommenterNameOriginX,lblCommentorName.frame.size.height + 10,nameWidth,MAX(commentStrHeight, 0.0f));
                    
                    lockImageview.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + (708 - 40), commentCellHeight-40, 21, 25);
					commentTimeLabel.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + (708 - 40)-210, commentCellHeight-40+2 , 200, 25);
                } else {
                    CGFloat nameWidth = ((appDelegate.window.frame.size.width-40) - (5 + 25 + arrowImageView.frame.size.width + 5));
                    CGFloat commentNCommenterNameOriginX = (5 + arrowImageView.frame.size.width + 2);
                    
                    commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                    commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                    
                    lblCommentorName.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) +commentNCommenterNameOriginX,2,nameWidth,MAX(commentorNameHeight, 0.0f));
                    
                    lblComment.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) +commentNCommenterNameOriginX,lblCommentorName.frame.size.height + 2,nameWidth,MAX(commentStrHeight, 0.0f));
                    lockImageview.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + (appDelegate.window.frame.size.width-40), commentCellHeight-20+1, 9, 14);
                    commentTimeLabel.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + (appDelegate.window.frame.size.width-40)-130, commentCellHeight-20+3, 125, 14);
                }
				//TODO KANAK
                commentTimeLabel.text = [appDelegate relativeDateString:reply.occurredTime];
                //				NSLog(@"Comment occured time: %@",[appDelegate relativeDateString:reply.occurredTime]);
                lblCommentorName.text = reply.displayName;
                
                lblComment.text = reply.text;
                
                lockImageview.image = [UIImage imageNamed:@"commentLock"];
                
                if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"Review"] != NSOrderedSame) {
                    lockImageview.hidden = NO;
                } else {
                    lockImageview.hidden = YES;
                }
                
                arrowImageView.image = [UIImage imageNamed:@"arrow_f"];
                
                //NSLog(@"AvatarPath:%@:%@",reply.avatarURL,reply.avatarURLDictionary);
                
                //if([[reply.avatarURL absoluteString] rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound)
                if([[reply.avatarURLDictionary objectForKey:@"thumb"] rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound)
                {
                    //[userImageView setImageWithURL:reply.avatarURL];
                   
                    [userImageView setImageWithURL:[NSURL URLWithString:[reply.avatarURLDictionary objectForKey:@"thumb"]]];
                } else if ([[reply.avatarURL absoluteString] rangeOfString:@"avatar-user" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                    
                    userImageView.image = [UIImage imageNamed:@"default-avatar-user"];
                    
                } else if([[reply.avatarURL absoluteString] rangeOfString:@"avatar-business" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                    
                    userImageView.image = [UIImage imageNamed:@"default-avatar-business"];
                }
            }
            
            [backgroundImgView setImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
            if (indexPath.row == replies_Arry.count) {
                [appDelegate setMaskTo:backgroundImgView byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(5.0, 5.0)];
            } else {
                [appDelegate setMaskTo:backgroundImgView byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(0.0, 0.0)];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor clearColor];
            cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
            
            return cell;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if([self isNotNull:liveFeedTblSlctd_IndexPath])
        {
            NSIndexPath *selectedindexPath = [NSIndexPath indexPathForRow:indexPath.row inSection:liveFeedTblSlctd_IndexPath.section];
            return [self canEditRowAtIndexPath:selectedindexPath];
        }
        else
        {
            return [self canEditRowAtIndexPath:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        BOOL isRowEditable = NO;
        
        if([selectedRecentActivity.eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame || [selectedRecentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [selectedRecentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [selectedRecentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame ||  [selectedRecentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame) { //check the event type
            return NO;
        } else if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"review"] == NSOrderedSame || [selectedRecentActivity.eventType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
            int likes_count = [selectedRecentActivity.likesCount intValue];
            int replies_count = [selectedRecentActivity.repliesCount intValue];
            if(indexPath.row == 0) {
                if((appDelegate.userProfileDataModel.userId.intValue == [selectedRecentActivity.userId intValue]) && replies_count == 0 && likes_count == 0)
                    return YES;
            } else if (replies_count > 0 && indexPath.row == 1) {
                CPReply *rply = [selectedRecentActivity.repliesArray objectAtIndex:indexPath.row - 1];
                if(rply.userId.intValue == appDelegate.userProfileDataModel.userId.intValue) {
                    isRowEditable = YES;
                }
            }
        } else if ([selectedRecentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame && [selectedRecentActivity.commentType caseInsensitiveCompare:@"broadcast"] != NSOrderedSame) {
            int likes_count = [selectedRecentActivity.likesCount intValue];
            int replies_count = [selectedRecentActivity.commentableCommentsCount intValue];
            if(indexPath.row == 0) {
                if((appDelegate.userProfileDataModel.userId.intValue == [selectedRecentActivity.otherUserId intValue]) && replies_count == 0 && likes_count == 0)
                    return YES;
            } else if (replies_count > 0 && indexPath.row == 1) {
                CPReply *rply = [selectedRecentActivity.repliesArray objectAtIndex:indexPath.row - 1];
                if(rply.userId.intValue == appDelegate.userProfileDataModel.userId.intValue) {
                    isRowEditable = YES;
                }
            }
        }
        
        return isRowEditable;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (editingStyle == UITableViewCellEditingStyleDelete)
        {
            if([self isNotNull:liveFeedTblSlctd_IndexPath]){
                NSIndexPath *selectedindexPath = [NSIndexPath indexPathForRow:indexPath.row inSection:liveFeedTblSlctd_IndexPath.section];
                [superViewRef deleteReviewOrCommentAtIndexPath:selectedindexPath];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                if (indexPath.row == 0 ) { //row at zero location is always review.
                    //  NSLog(@"delete review");
                    [self deleteReview:indexPath];
                } else {
                    //  NSLog(@"delete table row");
                    [self deleteComment:indexPath];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark Deleting Comment ===========================================
- (void)deleteComment:(NSIndexPath *)indexPath {
    [appDelegate showNetworkIndicator];
    [appDelegate showActivityIndicatorInView:appDelegate.window];
    @try {
        NSNumber *commetnId = nil;
        NSNumber *eventId;
        CPEventType eventType;
        RecentActivity *recentActivity = selectedRecentActivity;
        
        if ([self isNotNull:recentActivity]) {
            if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
                eventId = [NSNumber numberWithInt:[recentActivity.commentableId intValue]];
            } else {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
                eventId = recentActivity.eventId;
            }
            
            if([self isNotNull:recentActivity.repliesArray] && [recentActivity.repliesArray count] > indexPath.row - 1) {
                CPReply *reply = [recentActivity.repliesArray objectAtIndex:indexPath.row - 1];
                commetnId = reply.replyId;
            }
        }
        [appDelegate requestForDeletedComment:commetnId onReview:eventId atIndexPath:indexPath withCallbackObject:self andEventType:eventType];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)deleteReview:(NSIndexPath *)indexPath {
    @try {
        [appDelegate showNetworkIndicator];
        [appDelegate showActivityIndicatorInView:appDelegate.window];
        
        NSNumber *reviewId = nil;
        NSNumber *userId = nil;
        
        RecentActivity *recentActivity = nil;
        CPEventType eventType;
        
        if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
            reviewId = [NSNumber numberWithInt:[recentActivity.commentableId intValue]];
            userId = [NSNumber numberWithInt:[recentActivity.otherUserId intValue]];
        } else {
            eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
            reviewId = recentActivity.eventId;
            userId = [NSNumber numberWithInt:[recentActivity.userId intValue]];
        }
        [appDelegate requestForDeleteReview:reviewId onUser:userId atIndex:indexPath withCallbackObject:self andEventType:eventType];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFinishedDeletingComment:(NSDictionary *)results {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:[results objectForKey:@"indexPath"]]) {
            NSIndexPath *indexPath = [results objectForKey:@"indexPath"];
            {
                RecentActivity *recentActivity = selectedRecentActivity;
                if ([self isNotNull:recentActivity]) {
                    NSMutableArray *replies_Arry = [[NSMutableArray alloc] initWithArray:recentActivity.repliesArray];
                    if ([self isNotNull:replies_Arry] && replies_Arry.count > indexPath.row - 1) {
                        
                        CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
                        
                        /** Deleting if the same comment is existing in database with replyId to avoid the dublication
                         */
                        if ([self isNotNull:reply]) {
                            RecentActivity *commentRecentActvity = [[appDelegate getRecentActivityEntityByEventId:reply.replyId] objectAtIndex:0];
                            [appDelegate removeRecentActivityObjectFromDatabase:commentRecentActvity];
                            //[locDataModel_Arr removeObject:commentRecentActvity];
                        }
                        
                        /** Changing attributes of RecentActivity entities where activityId matches
                         */
                        NSArray *commentsRecentActivitiesArray;
                        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                            commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
                        } else {
                            commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
                        }
                        
                        [self removeReplyAndDecrementCommentsCountOfRecentActivitys:commentsRecentActivitiesArray andIndexPath:indexPath];
                        
                        [appDelegate saveContext];
                        comment_TableView.frame = CGRectMake(comment_TableView.frame.origin.x, comment_TableView.frame.origin.y, comment_TableView.frame.size.width, [self getHeightOfTable]);
                        
                        chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, comment_TableView.frame.origin.y + comment_TableView.frame.size.height - 10, chatBarView.frame.size.width, chatBarView.frame.size.height);
                        cmt_TextView.text=@"";
                        [comment_TableView reloadData];
                    }
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToDeleteComment:(NSString *)errorMsg {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)removeReplyAndDecrementCommentsCountOfRecentActivitys:(NSArray *)recentActivitysArray andIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            NSMutableArray *replies_Arry = [[NSMutableArray alloc] initWithArray:recentActivity.repliesArray];
            int repliesCount = [recentActivity.repliesCount intValue];
            
            if ([self isNotNull:replies_Arry] && replies_Arry.count > indexPath.row - 1) {
                
                [replies_Arry removeObjectAtIndex:indexPath.row - 1];       //remove the deleted row from replies array
                recentActivity.repliesArray = replies_Arry;//set the replies array as an object with same key "replies"
                repliesCount = repliesCount - 1;
                
                recentActivity.repliesCount = [NSNumber numberWithInt:repliesCount];
                recentActivity.commentableCommentsCount = [NSNumber numberWithInt:repliesCount];
            }
        }
    }
    
    TCEND
}

- (void)didFinishedDeletingReview:(NSDictionary *)results {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]])
        {
            //NSIndexPath *indexPath = [results objectForKey:@"indexPath"];
            RecentActivity *recentActivity = selectedRecentActivity;
            NSArray *recentActivitesArray;
            if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                recentActivitesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
            } else {
                recentActivitesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
            }
            
            for (RecentActivity *activity in recentActivitesArray) {
                [appDelegate removeRecentActivityObjectFromDatabase:activity];
            }
            [appDelegate saveContext];
            //[locDataModel_Arr removeObjectsInArray:recentActivitesArray];
            comment_TableView.frame = CGRectMake(comment_TableView.frame.origin.x, comment_TableView.frame.origin.y, comment_TableView.frame.size.width, [self getHeightOfTable]);
            
            chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, comment_TableView.frame.origin.y + comment_TableView.frame.size.height - 10, chatBarView.frame.size.width, chatBarView.frame.size.height);
            [comment_TableView reloadData];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToDeleteReview:(NSString *)errorMsg {
    @try {
        //        [appDelegate hideNetworkIndicator];
        TCSTART
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        TCEND
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}




#pragma mark - Table view delegate
-(NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //    NSLog(@"CommentViewController willSelectRowAtIndexPath");
    return indexPath;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)scrollToBottomAnimated:(BOOL)animated {
    
    @try {
        NSInteger replies_count = [selectedRecentActivity.repliesArray count];
        if (replies_count > 0) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:replies_count-1 inSection:0];
            [comment_TableView scrollToRowAtIndexPath:indexPath
                                     atScrollPosition:UITableViewScrollPositionTop animated:animated];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)rearrangeTable {
    @try {
        if ([cmt_TextView resignFirstResponder]) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.3];
            [comment_TableView setFrame:CGRectMake(self.view.frame.origin.x, COMMENTVIEW_TABLEORIGINY, comment_TableView.frame.size.width, comment_TableView.frame.size.height + chatBarMovedHeight + 10)];
            chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, chatBarView.frame.origin.y + chatBarMovedHeight, chatBarView.frame.size.width, chatBarView.frame.size.height);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)keyBoardHideNotification {
    [self rearrangeTable];
}

#pragma mark TextView Delegate methods
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    
    tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard:)];
    tapGesture.delegate = self;
    tapGesture.numberOfTapsRequired = 1;
    [comment_TableView addGestureRecognizer:tapGesture];
    return YES;
}
- (void)textFieldDidReturnWithIndexPath:(NSIndexPath*)indexPath {
    TCSTART
    NSLog(@"textFieldDidReturnWithIndexPath");
    TCEND
}
- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    @try {
        //        send_Btn.enabled = YES;
        iskeyBoardEnabled = TRUE;
        
        //        send_Btn.hidden = NO;
        if ((chatBarView.frame.size.height + chatBarView.frame.origin.y) > (self.view.frame.size.height - KEYBOARD_PORTRAIT_HEIGHT)) {
            chatBarMovedHeight = (chatBarView.frame.size.height + chatBarView.frame.origin.y) - (self.view.frame.size.height - KEYBOARD_PORTRAIT_HEIGHT-(CURRENT_DEVICE_VERSION>=7.0?22:0));
            
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.3];
            
            [comment_TableView setFrame:CGRectMake(self.view.frame.origin.x, COMMENTVIEW_TABLEORIGINY, comment_TableView.frame.size.width, comment_TableView.frame.size.height - (chatBarMovedHeight + 10))];
            chatBarView.frame = CGRectMake(chatBarView.frame.origin.x, chatBarView.frame.origin.y - chatBarMovedHeight, chatBarView.frame.size.width, chatBarView.frame.size.height);
            
            [UIView commitAnimations];
            [self scrollToBottomAnimated:YES];
        }
        int len = 140 - textView.text.length;
        statusLabel.text= [NSString stringWithFormat:@"%d | %d remaining", textView.text.length,len];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    @try {
        if ([text isEqualToString:@"\n"]) {
            NSLog(@"Keyboard dismiss");
            [textView resignFirstResponder];
            return NO;
        }
        //        BOOL returnValue = NO;
        int len = 140 - textView.text.length;
        if (len <= 0 && ![text isEqualToString:@""]) {
            return NO;
        }
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(CGFloat)getheightForHeaderForRecentActivity:(RecentActivity*)recentActivity {
    
    @try {
        
        //        if ([recentActivity.rowHeight floatValue] > 0.0) {
        //            return [recentActivity.rowHeight floatValue];
        //        } else {
        int rowHeight;
        if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame) {
            
            CGFloat diff;
            CGFloat dateLabelHeight;
            CGFloat textLayerWidth;
            CGFloat nameHeight;
            if (iPad) {
                diff = 10;
                dateLabelHeight = 30;
                textLayerWidth = 660;
                nameHeight = 30;
            } else {
                diff = 5;
                dateLabelHeight = 20;
                textLayerWidth = 255;
                nameHeight = 20;
            }
            
            NSMutableAttributedString *mAttrbtdStr = [self createAttributedStringForEntity:recentActivity];
            CGSize size = [appDelegate getFrameSizeForAttributedString:mAttrbtdStr withWidth:textLayerWidth];
            recentActivity.attributedStringHeight = [NSNumber numberWithFloat:size.height];
            rowHeight = size.height + nameHeight + (diff * 3) + dateLabelHeight;
        }else if([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame){
            //
            //            MessageDataModel *dataModal = [eventsArray objectAtIndex:indexPath.row];
            CGSize nameSize;
            if ([self isNotNull:recentActivity.title]) {
                nameSize = [recentActivity.title sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            }
            CGSize descptnSize = [recentActivity.descriptionMsg sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            CGFloat gaps;
            CGFloat heightOfTheRow;
            if (iPad) {
                gaps = 30;
                heightOfTheRow = 74;
            } else {
                gaps = 15;
                heightOfTheRow = 46;
            }
            if (nameSize.height + descptnSize.height + gaps > heightOfTheRow) {
                //                return nameSize.height + descptnSize.height + gaps;
                rowHeight =nameSize.height + descptnSize.height + gaps;
            } else {
                //                return heightOfTheRow;
                rowHeight = heightOfTheRow;
            }
            //
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) {
            if (iPad) {
                rowHeight = 65;
            } else {
                rowHeight = 55;
            }
        } else {
            rowHeight = [self reviewRPrivateMessageRBroadCastHeightOfRecentActivity:recentActivity];
        }
        
        if ([self isNotNull:recentActivity.starsCount] && recentActivity.starsCount.intValue > 0) {
            rowHeight = rowHeight + CELL_RATEIMAGEVIEWHEIGHT;
        }
        recentActivity.rowHeight = [NSNumber numberWithFloat:rowHeight];
        [appDelegate saveContext];
        return rowHeight;
        //        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat)reviewRPrivateMessageRBroadCastHeightOfRecentActivity:(RecentActivity *)recentActivity {
    TCSTART
    CGFloat reviewerNameHeight = 0.0f;
    CGFloat reviewStrHeight = 0.0f;
    CGFloat photoHeight = 0.0f;
    CGFloat diff;
    if (iPad) {
        diff = 20;
    } else {
        diff = 10;
    }
    NSString *name = nil;
    NSString *review = nil;
    if ([self isNotNull:recentActivity]) {
        review = recentActivity.reviewText;
        name = recentActivity.locationName;
        if ([self isNotNull:name])
            //replace appDelegate with self.locationDelegate for static libraries
            reviewerNameHeight = [appDelegate getStringHeight:name withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff + 30) withFontSize:titleFontSize withFontName:titleFontName];
        if ([self isNotNull:review])
            reviewStrHeight = [appDelegate getStringHeight:review withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff) withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
        
        if ([self isNotNull:recentActivity.photoUrlString]) {
            photoHeight = CELL_PLUGPHOTOHEIGHT;
        }
    }
    
    if (reviewerNameHeight == 0.0f)
        reviewerNameHeight = 15.0f;
    
    if (photoHeight > 0.0f)
        photoHeight += 5.0f;
    
    if ([recentActivity.starsCount intValue] > 0) {
        reviewStrHeight += 5.0f;
    }
    
    if ([recentActivity.starsCount intValue] <= 0 && reviewStrHeight == 0) {
        reviewStrHeight = (HEADER_MARGIN * 3);
    }
    
    if (iPad) {
        return reviewerNameHeight + reviewStrHeight + photoHeight + 30.0f + 50.0f;//"50" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    } else {
        return reviewerNameHeight + reviewStrHeight + photoHeight  + 25.0f + 30.0f;//"25" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    }
    TCEND
}
#pragma mark Table Cell Data Support
- (NSMutableAttributedString *)createAttributedStringForEntity:(RecentActivity *)recentActivity
{
    //@autoreleasepool {
    @try {
        NSMutableString *rowString = [[NSMutableString alloc]init];
        NSMutableArray *boldRangesMutableArray = [[NSMutableArray alloc]init];
        NSRange boldStrRange  = NSMakeRange(0, 0);
        NSRange boldStr2Range = NSMakeRange(0, 0);
        NSRange boldStr3Range = NSMakeRange(0, 0);
        
        
        if ([recentActivity.eventType caseInsensitiveCompare:@"Special"] == NSOrderedSame && [self isNotNull:recentActivity.rankNamesArray] && [recentActivity.rankNamesArray count] > 0) {
            
            //append the formated string
            [rowString appendString:[NSString stringWithFormat:@"Posted a new Reward for %@: \"%@\"",[recentActivity.rankNamesArray  objectAtIndex:0],recentActivity.specialTilte]];
            //get the range
            if ([self isNotNull:[recentActivity.rankNamesArray objectAtIndex:0]]) {
                boldStrRange = [rowString rangeOfString:[recentActivity.rankNamesArray objectAtIndex:0]];
            }
            if ([self isNotNull:recentActivity.specialTilte]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.specialTilte];
            }
        }
        
        
        //User Activities----------
        
        else if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame && [self isNotNull:recentActivity.locationName]) {
            [rowString appendString:[NSString stringWithFormat:@"Favorited %@",recentActivity.locationName ?: @""]];
            boldStrRange = [rowString rangeOfString:recentActivity.locationName];
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"Like"] == NSOrderedSame) {
            if ([self isNull:recentActivity.otherUserId] || [self isNull:recentActivity.userId]) {
                if ([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Liked message from %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                } else if ([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.userName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        if ([self isNotNull:recentActivity.userName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.userName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
            //            if ([self isNotNull:recentActivity.likableText]) {
            //                boldStr3Range = [rowString rangeOfString:recentActivity.likableText];
            //            }
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            if ([self isNull:recentActivity.userId] || [self isNull:recentActivity.otherUserId]) {
                if([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                    if ([self isNotNull:recentActivity.locationName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.locationName]];
                    }
                } else if([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                        if ([self isNotNull:recentActivity.otherUserName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                    
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"" ,recentActivity.locationName ?: @""]];
                    
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Userrank"] == NSOrderedSame) {
            if ([self isNotNull:recentActivity.rankName]) {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    [rowString appendString:[NSString stringWithFormat:@"%@ earned %@ rank at %@",recentActivity.otherUserName,recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                } else {
                    [rowString appendString:[NSString stringWithFormat:@"You earned %@ rank at %@",recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                }
                
                boldStrRange = [rowString rangeOfString:recentActivity.rankName];
                
                if ([self isNotNull:recentActivity.locationName]) {
                    boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
                }
            }
            //                }
            //            }
        }
        
        if(boldStrRange.location != NSNotFound && boldStrRange.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStrRange]];
        }
        
        if(boldStr2Range.location != NSNotFound && boldStr2Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr2Range]];
        }
        
        if(boldStr3Range.location != NSNotFound && boldStr3Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr3Range]];
        }
        
        if([self isNotNull:rowString]) {
            return [appDelegate getAttributedStringForString:rowString withBoldRanges:boldRangesMutableArray WithBoldFontName:titleFontName withNormalFontName:descriptionTextFontName];
        } else {
            return nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)textViewDidChange:(UITextView *)textView {
    @try {
        
        int len = 140 - textView.text.length;
        statusLabel.text= [NSString stringWithFormat:@"%d | %d remaining", textView.text.length,len];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    iskeyBoardEnabled = FALSE;
    NSLog(@"textViewDidEndEditing");
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}


@end
