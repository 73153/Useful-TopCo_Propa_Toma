//
//  NotificationsService.h
//  BeefOBrady
//
//  Created by Aruna on 21/01/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ApplicationConstants.h"

//write a protocol to respond to delegate call appropriately
@protocol RecentActivityServiceDelegate <NSObject>

@required
-(void)didFinishedStreamRequest:(NSDictionary *)results;
-(void)didFailToGetStreamWithError:(NSString *)errorMsg;

-(void)didFinishedSendingMostRecentViewedNotification;
-(void)didfailedtoSendMostRecentViewedNotificationOccuredAt:(NSString *)errorMsg;
@end
@class AppDelegate;
@interface RecentActivityService : NSObject <CPStreamServiceDelegate> {
    NSString *user_id;
    NSString *auth_token;
    NSString *request_Url;
    NSString *review_id;
    NSString *apiKey;
    
    id caller_;
    
    BOOL isRequestForRefresh;
    AppDelegate *appDelegate;
}
@property(nonatomic, strong) NSString *user_id;
@property(nonatomic, strong) NSString *auth_token;
@property(nonatomic, strong) NSString *request_Url;
@property(nonatomic, strong) NSString *review_id;
@property(nonatomic, strong) NSString *apiKey;
@property(nonatomic, readwrite) BOOL isRequestForRefresh;

-(id)initWithCaller:(id)caller;
-(void)getLiveStream:(NSInteger )page perPage:(NSInteger )per_page;
-(void)getLiveStreamWithEventType:(NSString*)eventType withEventId:(NSInteger)eventId;
- (void)updateMostRecentlyViewedNotificationstime:(NSDate *)viewedDate;
@end



