//
//  LocationMainViewController.h
//  LocationInfo
//
//  Created by shiva on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <CoreLocation/CoreLocation.h>

#import "StreamDataModel.h"

#import "StreamService.h"

#import "ProviderViewController.h"
#import "InteractViewController.h"
#import "InfoViewController.h"
#import "FollowService.h"
#import "MapView.h"

@class InteractViewController;
@class InfoViewController;
@class ProviderViewController;
@protocol LocationMainViewDelegate <NSObject>

@optional
-(CGFloat)getStringHeight:(NSString *)str withConstraintWidth:(NSInteger)width withFontSize:(NSInteger)fontSize;

@end

@interface LocationInfoViewController : UIViewController<UIWebViewDelegate,StreamServiceDelegate,LocationMainViewDelegate,FollowServiceDelegate,MapViewDelegate> {
    ProviderViewController *providerVC;
    InteractViewController *interActViewController;
    InfoViewController  *infoViewController;
    
    StreamDataModel *locationDataModal;
    
    //Map
    CLLocation *userNewLocation_;
    
    AppDelegate *appDelegate;
    NSString *channel_Id;
    
    NSInteger review_radius;

    IBOutlet UIImageView *lineSeparator;
    BOOL hasFavourited;
    
}

@property (readwrite, nonatomic) NSInteger review_radius;
@property (nonatomic, strong) StreamDataModel *locationDataModal;
@property (strong, nonatomic) IBOutlet UIButton *back_Btn;
@property (strong, nonatomic) IBOutlet UIButton *provider_Btn;
@property (strong, nonatomic) IBOutlet UIButton *interact_Btn;
@property (strong, nonatomic) IBOutlet UIButton *details_Btn;
@property (strong, nonatomic) IBOutlet UIButton *favorite_Btn;
@property (strong, nonatomic) IBOutlet UILabel *tabbarTitleLabel;
@property (strong, nonatomic) IBOutlet UIImageView *customTab_ImgView;
@property (strong, nonatomic) IBOutlet UIView *customTabView;

@property (strong, nonatomic)  NSString *channel_Id;

//Map
@property (nonatomic, strong) CLLocation  *userNewLocation;

@property (nonatomic, readwrite) float latitude;
@property (nonatomic, readwrite) float longitude;

-(IBAction)getProviders:(id)sender;
-(IBAction)getInteract:(id)sender;
-(IBAction)getDetails:(id)sender;
-(IBAction)setFavourite :(id)sender;

- (void)getLocationInfo;

-(IBAction)popToRootViewController:(id)sender;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;

-(void)bringAllFooterIconsToFront;
-(void)reloadData:(NSDictionary *)results;


- (void)openPhoneApp:(id)sender;

- (UIView *)returnTableHeaderViewForLocationSelectedTab:(NSString *)tabName pageTitle:(NSString *)pageTitle;
@end
