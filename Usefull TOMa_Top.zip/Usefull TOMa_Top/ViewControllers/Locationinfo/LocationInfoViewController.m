//
//  LocationMainViewController.m
//  LocationInfo
//
//  Created by shiva on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>

#import "LocationInfoViewController.h"

#import "AppDelegate.h"

@implementation LocationInfoViewController

@synthesize back_Btn;
@synthesize provider_Btn;
@synthesize interact_Btn;
@synthesize details_Btn;
@synthesize favorite_Btn;
@synthesize customTab_ImgView;
@synthesize tabbarTitleLabel;
@synthesize channel_Id;
@synthesize customTabView;
@synthesize locationDataModal;
//Map
@synthesize userNewLocation = userNewLocation_;

@synthesize latitude;
@synthesize longitude;
@synthesize review_radius;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    @try {
        self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
        if (self) {
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
        
        appDelegate.mapView.mapDelegate = self;
        appDelegate.mapView.stopUpdatingLocationInfo = NO;
        [appDelegate.mapView.locationManager startUpdatingLocation];
        userNewLocation_ = appDelegate.userCurrentLocation;
        customTab_ImgView.layer.shadowRadius = 15.0f;
        customTab_ImgView.layer.shadowColor = [[UIColor blackColor]CGColor];
        customTab_ImgView.layer.shadowOpacity = 1.0f;
        
        tabbarTitleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        //        tabbarTitleLabel.numberOfLines = 0;
        //        tabbarTitleLabel.lineBreakMode = UILineBreakModeWordWrap;
        
        [self getProviders:nil];
        
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        if(isiPhone6) {
            [customTabView setFrame:CGRectMake(0,customTabView.frame.origin.y-(isiPhone6PLUS?10:0), appDelegate.window.frame.size.width, customTabView.frame.size.height+(isiPhone6PLUS?10:0))];
            [customTab_ImgView setFrame:CGRectMake(0, 0, appDelegate.window.frame.size.width, customTab_ImgView.frame.size.height)];
        }
        customTabView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin;
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewWillAppear:(BOOL)animated {
    @try {
        [super viewWillAppear:YES];
        
        self.navigationController.navigationBar.hidden = YES;
        //self.navigationController.hidesBottomBarWhenPushed = YES;
        
        [self getLocationInfo];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
}

- (void)getLocationInfo {
    TCSTART
    if([self isNull:locationDataModal] && [self isNotNull:providerVC] && [self isNotNull:channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.authToken]){
        [appDelegate getLocationInfo:channel_Id showIn:self];
        
        [appDelegate showActivityIndicatorInView:providerVC.view];
        [appDelegate showNetworkIndicator];
    }
    TCEND
}

- (void)didFinishedGettingLocationBusiness:(NSDictionary *)results{
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:providerVC.view];
        
        if (results != nil) {
            [self reloadData:results];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)didFailedToGetLocationBusinessWithError:(NSString *)errorMsg{
    
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:providerVC.view];
        
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (UIView *)returnTableHeaderViewForLocationSelectedTab:(NSString *)tabName pageTitle:(NSString *)pageTitle {
    @try {
        UIView *tableHeaderView;
        UIImageView *businessLogo_imageView = nil;
        UIImageView *pageHeader_imageView;
        UILabel *businessName_Lbl = nil;
        UILabel *businessAddress_Lbl = nil;
        UIButton *businessPhoneNumb_Btn = nil;
        UIImageView *phoneIcon = nil;
        UIImageView *addressIcon = nil;
        UILabel *phoneNumberLabel = nil;
        
        
        CGFloat headerHeight;
        CGFloat diff;
        CGFloat businessNameHGT;
        CGFloat titleImageHeight;
        
        if (iPad) {
            diff = 10;
            businessNameHGT = 30;
            titleImageHeight = 50;
        }else if (isiPhone6PLUS)
        {
            diff = 5;
            businessNameHGT = 25;
            titleImageHeight = 30;
        }
        else {
            diff = 5;
            businessNameHGT = 20;
            titleImageHeight = 30;
        }
        
        CGSize addrSize = CGSizeMake(0.0f, 0.0f);
        if ([self isNotNull:locationDataModal.loc_Address]) {    //business address
            NSString *addrStr = [NSString stringWithFormat:@"%@, %@, %@",locationDataModal.loc_Address?:@"",locationDataModal.located_City?:@"",locationDataModal.loc_State?:@""];
            addrSize = [addrStr sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:locationAddressSize] constrainedToSize:CGSizeMake(self.view.frame.size.width - (diff + REVIEWER_IMAGE_WIDTH + 20 + diff + (iPad?30:isiPhone6PLUS?20:18) + (diff * 2)), 40) lineBreakMode:NSLineBreakByWordWrapping];
        }
        
        headerHeight = businessNameHGT + addrSize.height + businessNameHGT + titleImageHeight + diff * 2;
        
        if (!tableHeaderView) {
            tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, headerHeight)];
            tableHeaderView.layer.cornerRadius = 10.0f;
            tableHeaderView.backgroundColor = [UIColor clearColor];
            
            //sectionBG_image
            businessLogo_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(diff, 0,isiPhone6PLUS?(REVIEWER_IMAGE_WIDTH + 30):(REVIEWER_IMAGE_WIDTH + 20),isiPhone6PLUS?(REVIEWER_IMAGE_HEIGHT + 30):(REVIEWER_IMAGE_HEIGHT + 20))];
            businessLogo_imageView.layer.cornerRadius = 5.0f;
            businessLogo_imageView.layer.masksToBounds = YES;
            businessLogo_imageView.tag = 1;
            [tableHeaderView addSubview:businessLogo_imageView];
            
            //show the Business Name.
            businessName_Lbl = [[UILabel alloc]init];
            [businessName_Lbl setFrame:CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff + (diff - 5), -2, tableHeaderView.frame.size.width - (businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + (3 * diff) + 5), businessNameHGT)];
            businessName_Lbl.tag = 2;
            businessName_Lbl.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:locationNameSize];
            businessName_Lbl.backgroundColor = [UIColor clearColor];
            businessName_Lbl.textColor = [UIColor whiteColor];
            businessName_Lbl.numberOfLines = 0;
            businessName_Lbl.lineBreakMode = NSLineBreakByWordWrapping;
            
            [tableHeaderView addSubview:businessName_Lbl];
            
            //address point Image
            addressIcon = [[UIImageView alloc]init];
            if (iPad) {
                addressIcon.frame =  CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff + ((addrSize.height - 30)/2), 25, 30);
            } else {
                addressIcon.frame = CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff + ((addrSize.height - 18)/2), 12.5, 17.5);
            }
            addressIcon.tag = 7;
            [tableHeaderView addSubview:addressIcon];
            
            //show the business Address.
            businessAddress_Lbl = [[UILabel alloc]init];
            [businessAddress_Lbl setFrame:CGRectMake(addressIcon.frame.origin.x + addressIcon.frame.size.width + diff,businessName_Lbl.frame.origin.y + businessName_Lbl.frame.size.height + diff, addrSize.width, addrSize.height)];
            
            businessAddress_Lbl.tag = 3;
            businessAddress_Lbl.numberOfLines = 0;
            businessAddress_Lbl.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?17.0f:locationAddressSize];
            businessAddress_Lbl.backgroundColor = [UIColor clearColor];
            businessAddress_Lbl.textColor = [UIColor grayColor];
            [tableHeaderView addSubview:businessAddress_Lbl];
            
            //shwot the business Phone Number
            //phone Image
            phoneIcon = [[UIImageView alloc]init];
            phoneIcon.tag = 5;
            if (iPad) {
                phoneIcon.frame =  CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff,25,30);
            } else {
                phoneIcon.frame = CGRectMake(businessLogo_imageView.frame.origin.x + businessLogo_imageView.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff,12.5,17.5);
            }
            [tableHeaderView addSubview:phoneIcon];
            
            businessPhoneNumb_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [businessPhoneNumb_Btn setFrame:CGRectMake(phoneIcon.frame.origin.x + phoneIcon.frame.size.width + diff,businessAddress_Lbl.frame.origin.y + businessAddress_Lbl.frame.size.height + diff, tableHeaderView.frame.size.width - (phoneIcon.frame.origin.x + phoneIcon.frame.size.width + (2 * diff) + 20 ), businessNameHGT)];
            businessPhoneNumb_Btn.tag = 4;
            businessPhoneNumb_Btn.backgroundColor = [UIColor clearColor];
            [businessPhoneNumb_Btn addTarget:self action:@selector(openPhoneApp:) forControlEvents:UIControlEventTouchUpInside];
            [tableHeaderView addSubview:businessPhoneNumb_Btn];
            
            //shwot the business Address.
            phoneNumberLabel = [[UILabel alloc]init];
            [phoneNumberLabel setFrame:businessPhoneNumb_Btn.frame];
            phoneNumberLabel.tag = 6;
            phoneNumberLabel.numberOfLines = 0;
            phoneNumberLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?17.0f:locationAddressSize];
            phoneNumberLabel.backgroundColor = [UIColor clearColor];
            phoneNumberLabel.textColor = [UIColor grayColor];
            [tableHeaderView addSubview:phoneNumberLabel];
            
            pageHeader_imageView = [[UIImageView alloc]init];
            [tableHeaderView addSubview:pageHeader_imageView];
            
        }
        if (!businessLogo_imageView)
            businessLogo_imageView = (UIImageView *)[tableHeaderView viewWithTag:1];
        if (!businessName_Lbl)
            businessName_Lbl = (UILabel *)[tableHeaderView viewWithTag:2];
        if (!businessAddress_Lbl)
            businessAddress_Lbl = (UILabel *)[tableHeaderView viewWithTag:3];
        if (!businessPhoneNumb_Btn)
            businessPhoneNumb_Btn = (UIButton *)[tableHeaderView viewWithTag:4];
        if (!phoneIcon)
            phoneIcon = (UIImageView *)[tableHeaderView viewWithTag:5];
        if (!phoneNumberLabel)
            phoneNumberLabel = (UILabel *)[tableHeaderView viewWithTag:6];
        if (!addressIcon)
            addressIcon = (UIImageView *)[tableHeaderView viewWithTag:7];
        
        if ([self isNotNull:pageTitle]) {
            if (iPad) {
                pageHeader_imageView.frame = CGRectMake((tableHeaderView.frame.size.width - 500)/2, businessPhoneNumb_Btn.frame.origin.y + businessPhoneNumb_Btn.frame.size.height + 10, 500, titleImageHeight);
            } else {
                pageHeader_imageView.frame = CGRectMake((tableHeaderView.frame.size.width - 297)/2, businessPhoneNumb_Btn.frame.origin.y + businessPhoneNumb_Btn.frame.size.height + (isiPhone6PLUS?8:5), 297, titleImageHeight);
            }
            pageHeader_imageView.image = [UIImage imageNamed:pageTitle];
        } else {
            pageHeader_imageView.frame = CGRectMake(0,0,0,0);
        }
        
        tableHeaderView.frame = CGRectMake(0, 0, self.view.frame.size.width, headerHeight);
        //check for null and is class dictionary and url null or not if not null download or just display the defualt img
        if ([self isNotNull:locationDataModal]) {
            
            if ([self isNotNull:locationDataModal.loc_PublicLogo_Url] && [locationDataModal.loc_PublicLogo_Url rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                [businessLogo_imageView setImageWithURL:[NSURL URLWithString:locationDataModal.loc_PublicLogo_Url] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
            } else {
                businessLogo_imageView.image = [UIImage imageNamed:@"default-avatar-business"];
            }
            if ([self isNotNull:locationDataModal.loc_Name] || [self isNotNull:locationDataModal.located_City] || [self isNotNull:locationDataModal.loc_State])       //business name
                businessName_Lbl.text = locationDataModal.loc_Name;
            if ([self isNotNull:locationDataModal.loc_Address]) {    //business address
                businessAddress_Lbl.text = [NSString stringWithFormat:@"%@, %@, %@",locationDataModal.loc_Address?:@"",locationDataModal.located_City?:@"",locationDataModal.loc_State?:@""];
                addressIcon.image = [UIImage imageNamed:@"locationinfoarrow"];
            } else {
                businessAddress_Lbl.text = @"";
                addressIcon.hidden = YES;
            }
            if ([self isNotNull:locationDataModal.PhoneNo]) {      //business phone number
                NSString *formatedPhoneNumber = [appDelegate formatPhoneNumber:locationDataModal.PhoneNo];
                if ([self isNotNull:formatedPhoneNumber]) {
                    phoneNumberLabel.text = formatedPhoneNumber;
                    phoneIcon.image = [UIImage imageNamed:@"locationinfo_phone"];
                } else {
                    [phoneNumberLabel setText:@""];
                    phoneIcon.hidden = YES;
                }
            }
        }
        return tableHeaderView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)openPhoneApp:(id)sender {
    TCSTART
    if ([self isNotNull:locationDataModal.PhoneNo]) {
        UIAlertView *phoneCallAlertView = [[UIAlertView alloc]initWithTitle:@"Call" message:[NSString stringWithFormat:@"Do you want to call %@ at %@", locationDataModal.loc_Name?:@"",locationDataModal.PhoneNo] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Call", nil];
        [phoneCallAlertView show];
    }
    TCEND
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [appDelegate openPhoneApp:locationDataModal.PhoneNo];
    }
}

- (void)bringAllFooterIconsToFront {
    
    @try {
        [self.view bringSubviewToFront:customTabView];
        [customTabView bringSubviewToFront:customTab_ImgView];
        [customTabView bringSubviewToFront:provider_Btn];
        [customTabView bringSubviewToFront:interact_Btn];
        [customTabView bringSubviewToFront:details_Btn];
        [self.view bringSubviewToFront:favorite_Btn];
        [self.view bringSubviewToFront:back_Btn];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(IBAction)popToRootViewController:(id)sender {
    
    @try {
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
#pragma mark - TabButtons Actions & Their Configuration.

-(void)setImageForCustomTabbar:(int)tabNumber {
    
    @try {
        [customTab_ImgView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"providerTab%d",tabNumber]]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)manageViewController:(BOOL)provider viewCont:(BOOL)plug viewCont:(BOOL)details {
    @try {
        if ([self isNotNull:providerVC] && provider) {
            providerVC.view.hidden = YES;
        }  else {
            providerVC.view.hidden = NO;
        }
        
        if (infoViewController && details) {
            infoViewController.view.hidden = YES;
        } else {
            infoViewController.view.hidden = NO;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(IBAction)getProviders:(id)sender {
    
    @try {
        [self setImageForCustomTabbar:1];
        
        if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
            [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
            hasFavourited = YES;
        } else {
            hasFavourited = NO;
        }
        
        //hide the mapview if it is in full mode in details view.
        [self checkAndRemoveMapFullView];
        
        // show the LiveFeed view and remove all other views
        [self manageViewController:NO viewCont:YES viewCont:YES];
        UIView *pageHeader = [self returnTableHeaderViewForLocationSelectedTab:@"Provider" pageTitle:@"Providers_title"];
        //        self.view.frame.size.width
        //        HEADER_WIDTH
        pageHeader.frame = CGRectMake(0, pageHeader.frame.origin.y, self.view.frame.size.width, pageHeader.frame.size.height);
        if (!providerVC) {
            providerVC = [[ProviderViewController alloc] initWithFrame:CGRectMake(0, (iPad?75:isiPhone6PLUS?61:51), self.view.frame.size.width, (self.view.frame.size.height - (lineSeparator.frame.size.height + lineSeparator.frame.origin.y + (iPad?87:isiPhone6PLUS?60:50)))) andTableHeaderView:pageHeader];
            
            providerVC.caller = self;
            providerVC.streamInfoModel = locationDataModal;
            [self.view addSubview:providerVC.view];
            
            [providerVC reloadData];
        }
        
        [self bringAllFooterIconsToFront];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (IBAction)getInteract:(id)sender {
    @try {
        
        [self checkAndRemoveMapFullView];
        
        [infoViewController zoomOutMapView:nil];
        
        if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
            [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
            hasFavourited = YES;
        } else {
            hasFavourited = NO;
        }
        
        if (iPad) {
            interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController" bundle:nil andCaller:self andPhysiciansArray:locationDataModal.physiciansArray isFromMainView:NO];
        } else {
            interActViewController = [[InteractViewController alloc]initWithNibName:@"InteractViewController~iPhone" bundle:nil andCaller:self andPhysiciansArray:locationDataModal.physiciansArray isFromMainView:NO];
        }
        
        interActViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
        
        if (interActViewController) {
            interActViewController.caller = self;
            
            //[self presentModalViewController:interActViewController animated:YES];
            [self presentViewController:interActViewController animated:YES completion:^{
                //code
            }];
            [appDelegate.window bringSubviewToFront:interActViewController.view];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (IBAction)setFavourite:(id)sender {
    @try {
        
        if (hasFavourited) { //delete favorite
            
            if([self isNotNull:locationDataModal.channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.userId]  && [self isNotNull:locationDataModal.favorite_idStr]) {
                [appDelegate unfavoriteBusiness:appDelegate.userProfileDataModel.userId withBusinessToUnFollowId:locationDataModal.favorite_idStr withCallbackObject:self];
            }
        } else {
            
            if([self isNotNull:locationDataModal.channel_Id] && [self isNotNull:appDelegate.userProfileDataModel.userId]) {
                [appDelegate favoriteBusiness:appDelegate.userProfileDataModel.userId withBusinessToFollowId:locationDataModal.channel_Id withCallbackObject:self];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)getDetails:(id)sender {
    TCSTART
    [self setImageForCustomTabbar:3];
    
    if ([self isNotNull:locationDataModal.favorite_idStr]) {//favorited
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
    } else {
        hasFavourited = NO;
    }
    
    [self manageViewController:YES viewCont:YES viewCont:NO];
    UIView *pageHeader = [self returnTableHeaderViewForLocationSelectedTab:@"Details" pageTitle:@"details_title"];
    pageHeader.frame = CGRectMake(0, pageHeader.frame.origin.y, HEADER_WIDTH, pageHeader.frame.size.height);
    if (!infoViewController) {
        infoViewController = [[InfoViewController alloc] initWithFrame:CGRectMake(0, (iPad?75:51), appDelegate.window.frame.size.width, (self.view.frame.size.height - (lineSeparator.frame.size.height + lineSeparator.frame.origin.y + (iPad?87:50)))) andHeader:pageHeader];
        [self.view addSubview:infoViewController.view];
    }
    
    infoViewController.streamInfoModel = locationDataModal;
    
    infoViewController.tabbarMainVC = self;
    
    [infoViewController reloadTable];
    [self bringAllFooterIconsToFront];
    TCEND
}

#pragma mark AddFavorite Request Delegate Methods
- (void)didFinishedCreatingfavoriteBusiness:(NSString *)businessId {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
        if ([self isNotNull:businessId]){
            
            locationDataModal.favorite_idStr = businessId;
            if ([self isNotNull:locationDataModal.favorite_idStr]){ //favorited
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)didFailedToCreatefavoriteBusiness:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark DeleteFavorite Request Delegate Methods
-(void)didFinishedUnfavoriteBusiness {
    @try {
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow"] forState:UIControlStateNormal];
        hasFavourited = NO;
        [appDelegate hideNetworkIndicator];
        locationDataModal.favorite_idStr = nil;
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)didFailedToUnfavoriteBusinessWithError:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
        hasFavourited = YES;
        [appDelegate showErrorMsg:errorMsg];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

//=========================================END OF SHARE RELATED METHODS============================================//

//LocationInfo Response
-(void)reloadData:(NSDictionary *)results {
    
    @try {
        [appDelegate hideNetworkIndicator];
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]]) {
            locationDataModal = [results objectForKey:@"locationData"];
            
            if ([self isNotNull:locationDataModal]) {
                latitude = locationDataModal.loc_Latitude.floatValue;
                longitude = locationDataModal.loc_Longitude.floatValue;
                review_radius = locationDataModal.loc_ReviewRadius;
                //check for favorited id and change the footer icon accrodingly
                if ([self isNotNull:locationDataModal.favorite_idStr]) {
                    [favorite_Btn setImage:[UIImage imageNamed:@"locationtab_follow_f"] forState:UIControlStateNormal];
                    hasFavourited = YES;
                } else {
                    hasFavourited = NO;
                }
                //reload the location info table header params
                //load the livefeed table
                if ( [self isNotNull:providerVC]) { // configure and reload the live feed
                    [providerVC.view removeFromSuperview];
                    providerVC = nil;
                    [self getProviders:nil];
                }
                
                if ([self isNotNull:infoViewController]) {
                    [infoViewController.view removeFromSuperview];
                    infoViewController = nil;
                    [self getDetails:nil];
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark MapView Delegate methods


- (void)didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
    @try {
        appDelegate.userCurrentLocation = newLocation;
        userNewLocation_ = appDelegate.userCurrentLocation;
        appDelegate.locationErrorMessage = nil;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
-(void)didFailedToUpdateLocationWithError:(NSError *)error {
    
    @try {
        //show an alert.
        //   NSLog(@"failed to update location with error %@",error);
        if ([error domain] == kCLErrorDomain) {
            
            // We handle CoreLocation-related errors here
            switch ([error code]) {
                    
                case kCLErrorDenied:
                    appDelegate.locationErrorMessage = @"Location services are required to use ChatterPlug, please enable them before proceeding.";
                    break;
                case kCLErrorLocationUnknown:
                    appDelegate.locationErrorMessage = @"Unable to obtain GPS coordinates.";
                    break;
                case kCLErrorNetwork:
                    appDelegate.locationErrorMessage = @"Location network failure.";
                default:
                    break;
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)checkAndRemoveMapFullView {
    
    @try {
        if([self isNotNull:infoViewController] && infoViewController.mapFullVC.view.hidden == NO){
            [infoViewController.mapFullVC.view removeFromSuperview];
            infoViewController.mapFullVC = nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    //    NSLog(@"viewWillDisappear of LocationmainViewController");
    [appDelegate.mapView.locationManager stopUpdatingLocation];
    //    [appDelegate deleteAllImagesFromDocuments];
}
- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
