//
//  ProviderViewController.h
//  MemorialHealthSystem
//
//  Created by Aruna on 19/06/13.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "StreamDataModel.h"

@interface ProviderViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    CGRect viewFrame;
    UIView *tableHeaderView;
    AppDelegate *appDelegate;
    StreamDataModel *streamInfoModel;
    
    UITableView *providerTableView;
    
    NSMutableArray *specialtiesArray;
    NSMutableArray *specialistsArray;
    
    id caller;
}
@property (nonatomic, retain) id caller;
@property(nonatomic, strong)  StreamDataModel *streamInfoModel;

- (id)initWithFrame:(CGRect)frame andTableHeaderView:(UIView *)tableHeaderView_;
- (void)reloadData;
@end
