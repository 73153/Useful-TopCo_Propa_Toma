//
//  ProviderViewController.m
//  MemorialHealthSystem
//
//  Created by Aruna on 19/06/13.
//
//

#import "ProviderViewController.h"
#import "ProviderDetailsViewController.h"
#import "LocationInfoViewController.h"
@interface ProviderViewController ()

@end

@implementation ProviderViewController
@synthesize streamInfoModel;
@synthesize caller;

- (id)initWithFrame:(CGRect)frame andTableHeaderView:(UIView *)tableHeaderView_
{
    self = [super init];
    if (self) {
        viewFrame = frame;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        tableHeaderView = tableHeaderView_;
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    [super viewDidLoad];
    self.view.frame = viewFrame;
    self.view.backgroundColor = [UIColor clearColor];
    
    specialtiesArray = [[NSMutableArray alloc] initWithObjects:nil];
    specialistsArray = [[NSMutableArray alloc] initWithObjects:nil];
    
    CGFloat originX;
    CGFloat diff;
    if (iPad) {
        originX = -30;
        diff = 10;
    } else {
        originX = -2.5;
        diff = 5;
    }
    
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        originX = 5;
    }
    
    tableHeaderView.frame = CGRectMake(diff, 0, self.view.frame.size.width, tableHeaderView.frame.size.height);
    
    [self.view addSubview:tableHeaderView];
    
    providerTableView = [[UITableView alloc]initWithFrame:CGRectMake(originX, tableHeaderView.frame.size.height + diff , appDelegate.window.frame.size.width + (2 * -originX), self.view.frame.size.height - tableHeaderView.frame.size.height) style:UITableViewStyleGrouped];
    providerTableView.delegate = self;
    providerTableView.dataSource = self;
    providerTableView.backgroundView = nil;
    providerTableView.backgroundColor = [UIColor clearColor];
    if (CURRENT_DEVICE_VERSION < 7.0) {
        providerTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {
        providerTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    [self.view addSubview:providerTableView];
    TCEND
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)reloadData {
    TCSTART
    [self addObjectsToSpecilitiesAndSpecilistsArrays];
    [providerTableView reloadData];
    TCEND
}
- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    if ([self isNotNull:providerTableView]) {
        NSIndexPath *indexpath = [providerTableView indexPathForSelectedRow];
        [providerTableView deselectRowAtIndexPath:indexpath animated:YES];
    }
    TCEND
}
- (void)addObjectsToSpecilitiesAndSpecilistsArrays {
    TCSTART
    
    NSArray *allPhysiciansArray = streamInfoModel.physiciansArray;
    
    /** Adding Specilities
     */
    
    for (CPPhysician *physician in allPhysiciansArray) {
        for (int i = 0; i < physician.physicianSpecialities.count; i++) { /** for avoiding specility duplicates */
            BOOL hasSpecility = NO;
            for (int j = 0; j < specialtiesArray.count; j++) {
                if ([[specialtiesArray objectAtIndex:j] caseInsensitiveCompare:[physician.physicianSpecialities objectAtIndex:i]] == NSOrderedSame) {
                    hasSpecility = YES;
                    break;
                }
            }
            if (!hasSpecility) {
                [specialtiesArray addObject:[physician.physicianSpecialities objectAtIndex:i]];
            }
        }
    }
    
    
    /** Adding Specilists based on specilities array
     */
    for (int i = 0; i < specialtiesArray.count; i++) {
        NSMutableArray *providersArray = [[NSMutableArray alloc] init];
        for (CPPhysician *physician in allPhysiciansArray) {
            for (int j = 0; j < physician.physicianSpecialities.count; j++) {
                if ([[physician.physicianSpecialities objectAtIndex:j] caseInsensitiveCompare:[specialtiesArray objectAtIndex:i]] == NSOrderedSame) {
                    [providersArray addObject:physician];
                }
            }
        }
        [specialistsArray addObject:[NSDictionary dictionaryWithObjectsAndKeys:providersArray,[specialtiesArray objectAtIndex:i], nil]];
    }
    NSLog(@"SpecilitiesArray:%@ %@",specialistsArray,specialtiesArray);
    TCEND
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma -
#pragma mark tableView DataSource & Delegate Methods.

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
   	return specialtiesArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    TCSTART
    NSArray *providersArray = [[specialistsArray objectAtIndex:section] objectForKey:[specialtiesArray objectAtIndex:section]];
    if(providersArray.count > 0){ //show search results
        return [providersArray count];
    }  else {
        return 0;
    }
    TCEND
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (iPad) {
        return 80;
    } else {
        return isiPhone6PLUS?60:50;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    if (iPad) {
        return 65.0;
    } else {
        return isiPhone6PLUS?60.0:50.0;
    }
    
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        
        UIView *headerView = [[UIView alloc] init];
        headerView.backgroundColor = [UIColor clearColor];
        
        CGRect headerLabelRect;
        CGFloat headerViewHeight;
        CGFloat headerViewOriginX;
        if (iPad) {
            headerViewOriginX = ((CURRENT_DEVICE_VERSION < 7.0)?30:-1.5);
            headerLabelRect = CGRectMake(headerViewOriginX, 5, 748, 55);
            headerViewHeight = 65;
        } else {
            headerViewOriginX = ((CURRENT_DEVICE_VERSION < 7.0)?7.5:isiPhone6PLUS?7:0);
            headerLabelRect = CGRectMake(headerViewOriginX, 5, appDelegate.window.frame.size.width-10,isiPhone6PLUS?50:40);
            headerViewHeight = isiPhone6PLUS?60:50;
        }
        
        headerView.frame = CGRectMake(headerViewOriginX, 0.0, self.view.frame.size.width, headerViewHeight);
        UILabel *headerLabel = [[UILabel alloc]initWithFrame:headerLabelRect];
        headerLabel.textAlignment = NSTextAlignmentCenter;
        headerLabel.textColor = [UIColor lightGrayColor];
        headerLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?21.0f:SectionHeaderTitleFontSize];
        headerLabel.numberOfLines = 0;
        headerLabel.lineBreakMode = NSLineBreakByWordWrapping;
        headerLabel.backgroundColor = [UIColor clearColor];
        headerLabel.text = [specialtiesArray objectAtIndex:section];
        
        [headerView addSubview:headerLabel];
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        UITableViewCell *cell = nil;
        NSString *cellIdentifier = @"providerCell";
        UIImageView *avtar = nil;
        UILabel *name = nil;
        
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] ;
            
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
            
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]] ;
            
            CGFloat diff;
            CGRect nameRect;
            if (iPad) {
                diff = 10;
                nameRect = CGRectMake(80, 2, 618, 60);
            }else if (isiPhone6PLUS)
            {
                diff = 5;
                nameRect = CGRectMake(60, 5, appDelegate.window.frame.size.width-60, 50);
            }
            else {
                diff = 5;
                nameRect = CGRectMake(50, 5, 240, 40);
            }
            
            avtar = [[UIImageView alloc]initWithFrame:CGRectMake(diff, diff,isiPhone6PLUS?(REVIEWER_IMAGE_WIDTH+10):REVIEWER_IMAGE_WIDTH ,isiPhone6PLUS?(REVIEWER_IMAGE_HEIGHT+10):REVIEWER_IMAGE_HEIGHT)];
            [avtar setBackgroundColor:[UIColor clearColor]];
            [avtar.layer setBorderColor:[[UIColor clearColor]CGColor]];
            [avtar.layer setBorderWidth:1.0f];
            avtar.layer.cornerRadius = 5.0;
            avtar.layer.masksToBounds = YES;
            [avtar setTag:1];
            [cell.contentView addSubview:avtar];
            
            
            name = [[UILabel alloc] initWithFrame:nameRect];
            name.backgroundColor = [UIColor clearColor];
            name.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
            [name setTag:2];
            name.textColor = [UIColor whiteColor];
            [cell.contentView addSubview:name];
            
        }
        
        if (!avtar)
            avtar = (UIImageView*)[cell viewWithTag:1];
        if (!name)
            name = (UILabel*)[cell viewWithTag:2];
        
        NSArray *providersArray = [[specialistsArray objectAtIndex:indexPath.section] objectForKey:[specialtiesArray objectAtIndex:indexPath.section]];
        
        
        CPPhysician *physician = nil;
        if([self isNotNull:providersArray] && providersArray.count > indexPath.row) {
            physician = [providersArray objectAtIndex:indexPath.row];
        }
        if ([self isNotNull:physician.physicianName]) {
            name.text = physician.physicianName;
        } else {
            name.text = @"";
        }
        //NSLog(@"PhycianInBlock");
        if ([self isNotNull:physician.physicianAvatarUrl]
            && [[physician.physicianAvatarUrl absoluteString] rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            NSString *thumbUrl = [appDelegate getavatarThumbURL:[physician.physicianAvatarUrl absoluteString]];
            [avtar setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-provider"]];
        } else {
            avtar.image=[UIImage imageNamed:@"default-avatar-provider"];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?80:isiPhone6PLUS?58:50) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
        
        if(iPhone && CURRENT_DEVICE_VERSION >= 8.0) {
            CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
            cell.accessoryView=nil;
            if([cell.contentView viewWithTag:9]) {
                //[[cell.contentView viewWithTag:9] removeFromSuperview];
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                [[cell.contentView viewWithTag:9] setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                
            } else {
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                accessoryimgView.tag=9;
                [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                [cell.contentView addSubview:accessoryimgView];
            }
        }
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    NSArray *providersArray = [[specialistsArray objectAtIndex:indexPath.section] objectForKey:[specialtiesArray objectAtIndex:indexPath.section]];
    
    CPPhysician *physician = nil;
    if([self isNotNull:providersArray] && providersArray.count > indexPath.row) {
        physician = [providersArray objectAtIndex:indexPath.row];
    }
    if ([self isNotNull:physician]) {
        if ([caller isKindOfClass:[LocationInfoViewController class]]) {
            LocationInfoViewController *locationInfoVC = (LocationInfoViewController *)caller;
            ProviderDetailsViewController *providerDetailsVC = [[ProviderDetailsViewController alloc] initWithPhysician:physician];
            providerDetailsVC.locationDataModal = streamInfoModel;
            [locationInfoVC.navigationController pushViewController:providerDetailsVC animated:YES];
        }
    }
    TCEND
}
@end
