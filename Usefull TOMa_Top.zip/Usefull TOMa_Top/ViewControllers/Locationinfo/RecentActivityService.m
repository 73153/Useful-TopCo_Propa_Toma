//
//  NotificationsService.m
//  BeefOBrady
//
//  Created by Aruna on 21/01/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "RecentActivityService.h"
#import "RecentActivity.h"
#import "AppDelegate.h"

@implementation RecentActivityService
@synthesize user_id;
@synthesize auth_token;
@synthesize request_Url;
@synthesize review_id;
@synthesize apiKey;
@synthesize isRequestForRefresh;

-(id)initWithCaller:(id)caller {
    
    @try {
        if (self = [super init]) {
            caller_ = caller;
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        }
        return  self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark
#pragma mark LoadFavoritesBusinesses request methods
- (void)getLiveStream:(NSInteger)page perPage:(NSInteger )per_page {
    @try {
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:request_Url];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        commonParameters.pageSize = [NSNumber numberWithInteger:per_page];
        
        CPStreamService *service = [[CPStreamService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        [service getLiveStreamPage:[NSNumber numberWithInteger:page]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)getLiveStreamWithEventType:(NSString *)eventType withEventId:(NSInteger)eventId
{
    @try {
        NSLog(@"InLiveStreamEvent:%@:%d",eventType,eventId);
        CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
        commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
        commonParameters.authenticationToken = auth_token;
        commonParameters.applicationURL = [NSURL URLWithString:request_Url];
        commonParameters.apiKey = apiKey;
        commonParameters.isDebug = YES;
        
        CPStreamService *service = [[CPStreamService alloc] initWithCommonParameters:commonParameters withDelegate:self];
        //[service getLiveStreamEventType:eventType withEventId:[NSNumber numberWithInteger:eventId]];
        [service getLiveStreamEventType:eventType withEventId:[NSNumber numberWithInteger:eventId]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didReceiveStream:(NSArray*) results {
    @try {
        NSLog(@"Did Receive Stream called!");
        BOOL isResponseNull = YES;
        if (isRequestForRefresh) {
            NSDictionary *attributesDict = [[NSDictionary alloc] initWithObjectsAndKeys:@"RecentActivity",@"entityName", nil];
            
            [appDelegate removeAllObjectsInEntitityWithAttributes:attributesDict];
        }
		//FROM
		NSError *error1;
        NSEntityDescription *entity=[NSEntityDescription entityForName:@"RecentActivity" inManagedObjectContext:appDelegate.managedObjectContext];
        NSFetchRequest *fetch=[[NSFetchRequest alloc]init];
        [fetch setEntity:entity];
        [fetch setSortDescriptors:[NSArray arrayWithObject:[[NSSortDescriptor alloc]initWithKey:@"sno" ascending:NO]]];
        NSArray *array1=[appDelegate.managedObjectContext executeFetchRequest:fetch error:&error1];
        int sNumber=0;
        if(array1.count>0){
            sNumber=[[[array1 objectAtIndex:0]valueForKey:@"sno"]intValue];
		}
		if (sNumber>0) {
			NSLog(@"\n\nSNUMBERRRRRRRRRRRR: %d\n\n",sNumber);
		}
		//TO
		
        if ([self isNotNull:results] && [results isKindOfClass:[NSArray class]]) {
            if (results.count > 0) {
                isResponseNull = NO;
            }
            for (int i = 0; i < results.count; i++) {
                if([[results objectAtIndex:i] isKindOfClass:[CPMessage class]]) {
                    RecentActivity *modal = [NSEntityDescription insertNewObjectForEntityForName:@"RecentActivity" inManagedObjectContext:appDelegate.managedObjectContext];
                    //TODO KANAK FOR ORDER
					modal.sno = [NSNumber numberWithInt:i+1+sNumber];
					
                    CPMessage *message = [results objectAtIndex:i];
                    if ([self isNotNull:message.messageId]) {
                        modal.eventId = message.messageId;
                    }
                    
                    //                    modal.messageType = message.messageType;
                    
                    if (message.messageType == CPMessageTypeNews) {
                        modal.messageType = @"Note";
                    }else if (message.messageType == CPMessageTypeEvents) {
                        modal.messageType = @"Announcement";
                    }else if (message.messageType == CPMessageTypeReferences) {
                        modal.messageType = @"References";
                    }else if (message.messageType == CPMessageTypeCommunity) {
                        modal.messageType = @"Community";
                    }else if (message.messageType == CPMessageTypeHealth) {
                        modal.messageType = @"Health";
                    }else if (message.messageType == CPMessageTypeVideo) {
                        modal.messageType = @"Video";
                    }else if (message.messageType == CPMessageTypeAudio) {
                        modal.messageType = @"Audio";
                    }else if(message.messageType == CPMessageReminder){
                        modal.messageType = @"Reminder";
                    }
                    
                    modal.eventType =  modal.messageType;
                    
                    if ([self isNotNull:message.audioUrl]) {
                        modal.audioUrl = message.audioUrl;
                    }
                    
                    if ([self isNotNull:message.videoUrl]) {
                        modal.videoUrl = message.videoUrl;
                    }
                    if ([self isNotNull:message.title]) {
                        modal.title = message.title;
                    }
                    
                    if ([self isNotNull:message.description]) {
                        modal.descriptionMsg = message.description;
                    }
                    if ([self isNotNull:message.description_html]) {
                        modal.descriptionHtml = message.description_html;
                    }
                    modal.date = message.createdAt;
                }else{
                    CPEvent *event = [results objectAtIndex:i];
                    if ([self isNotNull:event]) {
                        //StreamModal *modal = [[StreamModal alloc]init];
                        RecentActivity *modal = [NSEntityDescription insertNewObjectForEntityForName:@"RecentActivity" inManagedObjectContext:appDelegate.managedObjectContext];
                        //TODO KANAK FOR ORDER
                        modal.sno = [NSNumber numberWithInt:i+1+ sNumber];
                        
                        if([self isNotNull:event.eventId]) {
                            modal.eventId = event.eventId;
                        }
                        
                        modal.rowHeight = [NSNumber numberWithFloat:0.0];
                        
                        if([self isNotNull:event.locationAvatarURL]) {
                            modal.businessAvatarUrl = [event.locationAvatarURL absoluteString];
                        }
                        
                        if([self isNotNull:event.eventType]) {
                            modal.eventType = event.eventType;
                        }
                        
                        if([self isNotNull:event.locationId]) {
                            modal.channel_Id = event.locationId;
                        }
                        
                        if([self isNotNull:event.locationName]) {
                            modal.locationName = event.locationName;
                        }
                        
                        if([self isNotNull:event.eventOccurredTime]) {
                            modal.date = event.eventOccurredTime;
                        }
                        
                        if ([self isNotNull:event.locationCoordinates]) {
                            modal.locationCoordinates = event.locationCoordinates;
                        }
                        
                        if ([self isNotNull:event.userAvatarURL]) {
                            modal.userAvatarUrl = [event.userAvatarURL absoluteString];
                        }
                        
                        if([self isNotNull:event.userAvatarURLDictionary])
                        {
                            //getting Wrong response
                            //modal.userAvatarURLDictionary=[NSDictionary dictionaryWithDictionary:event.userAvatarURLDictionary];
                        }
                        
                        if([self isNotNull:event.otherUserAvatarURLDictionary])
                        {
                            //modal.otherUserAvatarURLDictionary=[NSDictionary dictionaryWithDictionary:event.otherUserAvatarURLDictionary];
                        }
                        
                        if([self isNotNull:event.locationAvatarURLDictionary])
                        {
                            //modal.locationAvatarURLDictionary=[NSDictionary dictionaryWithDictionary:event.locationAvatarURLDictionary];
                        }
                        
                        if ([self isNotNull:event.userId]) {
                            modal.userId = [NSString stringWithFormat:@"%@",event.userId];
                        }
                        
                        if ([self isNotNull:event.userName]) {
                            modal.userName = event.userName;
                        }
                        
                        if ([self isNotNull:event.otherUserAvatarURL]) {
                            modal.otherUserAvatarUrl = [event.otherUserAvatarURL absoluteString];
                        }
                        
                        if ([self isNotNull:event.otherUserId]) {
                            modal.otherUserId = [NSString stringWithFormat:@"%@",event.otherUserId];
                        }
                        
                        if ([self isNotNull:event.otherUserName]) {
                            modal.otherUserName = event.otherUserName;
                        }
                        
                        if ([self isNotNull:event.locationCityState]) {
                            modal.locationCityState = event.locationCityState;
                        }
                        
                        if([event isKindOfClass:[CPLikeEvent class]]) {
                            CPLikeEvent *like = [results objectAtIndex:i];
                            if ([self isNotNull:like.likableText]) {
                                NSString *likableText = like.likableText;
                                
                                NSArray *seperatedComponents = [appDelegate getSeperatedStringComponentsFromString:likableText];
                                if ([self isNotNull:seperatedComponents]) { //notification text.
                                    if (seperatedComponents.count > 0) {
                                        modal.likableText = [seperatedComponents objectAtIndex:0];
                                        modal.likableText = [modal.likableText stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                                    }
                                    
                                    NSString *rateString = nil;
                                    if (seperatedComponents.count > 1) { //rating string
                                        rateString = [seperatedComponents objectAtIndex:1];
                                    }
                                    
                                    if ([self isNotNull:rateString]) { // get rating count;
                                        modal.starsCount = [NSString stringWithFormat:@"%d",[appDelegate getRatingCountFromNotificationText:rateString]];
                                    }
                                    
                                    if (modal.starsCount.intValue > 0) {
                                        modal.showRating = [NSNumber numberWithBool:YES];
                                    } else {
                                        modal.showRating = [NSNumber numberWithBool:NO];
                                        modal.starsCount = nil;
                                    }
                                } else {
                                    modal.likableText = likableText;
                                    modal.starsCount = nil;
                                    modal.showRating = [NSNumber numberWithBool:NO];
                                }
                            }
                            
                            if ([self isNotNull:like.likableType]) {
                                modal.likableType = like.likableType;
                            }
                            if ([self isNotNull:like.locationAvatarURL]) {
                                modal.likableAvatar = [like.locationAvatarURL absoluteString];
                            }
                            
                            if ([self isNotNull:like.likableCommentCount]) {
                                modal.likableCommentsCount = like.likableCommentCount;
                            }
                            
                            if ([self isNotNull:like.likableId]) {
                                modal.likableId = [NSString stringWithFormat:@"%@",like.likableId];
                            }
                            
                            if ([self isNotNull:like.likableLikeCount]) {
                                modal.likableLikesCount = like.likableLikeCount;
                            }
                            
                            if ([self isNotNull:like.userName]) {
                                modal.likableUserName = like.userName;
                            }
                            
                            modal.eventType = @"Like";
                        } else if([event isKindOfClass:[CPReviewPlug class]]) {
                            CPReviewPlug *review = [results objectAtIndex:i];
                            if ([self isNotNull:review.reviewRating]) {
                                modal.starsCount = [NSString stringWithFormat:@"%@",review.reviewRating];
                            }
                            
                            modal.eventType = @"review";
                            if ([self isNotNull:review.reviewText]) {
                                modal.reviewText = review.reviewText;
                            }
                            
                            if ([self isNotNull:review.deviceName]) {
                                modal.deviceName = review.deviceName;
                            }
                            
                            if ([self isNotNull:review.likeCount]) {
                                modal.likesCount = review.likeCount;
                            }
                            
                            if ([self isNotNull:review.photoURL]) {
                                modal.photoUrlString = [review.photoURL absoluteString];
                            }
                            
                            modal.onLocation = [NSNumber numberWithBool:review.onLocation];
                            
                            if ([self isNotNull:review.replies]) {
                                modal.repliesCount = review.repliesCount;
                                modal.repliesArray = review.replies;
                            }
                        } else if([event isKindOfClass:[CPPrivateMessageEvent class]]) {
                            CPPrivateMessageEvent *privateMessage = [results objectAtIndex:i];
                            
                            if ([self isNotNull:privateMessage.privateText]) {
                                modal.reviewText = privateMessage.privateText;
                            }
                            
                            if ([self isNotNull:privateMessage.deviceName]) {
                                modal.deviceName = privateMessage.deviceName;
                            }
                            
                            if ([self isNotNull:privateMessage.likeCount]) {
                                modal.likesCount = privateMessage.likeCount;
                            }
                            
                            if ([self isNotNull:privateMessage.photo_url]) {
                                modal.photoUrlString = [privateMessage.photo_url absoluteString];
                            }
                            
                            if ([self isNotNull:privateMessage.userAvatarURL]) {
                                modal.userAvatarUrl = [privateMessage.userAvatarURL absoluteString];
                            }
                            
//                            //NSDictionary *dict=[NSDictionary dictionaryWithDictionary:privateMessage.photo_urls];
//                            if ([self isNotNull:privateMessage.photo_urls]) {
//                                modal.photoUrlStrings =[NSDictionary dictionaryWithDictionary:privateMessage.photo_urls];
//                            }
                            
                            modal.onLocation = [NSNumber numberWithBool:privateMessage.onLocation];
                            modal.eventType = @"PrivateMessage";
                            
                            if ([self isNotNull:privateMessage.replies]) {
                                modal.repliesCount = privateMessage.repliesCount;
                                modal.repliesArray = privateMessage.replies;
                            }
                        } else if([event isKindOfClass:[CPBroadcastPlug class]]) {
                            CPBroadcastPlug *broadCast = [results objectAtIndex:i];
                            
                            if ([self isNotNull:broadCast.message]) {
                                modal.reviewText = broadCast.message;
                            }
                            
                            if ([self isNotNull:broadCast.deviceName]) {
                                modal.deviceName = broadCast.deviceName;
                            }
                            
                            if ([self isNotNull:broadCast.likeCount]) {
                                modal.likesCount = broadCast.likeCount;
                            }
                            
                            if ([self isNotNull:broadCast.replies]) {
                                modal.repliesCount = broadCast.repliesCount;
                                modal.repliesArray = broadCast.replies;
                            }
                            modal.eventType = @"Broadcast";
                        } else if([event isKindOfClass:[CPSpecialEvent class]]) {
                            CPSpecialEvent *special = [results objectAtIndex:i];
                            if ([self isNotNull:special.specialId]) {
                                modal.specialId = special.specialId;
                            }
                            if ([self isNotNull:special.title]) {
                                modal.specialTilte = special.title;
                            }
                            if ([self isNotNull:special.redemptionList]) {
                                NSMutableArray *ranksArray = [[NSMutableArray alloc] init];
                                for (int i = 0 ; i < special.redemptionList.count; i++) {
                                    int rankNumber = [[special.redemptionList objectAtIndex:i] intValue];
                                    switch (rankNumber) {
                                        case 0:
                                            [ranksArray addObject:@"Bronze"];
                                            break;
                                        case 1:
                                            [ranksArray addObject:@"Silver"];
                                            break;
                                        case 2:
                                            [ranksArray addObject:@"Gold"];
                                            break;
                                        case 3:
                                            [ranksArray addObject:@"Anybody"];
                                            break;
                                            
                                        default:
                                            break;
                                    }
                                }
                                modal.rankNamesArray = ranksArray;
                            }
                            modal.eventType = @"Special";
                        } else if([event isKindOfClass:[CPFollowEvent class]]) {
                            //                        CPFollowEvent *rank = [results objectAtIndex:i];
                            modal.eventType = @"Follow";
                        } else if([event isKindOfClass:[CPCommentEvent class]]) {
                            CPCommentEvent *comment = [results objectAtIndex:i];
                            
                            if ([self isNotNull:comment.commentText]) {
                                modal.commentText = comment.commentText;
                            }
                            
                            if ([self isNotNull:comment.commentableText]) {
                                modal.reviewText = comment.commentableText;
                                modal.commentableText = comment.commentableText;
                            }
                            
                            if ([self isNotNull:comment.commentableCommentCount]) {
                                modal.repliesCount = comment.commentableCommentCount;
                                modal.commentableCommentsCount = comment.commentableCommentCount;
                            }
                            
                            if ([self isNotNull:comment.commentableLikeCount]) {
                                modal.likesCount = comment.commentableLikeCount;
                                modal.commentableLikesCount = comment.commentableLikeCount;
                            }
                            
                            if ([self isNotNull:comment.plugId]) {
                                modal.commentableId = [NSNumber numberWithInt:[comment.plugId intValue]];
                            }
                            
                            switch (comment.plugType) {
                                case CPEventTypeBroadcast:
                                    modal.commentType = @"Broadcast";
                                    break;
                                case CPEventTypeReview:
                                    modal.commentType = @"Review";
                                    break;
                                case CPEVentTypePrivateMessage:
                                    modal.commentType = @"Privatemessage";
                                    break;
                                default:
                                    break;
                            }
                            
                            modal.eventType = @"Comment";
                            
                        } else if([event isKindOfClass:[CPRecentActivitySurveyEvent class]]) {
                            CPRecentActivitySurveyEvent *surveyEvent = [results objectAtIndex:i];
                            
                            if ([self isNotNull:surveyEvent.surveyId]) {
                                modal.surveyId = [surveyEvent.surveyId stringValue];
                            }
                            
                            if ([self isNotNull:surveyEvent.surveyName]) {
                                modal.surveyTitle = surveyEvent.surveyName;
                            }
                            
                            modal.eventType = @"Surveys";
                            
                        } else if([event isKindOfClass:[CPRankEvent class]]) {
                            CPRankEvent *rank = [results objectAtIndex:i];
                            switch (rank.earnedRankType) {
                                case CPRankBronze:
                                    modal.rankName = @"bronze";
                                    break;
                                case CPRankGold:
                                    modal.rankName = @"gold";
                                    break;
                                case CPRankSilver:
                                    modal.rankName = @"silver";
                                    break;
                                default:
                                    break;
                            }
                            
                            modal.eventType = @"Rank";
                        }
                        //Hardcoding
                        //                    if (i==1) {
                        //                        modal.title = @"Announcing: PatientPlug 2.0";
                        //                        modal.videoUrl = @"";
                        //                        modal.audioUrl = @"";
                        //                        modal.descriptionHtml = @"Hello everybody, we're here with PatientPlug 2.0. HTML.";
                        //                        modal.eventType = @"Announcement";
                        //                        modal.descriptionMsg =@"Hello everybody, we're here with PatientPlug 2.0.";
                        //                    }
                    }
                    
                }
            }//end of for loop
        }
        NSError *error;
        BOOL isDataSaved = YES;
        // Store what we imported already
        if (![appDelegate.managedObjectContext save:&error]) {
            isDataSaved = NO;
            // Handle the error.
            //  NSLog(@"%@", [error domain]);
        }
        // NSLog(@"modal creation is completed");
        //create a dictionary and add streamModalarray as an object with key streamData
        NSDictionary *streamModalDict = [[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:isDataSaved],@"success",[NSNumber numberWithBool:isResponseNull],@"response", nil];
        //send the modal class objects to super controller
        if (caller_ && [caller_ conformsToProtocol:@protocol(RecentActivityServiceDelegate)] && [caller_ respondsToSelector:@selector(didFinishedStreamRequest:)]) {
            [caller_ didFinishedStreamRequest:streamModalDict];
        }
        caller_ = nil;
    }
    @catch (NSException *exception) { //cath and display the exception
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didFailToReceiveStreamWithError:(NSError*) error {
    @try {
        //inform super controller that something went wrong
        if (caller_ && [caller_ conformsToProtocol:@protocol(RecentActivityServiceDelegate)] && [caller_ respondsToSelector:@selector(didFailToGetStreamWithError:)]) {
            [caller_ didFailToGetStreamWithError:[error localizedDescription]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)updateMostRecentlyViewedNotificationstime:(NSDate *)viewedDate {
    TCSTART
    CPCommonParameters *commonParameters = [[CPCommonParameters alloc] init];
    commonParameters.userId = [NSNumber numberWithInteger:[user_id integerValue]];
    commonParameters.authenticationToken = auth_token;
    commonParameters.applicationURL = [NSURL URLWithString:request_Url];
    commonParameters.apiKey = apiKey;
    commonParameters.isDebug = YES;
    
    CPStreamService *service = [[CPStreamService alloc] initWithCommonParameters:commonParameters withDelegate:self];
    [service updateMostRecentlyViewedNotificationTime:viewedDate];
    TCEND
}

- (void) didUpdateMostRecentlyViewedNotificationTime {
    TCSTART
    if (caller_ && [caller_ conformsToProtocol:@protocol(RecentActivityServiceDelegate)]  && [caller_ respondsToSelector:@selector(didFinishedSendingMostRecentViewedNotification)]) {
        [caller_ didFinishedSendingMostRecentViewedNotification];
    }
    TCEND
}
- (void) didFailToUpdateMostRecentlyViewedNotificationTimeWithError:(NSError*) error {
    TCSTART
    if (caller_ && [caller_ conformsToProtocol:@protocol(RecentActivityServiceDelegate)] && [caller_ respondsToSelector:@selector(didfailedtoSendMostRecentViewedNotificationOccuredAt:)]) {
        [caller_ didfailedtoSendMostRecentViewedNotificationOccuredAt:[error localizedDescription]];
    }
    TCEND
}
@end
