//
//  RedeemSpecialViewController.h
//  ChatterPlug
//
//  Created by shiva on 3/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ProviderDetailsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate> {
    
    CPPhysician *physician;
    UITableView *providerDetailsTable;
    AppDelegate *appDelegate;
    StreamDataModel *locationDataModal;
}
@property (nonatomic, retain) StreamDataModel *locationDataModal;
- (id)initWithPhysician:(CPPhysician *)physicianEvent;

@end
