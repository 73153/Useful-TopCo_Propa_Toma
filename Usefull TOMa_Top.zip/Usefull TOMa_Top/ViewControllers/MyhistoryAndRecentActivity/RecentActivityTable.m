//
//  LiveFeedViewController.m
//  LocationInfo
//
//  Created by shiva on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "RecentActivityTable.h"

#import "StreamService.h"
#import "CommentViewController.h"
#import "ReviewTableCell.h"
#import "NSAttributedString+Encoding.h"
#import "VideoPlayerViewController.h"
#import "DetailViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation RecentActivityTable
@synthesize locDataModel_Arr;
@synthesize myhistoryVCCaller;
@synthesize reloading;


- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    @try {
        self = [super initWithFrame:frame style:style];
        if (self) {
            // Initialization code
            editable_commment_indexpath = [NSIndexPath indexPathForRow:-1 inSection:-1];
            NSLog(@"TableView Width:%f",self.frame.size.width);
            appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
            
            self.delegate = self;
            self.dataSource = self;
            self.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
            
            self.backgroundColor = [UIColor clearColor];
            //            self.separatorColor = [UIColor colorWithRed:(54.0f/255.0f) green:(54.0f/255.0f) blue:(57.0f/255.0f) alpha:1.0f];
            self.separatorColor = [UIColor clearColor];
            self.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
            self.autoresizingMask = UIViewAutoresizingFlexibleHeight;
            self.allowsSelectionDuringEditing = YES;
            locDataModel_Arr = [[NSMutableArray alloc] init];
            
            //add the refreshstream class to the table view
            refreshLiveFeed = [[RefreshView alloc] initWithFrame:
                               CGRectMake(self.frame.origin.x,- self.bounds.size.height,
                                          self.frame.size.width, self.bounds.size.height)];
            [self addSubview:refreshLiveFeed];
            self.showsVerticalScrollIndicator = YES;
            
            commentCell_height = 30;
            
            plugBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            plugBtn.backgroundColor = [UIColor blueColor];
            plugBtn.frame = CGRectMake(310, 5, 48, 25);
            plugBtn.tag = 1;
            [plugBtn setBackgroundImage:[UIImage imageNamed:@"delete.jpg"] forState:UIControlStateNormal];
            [plugBtn addTarget:self action:@selector(deleteSection:event:) forControlEvents:UIControlEventTouchUpInside];
            
            activityPageNumber = 1;
        }
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}


#pragma mark Scrolling Overrides
#pragma mark TableScrollView Delegate Methods Refreshing Table
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    @try {
        isDeleteBtnVisible = NO;
        plugBtn.frame = CGRectMake(320, 5, 48, 25);
        // NSLog(@"scrollViewWillBeginDragging");
        if (!reloading) {
            checkForRefresh = YES;  //  only check offset when dragging
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    @try {
        // NSLog(@"scrollViewDidScroll with offset %f",scrollView.contentOffset.y);
        if (reloading) return;
        
        if (checkForRefresh) {
            if (refreshLiveFeed.isFlipped && scrollView.contentOffset.y > -45.0f && scrollView.contentOffset.y < 0.0f && !reloading) {
                [refreshLiveFeed flipImageAnimated:YES];
                [refreshLiveFeed setStatus:kPullToReloadStatus];
                
            } else if (!refreshLiveFeed.isFlipped && scrollView.contentOffset.y < -45.0f) {
                [refreshLiveFeed flipImageAnimated:YES];
                [refreshLiveFeed setStatus:kReleaseToReloadStatus];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Load images for all onscreen rows when scrolling is finished
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    @try {
        if (reloading) return;
        
        if (scrollView.contentOffset.y <= -45.0f) {
            [self showReloadAnimationAnimated:YES];
            [self refreshRecentActivities];
        }
        checkForRefresh = NO;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
}

- (NSIndexPath *)getIndexPathForEvent:(UIEvent *)event {
    
    NSIndexPath *indexPath = nil;
    @try {
        NSSet *allTouches = [event allTouches];
        CGPoint likeLocationPoint = [[allTouches anyObject]locationInView:self];
        indexPath = [self indexPathForRowAtPoint:likeLocationPoint];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
    return indexPath;
}

- (void) showReloadAnimationAnimated:(BOOL)animated
{
    @try {
        reloading = YES;
        [refreshLiveFeed toggleActivityView:YES];
        
        if (animated) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            self.contentInset = UIEdgeInsetsMake(40.0f, 0.0f, 0.0f, 0.0f);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)dataSourceDidFinishLoadingNewData {
    
    @try {
        reloading = NO;
        [refreshLiveFeed flipImageAnimated:NO];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        [self setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
        [refreshLiveFeed setStatus:kPullToReloadStatus];
        [refreshLiveFeed toggleActivityView:NO];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)refreshRecentActivities {
    activityPageNumber = 1;
    [myhistoryVCCaller netWorkCallForStreamRefresh];
}

#pragma mark CPEventType
- (CPEventType)returnCPEventTypeBySpecifiedParameter:(NSString *)eventType {
    TCSTART
    if ([eventType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
        return CPEventTypeReview;
    } else if ([eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
        return CPEventTypeBroadcast;
    } else  {
        return CPEVentTypePrivateMessage;
    }
    TCEND
}
#pragma mark Like A Review related
-(void)likeReview:(id)sender event:(UIEvent *)event{
    
    @try {
        NSIndexPath *indexPath = [self getIndexPathForEvent:event]; // get the indexpath
        [self sendLikeRequest:indexPath];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)sendLikeRequest:(NSIndexPath *)indexPath {
    @try {
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            
            NSString *reviewId;
            CPEventType eventType;
            
            RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
            if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
                reviewId = [recentActivity.commentableId stringValue];
            } else {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
                reviewId = [recentActivity.eventId stringValue];
            }
            
            [appDelegate likedReviewWithReviewId:reviewId ofType:eventType withIndexPath:indexPath callbackObject:self];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Like A Review Request Delegate Methods
- (void)didFinishedLikedReviewRequest:(NSDictionary *)results {
    
    [appDelegate hideNetworkIndicator];
    @try {
        //   NSLog(@"didFinishedLikedReviewRequest %@",results);
        if ([self isNotNull:results] && [self isNotNull:[results objectForKey:@"likable_id"]]) {
            
            NSIndexPath *indexPath = [results objectForKey:@"indexPath"];
            RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
            
            NSArray *likesRecentActivitiesArray;
            if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                likesRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
            } else {
                likesRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
            }
            
            [self IncrementLikesCountOfRecentActivitys:likesRecentActivitiesArray];
            [appDelegate saveContext];
            //            [self reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
            [self reloadData];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)IncrementLikesCountOfRecentActivitys:(NSArray *)recentActivitysArray {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            int likes_count = [recentActivity.likesCount intValue];
            likes_count++;
            NSNumber *like_count = [NSNumber numberWithInt:likes_count];
            recentActivity.likesCount = like_count;
            recentActivity.commentableLikesCount = like_count;
        }
    }
    
    TCEND
}
- (void)didFailedToPostLikeWithError:(NSString *)errorMsg {
    
    @try {
        [appDelegate hideNetworkIndicator];
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark Comment Related Methods ======================================
- (void)postComment:(NSString *)commentText withIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        if ([self isNull:commentText])
            return;
        
        NSString *broadCastId = nil;
        NSString *reviewId = nil;
        NSString *privateMessageId = nil;
        RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            if ([recentActivity.commentType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
                broadCastId = [recentActivity.commentableId stringValue];
            } else if ([recentActivity.commentType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
                reviewId = [recentActivity.commentableId stringValue];
            } else {
                privateMessageId = [recentActivity.commentableId stringValue];
            }
        } else if([recentActivity.eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame) {
            broadCastId = [recentActivity.eventId stringValue];
        } else if([recentActivity.eventType caseInsensitiveCompare:@"review"] == NSOrderedSame) {
            reviewId = [recentActivity.eventId stringValue];
        } else {
            privateMessageId = [recentActivity.eventId stringValue];
        }
        
        if (commentText.length > 0) {
            [commentText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        [appDelegate postComment:commentText onReview:reviewId onBroadCast:broadCastId onPrivateMessage:privateMessageId withIndexPath:indexPath withCallbackObject:self withchannel_Id:recentActivity.channel_Id];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark Post Comment Request Delegate Methods.
- (void)didFinishedPostingComment:(NSDictionary *)results {
    @try {
        [appDelegate hideNetworkIndicator];
        //        NSLog(@"didFinishedPostingComment %@",results);
        if([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:[results objectForKey:@"postCommentResponse"]]){
            NSIndexPath *indexPath = nil;
            if ([self isNotNull:[results objectForKey:@"indexPath"]])
                indexPath = [results objectForKey:@"indexPath"];
            
            if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
                RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
                
                NSArray *commentsRecentActivitiesArray;
                if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                    commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
                } else {
                    commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
                }
                [self addReplyAndIncrementCommentsCountOfRecentActivitys:commentsRecentActivitiesArray andIndexPath:indexPath andComments:results];
                
                [appDelegate saveContext];
                
                //                [self reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
                [self reloadData];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)addReplyAndIncrementCommentsCountOfRecentActivitys:(NSArray *)recentActivitysArray andIndexPath:(NSIndexPath *)indexPath andComments:(NSDictionary *)results {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            NSMutableArray *replies_array = [[NSMutableArray alloc]init];
            int repliesCount = [recentActivity.repliesCount intValue];
            
            if ([self isNotNull:[results objectForKey:@"postCommentResponse"]]) {
                [replies_array addObject:[results objectForKey:@"postCommentResponse"]];
            }
            
            if ([self isNotNull:recentActivity.repliesArray]) {
                [replies_array addObjectsFromArray:recentActivity.repliesArray];
            }
            
            if ([self isNotNull:replies_array] && replies_array.count > 0) {
                recentActivity.repliesArray = replies_array;
            }
            
            repliesCount = repliesCount + 1;
            recentActivity.repliesCount = [NSNumber numberWithInt:repliesCount];
            recentActivity.commentableCommentsCount = [NSNumber numberWithInt:repliesCount];
        }
    }
    
    TCEND
}

- (void)didFailedToPostCommentWithError:(NSString *)errorMsg {
    @try {
        [appDelegate hideNetworkIndicator];
        //  NSLog(@"didFailedToPostCommentWithError %@",errorMsg);
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark Deleting Comment ===========================================
- (void)deleteComment:(NSIndexPath *)indexPath {
    [appDelegate showNetworkIndicator];
    [appDelegate showActivityIndicatorInView:appDelegate.window];
    
    @try {
        NSNumber *commetnId = nil;
        NSNumber *eventId;
        CPEventType eventType;
        RecentActivity *recentActivity = nil;
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
        }
        if ([self isNotNull:recentActivity]) {
            if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
                eventId = [NSNumber numberWithInt:[recentActivity.commentableId intValue]];
            } else {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
                eventId = recentActivity.eventId;
            }
            
            if([self isNotNull:recentActivity.repliesArray] && [recentActivity.repliesArray count] > indexPath.row - 1) {
                CPReply *reply = [recentActivity.repliesArray objectAtIndex:indexPath.row - 1];
                commetnId = reply.replyId;
            }
        }
        [appDelegate requestForDeletedComment:commetnId onReview:eventId atIndexPath:indexPath withCallbackObject:self andEventType:eventType];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFinishedDeletingComment:(NSDictionary *)results {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:[results objectForKey:@"indexPath"]]) {
            NSIndexPath *indexPath = [results objectForKey:@"indexPath"];
            
            if ([self isNotNull:indexPath] && [self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
                
                RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
                if ([self isNotNull:recentActivity]) {
                    NSMutableArray *replies_Arry = [[NSMutableArray alloc] initWithArray:recentActivity.repliesArray];
                    if ([self isNotNull:replies_Arry] && replies_Arry.count > indexPath.row - 1) {
                        
                        CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
                        
                        /** Deleting if the same comment is existing in database with replyId to avoid the dublication
                         */
                        if ([self isNotNull:reply]) {
                            RecentActivity *commentRecentActvity = [[appDelegate getRecentActivityEntityByEventId:reply.replyId] objectAtIndex:0];
                            [appDelegate removeRecentActivityObjectFromDatabase:commentRecentActvity];
                            [locDataModel_Arr removeObject:commentRecentActvity];
                        }
                        
                        /** Changing attributes of RecentActivity entities where activityId matches
                         */
                        NSArray *commentsRecentActivitiesArray;
                        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                            commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
                        } else {
                            commentsRecentActivitiesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
                        }
                        
                        [self removeReplyAndDecrementCommentsCountOfRecentActivitys:commentsRecentActivitiesArray andIndexPath:indexPath];
                        
                        [appDelegate saveContext];
                        //                            [self reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationNone];
                        [self reloadData];
                    }
                }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)removeReplyAndDecrementCommentsCountOfRecentActivitys:(NSArray *)recentActivitysArray andIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if ([self isNotNull:recentActivitysArray] && recentActivitysArray.count > 0) {
        for (RecentActivity *recentActivity in recentActivitysArray) {
            NSMutableArray *replies_Arry = [[NSMutableArray alloc] initWithArray:recentActivity.repliesArray];
            int repliesCount = [recentActivity.repliesCount intValue];
            
            if ([self isNotNull:replies_Arry] && replies_Arry.count > indexPath.row - 1) {
                
                [replies_Arry removeObjectAtIndex:indexPath.row - 1];       //remove the deleted row from replies array
                recentActivity.repliesArray = replies_Arry;//set the replies array as an object with same key "replies"
                repliesCount = repliesCount - 1;
                
                recentActivity.repliesCount = [NSNumber numberWithInt:repliesCount];
                recentActivity.commentableCommentsCount = [NSNumber numberWithInt:repliesCount];
            }
        }
    }
    
    TCEND
}
- (void)didFailedToDeleteComment:(NSString *)errorMsg {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark Delete Review ===========================================

- (void)deleteReview:(NSIndexPath *)indexPath {
    
    @try {
        [appDelegate showNetworkIndicator];
        [appDelegate showActivityIndicatorInView:appDelegate.window];
        
        NSNumber *reviewId = nil;
        NSNumber *userId = nil;
        
        RecentActivity *recentActivity = nil;
        CPEventType eventType;
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
            if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.commentType];
                reviewId = [NSNumber numberWithInt:[recentActivity.commentableId intValue]];
                userId = [NSNumber numberWithInt:[recentActivity.otherUserId intValue]];
            } else {
                eventType = [self returnCPEventTypeBySpecifiedParameter:recentActivity.eventType];
                reviewId = recentActivity.eventId;
                userId = [NSNumber numberWithInt:[recentActivity.userId intValue]];
            }
        }
        [appDelegate requestForDeleteReview:reviewId onUser:userId atIndex:indexPath withCallbackObject:self andEventType:eventType];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFinishedDeletingReview:(NSDictionary *)results {
    
    @try {
        //        [appDelegate hideNetworkIndicator];
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        
        if ([self isNotNull:results] && [results isKindOfClass:[NSDictionary class]] && [self isNotNull:[results objectForKey:@"indexPath"]]) {
            NSIndexPath *indexPath = [results objectForKey:@"indexPath"];
            if ([self isNotNull:indexPath] && [self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
                RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
                
                NSArray *recentActivitesArray;
                if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                    recentActivitesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.commentableId];
                } else {
                    recentActivitesArray = [appDelegate getRecentActivityEntityByEventId:recentActivity.eventId];
                }
                
                for (RecentActivity *activity in recentActivitesArray) {
                    [appDelegate removeRecentActivityObjectFromDatabase:activity];
                }
                [appDelegate saveContext];
                [locDataModel_Arr removeObjectsInArray:recentActivitesArray];
                [self reloadData];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToDeleteReview:(NSString *)errorMsg {
    @try {
        //        [appDelegate hideNetworkIndicator];
        TCSTART
        [appDelegate hideNetworkIndicator];
        [appDelegate removeNetworkIndicatorInView:appDelegate.window];
        TCEND
        [appDelegate showErrorMsg:errorMsg];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark showAllComments
-(void)showAllComments:(id)sender event:(UIEvent *)event {
    @try {
        //  NSLog(@"showAllComments");
        NSIndexPath *indexPath = [self getIndexPathForEvent:event];
        [self goToCommentPage:indexPath];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)writeComment:(id)sender event:(UIEvent *)event {
    
    @try {
        //   NSLog(@"Write Comment");
        NSIndexPath *indexPath = [self getIndexPathForEvent:event];
        [self goToCommentPage:indexPath];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)addCommentView:(NSString *)eventType withId:(NSNumber *)eventId
{
    for(RecentActivity *activity in locDataModel_Arr)
    {
        // if([activity.eventId intValue] == eventId.intValue && [activity.eventType isEqualToString:eventType])
        NSLog(@"Values: %@:%@",activity.eventId,eventId);
        if([activity.eventId intValue] == eventId.intValue)
        {
            int row=1,section=1;
            section=[locDataModel_Arr indexOfObject:activity];
            if ([activity.repliesArray count] > 0) {
                if ([activity.eventType caseInsensitiveCompare:@"Review"] == NSOrderedSame || [activity.eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame || [activity.eventType caseInsensitiveCompare:@"Privatemessage"] == NSOrderedSame) {
                    if ([activity.repliesCount intValue] > 0 && [activity.repliesCount intValue] <= 1) {
                        row= [activity.repliesCount intValue] + 1;
                    } else if([activity.repliesCount intValue] >= 2) {
                        row= 2 + 1;
                    }
                }
            }
            NSIndexPath *inPath=[NSIndexPath indexPathForRow:row inSection:section];
            [self goToCommentPage:inPath];
        }
        //NSLog(@"activity:%@",activity);
    }
}

-(void)activityCheck:(NSIndexPath *)indexPath
{
    RecentActivity *activity = [locDataModel_Arr objectAtIndex:indexPath.section];
    if([self isNull:activity.eventId] && [self isNotNull:myhistoryVCCaller.activityCheckObject])
    {
        [locDataModel_Arr replaceObjectAtIndex:indexPath.section withObject:myhistoryVCCaller.activityCheckObject];
    }
}

- (void)goToCommentPage:(NSIndexPath *)indexPath {
    @try {
        if ([self isNotNull:indexPath]) {
            
            if([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
                //[self activityCheck:indexPath];
                RecentActivity *activity = [locDataModel_Arr objectAtIndex:indexPath.section];
                CommentViewController *commentVC = [[CommentViewController alloc]initWithNavigationCaller:self andLivefeedIndexPath:indexPath];
                
                CGFloat headerHeight;
                
                if ([activity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                    headerHeight = [self reviewRPrivateMessageRBroadCastHeightOfRecentActivity:activity];
                } else {
                    headerHeight = [self getheightForHeaderInSection:indexPath.section];
                }
                //commentVC.locationDelegate = locationDelegate_;
                commentVC.sectionHeght_float = headerHeight;
                [myhistoryVCCaller.navigationController pushViewController:commentVC animated:YES];
                myhistoryVCCaller.navigationController.navigationBar.hidden = YES;
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}


-(void)showDeleteBtn:(UIGestureRecognizer *)recognizer{
    
    @try {
        //might need to check if swipe has ended (otherwise not time to handle yet)
        if (recognizer.state != UIGestureRecognizerStateEnded)
            return;
        
        UIView *view = [recognizer view];
        [self animateBtnFrame:view];
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)animateBtnFrame:(UIView *)view {
    
    @try {
        //if (!plugBtn)
        //    plugBtn = (UIButton *)[view viewWithTag:1];
        //
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.6f];
        if (!isDeleteBtnVisible) {
            isDeleteBtnVisible = YES;
            [view addSubview:plugBtn];
            [view bringSubviewToFront:plugBtn];
            plugBtn.frame = CGRectMake(240, 5, 48, 25);
        }
        else{
            isDeleteBtnVisible = NO;
            plugBtn.frame = CGRectMake(320, 5, 48, 25);
        }
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)deleteSection:(id)sender event:(UIEvent *)event{
    @try {
    }
    @catch (NSException *exception) {
        NSLog(@"exception raised in LiveFeedTable while deleting sectin %@",exception);
    }
    @finally {
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    
    @try {
        //NSLog(@"gesturerecognizer state %d",gestureRecognizer.state);
        
        if ([touch.view isKindOfClass:[UIButton class]]) {      //change it to your condition
            return NO;
        }
        if (isDeleteBtnVisible) {
            UIView *view = [gestureRecognizer view];
            [self animateBtnFrame:view];
            return NO;
        }
        return YES;
    }
    @catch (NSException *exception) {
        //     NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark TableView Section & Row helper methods

-(CGFloat)getheightForHeaderInSection:(NSInteger)section {
    
    @try {
        
        RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:section];
        //        if ([recentActivity.rowHeight floatValue] > 0.0) {
        //            return [recentActivity.rowHeight floatValue];
        //        } else {
        int rowHeight;
        if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame) {
            
            CGFloat diff;
            CGFloat dateLabelHeight;
            CGFloat textLayerWidth;
            CGFloat nameHeight;
            if (iPad) {
                diff = 10;
                dateLabelHeight = 30;
                textLayerWidth = 660;
                nameHeight = 30;
            }else if (isiPhone6PLUS)
            {
                diff = 10;
                dateLabelHeight = 25;
                textLayerWidth = 255;
                nameHeight = 30;
            }
            else {
                diff = 5;
                dateLabelHeight = 20;
                textLayerWidth = 255;
                nameHeight = 20;
            }
            
            NSMutableAttributedString *mAttrbtdStr = [self createAttributedStringForEntity:recentActivity];
            CGSize size = [appDelegate getFrameSizeForAttributedString:mAttrbtdStr withWidth:textLayerWidth];
            recentActivity.attributedStringHeight = [NSNumber numberWithFloat:size.height];
            rowHeight = size.height + nameHeight + (diff * 3) + dateLabelHeight;
        }else if([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame){
            //
            //            MessageDataModel *dataModal = [eventsArray objectAtIndex:indexPath.row];
            CGSize nameSize;
            if ([self isNotNull:recentActivity.title]) {
                nameSize = [recentActivity.title sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            }
            CGSize descptnSize;
            descptnSize = [recentActivity.descriptionMsg sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
            CGFloat gaps;
            CGFloat heightOfTheRow;
            if (iPad) {
                gaps = 30;
                heightOfTheRow = 74;
            }else if (isiPhone6PLUS)
            {
                gaps = 20;
                heightOfTheRow = 66;
            }
            else {
                gaps = 15;
                heightOfTheRow = 46;
            }
            if (nameSize.height + descptnSize.height + gaps > heightOfTheRow) {
                //                return nameSize.height + descptnSize.height + gaps;
                rowHeight =nameSize.height + descptnSize.height + gaps;
            } else {
                //                return heightOfTheRow;
                rowHeight = heightOfTheRow;
            }
            //
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) {
            if (iPad) {
                rowHeight = 65;
            } else {
                rowHeight = isiPhone6PLUS?75:55;
            }
        } else {
            rowHeight = [self reviewRPrivateMessageRBroadCastHeightOfRecentActivity:recentActivity];
        }
        
        if ([self isNotNull:recentActivity.starsCount] && recentActivity.starsCount.intValue > 0) {
            rowHeight = rowHeight + CELL_RATEIMAGEVIEWHEIGHT;
        }
        recentActivity.rowHeight = [NSNumber numberWithFloat:rowHeight];
        [appDelegate saveContext];
        return rowHeight;
        //        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat)reviewRPrivateMessageRBroadCastHeightOfRecentActivity:(RecentActivity *)recentActivity {
    TCSTART
    CGFloat reviewerNameHeight = 0.0f;
    CGFloat reviewStrHeight = 0.0f;
    CGFloat photoHeight = 0.0f;
    CGFloat diff;
    if (iPad) {
        diff = 20;
    } else {
        diff = isiPhone6PLUS?20:10;
    }
    NSString *name = nil;
    NSString *review = nil;
    if ([self isNotNull:recentActivity]) {
        review = recentActivity.reviewText;
        name = recentActivity.locationName;
        if ([self isNotNull:name])
            //replace appDelegate with self.locationDelegate for static libraries
            reviewerNameHeight = [appDelegate getStringHeight:name withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff + 30) withFontSize:isiPhone6PLUS?18.0f:titleFontSize withFontName:titleFontName];
        if ([self isNotNull:review]){
            reviewStrHeight = [appDelegate getStringHeight:review withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff) withFontSize:isiPhone6PLUS?18.0f:descriptionTextFontSize withFontName:descriptionTextFontName];
        }
        if ([self isNotNull:recentActivity.photoUrlString]) {
            photoHeight = CELL_PLUGPHOTOHEIGHT;
        }
    }
    
    if (reviewerNameHeight == 0.0f)
        reviewerNameHeight = 15.0f;
    
    if (photoHeight > 0.0f)
        photoHeight += 5.0f;
    
    if ([recentActivity.starsCount intValue] > 0) {
        reviewStrHeight += 5.0f;
    }
    
    if ([recentActivity.starsCount intValue] <= 0 && reviewStrHeight == 0) {
        reviewStrHeight = (HEADER_MARGIN * 3);
    }
    
    if (iPad) {
        return reviewerNameHeight + reviewStrHeight + photoHeight + 30.0f + 50.0f;//"50" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    } else {
        return reviewerNameHeight + reviewStrHeight + photoHeight  + 25.0f + 30.0f;//"25" is for showing the comments and likes count as well for displaying the time of review. "25" is for spacing
    }
    TCEND
}

#pragma mark Tableview Datasource and dalegate methods
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (locDataModel_Arr.count == 0) {
        return 300;
    }
    return 1.0;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        UIView *headerView; //
        UILabel *messageLabel;
        
        headerView = [[UIView alloc] initWithFrame:CGRectZero];
        if (locDataModel_Arr.count == 0) {
            if (iPad) {
                messageLabel = [[UILabel alloc] initWithFrame: CGRectMake(5, 5, HEADER_WIDTH,80)];
            } else {
                messageLabel = [[UILabel alloc] initWithFrame: CGRectMake(5, 5, HEADER_WIDTH,80)];
            }
            
            messageLabel.textAlignment = NSTextAlignmentCenter;
            messageLabel.textColor = [UIColor whiteColor];
            messageLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
            messageLabel.numberOfLines = 0;
            messageLabel.text = @"You have no history and recent activities.";
            messageLabel.backgroundColor = [UIColor clearColor];
            [headerView addSubview:messageLabel];
        }
        headerView.backgroundColor = [UIColor clearColor];
        
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    if(indexPath.section == locDataModel_Arr.count) {
        return (iPad?70:isiPhone6PLUS?60:40);
    }
    if(indexPath.row == 0 && locDataModel_Arr.count > 0) {
        return [self getheightForHeaderInSection:indexPath.section];
    }
    
    RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
    if ([recentActivity.eventType caseInsensitiveCompare:@"Review"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Privatemessage"] == NSOrderedSame) {
        if (([recentActivity.repliesCount intValue] > 1 && indexPath.row == 2)) {
            return (iPad ? 50 :isiPhone6PLUS?50:30);
        }
        return [self getheightForRowInSection:indexPath]+(iPad?0:isiPhone6PLUS?10:5);
    }
    //        else if([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
    //                    CGSize nameSize;
    //                    if ([self isNotNull:recentActivity.title]) {
    //                        nameSize = [recentActivity.title sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    //                    }
    //                    CGSize descptnSize = [recentActivity.descriptionMsg sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    //                    CGFloat gaps;
    //                    CGFloat heightOfTheRow;
    //                    if (iPad) {
    //                        gaps = 30;
    //                        heightOfTheRow = 70;//74
    //                    } else {
    //                        gaps = 15;
    //                        heightOfTheRow = 46;//46
    //                    }
    //                    if (nameSize.height + descptnSize.height + gaps > heightOfTheRow) {
    //                        return nameSize.height + descptnSize.height + gaps;
    //                    } else {
    //                        return heightOfTheRow;
    //                    }
    //        }else{
    //                        if(indexPath.row == 0 && locDataModel_Arr.count > 0) {
    //                            return [self getheightForHeaderInSection:indexPath.section];
    //                        }
    //        }
    TCEND
    //
    //    TCSTART
    //    CGSize nameSize;
    //    if ([self isNotNull:dataModal.recentActivity.nameSize]) {
    //        nameSize = [dataModal.messageTitle sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    //    }
    //    CGSize descptnSize = [dataModal.description sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    //    CGFloat gaps;
    //    CGFloat heightOfTheRow;
    //    if (iPad) {
    //        gaps = 30;
    //        heightOfTheRow = 74;
    //    } else {
    //        gaps = 15;
    //        heightOfTheRow = 46;
    //    }
    //    if (nameSize.height + descptnSize.height + gaps > heightOfTheRow) {
    //        return nameSize.height + descptnSize.height + gaps;
    //    } else {
    //        return heightOfTheRow;
    //    }
    //    TCEND
    
    //
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    @try {
        NSLog(@"locDataModel_Arr.count: %d, activityPageNumber: %d",locDataModel_Arr.count,activityPageNumber);
        if(locDataModel_Arr.count > 0 && locDataModel_Arr.count >= activityPageNumber * 25 && locDataModel_Arr.count <= 1500) {
            return locDataModel_Arr.count + 1;
        } else {
            return locDataModel_Arr.count;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    @try {
        if (locDataModel_Arr.count > section) {
            RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:section];
            if ([recentActivity.repliesArray count] > 0) {
                if ([recentActivity.eventType caseInsensitiveCompare:@"Review"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Privatemessage"] == NSOrderedSame) {
                    if ([recentActivity.repliesCount intValue] > 0 && [recentActivity.repliesCount intValue] <= 1) {
                        return [recentActivity.repliesCount intValue] + 1;
                    } else if([recentActivity.repliesCount intValue] >= 2) {
                        return 2 + 1;
                    }
                }
            }
        }
        return 1;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = nil;
    //CommentTextView *cmt_TextView = nil;
    UIButton *btnMoreComments = nil;
    UIImageView *arrowImageView = nil;
    UILabel *lblCommentorName = nil;
    UILabel *lblComment = nil;
    UIImageView *userImageView = nil;
    UIImageView *lockImageview = nil;
    UILabel *commentTimeLabel =nil;
    BOOL isReturnReturned=NO;
    @try {
        
        static NSString *headerIdentifier = @"headerIdentifier";
        static NSString *commentCellIdentifier = @"CommentCellIdentifier";
        static NSString *loadMoreCellIdentifier = @"loadMoreCellIdentifier";
        static NSString *seeAllCommentsIdentifier = @"SeeAllCommentsIdentifier";
        if(indexPath.section == locDataModel_Arr.count) {
            UIActivityIndicatorView *activityIndicator_view = nil;
            UIView *loadMoreCellBg = nil;
            cell = [tableView dequeueReusableCellWithIdentifier:loadMoreCellIdentifier];
            if(cell == nil){
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:loadMoreCellIdentifier];
                
                activityIndicator_view = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:(iPad?UIActivityIndicatorViewStyleWhiteLarge:UIActivityIndicatorViewStyleWhite)];
                if (iPad) {
                    loadMoreCellBg = [[UIView alloc]initWithFrame:CGRectMake(10, 0, 748, 70)];
                    activityIndicator_view.frame = CGRectMake((CELL_CONTENT_WIDTH - 40)/2, 15, 40, 40);
                } else {
                    loadMoreCellBg = [[UIView alloc]initWithFrame:CGRectMake(5, 0, appDelegate.window.frame.size.width-10, 40)];
                    activityIndicator_view.frame = CGRectMake((CELL_CONTENT_WIDTH - 20)/2, 10, 20, 20);
                }
                loadMoreCellBg.layer.cornerRadius = 6.0f;
                loadMoreCellBg.layer.masksToBounds = YES;
                loadMoreCellBg.opaque = YES;
                loadMoreCellBg.tag = -1200;
                loadMoreCellBg.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"livefeedcellbg"]];
                [cell addSubview:loadMoreCellBg];
                
                [loadMoreCellBg addSubview:activityIndicator_view];
                activityIndicator_view.tag = -7000;
                
            }
            if (!loadMoreCellBg) {
                loadMoreCellBg = (UIView *)[cell viewWithTag:-1200];
            }
            if (!activityIndicator_view) {
                activityIndicator_view = (UIActivityIndicatorView *)[loadMoreCellBg viewWithTag:-7000];
            }
            
            [activityIndicator_view startAnimating];
            cell.backgroundColor = [UIColor clearColor];
            cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
            isReturnReturned=YES;
            return cell;
        }
        
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
            //            NSLog(@"Rec. Actvity title: %@, desc: %@",recentActivity.title,recentActivity.description);
            isReturnReturned=YES;
            if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame||[recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame) {
                UITableViewCell *cell = [self tableView:tableView loadFavoriteRLikeRCmtCellAtIndexpath:indexPath];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.backgroundColor = [UIColor clearColor];
                cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                
                return cell;
            } else if([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) {
                UITableViewCell *cell = [self tableView:tableView loadSurveyCellAtIndexpath:indexPath];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.backgroundColor = [UIColor clearColor];
                cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                return cell;
            } else if([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame  || [recentActivity.eventType caseInsensitiveCompare:@"Reminder"] == NSOrderedSame) {
                
                static NSString *CellIndentifier = @"CellForMessage";
                UITableViewCell *cell = nil;
                UIImageView *avtar = nil;
                UILabel *name = nil;
                UILabel *descrption = nil;
                
                CGFloat diff;
                CGFloat accessoryWidth;
                CGFloat rowHeight;
                CGFloat avtarImgWidhtNHeight;
                UIView * followingView = nil;
                UIImageView *backgroundImgView = nil;
                if (iPad) {
                    diff = 10;//16
                    accessoryWidth = 30;
                    rowHeight = 74;
                    avtarImgWidhtNHeight = 54;
                }else if (isiPhone6PLUS)
                {
                    diff = 10;
                    accessoryWidth = 30;
                    rowHeight = 66;
                    avtarImgWidhtNHeight = 46;
                }
                else {
                    diff = 7;
                    accessoryWidth = 20;
                    rowHeight = 46;
                    avtarImgWidhtNHeight = 36;
                }
                
                //                cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
                //initialize cell and its subviews instances once and use them when table scrolling through their instances retrieved based on "Tag" value
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIndentifier];
                    //                    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                    //                        [appDelegate addBackgroundViewToTheCell:cell];
                    //                    }
                    cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]] ;
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    followingView = [[UIView alloc] init];
                    followingView.layer.cornerRadius = 6.0f;
                    followingView.layer.masksToBounds = YES;
                    followingView.opaque = YES;
                    followingView.tag = -1200;
                    followingView.backgroundColor = [UIColor clearColor];
                    [cell addSubview:followingView];
                    
                    backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"livefeedcellbg"]];
                    backgroundImgView.tag = -2000;
                    backgroundImgView.layer.cornerRadius = 5.0f;
                    backgroundImgView.layer.masksToBounds = YES;
                    
                    [followingView addSubview:backgroundImgView];
                    
                    if (iPad) {
                        followingView.frame = CGRectMake(10, 0, 748, [recentActivity.rowHeight floatValue]);
                    } else {
                        followingView.frame = CGRectMake(5, 0, appDelegate.window.frame.size.width-10, [recentActivity.rowHeight floatValue]);
                    }
                    NSLog(@"cell Height: %@",recentActivity.rowHeight);
                    backgroundImgView.frame = CGRectMake(0, 0, HEADER_WIDTH, followingView.frame.size.height);
                    
                    
                    avtar = [[UIImageView alloc]initWithFrame:CGRectMake(diff+(iPad?6:0), diff, avtarImgWidhtNHeight, avtarImgWidhtNHeight)];
                    [avtar setBackgroundColor:[UIColor clearColor]];
                    [avtar.layer setBorderColor:[[UIColor clearColor]CGColor]];
                    [avtar.layer setBorderWidth:1.0f];
                    avtar.layer.cornerRadius = 5.0;
                    avtar.layer.masksToBounds = YES;
                    [avtar setTag:1];
                    //                    [cell.contentView addSubview:avtar];
                    [followingView addSubview:avtar];
                    
                    name = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff ,diff-3, CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + diff + accessoryWidth),40)];
                    name.backgroundColor = [UIColor clearColor];
                    name.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
                    [name setTag:2];
                    name.numberOfLines = 0;
                    name.lineBreakMode = NSLineBreakByWordWrapping;
                    name.textAlignment = NSTextAlignmentLeft;
                    name.textColor = [UIColor lightGrayColor];
                    //                    [cell.contentView addSubview:name];
                    [followingView addSubview:name];
                    
                    descrption = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff ,diff - 3, CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + diff + accessoryWidth),40)];
                    descrption.backgroundColor = [UIColor clearColor];
                    descrption.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                    [descrption setTag:3];
                    descrption.numberOfLines = 0;
                    descrption.lineBreakMode = NSLineBreakByWordWrapping;
                    descrption.textAlignment = NSTextAlignmentLeft;
                    descrption.textColor = [UIColor lightGrayColor];
                    //                    [cell.contentView addSubview:descrption];
                    [followingView addSubview:descrption];
                    
                    
                }
                
                if (!avtar) {
                    avtar = (UIImageView *)[cell.contentView viewWithTag:1];
                }
                if (!name)
                    name = (UILabel *)[cell.contentView viewWithTag:2];
                if (!descrption) {
                    descrption = (UILabel *)[cell.contentView viewWithTag:3];
                }
                
                //get the Like data for a row
                //                MessageDataModel *dataModel = [eventsArray objectAtIndex:indexPath.row];
                
                //check if Like data for a row is not null
                if ([self isNotNull:recentActivity]) {
                    
                    if ([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"EventsPlaceHolder"];
                    } else if ([recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"ReferencesPlaceHolder"];
                    } else if ([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"NewsPlaceHolder"];
                    } else if ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"AudioPlaceHolder"];
                    } else if ([recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"VideoPlaceHolder"];
                    }  else if ([recentActivity.eventType caseInsensitiveCompare:@"Reminder"] == NSOrderedSame) {
                        avtar.image = [UIImage imageNamed:@"ReminderPlaceHolder"];
                    }
                    else {
                        avtar.image = [UIImage imageNamed:@"default-avatar-business"];
                    }
                    
                    //Display the name of a business or user
                    if ([self isNotNull:recentActivity.title]) {
                        name.text = recentActivity.title;
                    } else {
                        name.text = @"";
                    }
                    //
                    CGSize nameSize = [recentActivity.title sizeWithFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
                    name.frame = CGRectMake(name.frame.origin.x, name.frame.origin.y, name.frame.size.width, nameSize.height);
                    
                    if ([self isNotNull:recentActivity.descriptionMsg]) {
                        descrption.text = recentActivity.descriptionMsg;
                    } else {
                        descrption.text = @"";
                        if ((nameSize.height + (diff * 2)) < rowHeight) {
                            name.frame = CGRectMake(name.frame.origin.x, name.frame.origin.y, name.frame.size.width, rowHeight - (name.frame.origin.y * 2));
                        }
                    }
                    CGSize descrptionSize = [recentActivity.descriptionMsg sizeWithFont:[UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 20000.0f) lineBreakMode:NSLineBreakByWordWrapping];
                    descrption.frame = CGRectMake(descrption.frame.origin.x, name.frame.origin.y + name.frame.size.height + diff, descrption.frame.size.width, descrptionSize.height);
                }
                cell.backgroundColor = [UIColor clearColor];
                return cell;
                
            } else {
                int replies_count = 0;
                int likesCount = 0;
                NSString *deviceName;
                replies_count = [recentActivity.repliesCount intValue];
                
                if (indexPath.row == 0) {
                    NSString *eventType = nil;
                    
                    ReviewTableCell *review_cell = [tableView dequeueReusableCellWithIdentifier:headerIdentifier];
                    if (review_cell == nil) {
                        review_cell = [[ReviewTableCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:headerIdentifier];
                        [review_cell addSubviewToTableCell:self];
                        review_cell.backgroundColor = [UIColor clearColor];
                        //                        review_cell.backgroundView = nil;
                        review_cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                    }
                    //reset the photoUrl and its height so that previous values will be erased.
                    review_cell.photoUrl_str = nil;
                    review_cell.photoheight_float = 0.0f;
                    review_cell.rateImage = nil;
                    review_cell.locationImgview.hidden = YES;
                    
                    eventType = recentActivity.eventType;
                    replies_count = [recentActivity.repliesCount intValue];
                    likesCount = [recentActivity.likesCount intValue];
                    
                    if ([self isNotNull:recentActivity.reviewText]) {
                        review_cell.reviewText_str = recentActivity.reviewText;
                    } else {
                        review_cell.reviewText_str = @"";
                    }
                    
                    if ([self isNotNull:recentActivity.userAvatarUrl]) {
                        review_cell.reviewerAvatarUrl_str = recentActivity.userAvatarUrl;
                    } else {
                        review_cell.reviewerAvatarUrl_str = @"";
                    }
                    
                    deviceName = recentActivity.deviceName;
                    
                    if([eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame) {
                        
                        if ([self isNotNull:recentActivity.locationName]) {
                            
                            review_cell.reviewerName_str = recentActivity.locationName;
                        } else {
                            review_cell.reviewerName_str = @"";
                        }
                        
                        if ([self isNotNull:recentActivity.businessAvatarUrl]) {
                            review_cell.reviewerAvatarUrl_str = recentActivity.businessAvatarUrl;
                        } else {
                            review_cell.reviewerAvatarUrl_str = @"";
                        }
                        
                        review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-business";
                        
                    } else  {
                        
                        if ([eventType caseInsensitiveCompare:@"Review"] == NSOrderedSame) {
                            
                            if ([self isNotNull:recentActivity.starsCount] && [recentActivity.starsCount intValue] > 0) {
                                
                                review_cell.rateImage = [appDelegate getImageForRating:[recentActivity.starsCount intValue]];
                            } else {
                                review_cell.rateImage = nil;
                            }
                            
                            if ([recentActivity.onLocation boolValue]) {
                                review_cell.locationImgview.hidden = NO;
                            }
                        }
                        
                        
                        if ([self isNotNull:recentActivity.userName]) {
                            review_cell.reviewerName_str = recentActivity.userName;
                        } else {
                            review_cell.reviewerName_str = @"";
                        }
                        
                        review_cell.reviewer_Default_AvatarUrl_str = @"default-avatar-user";
                    }
                    
                    
                    CGFloat diff;
                    if (iPad) {
                        diff = 20;
                    } else {
                        diff = isiPhone6PLUS?15:10;
                    }
                    if ([self isNotNull:review_cell.reviewerName_str] && review_cell.reviewerName_str.length > 0) {
                        //replace appDelegate with self.locationDelegate for static libraries
                        review_cell.reviewerNameHeight_float = [appDelegate getStringHeight:review_cell.reviewerName_str withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff + 30) withFontSize:isiPhone6PLUS?18.0f:titleFontSize withFontName:titleFontName];
                    } else {
                        review_cell.reviewerNameHeight_float = 0.0f;
                    }
                    if ([self isNotNull:review_cell.reviewText_str] && review_cell.reviewText_str.length > 0) {
                        review_cell.reviewTextHeight_float = [appDelegate getStringHeight:review_cell.reviewText_str withConstraintWidth:(HEADER_WIDTH - 10) - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH + diff) withFontSize:isiPhone6PLUS?18.0f:descriptionTextFontSize withFontName:descriptionTextFontName];
                        //   NSLog(@"review textheight float is %f",review_cell.reviewTextHeight_float);
                    } else {
                        review_cell.reviewTextHeight_float = 0.0f;
                    }
                    
                    if ([eventType caseInsensitiveCompare:@"review"] == NSOrderedSame || [eventType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
                        NSString *photoString = recentActivity.photoUrlString;
                        
                        if ([self isNotNull:photoString] && [photoString rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
                            review_cell.photoheight_float = CELL_PLUGPHOTOHEIGHT;
                            //NSString *photo_url = [appDelegate getPlugPhotoUrlString:photoString];
                            NSString *photo_url = photoString;
                            review_cell.photoUrl_str =  photo_url;
                            review_cell.postedImage = nil;
                        } else {
                            review_cell.photoheight_float = 0.0;
                            review_cell.photoUrl_str = @"";
                            review_cell.postedImage = nil;
                        }
                    } else {
                        review_cell.photoheight_float = 0.0;
                        review_cell.photoUrl_str = @"";
                        review_cell.postedImage = nil;
                    }
                    
                    
                    if ([self isNotNull:review_cell.rateImage]) {
                        review_cell.rateImageViewHieght_float = CELL_RATEIMAGEVIEWHEIGHT;
                    } else {
                        review_cell.rateImageViewHieght_float = 0.0f;
                    }
                    
                    review_cell.likeCount_str = [NSString stringWithFormat:@"%d",likesCount];
                    
                    review_cell.commentCount_str = [NSString stringWithFormat:@"%d",replies_count];
                    
                    if ([self isNotNull:recentActivity.date ]) {
                        
                        review_cell.time_str = [NSString stringWithFormat:@"%@",[appDelegate relativeDateString:recentActivity.date]];
                        
                    } else {
                        review_cell.time_str = @"";
                    }
                    
                    review_cell.hideCommentButton = NO;
                    
                    if ([eventType caseInsensitiveCompare:@"PrivateMessage"] == NSOrderedSame) {
                        review_cell.isPrivatePlug = YES;
                    } else {
                        review_cell.isPrivatePlug = NO;
                    }
                    
                    [review_cell setData];
                    review_cell.backgroundColor = [UIColor clearColor];
                    review_cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                    
                    if (replies_count > 0 && CURRENT_DEVICE_VERSION >= 7.0) {
                        review_cell.lineLabel.hidden = NO;
                    } else {
                        review_cell.lineLabel.hidden = YES;
                    }
                    
                    return review_cell;
                } else {
                    if ((replies_count > 1 && indexPath.row == 2)) {
                        UIImageView *backgroundImgView = nil;
                        cell = [tableView dequeueReusableCellWithIdentifier:seeAllCommentsIdentifier];
                        if (cell == nil) {
                            
                            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:seeAllCommentsIdentifier];
                            
                            backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
                            backgroundImgView.tag = 2000;
                            if (iPad) {
                                backgroundImgView.frame = CGRectMake((iPadCOMMENTCELLORIGINX) - 15, 0, 708, 50);
                            } else {
                                backgroundImgView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX), 0, appDelegate.window.frame.size.width-20, 30);
                            }
                            
                            [cell.contentView addSubview:backgroundImgView];
                            
                            if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section && [self isNotNull:[locDataModel_Arr objectAtIndex:indexPath.section]]) {
                                
                                //First reduce the texdfiled for commenting width.
                                btnMoreComments  = [UIButton buttonWithType:UIButtonTypeCustom];
                                btnMoreComments.tag = 2;
                                btnMoreComments.opaque = YES;
                                btnMoreComments.titleLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                                [btnMoreComments addTarget:self action:@selector(showAllComments:event:) forControlEvents:UIControlEventTouchUpInside];
                                [cell.contentView addSubview:btnMoreComments];
                                btnMoreComments.hidden = YES;
                                
                                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                            }
                        }
                        
                        if(editable_commment_indexpath.section ==  indexPath.section && editable_commment_indexpath.row ==  indexPath.row) {
                            return cell;
                        }
                        
                        if (!backgroundImgView) {
                            backgroundImgView = (UIImageView *)[cell.contentView viewWithTag:2000];
                        }
                        [backgroundImgView setImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
                        if (!btnMoreComments)
                            btnMoreComments = (UIButton *) [cell.contentView viewWithTag:2];
                        if (replies_count > 1) {
                            btnMoreComments.hidden = NO;
                            [btnMoreComments setTitle:[NSString stringWithFormat:@"See all %d comments >>",replies_count] forState:UIControlStateNormal];
                            if (iPad) {
                                btnMoreComments.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + 5 , 0, 708 , 50);
                            } else {
                                btnMoreComments.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + 5 , 0, 280, 30);
                            }
                        }
                        else{
                            btnMoreComments.hidden = YES;
                        }
                        
                        [appDelegate setMaskTo:backgroundImgView byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(5.0, 5.0)];
                        
                        
                    } else { //comment cell
                        CGFloat commentorNameHeight;
                        CGFloat commentStrHeight;
                        NSArray *replies_Arry;
                        
                        UIImageView *backgroundImgView = nil;
                        if (locDataModel_Arr.count > indexPath.section && [self isNotNull:recentActivity]) {
                            replies_Arry = recentActivity.repliesArray;
                        }
                        
                        cell = [tableView dequeueReusableCellWithIdentifier:commentCellIdentifier];
                        if (cell == nil) {
                            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:commentCellIdentifier];
                            
                            backgroundImgView = [[UIImageView alloc] init];
                            [backgroundImgView setImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
                            backgroundImgView.tag = 2000;
                            backgroundImgView.frame = CGRectMake((iPadCOMMENTCELLORIGINX) - 15, 0, 708, 60);
                            [cell.contentView addSubview:backgroundImgView];
                            
                            arrowImageView = [[UIImageView alloc]initWithFrame:CGRectMake((iPadCOMMENTCELLORIGINX) + 0, 3, 23, 32)];
                            arrowImageView.tag = 3;
                            [cell.contentView addSubview:arrowImageView];
                            
                            //Commentor Name
                            lblCommentorName = [[UILabel alloc]init];
                            lblCommentorName.numberOfLines = 0;
                            lblCommentorName.tag = 4;
                            lblCommentorName.opaque = YES;
                            lblCommentorName.textColor = [UIColor whiteColor];
                            lblCommentorName.backgroundColor = [UIColor clearColor];
                            lblCommentorName.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
                            [cell.contentView addSubview:lblCommentorName];
                            
                            //Comment
                            lblComment = [[UILabel alloc]init];
                            lblComment.numberOfLines = 0;
                            lblComment.opaque =  YES;
                            lblComment.tag = 5;
                            lblComment.backgroundColor = [UIColor clearColor];
                            lblComment.textColor = [UIColor whiteColor];
                            lblComment.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
                            [cell.contentView addSubview:lblComment];
                            
                            //Commentor Image
                            userImageView = [[UIImageView alloc]initWithFrame:CGRectMake((iPadCOMMENTCELLORIGINX) + backgroundImgView.frame.size.width - 60, 10, 40, 40)];
                            userImageView.layer.cornerRadius = 3.0f;
                            userImageView.layer.masksToBounds = YES;
                            userImageView.opaque = YES;
                            userImageView.tag = 6;
                            [cell.contentView addSubview:userImageView];
                            
                            //TODO KANAK
                            commentTimeLabel = [[UILabel alloc]init];
                            commentTimeLabel.layer.cornerRadius = 6.0f;
                            commentTimeLabel.layer.masksToBounds = YES;
                            commentTimeLabel.opaque = YES;
                            commentTimeLabel.tag = -77;
                            commentTimeLabel.textColor = [UIColor whiteColor];
                            commentTimeLabel.backgroundColor = [UIColor clearColor];
                            commentTimeLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?14.0f:dateFontSize];
                            commentTimeLabel.textAlignment = NSTextAlignmentRight;
                            [cell.contentView addSubview:commentTimeLabel];
                            
                            lockImageview = [[UIImageView alloc]init];
                            lockImageview.layer.cornerRadius = 6.0f;
                            lockImageview.layer.masksToBounds = YES;
                            lockImageview.opaque = YES;
                            lockImageview.tag = -6;
                            [cell.contentView addSubview:lockImageview];
                            
                            
                            if (!iPad) {
                                backgroundImgView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX), 0, appDelegate.window.frame.size.width-20, 60);
                                arrowImageView.frame = CGRectMake( (iPhoneCOMMENTCELLORIGINX) + 5, 3, 10, 10);
                                userImageView.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + appDelegate.window.frame.size.width-55, 5, 23, 23);
                            }
                        }
                        if (!arrowImageView)
                            arrowImageView = (UIImageView *)[cell.contentView viewWithTag:3];
                        if (!lblCommentorName)
                            lblCommentorName = (UILabel *) [cell.contentView viewWithTag:4];
                        if (!lblComment)
                            lblComment = (UILabel *)[cell.contentView viewWithTag:5];
                        if (!userImageView)
                            userImageView = (UIImageView *) [cell.contentView viewWithTag:6];
                        if (!lockImageview) {
                            lockImageview = (UIImageView *) [cell.contentView viewWithTag:-6];
                        }
                        if (!commentTimeLabel) {
                            commentTimeLabel = (UILabel *) [cell.contentView viewWithTag:-77];
                        }
                        
                        if (!backgroundImgView) {
                            backgroundImgView = (UIImageView *)[cell.contentView viewWithTag:2000];
                        }
                        
                        CGFloat rowheight = [self getheightForRowInSection:indexPath]+(iPad?0:isiPhone6PLUS?7:5);;
                        backgroundImgView.frame = CGRectMake(backgroundImgView.frame.origin.x, backgroundImgView.frame.origin.y, backgroundImgView.frame.size.width, rowheight);
                        if ([replies_Arry isKindOfClass:[NSArray class]] && replies_Arry.count > indexPath.row - 1 && [self isNotNull:[replies_Arry objectAtIndex:indexPath.row - 1]]) {
                            CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
                            
                            arrowImageView.image = [UIImage imageNamed:@"arrow_b"];
                            
                            if (iPad) {
                                CGFloat nameWidth = (708 - (5 + 40 + arrowImageView.frame.size.width + 40));
                                CGFloat commentNCommenterNameOriginX = (5 + arrowImageView.frame.size.width + 10);
                                
                                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                                //}
                                lblCommentorName.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + commentNCommenterNameOriginX ,5,nameWidth,MAX(commentorNameHeight, 0.0f));
                                
                                lblComment.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + commentNCommenterNameOriginX,lblCommentorName.frame.size.height + 10,nameWidth,MAX(commentStrHeight, 0.0f));
                                
                                lockImageview.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + (708 - 40), rowheight-40, 21, 25);
                                //								commentTimeLabel.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + (708 - 40)-210, rowheight-38+2 , 200, 25);
                                commentTimeLabel.frame = CGRectMake((iPadCOMMENTCELLORIGINX) + (708 - 40)-220, rowheight-40 , 210, 30);
                                
                            } else {
                                CGFloat nameWidth = ((appDelegate.window.frame.size.width-40)- (5 + 25 + arrowImageView.frame.size.width + 5));
                                CGFloat commentNCommenterNameOriginX = (5 + arrowImageView.frame.size.width + 2);
                                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:isiPhone6PLUS?18.0f:titleFontSize withFontName:titleFontName];
                                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:isiPhone6PLUS?18.0f:descriptionTextFontSize withFontName:descriptionTextFontName];
                                
                                lblCommentorName.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) +commentNCommenterNameOriginX,2,nameWidth,MAX(commentorNameHeight, 0.0f));
                                
                                lblComment.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + commentNCommenterNameOriginX,lblCommentorName.frame.size.height + 2,nameWidth,MAX(commentStrHeight, 0.0f));
                                lockImageview.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + (appDelegate.window.frame.size.width-40),rowheight-20, 9, 14);
                                commentTimeLabel.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + (appDelegate.window.frame.size.width-40) -130,isiPhone6PLUS?(rowheight-24):(rowheight-20+3), 125,isiPhone6PLUS?18:14);
                                //								commentTimeLabel.frame = CGRectMake((iPhoneCOMMENTCELLORIGINX) + 280-130, rowheight+1, 125, 14);
                            }
                            commentTimeLabel.text = [appDelegate relativeDateString:reply.occurredTime];
                            //							NSLog(@"Comment occured time: %@",[appDelegate relativeDateString:reply.occurredTime]);
                            
                            lblCommentorName.text = reply.displayName;
                            lblComment.text = reply.text;
                            
                            lockImageview.image = [UIImage imageNamed:@"commentLock"];
                            if ([recentActivity.eventType caseInsensitiveCompare:@"Review"] != NSOrderedSame) {
                                lockImageview.hidden = NO;
                            } else {
                                lockImageview.hidden = YES;
                            }
                            
                            if([[reply.avatarURL absoluteString] rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound)
                                [userImageView setImageWithURL:[NSURL URLWithString:[appDelegate getUserAvatarUrlString:[reply.avatarURL absoluteString]]] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
                            else
                                userImageView.image = [UIImage imageNamed:@"default-avatar-user"];
                            
                            cell.selectionStyle = UITableViewCellSelectionStyleNone;
                        }
                        
                        [backgroundImgView setImage:[UIImage imageNamed:@"commentlivefeedcellbg"]];
                        
                        if (indexPath.row == replies_count) {
                            [appDelegate setMaskTo:backgroundImgView byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(5.0, 5.0)];
                        } else {
                            [appDelegate setMaskTo:backgroundImgView byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(0.0, 0.0)];
                        }
                    }
                    cell.backgroundColor = [UIColor clearColor];
                    cell.backgroundView = [[UIView alloc] initWithFrame:CGRectZero];
                    return cell;
                }
            }
        }
        
        if(!isReturnReturned) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:loadMoreCellIdentifier];
            return cell;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    return cell;
}


- (CGFloat)getheightForRowInSection:(NSIndexPath *)indexPath {
    
    @try {
        CGFloat commentorNameHeight = 0;
        CGFloat commentStrHeight = 0;
        RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
        NSArray *replies_Arry = recentActivity.repliesArray;
        if ([replies_Arry isKindOfClass:[NSArray class]] && replies_Arry.count > indexPath.row - 1) {
            CPReply *reply = [replies_Arry objectAtIndex:indexPath.row - 1];
            
            if (iPad) {
                CGFloat nameWidth = ((708)- (5 + 40 + 23 + 40));
                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:titleFontSize withFontName:titleFontName];
                
                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:descriptionTextFontSize withFontName:descriptionTextFontName];
                
                //                NSLog(@"RowHeight:%f",commentorNameHeight + commentStrHeight + 30 + 15);
                return commentorNameHeight + commentStrHeight + 30 + 15 ;//"30" is for shwoing the time of review and 15 for spacing.
            }else {
                CGFloat nameWidth = (280 - (5 + 25 + 10 + 5));
                commentorNameHeight = [appDelegate getStringHeight:reply.displayName withConstraintWidth:nameWidth withFontSize:isiPhone6PLUS?18.0f:titleFontSize withFontName:titleFontName];
                
                commentStrHeight = [appDelegate getStringHeight:reply.text withConstraintWidth:nameWidth withFontSize:isiPhone6PLUS?18.0f:descriptionTextFontSize withFontName:descriptionTextFontName];
                
                //                NSLog(@"RowHeight:%f",commentorNameHeight + commentStrHeight + 15.0f);
                return commentorNameHeight + commentStrHeight + 15.0f ;//"15" is for shwoing the time of review.
            }
        } else {
            return 0.0f;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView loadFavoriteRLikeRCmtCellAtIndexpath:(NSIndexPath *)indexPath {
    
    @try {
        UITableViewCell *cell = nil;
        
        UIImageView *user_ImgView = nil;
        UILabel *nameLbl = nil;
        UILabel *dateLbl = nil;
        CATextLayer *textLayer = nil;   //used to draw the attributed string
        CALayer *layer = nil;           //used to draw the attributed string on textlayer and add that
        UIView *followingView = nil;
        UIImageView *backgroundImgView = nil;
        UIImageView *lockImageview = nil;
        static NSString *MyIdentifier = @"MyIdentifier";
        
        UIImageView *rateImgView = nil;
        UIImage *rateImage = nil;
        
        UIImageView *otherUser_ImgView = nil;
        CGFloat otherImgViewOrigin;
        //    CGFloat textLayerWidth;
        if (iPad) {
            //        diff = 10;
            otherImgViewOrigin = 45;
            //        textLayerWidth = 658;
        } else {
            //        diff = 5;
            //otherImgViewOrigin = isiPhone6PLUS?45:25;
            otherImgViewOrigin = 25;
            //        textLayerWidth = 250;
        }
        
        //        cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        
        CGFloat diff;
        CGFloat dateLabelHeight;
        CGFloat textLayerWidth;
        CGFloat nameHeight;
        CGFloat nameOriginY;
        if (iPad) {
            diff = 10;
            dateLabelHeight = 30;
            textLayerWidth = 660;
            nameHeight = 30;
            nameOriginY = 2;
        }else if (isiPhone6PLUS)
        {
            diff = 5;
            dateLabelHeight = 35;
            textLayerWidth = appDelegate.window.frame.size.width-65;
            nameHeight = 30;
            nameOriginY = 10;
        }
        else {
            diff = 5;
            dateLabelHeight = 20;
            textLayerWidth = appDelegate.window.frame.size.width-65;
            nameHeight = 20;
            nameOriginY = 5;
        }
        
        RecentActivity *recentActivity = nil;
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
        }
        if (cell == nil) {
            
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
            
            
            followingView = [[UIView alloc] init];
            followingView.layer.cornerRadius = 6.0f;
            followingView.layer.masksToBounds = YES;
            followingView.opaque = YES;
            followingView.tag = -1200;
            followingView.backgroundColor = [UIColor clearColor];
            [cell addSubview:followingView];
            
            
            backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"livefeedcellbg"]];
            backgroundImgView.tag = -2000;
            backgroundImgView.layer.cornerRadius = 5.0f;
            backgroundImgView.layer.masksToBounds = YES;
            backgroundImgView.frame = CGRectMake(0, 0, HEADER_WIDTH, followingView.frame.size.height);
            [followingView addSubview:backgroundImgView];
            
            user_ImgView = [[UIImageView alloc]initWithFrame:CGRectMake(diff, diff, REVIEWER_IMAGE_WIDTH, REVIEWER_IMAGE_HEIGHT)];
            user_ImgView.tag = -1;
            user_ImgView.layer.cornerRadius     = 4.0f;
            user_ImgView.layer.masksToBounds    = YES;
            user_ImgView.layer.opaque           = NO;
            [followingView addSubview:user_ImgView];
            
            nameLbl = [[UILabel alloc]initWithFrame:CGRectMake(user_ImgView.frame.origin.x + user_ImgView.frame.size.width + diff,nameOriginY,textLayerWidth,nameHeight)];
            [followingView addSubview:nameLbl];
            nameLbl.backgroundColor = [UIColor clearColor];
            nameLbl.tag = -3;
            nameLbl.numberOfLines = 0;
            nameLbl.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
            nameLbl.textColor = [UIColor whiteColor];
            
            dateLbl = [[UILabel alloc]init];
            [followingView addSubview:dateLbl];
            dateLbl.backgroundColor = [UIColor clearColor];
            dateLbl.textAlignment  = NSTextAlignmentRight;
            dateLbl.tag = -4;
            dateLbl.font = [UIFont fontWithName:dateFontName size:isiPhone6PLUS?14.0f:dateFontSize];
            dateLbl.textColor = [UIColor whiteColor];
            dateLbl = nil;
            
            textLayer = [[CATextLayer alloc] init];
            textLayer.backgroundColor = [UIColor clearColor].CGColor;
            [textLayer setForegroundColor:[[UIColor clearColor] CGColor]];
            [textLayer setContentsScale:[[UIScreen mainScreen] scale]];
            textLayer.wrapped = YES;
            layer = followingView.layer;
            [layer addSublayer:textLayer];
            textLayer = nil;
            
            rateImgView = [[UIImageView alloc]init];
            rateImgView.tag = -12;
            [followingView addSubview:rateImgView];
            rateImgView.hidden = YES;
            rateImgView = nil;
            
            lockImageview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"livefeedLock"]];
            lockImageview.layer.cornerRadius = 6.0f;
            lockImageview.layer.masksToBounds = YES;
            lockImageview.opaque = YES;
            lockImageview.tag = -6;
            [followingView addSubview:lockImageview];
            
            
            //OTHER USER
            //#define FAVOURITE_IMAGE_WIDTH (iPad?20.0f:20.0f)
            //#define FAVOURITE_IMAGE_HEIGHT (iPad?15.0f:15.0f)
            
            //            if (iPad) {
            otherUser_ImgView = [[UIImageView alloc]initWithFrame:CGRectMake(otherImgViewOrigin, otherImgViewOrigin, FAVOURITE_IMAGE_WIDTH, FAVOURITE_IMAGE_HEIGHT)];
            //            }else{
            //            otherUser_ImgView = [[UIImageView alloc]initWithFrame:CGRectMake(otherImgViewOrigin, otherImgViewOrigin, COMMENTOR_IMAGE_WIDTH, COMMENTOR_IMAGE_HEIGHT)];
            //            }
            
            otherUser_ImgView.tag = 7;
            otherUser_ImgView.layer.cornerRadius = 4.0f;
            otherUser_ImgView.layer.masksToBounds = YES;
            [followingView addSubview:otherUser_ImgView];
            //            otherUser_ImgView = nil;
            //
        }
        if (!followingView) {
            followingView = (UIView *)[cell viewWithTag:-1200];
        }
        if (!backgroundImgView) {
            backgroundImgView = (UIImageView *)[followingView viewWithTag:-2000];
        }
        if (!user_ImgView)
            user_ImgView = (UIImageView *)[followingView viewWithTag:-1];
        
        if (!otherUser_ImgView) {
            otherUser_ImgView = (UIImageView *)[cell.contentView viewWithTag:7];
        }
        
        if (!nameLbl)
            nameLbl = (UILabel *)[followingView viewWithTag:-3];
        if (!dateLbl)
            dateLbl = (UILabel *)[followingView viewWithTag:-4];
        
        if (!rateImgView) {
            rateImgView = (UIImageView *)[followingView viewWithTag:-12];
        }
        
        if (!lockImageview) {
            lockImageview = (UIImageView *)[followingView viewWithTag:-6];
        }
        
        
        if (iPad) {
            followingView.frame = CGRectMake(10, 0, 748, [recentActivity.rowHeight floatValue]);
        } else {
            followingView.frame = CGRectMake(5, 0, appDelegate.window.frame.size.width-10, [recentActivity.rowHeight floatValue]);
        }
        
        backgroundImgView.frame = CGRectMake(0, 0, HEADER_WIDTH, followingView.frame.size.height);
        
        if (([self isNotNull:recentActivity.userAvatarUrl] && [recentActivity.userAvatarUrl rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound)) {
            
            NSString *business_avatar_url;// = [appDelegate getUserAvatarUrlString:recentActivity.userAvatarUrl];
            
            if ([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame) {
                business_avatar_url = [appDelegate getUserAvatarUrlString:recentActivity.businessAvatarUrl];
            }else{
                business_avatar_url = [appDelegate getUserAvatarUrlString:recentActivity.userAvatarUrl];
            }
            if([recentActivity.eventType isEqualToString:@"Special"]){
            [user_ImgView setImageWithURL:[NSURL URLWithString:business_avatar_url] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
            }
            else
            [user_ImgView setImageWithURL:[NSURL URLWithString:business_avatar_url] placeholderImage:[UIImage imageNamed:@"default-avatar-user"]];
            
            business_avatar_url = nil;
        } else if (([self isNotNull:recentActivity.businessAvatarUrl] && [recentActivity.businessAvatarUrl rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound)) {
            
            NSString *business_avatar_url = [appDelegate getUserAvatarUrlString:recentActivity.businessAvatarUrl];
            [user_ImgView setImageWithURL:[NSURL URLWithString:business_avatar_url] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
            
            business_avatar_url = nil;
        } else {
            if(([recentActivity.eventType isEqualToString:@"Special"] || ([self isNotNull:recentActivity.businessAvatarUrl] && [recentActivity.businessAvatarUrl rangeOfString:@"avatar-business" options:NSCaseInsensitiveSearch].location != NSNotFound))) {
                user_ImgView.image = [UIImage imageNamed:@"default-avatar-business"];
            } else if (([self isNotNull:recentActivity.userAvatarUrl] && [recentActivity.userAvatarUrl rangeOfString:@"avatar-user" options:NSCaseInsensitiveSearch].location != NSNotFound)) {
                user_ImgView.image = [UIImage imageNamed:@"default-avatar-user"];
            }
        }
        if ([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame) {
            [otherUser_ImgView setHidden:NO];
            [otherUser_ImgView setImage:[UIImage imageNamed:@"heart"]];
        }else{
            otherUser_ImgView.hidden = YES;
        }
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            otherUser_ImgView.hidden = YES;
            //            NSLog(@"Comment in comm: %@",recentActivity.commentText);
        }
        
        //Display the name of a business or user
        if ([recentActivity.eventType isEqualToString:@"Special"] && [self isNotNull:recentActivity.locationName]) {
            nameLbl.text = recentActivity.locationName;
        } else if([self isNotNull:recentActivity.userName]){
            nameLbl.text = recentActivity.userName;
        } else {
            nameLbl.text = @"";
        }
        
        //TExt layer
        if (!layer)
            layer = followingView.layer;
        for (id subLayer in layer.sublayers) {
            if ([subLayer isKindOfClass:[CATextLayer class]]) {
                // NSLog(@"found textlayer");
                textLayer = subLayer;
            }
        }
        NSMutableAttributedString *mAttrbtdStr = [self createAttributedStringForEntity:recentActivity];
        textLayer.frame = CGRectMake(user_ImgView.frame.origin.x + user_ImgView.frame.size.width + diff, nameLbl.frame.origin.y + nameLbl.frame.size.height + diff, textLayerWidth, recentActivity.attributedStringHeight.floatValue);
        if([self isNotNull:mAttrbtdStr]) {
            textLayer.string = mAttrbtdStr;
            
        }
        NSMutableDictionary *newActions = [appDelegate getTextLayerTextAnimationStopProperties];
        textLayer.actions = newActions;
        mAttrbtdStr = nil;
        
        //Rate image
        if ([self isNotNull:recentActivity.starsCount] && [recentActivity.starsCount intValue] > 0) {
            rateImage = [appDelegate getImageForRating:[recentActivity.starsCount intValue]];
        } else {
            rateImage = nil;
        }
        CGFloat rateImageViewHeight_float;
        if ([self isNotNull:rateImage]) {
            rateImgView.hidden = NO;
            rateImgView.image = rateImage;
            rateImageViewHeight_float = CELL_RATEIMAGEVIEWHEIGHT;
        } else {
            rateImgView.hidden = YES;
            rateImageViewHeight_float = 0.0f;
        }
        [rateImgView setFrame:CGRectMake(textLayer.frame.origin.x,textLayer.frame.origin.y + textLayer.frame.size.height + 5, CELL_RATEIMAGEVIEWWIDTH, rateImageViewHeight_float)];
        
        //Date label
        dateLbl.frame = CGRectMake(user_ImgView.frame.origin.x + user_ImgView.frame.size.width + diff, rateImgView.frame.origin.y + rateImgView.frame.size.height + (iPad?10:-2), textLayerWidth, dateLabelHeight);
        
        if ([self isNotNull:recentActivity.date]) {
            dateLbl.text = [NSString stringWithFormat:@"%@",[appDelegate relativeDateString:recentActivity.date]];
        } else {
            dateLbl.text = @"";
        }
        
        if ([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            lockImageview.hidden = NO;
            dateLbl.frame = CGRectMake(dateLbl.frame.origin.x, dateLbl.frame.origin.y, dateLbl.frame.size.width - (iPad?30:10), dateLabelHeight);
            if (iPad) {
                [lockImageview setFrame:CGRectMake(dateLbl.frame.origin.x + dateLbl.frame.size.width + 3,  dateLbl.frame.origin.y, 21, 25)];
            } else {
                [lockImageview setFrame:CGRectMake(dateLbl.frame.origin.x + dateLbl.frame.size.width + 3,  dateLbl.frame.origin.y + 3, 9, 14)];
            }
        } else {
            lockImageview.hidden = YES;
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"%s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}


/** Need to refresh this header if survey is submitted.thats way it is set as section headerview.
 */
- (UITableViewCell *)tableView:(UITableView *)tableView loadSurveyCellAtIndexpath:(NSIndexPath *)indexPath {
    @try {
        static NSString *MyIdentifier = @"surveyIdentifier";
        UITableViewCell *cell = nil;
        
        UIView *surveyView = nil;
        UIImageView *backgroundImgView = nil;
        
        UILabel *surveyLabel = nil;
        UILabel *surveyNameLabel = nil;
        
        CGFloat headerHeight;
        if (iPad) {
            headerHeight = 65;
        }else if (isiPhone6PLUS)
        {
            headerHeight = 75;
        }
        else {
            headerHeight = 55;
        }
        cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
            
            surveyView = [[UIView alloc] init];
            [surveyView addSubview:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"livefeedsurvey"]]];
            surveyView.layer.cornerRadius = 6.0f;
            surveyView.layer.masksToBounds = YES;
            surveyView.opaque = YES;
            surveyView.tag = -1200;
            surveyView.backgroundColor = [UIColor clearColor];
            [cell addSubview:surveyView];
            
            backgroundImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"livefeedsurvey"]];
            backgroundImgView.tag = -2000;
            backgroundImgView.layer.cornerRadius = 5.0f;
            backgroundImgView.layer.masksToBounds = YES;
            [surveyView addSubview:backgroundImgView];
            
            
            surveyNameLabel = [[UILabel alloc] init];
            surveyNameLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:surveyTitleFontSize];
            surveyNameLabel.backgroundColor = [UIColor clearColor];
            surveyNameLabel.textColor = [UIColor blackColor];
            surveyNameLabel.numberOfLines = 0;
            surveyNameLabel.tag = 12;
            [surveyView addSubview:surveyNameLabel];
            
            surveyLabel = [[UILabel alloc] init];
            surveyLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?16.0f:(surveyTitleFontSize-2)];
            surveyLabel.backgroundColor = [UIColor clearColor];
            surveyLabel.textColor = [UIColor blackColor];
            surveyLabel.numberOfLines = 0;
            surveyLabel.tag = 11;
            surveyLabel.text = @"Help us improve our services by taking this short survey!";
            [surveyView addSubview:surveyLabel];
        }
        
        if (!surveyView) {
            surveyView = (UIView *)[cell viewWithTag:-1200];
        }
        
        if (!backgroundImgView) {
            backgroundImgView = (UIImageView *)[surveyView viewWithTag:-2000];
        }
        if (!surveyLabel) {
            surveyLabel = (UILabel *)[surveyView viewWithTag:11];
        }
        if (!surveyNameLabel) {
            surveyNameLabel = (UILabel *)[surveyView viewWithTag:12];
        }
        
        if (iPad) {
            surveyView.frame = CGRectMake(10, 0, 748, headerHeight);
            surveyNameLabel.frame = CGRectMake(95, 3, 590, 23);
            surveyLabel.frame = CGRectMake(95, 30, 590, 30);
        } else {
            surveyView.frame = CGRectMake(5, 0, appDelegate.window.frame.size.width-10, headerHeight);
            if(isiPhone6PLUS) {
                surveyNameLabel.frame = CGRectMake(78, 3, appDelegate.window.frame.size.width-80, 20);
                surveyLabel.frame = CGRectMake(78, 25, appDelegate.window.frame.size.width-80, 40);
            }
            else {
                surveyNameLabel.frame = CGRectMake(60, 3, appDelegate.window.frame.size.width-87, 15);
                surveyLabel.frame = CGRectMake(60, 20, appDelegate.window.frame.size.width-87, 30);
            }
        }
        
        backgroundImgView.frame = CGRectMake(0, 0, HEADER_WIDTH, surveyView.frame.size.height);
        
        RecentActivity *recentActivity = nil;
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
        }
        
        if ([self isNotNull:recentActivity.surveyTitle]) {
            surveyNameLabel.text = recentActivity.surveyTitle;
        } else {
            surveyNameLabel.text = @"Survey Name";
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"%s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        if (indexPath.section == locDataModel_Arr.count) {
            activityPageNumber = activityPageNumber + 1;
            [myhistoryVCCaller performSelector:@selector(loadMoreAcitivitiesWithPageNumber:) withObject:[NSNumber numberWithInt:activityPageNumber] afterDelay:0.001];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!reloading) {
        return [self canEditRowAtIndexPath:indexPath];
    } else {
        return NO;
    }
}

- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (editingStyle == UITableViewCellEditingStyleDelete)
        {
            [self deleteReviewOrCommentAtIndexPath:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    @finally {
    }
}

- (BOOL)canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        BOOL isRowEditable = NO;
        
        if ([self isNotNull:locDataModel_Arr] && locDataModel_Arr.count > indexPath.section) {
            
            RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
            if([recentActivity.eventType caseInsensitiveCompare:@"Broadcast"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"special"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"like"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"rank"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame) { //check the event type
                return NO;
            } else if([recentActivity.eventType caseInsensitiveCompare:@"Review"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"Privatemessage"] == NSOrderedSame) {
                int likes_count = [recentActivity.likesCount intValue];
                int replies_count = [recentActivity.repliesCount intValue];
                if(indexPath.row == 0) {
                    if((appDelegate.userProfileDataModel.userId.intValue == [recentActivity.userId intValue]) && replies_count == 0 && likes_count == 0)
                        return YES;
                } else if (replies_count >= 1 && indexPath.row == 1) {
                    CPReply *rply = [recentActivity.repliesArray objectAtIndex:indexPath.row - 1];
                    if(rply.userId.intValue == appDelegate.userProfileDataModel.userId.intValue) {
                        isRowEditable = YES;
                    }
                }
            }
        }
        return isRowEditable;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)deleteReviewOrCommentAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (indexPath.row == 0 ) { //row at zero location is always review.
            //  NSLog(@"delete review");
            [self deleteReview:indexPath];
        } else {
            //  NSLog(@"delete table row");
            [self deleteComment:indexPath];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    @try {
        if(!reloading) {
            NSLog(@"Section:Row  %i:%i",indexPath.section,indexPath.row);
            if([self isNotNull:[locDataModel_Arr objectAtIndex:indexPath.section]]) {
                RecentActivity *recentActivity = [locDataModel_Arr objectAtIndex:indexPath.section];
                if ([recentActivity.eventType caseInsensitiveCompare:@"review"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"broadcast"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"privatemessage"] == NSOrderedSame || [recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
                    [self goToCommentPage:indexPath];
                } else if ([recentActivity.eventType caseInsensitiveCompare:@"Surveys"] == NSOrderedSame && indexPath.row == 0) {
                    [myhistoryVCCaller makeSurveyQuestionsRequestWithSurveyId:recentActivity.surveyId];
                } else if ([recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame ||[recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
                    if ([appDelegate connectedToNetwork]) {
                        CGRect playerViewFrame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height);
                        
                        VideoPlayerViewController *videoPlayerVC = nil;
                        if ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
                            if ([self isNotNull:recentActivity.audioUrl]) {
                                videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:recentActivity.audioUrl andFrame:playerViewFrame andMediaType:@"Audio"];
                            }
                        } else {
                            if ([self isNotNull:recentActivity.videoUrl]) {
                                videoPlayerVC = [[VideoPlayerViewController alloc] initWithURL:recentActivity.videoUrl andFrame:CGRectMake(0, 0, playerViewFrame.size.height, playerViewFrame.size.width) andMediaType:@"Video"];
                            }
                        }
                        float osVersion = [[[UIDevice currentDevice] systemVersion] floatValue];
                        if (osVersion >= 5.0) {
                            [myhistoryVCCaller presentViewController:videoPlayerVC animated:YES completion:nil];
                        } else {
                            //[myhistoryVCCaller presentModalViewController: videoPlayerVC animated: YES];
                            [myhistoryVCCaller presentViewController:videoPlayerVC animated:YES completion:^{
                                //code
                            }];
                        }
                        
                    } else {
                        [appDelegate showErrorMsg:@"Internet connection appears to be offline"];
                    }
                } else {
                    if ([self isNotNull:recentActivity.descriptionHtml]) {
                        //TODO
                        CPMessageType cpMessageType;
                        
                        if ([recentActivity.eventType caseInsensitiveCompare:@"Note"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeNews;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Announcement"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeEvents;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"References"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeReferences;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Community"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeCommunity;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Health"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeHealth;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Video"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeVideo;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Audio"] == NSOrderedSame) {
                            cpMessageType = CPMessageTypeAudio;
                        }else if ([recentActivity.eventType caseInsensitiveCompare:@"Reminder"] == NSOrderedSame) {
                            cpMessageType = CPMessageReminder;
                        }
                        
                        DetailViewController *detailVC = [[DetailViewController alloc] initWithFrame:myhistoryVCCaller.view.frame andViewType:cpMessageType HTMLDescription:recentActivity.descriptionHtml];
                        detailVC.caller = self;
                        detailVC.detailTitleStr = recentActivity.title;
                        [myhistoryVCCaller.navigationController pushViewController:detailVC animated:YES];
                    }
                }
                
            }
        } else {
            [appDelegate showForegroundNotificationBanner:@"Refreshing recent activities. \nPlease wait..."];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,   exception);
    }
    @finally {
    }
}

#pragma mark Table Cell Data Support
- (NSMutableAttributedString *)createAttributedStringForEntity:(RecentActivity *)recentActivity
{
    //@autoreleasepool {
    @try {
        NSMutableString *rowString = [[NSMutableString alloc]init];
        NSMutableArray *boldRangesMutableArray = [[NSMutableArray alloc]init];
        NSRange boldStrRange  = NSMakeRange(0, 0);
        NSRange boldStr2Range = NSMakeRange(0, 0);
        NSRange boldStr3Range = NSMakeRange(0, 0);
        
        
        if ([recentActivity.eventType caseInsensitiveCompare:@"Special"] == NSOrderedSame && [self isNotNull:recentActivity.rankNamesArray] && [recentActivity.rankNamesArray count] > 0) {
            
            //append the formated string
            [rowString appendString:[NSString stringWithFormat:@"Posted a new Reward for %@: \"%@\"",[recentActivity.rankNamesArray  objectAtIndex:0],recentActivity.specialTilte]];
            //get the range
            if ([self isNotNull:[recentActivity.rankNamesArray objectAtIndex:0]]) {
                boldStrRange = [rowString rangeOfString:[recentActivity.rankNamesArray objectAtIndex:0]];
            }
            if ([self isNotNull:recentActivity.specialTilte]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.specialTilte];
            }
        }
        
        
        //User Activities----------
        
        else if([recentActivity.eventType caseInsensitiveCompare:@"follow"] == NSOrderedSame && [self isNotNull:recentActivity.locationName]) {
            [rowString appendString:[NSString stringWithFormat:@"Favorited %@",recentActivity.locationName ?: @""]];
            boldStrRange = [rowString rangeOfString:recentActivity.locationName];
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"Like"] == NSOrderedSame) {
            if ([self isNull:recentActivity.otherUserId] || [self isNull:recentActivity.userId]) {
                if ([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Liked message from %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                } else if ([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.userName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        if ([self isNotNull:recentActivity.userName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.userName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ : \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                        
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked %@'s message to %@ : \"%@\"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Liked your message to %@ \"%@\"",recentActivity.locationName ?: @"",recentActivity.likableText ?: @""]];
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
            //            if ([self isNotNull:recentActivity.likableText]) {
            //                boldStr3Range = [rowString rangeOfString:recentActivity.likableText];
            //            }
            
        } else if([recentActivity.eventType caseInsensitiveCompare:@"comment"] == NSOrderedSame) {
            if ([self isNull:recentActivity.userId] || [self isNull:recentActivity.otherUserId]) {
                if([self isNull:recentActivity.otherUserId]) {
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                    if ([self isNotNull:recentActivity.locationName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.locationName]];
                    }
                } else if([self isNull:recentActivity.userId]) {
                    if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                        if ([self isNotNull:recentActivity.otherUserName]) {
                            boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                        }
                    } else {
                        [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"",recentActivity.locationName ?: @""]];
                        boldStrRange = [rowString rangeOfString:@"your"];
                    }
                }
            } else {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on %@'s message to %@",recentActivity.commentText ?: @"",recentActivity.otherUserName ?: @"",recentActivity.locationName ?: @""]];
                    
                    if ([self isNotNull:recentActivity.otherUserName]) {
                        boldStrRange = [rowString rangeOfString:[NSString stringWithFormat:@"%@'s",recentActivity.otherUserName]];
                    }
                    
                } else if([recentActivity.otherUserId intValue] == [appDelegate.userProfileDataModel.userId intValue]) {
                    
                    [rowString appendString:[NSString stringWithFormat:@"Replied \"%@\" on your message to %@",recentActivity.commentText ?: @"" ,recentActivity.locationName ?: @""]];
                    
                    boldStrRange = [rowString rangeOfString:@"your"];
                }
            }
            
            if ([self isNotNull:recentActivity.locationName]) {
                boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
            }
            
        } else if ([recentActivity.eventType caseInsensitiveCompare:@"Userrank"] == NSOrderedSame) {
            if ([self isNotNull:recentActivity.rankName]) {
                if ([recentActivity.otherUserId intValue] != [appDelegate.userProfileDataModel.userId intValue]) {
                    [rowString appendString:[NSString stringWithFormat:@"%@ earned %@ rank at %@",recentActivity.otherUserName,recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                } else {
                    [rowString appendString:[NSString stringWithFormat:@"You earned %@ rank at %@",recentActivity.rankName?:@"",recentActivity.locationName?:@""]];
                }
                
                boldStrRange = [rowString rangeOfString:recentActivity.rankName];
                
                if ([self isNotNull:recentActivity.locationName]) {
                    boldStr2Range = [rowString rangeOfString:recentActivity.locationName];
                }
            }
            //                }
            //            }
        }
        
        if(boldStrRange.location != NSNotFound && boldStrRange.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStrRange]];
        }
        
        if(boldStr2Range.location != NSNotFound && boldStr2Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr2Range]];
        }
        
        if(boldStr3Range.location != NSNotFound && boldStr3Range.length > 0) {
            [boldRangesMutableArray addObject:[NSValue valueWithRange:boldStr3Range]];
        }
        
        if([self isNotNull:rowString]) {
            return [appDelegate getAttributedStringForString:rowString withBoldRanges:boldRangesMutableArray WithBoldFontName:titleFontName withNormalFontName:descriptionTextFontName];
        } else {
            return nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}



#pragma mark View Orientation
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
