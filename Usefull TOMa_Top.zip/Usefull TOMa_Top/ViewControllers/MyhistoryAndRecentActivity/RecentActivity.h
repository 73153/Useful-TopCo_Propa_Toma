//
//  RecentActivity.h
//  MemorialHealthSystem
//
//  Created by Aruna on 18/06/13.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface RecentActivity : NSManagedObject

@property (nonatomic, retain) NSNumber * onLocation;
@property (nonatomic, retain) NSNumber * attributedStringHeight;
@property (nonatomic, retain) NSString * badges;
@property (nonatomic, retain) NSString * businessAvatarUrl;
@property (nonatomic, retain) NSString * businessName;
@property (nonatomic, retain) NSString * channel_Id;
@property (nonatomic, retain) NSString * commentableAvatar;
@property (nonatomic, retain) NSNumber * commentableCommentsCount;
@property (nonatomic, retain) NSNumber * commentableId;
@property (nonatomic, retain) NSNumber * commentableLikesCount;
@property (nonatomic, retain) NSString * commentableText;
@property (nonatomic, retain) NSString * commentableUserName;
@property (nonatomic, retain) NSString * commentText;
@property (nonatomic, retain) NSString * commentType;
@property (nonatomic, retain) NSDate * date;
@property (nonatomic, retain) NSString * deviceName;
@property (nonatomic, retain) NSNumber * eventId;
@property (nonatomic, retain) NSString * eventType;
@property (nonatomic, retain) NSString * followersCount;
@property (nonatomic, retain) NSString * followingsCount;
@property (nonatomic, retain) NSNumber * isUserFollowsYou;
@property (nonatomic, retain) NSNumber * isYouFollowUser;
@property (nonatomic, retain) NSString * likableAvatar;
@property (nonatomic, retain) NSString * likableType;
@property (nonatomic, retain) NSNumber * likableCommentsCount;
@property (nonatomic, retain) NSString * likableId;
@property (nonatomic, retain) NSNumber * likableLikesCount;
@property (nonatomic, retain) NSString * likableText;
@property (nonatomic, retain) NSString * likableUserName;
@property (nonatomic, retain) NSNumber * likesCount;
@property (nonatomic, retain) NSString * locationCityState;
@property (nonatomic, retain) id locationCoordinates;
@property (nonatomic, retain) NSString * locationName;
@property (nonatomic, retain) NSString * notificationAvatar;
@property (nonatomic, retain) NSString * notificationSubject;
@property (nonatomic, retain) NSString * notificationText;
@property (nonatomic, retain) NSString * otherUserAvatarUrl;
@property (nonatomic, retain) NSString * otherUserId;
@property (nonatomic, retain) NSString * otherUserName;
@property (nonatomic, retain) NSNumber * phoneNumber;
@property (nonatomic, retain) NSString * photoUrlString;
@property (nonatomic, retain) NSDictionary *photoUrlStrings;
@property (nonatomic, retain) NSString * rankName;
@property (nonatomic, retain) id rankNamesArray;
@property (nonatomic, retain) id repliesArray;
@property (nonatomic, retain) NSNumber * repliesCount;
@property (nonatomic, retain) NSString * reviewCount;
@property (nonatomic, retain) NSString * reviewText;
@property (nonatomic, retain) NSNumber * rowHeight;
@property (nonatomic, retain) NSNumber * showRating;
@property (nonatomic, retain) NSNumber * specialId;
@property (nonatomic, retain) NSString * specialTilte;
@property (nonatomic, retain) NSString * starsCount;
@property (nonatomic, retain) NSString * streamId;
@property (nonatomic, retain) NSString * userAvatarUrl;
@property (nonatomic, retain) NSString * userId;
@property (nonatomic, retain) NSString * userName;
@property (nonatomic, retain) NSString * surveyId;
@property (nonatomic, retain) NSString * surveyTitle;
@property (nonatomic, retain) NSDictionary *userAvatarURLDictionary;
@property (nonatomic, retain) NSDictionary *otherUserAvatarURLDictionary;
@property (nonatomic, retain) NSDictionary *locationAvatarURLDictionary;
    //For Resources news

@property (nonatomic, retain) NSString * audioUrl;
@property (nonatomic, retain) NSString * videoUrl;
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * descriptionHtml;
@property (nonatomic, retain) NSString * descriptionMsg;
@property (nonatomic, retain) NSString * messageType;

@property (nonatomic, retain) NSNumber * sno;

@end
