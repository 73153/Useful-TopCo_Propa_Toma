//
//  RecentActivity.m
//  MemorialHealthSystem
//
//  Created by Aruna on 18/06/13.
//
//

#import "RecentActivity.h"


@implementation RecentActivity

@dynamic onLocation;
@dynamic attributedStringHeight;
@dynamic badges;
@dynamic businessAvatarUrl;
@dynamic businessName;
@dynamic channel_Id;
@dynamic commentableAvatar;
@dynamic commentableCommentsCount;
@dynamic commentableId;
@dynamic commentableLikesCount;
@dynamic commentableText;
@dynamic commentableUserName;
@dynamic commentText;
@dynamic commentType;
@dynamic date;
@dynamic deviceName;
@dynamic eventId;
@dynamic eventType;
@dynamic followersCount;
@dynamic followingsCount;
@dynamic isUserFollowsYou;
@dynamic isYouFollowUser;
@dynamic likableAvatar;
@dynamic likableType;
@dynamic likableCommentsCount;
@dynamic likableId;
@dynamic likableLikesCount;
@dynamic likableText;
@dynamic likableUserName;
@dynamic likesCount;
@dynamic locationCityState;
@dynamic locationCoordinates;
@dynamic locationName;
@dynamic notificationAvatar;
@dynamic notificationSubject;
@dynamic notificationText;
@dynamic otherUserAvatarUrl;
@dynamic otherUserId;
@dynamic otherUserName;
@dynamic phoneNumber;
@dynamic photoUrlString;
@dynamic photoUrlStrings;
@dynamic rankName;
@dynamic rankNamesArray;
@dynamic repliesArray;
@dynamic repliesCount;
@dynamic reviewCount;
@dynamic reviewText;
@dynamic rowHeight;
@dynamic showRating;
@dynamic specialId;
@dynamic specialTilte;
@dynamic starsCount;
@dynamic streamId;
@dynamic userAvatarUrl;
@dynamic userId;
@dynamic userName;
@dynamic surveyId;
@dynamic surveyTitle;
@dynamic userAvatarURLDictionary;
@dynamic otherUserAvatarURLDictionary;
@dynamic locationAvatarURLDictionary;

@dynamic audioUrl;
@dynamic videoUrl;
@dynamic title;
@dynamic descriptionMsg;
@dynamic descriptionHtml;
@dynamic messageType;
@dynamic sno;

@end
