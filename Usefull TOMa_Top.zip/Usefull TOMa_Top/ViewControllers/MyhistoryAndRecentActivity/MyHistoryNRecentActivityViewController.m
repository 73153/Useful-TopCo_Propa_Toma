//
//  MyHistoryNRecentActivityViewController.m
//  MemorialHealthSystem
//
//  Created by Aruna on 17/06/13.
//
//

#import "MyHistoryNRecentActivityViewController.h"
#import "RecentActivity.h"
@interface MyHistoryNRecentActivityViewController ()

@end

@implementation MyHistoryNRecentActivityViewController
@synthesize isSubmitBtnOnSurveyViewClicked,reloadCheck,activityCheckObject;

- (id)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        viewFrame = frame;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        //[self registerForNotifications];
    }
    
    return self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad {
    TCSTART
    [super viewDidLoad];
	self.view.frame = viewFrame;
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    image.image = [UIImage imageNamed:@"bg"];
    [self.view addSubview:image];
    
    [self.view addSubview:[appDelegate returnHeaderViewTocaller:self sectionHeaderImgName:@"myhistory&recentActivity_title"]];
    
    CGFloat originY;
    if (iPad) {
        originY = 140;
    } else {
        originY = 85;
    }
    
    [self getStreamDataRequestForRefresh:NO];
    
    streamTable = [[RecentActivityTable alloc]initWithFrame:CGRectMake(0, originY, self.view.frame.size.width, (self.view.frame.size.height - originY - (CURRENT_DEVICE_VERSION >= 7.0f ? 20 : 0))) style:UITableViewStyleGrouped];
    [self.view addSubview:streamTable];
    NSLog(@"Streamtable Widt: %f",streamTable.frame.size.width);
    streamTable.myhistoryVCCaller = self;
    [self.view addSubview:streamTable];

    TCEND
                  }

-(void)viewWillAppear:(BOOL)animated
{
    if(reloadCheck == YES)
    {
        //[appDelegate showActivityIndicatorInView:self.view];
        streamTable.reloading=YES;
        [self netWorkCallForStreamRefresh];
        //[self getStreamDataRequestForRefresh:YES];
        reloadCheck=NO;
    }
}
-(void)viewDidAppear:(BOOL)animated
{
    
    //NSLog(@"In RecentActivity Block.");
    //streamTable.locDataModel_Arr
}

-(void)viewDidUnload
{
    //[self unregisterForNotifications];
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

-(void)unregisterForNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"notifyData" object:nil];
}

- (void)registerForNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(notificationHandler:)
                                                 name:@"notifyData" object:nil];
}
/*** Your custom method called on notification ***/
-(void)notificationHandler:(NSNotification*)notification
{
    NSLog(@"UserInfoData: %@",[notification userInfo]);
    userInfoData=[notification userInfo];
    // Notification Handling ->History
}


- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)gotoMainPage {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)getStreamDataRequestForRefresh:(BOOL)refresh {
    [appDelegate getStreamData:1 perPage:25 showActivityIndicator:YES requestForRefresh:refresh caller:self];
}

- (void)notificationCheck:(NSDictionary*)notificationData
{
    //eventId and eventType
    //NSLog(@"%@:%@",[notificationData objectForKey:@"event_id"],[notificationData objectForKey:@"event_type"]);
    [streamTable addCommentView:[notificationData objectForKey:@"event_type"] withId:[notificationData objectForKey:@"event_id"]];
    appDelegate.notificationInfo=nil;
    userInfoData=nil;
}

#pragma mark refresh Stream request delegate methods

- (void)didFinishedStreamRequest:(NSDictionary *)results {
    @try {
            //TODO KANAK
        //NSLog(@"didFinishedNotificationsRequest %@",results);
        //[appDelegate removeNetworkIndicatorInView:self.view];
        streamTable.reloading=NO;
        if ([self isNotNull:results] && [results objectForKey:@"success"]) {
            
            isStreamResponseNull = [[results objectForKey:@"response"]boolValue];
            [self reloaData];
            if([self isNotNull:userInfoData])
                [self notificationCheck:userInfoData];
            else
            {
            if(appDelegate.notificationInfo != nil)
            {
                [self notificationCheck:appDelegate.notificationInfo];
            }
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToGetStreamResponse {
    streamTable.reloading=NO;
    //[appDelegate removeNetworkIndicatorInView:self.view];
    [streamTable dataSourceDidFinishLoadingNewData];
}
- (void)getAllEntitiesOfRecentActivity {
    TCSTART
    streamTable.locDataModel_Arr = [[NSMutableArray alloc] initWithArray:[appDelegate executeAndReturnAllEntitiesWithEntityForName:@"RecentActivity"]];
    TCEND
}

#pragma mark Reload Data
- (void)reloaData {
    @try {
        
        [self getAllEntitiesOfRecentActivity];
    
        // get the mostrecent notification date and send it to the server for maintaing the badge count at server
//        if([self isNotNull:streamTable.locDataModel_Arr] && streamTable.locDataModel_Arr.count > 0) {
//            
//            //get the notification object from the fetchedresultscontroller object.
//            RecentActivity *recentActivity = [streamTable.locDataModel_Arr objectAtIndex:0];
//            
//            if([self isNotNull:recentActivity] && [self isNotNull:recentActivity.date]) { //check if notification and date are not null
//                
//                //get the saved date if any.
//                NSDate *mostRecentNotificationDate = [[NSUserDefaults standardUserDefaults]objectForKey:@"mostrecentnotificationdate"];
//                
//                //get the notification date from the string.
//                NSDate *notificationDate = recentActivity.date;
//                
//                //check if both dates are equal then we don't haven't recieved any notifications from server.
//                if(![mostRecentNotificationDate isEqualToDate:notificationDate]) {
//                    //send a request to the server.
//                    [appDelegate sendMostRecentlyViewedNotificationOccuredAt:recentActivity.date];
//                }
//            }
//        }
        [streamTable dataSourceDidFinishLoadingNewData];
        [streamTable reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark LoadMoreActivities ==================================================
- (void)loadMoreAcitivitiesWithPageNumber:(NSNumber *)activityPageNumber {
    @try {
       
        [appDelegate getStreamData:[activityPageNumber intValue] perPage:25 showActivityIndicator:NO requestForRefresh:NO caller:self];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)netWorkCallForStreamRefresh {
    @try {
        [appDelegate getStreamData:1 perPage:25 showActivityIndicator:NO requestForRefresh:YES caller:self];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark surveys related
- (void)makeSurveyQuestionsRequestWithSurveyId:(NSString *)surveyId {
    TCSTART
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken] && [self isNotNull:surveyId]) {
        [appDelegate showActivityIndicatorInView:streamTable];
        [appDelegate showNetworkIndicator];
    
        [appDelegate getSurveyQuestionsWithSurveyId:surveyId andchannel_Id:@"-1" withCaller:self];
    }
    TCEND
}

- (void)didReceiveSurveyQuestionsWithEvent:(CPSurveyEvent *)event {
    TCSTART
    if ([self isNotNull:event]) {
        if (event.prompts.count > 0) {
            NSMutableArray *questionsArray = [[NSMutableArray alloc] init];
            for (CPSurveyPrompt *prompt in event.prompts) {
                NSMutableDictionary *questionDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:prompt.text,@"text",[prompt.promptId stringValue],@"id",prompt.responseType,@"responseType", nil];
                [questionsArray addObject:questionDict];
            }
            surveyView = [[SurveyView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - ((CURRENT_DEVICE_VERSION < 7.0)?0:20)) andQuestionsArray:questionsArray andCaller:self andPhysiciansArray:[appDelegate getPhysicians] isPrimarysurvey:NO];
            surveyView.location_id = @"-1";
            surveyView.survey_id = [event.surveyId stringValue];
            [self.view addSubview:surveyView];
        }
    } else {
        [appDelegate showErrorMsg:@"No surveys are avaliable"];
    }
    [appDelegate removeNetworkIndicatorInView:streamTable];
    [appDelegate hideNetworkIndicator];
    TCEND
}

- (void)didFailToReceiveSurveyQuestionsWithErrorMsg:(NSString *)error {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:streamTable];
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:error];
    TCEND
}

#pragma mark Post survey delegate methods
- (void)didReceiveSurveyPostResponseWithEvent:(CPSurveyEvent *)event {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate hideNetworkIndicator];
    if ([self isNotNull:surveyView] && [surveyView respondsToSelector:@selector(displyImDoneScreen)] && isSubmitBtnOnSurveyViewClicked) {
        [surveyView displyImDoneScreen];
    }
    surveyView = nil;
    isSubmitBtnOnSurveyViewClicked = NO;
    [self sucessfullySubmittedSurveyNeedToRefreshScreen];
    TCEND
}
- (void)didFailToReceiveSurveyPostResponseWithErrorMsg:(NSString *)error {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:appDelegate.window];
    [appDelegate hideNetworkIndicator];
    [appDelegate showErrorMsg:error];
    TCEND
}

- (void)sucessfullySubmittedSurveyNeedToRefreshScreen {
    TCSTART
    [streamTable.locDataModel_Arr removeAllObjects];
    [self netWorkCallForStreamRefresh];
    TCEND
}
- (void)viewWillDisappear:(BOOL)animated {
    
}
@end
