//
//  LiveFeedViewController.h
//  LocationInfo
//
//  Created by shiva on 12/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StreamDataModel.h"
#import "StreamService.h"
#import "CommentTextView.h"
#import "AppDelegate.h"
#import "RefreshView.h"
#import "MyHistoryNRecentActivityViewController.h"

@class MyHistoryNRecentActivityViewController;
@interface RecentActivityTable : UITableView<StreamServiceDelegate,UITextViewDelegate,UIGestureRecognizerDelegate,UITableViewDelegate,UITableViewDataSource> {
    
    NSMutableArray *locDataModel_Arr;
    MyHistoryNRecentActivityViewController *myhistoryVCCaller;
    
    //table refresh on pull 
    BOOL checkForRefresh;
	BOOL reloading;
    BOOL isDeleteBtnVisible;
     UIButton *plugBtn;
    NSInteger commentCell_height;
    CommentTextView *edited_comment_textView;
    NSIndexPath *editable_commment_indexpath;
    AppDelegate *appDelegate;
    RefreshView *refreshLiveFeed;
    
    int activityPageNumber;
}

@property(strong, nonatomic) MyHistoryNRecentActivityViewController *myhistoryVCCaller;
@property(nonatomic,readwrite) BOOL reloading;
@property(strong, nonatomic ) NSMutableArray *locDataModel_Arr;

-(void) showReloadAnimationAnimated:(BOOL)animated;
-(void)refreshRecentActivities;
-(void)dataSourceDidFinishLoadingNewData;
-(void)animateBtnFrame:(UIView *)view;
-(void)goToCommentPage:(NSIndexPath *)indexPath;
-(CGFloat)getheightForHeaderInSection:(NSInteger)section;
-(void)sendLikeRequest:(NSIndexPath *)indexPath;
-(NSIndexPath *)getIndexPathForEvent:(UIEvent *)event;
-(void)postComment:(NSString *)commentText withIndexPath:(NSIndexPath *)indexPath;
-(BOOL)canEditRowAtIndexPath:(NSIndexPath *)indexPath;
-(void)deleteReviewOrCommentAtIndexPath:(NSIndexPath *)indexPath;
-(UITableViewCell *)tableView:(UITableView *)tableView loadFavoriteRLikeRCmtCellAtIndexpath:(NSIndexPath *)indexPath;
-(void)addCommentView:(NSString*)eventType withId:(NSNumber*)eventId;

@end
