//
//  MyHistoryNRecentActivityViewController.h
//  MemorialHealthSystem
//
//  Created by Aruna on 17/06/13.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "RefreshView.h"
#import "RecentActivityTable.h"
#import "RecentActivityService.h"
#import "StreamService.h"
#import "SurveyView.h"

@class RecentActivityTable;

@interface MyHistoryNRecentActivityViewController : UIViewController<StreamServiceDelegate> {
    CGRect viewFrame;
    AppDelegate *appDelegate;
    RecentActivityTable *streamTable;
    SurveyView *surveyView;
    BOOL isStreamResponseNull;
    BOOL reloadCheck;
    RecentActivity *activityCheckObject;
    NSDictionary *userInfoData;
}

@property (nonatomic, readwrite) BOOL isSubmitBtnOnSurveyViewClicked;
@property (nonatomic,retain) RecentActivity *activityCheckObject;
@property (nonatomic, readwrite) BOOL reloadCheck;

- (id)initWithFrame:(CGRect)frame;
- (void)netWorkCallForStreamRefresh;
- (void)loadMoreAcitivitiesWithPageNumber:(NSNumber *)activityPageNumber;
- (void)didFailedToGetStreamResponse;

- (void)makeSurveyQuestionsRequestWithSurveyId:(NSString *)surveyId;
- (void)sucessfullySubmittedSurveyNeedToRefreshScreen;
@end
