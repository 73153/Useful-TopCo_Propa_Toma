//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import "BusinessRewardsViewController.h"
#import "NSObject+PE.h"
#import "BusinessReward.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>
@interface BusinessRewardsViewController ()

@end

@implementation BusinessRewardsViewController

@synthesize user_id;
@synthesize rank_all_count;
@synthesize rank_silver_count;
@synthesize rank_bronze_count;
@synthesize rank_gold_count;
@synthesize fetchedResultsController;

- (id)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        // Custom initialization
        vcFrame = frame; // set the view frame.
    }
    return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    @try {
        rankName = @"no";
        [super viewDidLoad];
        self.view.frame = vcFrame;
        rewardsArray = [[NSMutableArray alloc] init];
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        is_rank_silver_TabSlctd = NO;
        is_rank_bronze_TabSlctd = NO;
        is_rank_gold_TabSlctd = NO;
        is_rank_all_TabSlctd = YES;
        
        [self setupUI];
        rank_pagenumber = 1;
        
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        //set the position of the button
        if (iPad) {
            backButton.frame = CGRectMake(5,10, 84, 48);
        } else {
            backButton.frame = CGRectMake(5,7, 59, 32);
        }
        //set the button's title
        [backButton setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        //listen for clicks
        [backButton addTarget:self action:@selector(popThePresentViewController:)
             forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:backButton];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0 && self.view.frame.size.height == appDelegate.window.frame.size.height) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


- (void)popThePresentViewController:(id)sender {
    @try {
        [appDelegate hideNetworkIndicator];
        [self.navigationController popViewControllerAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)setupUI {
    TCSTART
    //set background color
    UIImageView *bg_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
    bg_ImgView.frame = self.view.bounds;
    [self.view addSubview:bg_ImgView];
    
    UILabel *achievemntsHeaderLbl ;
    if (iPad) {
        achievemntsHeaderLbl =[[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width - 300)/2,13 ,300,45)];
    } else {
        achievemntsHeaderLbl = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, appDelegate.window.frame.size.width,25)];
    }
    achievemntsHeaderLbl.textColor = [UIColor whiteColor];
    achievemntsHeaderLbl.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    achievemntsHeaderLbl.backgroundColor = [UIColor clearColor];
    achievemntsHeaderLbl.text = @"REWARDS";
    achievemntsHeaderLbl.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:achievemntsHeaderLbl];
    

    UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
    lineImgView.image = [UIImage imageNamed:@"line"];
    [self.view addSubview:lineImgView];
    //button to display user_all_ranks.
    
    selectedDetailBG_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(20,lineImgView.frame.origin.y + lineImgView.frame.size.height + 10,appDelegate.window.frame.size.width-40, 80)];
    if (!iPad) {
        selectedDetailBG_imageView.frame = CGRectMake(10,lineImgView.frame.origin.y + lineImgView.frame.size.height + 5,appDelegate.window.frame.size.width-20,40);
    }
    [selectedDetailBG_imageView setImage:[UIImage imageNamed:@"allRewardTab"]];
    [self.view addSubview:selectedDetailBG_imageView];
    
    all_ranks_btn = [UIButton buttonWithType:UIButtonTypeCustom];
    all_ranks_btn.frame = CGRectMake((iPad?20:10),selectedDetailBG_imageView.frame.origin.y,(selectedDetailBG_imageView.frame.size.width/4), selectedDetailBG_imageView.frame.size.height);
    //[all_ranks_btn setImage:[UIImage imageNamed:@"all_f"] forState:UIControlStateNormal];
    [all_ranks_btn addTarget:self action:@selector(displayAllRanks:) forControlEvents:UIControlEventTouchUpInside];
    all_ranks_btn.layer.cornerRadius = 5.0f;
    all_ranks_btn.layer.masksToBounds = YES;
    [self.view addSubview:all_ranks_btn];
    
    //button to display user_Bronze_ranks.
    bronze_rank_btn = [UIButton buttonWithType:UIButtonTypeCustom];
    bronze_rank_btn.frame = CGRectMake(all_ranks_btn.frame.origin.x+all_ranks_btn.frame.size.width,selectedDetailBG_imageView.frame.origin.y,(selectedDetailBG_imageView.frame.size.width/4), selectedDetailBG_imageView.frame.size.height);
    //[bronze_rank_btn setImage:[UIImage imageNamed:@"bronze"] forState:UIControlStateNormal];
    [bronze_rank_btn addTarget:self action:@selector(displayBronzeRanks:) forControlEvents:UIControlEventTouchUpInside];
    bronze_rank_btn.layer.cornerRadius = 5.0f;
    bronze_rank_btn.layer.masksToBounds = YES;
    [self.view addSubview:bronze_rank_btn];
    
    //button to display user_Silver_ranks.
    silver_rank_btn = [UIButton buttonWithType:UIButtonTypeCustom];
    silver_rank_btn.frame = CGRectMake(bronze_rank_btn.frame.origin.x+bronze_rank_btn.frame.size.width,selectedDetailBG_imageView.frame.origin.y,(selectedDetailBG_imageView.frame.size.width/4), selectedDetailBG_imageView.frame.size.height);
    //[silver_rank_btn setImage:[UIImage imageNamed:@"silver"] forState:UIControlStateNormal];
    [silver_rank_btn addTarget:self action:@selector(displaySilverRanks:) forControlEvents:UIControlEventTouchUpInside];
    silver_rank_btn.layer.cornerRadius = 5.0f;
    silver_rank_btn.layer.masksToBounds = YES;
    [self.view addSubview:silver_rank_btn];
    
    //button to display user_Bronze_ranks.
    gold_rank_btn = [UIButton buttonWithType:UIButtonTypeCustom];
    gold_rank_btn.frame = CGRectMake(silver_rank_btn.frame.origin.x+silver_rank_btn.frame.size.width,selectedDetailBG_imageView.frame.origin.y,(selectedDetailBG_imageView.frame.size.width/4), selectedDetailBG_imageView.frame.size.height);
    //[gold_rank_btn setImage:[UIImage imageNamed:@"gold"] forState:UIControlStateNormal];
    [gold_rank_btn addTarget:self action:@selector(displayGoldRanks:) forControlEvents:UIControlEventTouchUpInside];
    gold_rank_btn.layer.cornerRadius = 5.0f;
    gold_rank_btn.layer.masksToBounds = YES;
    [self.view addSubview:gold_rank_btn];
    
    CGFloat originX = 0;
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        originX = 5;
    }
    
    //Tabel to display RankAchivements Data
    rank_tableView = [[UITableView alloc] initWithFrame:CGRectMake(originX, silver_rank_btn.frame.origin.y + silver_rank_btn.frame.size.height - 4, self.view.frame.size.width - (2*originX), self.view.frame.size.height - (silver_rank_btn.frame.origin.y + silver_rank_btn.frame.size.height)) style:UITableViewStyleGrouped];
    rank_tableView.delegate = self;
    rank_tableView.dataSource = self;
    rank_tableView.backgroundView = nil;
    rank_tableView.backgroundColor = [UIColor clearColor];
    rank_tableView.layer.masksToBounds = YES;
    if (CURRENT_DEVICE_VERSION>=7.0) {
        rank_tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }else{
        rank_tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
    //FolllowingTbl.layer.cornerRadius = 10;
    [self.view addSubview:rank_tableView];
    
    //add the refreshstream class to the table view
    refreshNotificationsView = [[RefreshView alloc] initWithFrame:
                                CGRectMake(self.view.frame.origin.x,-rank_tableView.bounds.size.height,
                                           self.view.frame.size.width, rank_tableView.bounds.size.height)];
    [rank_tableView addSubview:refreshNotificationsView];
    TCEND
}

- (void)viewWillAppear:(BOOL)animated {
    
    @try {
        [super viewWillAppear:YES];
        [self reloadDataWithRemakeConnectionIfDataNull:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)reloadDataWithRemakeConnectionIfDataNull:(BOOL)reconnect {
    
    @try {
        NSError *error;
        fetchedResultsController = [appDelegate fetchedResultsControllerForEntityName:@"BusinessReward" withPredicate:nil sortWithKey:@"rewardId" sortWithAscending:YES];
        fetchedResultsController.delegate = self;
        if(![fetchedResultsController performFetch:&error]) {
            // Update to handle the error appropriately.
            // NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            //exit(-1);  // Fail
        }
        
        if(reconnect) {
            if(![[fetchedResultsController fetchedObjects]count] > 0) {
                [self getRewardsForRefresh:NO];
            } else {
                [self reloadData];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)getRewardsForRefresh:(BOOL)isRefresh {
    TCSTART
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken]) {
        if (!isRequestIsInProgress) {
            isRequestIsInProgress = YES;
            if (!isRefresh) {
                [appDelegate showActivityIndicatorInView:self.view];
            }
            [appDelegate showNetworkIndicator];
            [appDelegate getGlobalBusinessRewardsWithCaller:self requestForRefresh:isRefresh];
        }
    }
    TCEND
}


#pragma mark TopMenu Selection Methods.
-(void)displayAllRanks:(id)sender{
    TCSTART
    is_rank_silver_TabSlctd = NO;
    is_rank_bronze_TabSlctd = NO;
    is_rank_gold_TabSlctd = NO;
    is_rank_all_TabSlctd = YES;
    
    [self setImageForTopMenuBtns];
    
    [self reloadData];
    TCEND
}

-(void)displaySilverRanks:(id)sender{
    TCSTART
    
    is_rank_silver_TabSlctd = YES;
    is_rank_bronze_TabSlctd = NO;
    is_rank_gold_TabSlctd = NO;
    is_rank_all_TabSlctd = NO;
    
    [self setImageForTopMenuBtns];
    
    [self reloadData];
    TCEND
}

-(void)displayBronzeRanks:(id)sender{
    TCSTART
    is_rank_silver_TabSlctd = NO;
    is_rank_bronze_TabSlctd = YES;
    is_rank_gold_TabSlctd = NO;
    is_rank_all_TabSlctd = NO;
    
    [self setImageForTopMenuBtns];
    
    [self reloadData];
    TCEND
}

-(void)displayGoldRanks:(id)sender{
    TCSTART
    is_rank_silver_TabSlctd = NO;
    is_rank_bronze_TabSlctd = NO;
    is_rank_gold_TabSlctd = YES;
    is_rank_all_TabSlctd = NO;
    
    [self setImageForTopMenuBtns];
    
    [self reloadData];
    TCEND
}

-(void)finishedGetBusinessRewardsRequest:(NSDictionary *)response {
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    isRequestIsInProgress = NO;
    [rewardsArray removeAllObjects];
    @try {
        if ([self isNotNull:response] && [response isKindOfClass:[NSDictionary class]]) {
            
            is_rank_response_Null = [[response objectForKey:@"response"]boolValue];
            
            [self reloadData];
        } else {
            [rank_tableView reloadData];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (void)failedToGetBusinessRewards {
    isRequestIsInProgress = NO;
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
}
- (void)reloadData {
    
    @try {
        NSError *error = nil;
        
        NSPredicate *predicate = nil;
        [rewardsArray removeAllObjects];
        [self dataSourceDidFinishLoadingNewData];
        
        fetchedResultsController = [appDelegate fetchedResultsControllerForEntityName:@"BusinessReward" withPredicate:predicate sortWithKey:@"rewardId" sortWithAscending:NO];
        
        if(![fetchedResultsController performFetch:&error]) {
            // Update to handle the error appropriately.
            //   NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            //   exit(-1);  // Fail
        }
        rank_all_count = 0;
        rank_bronze_count = 0;
        rank_gold_count = 0;
        rank_silver_count = 0;
        
        if(is_rank_all_TabSlctd) {
            rankName = @"no";
            [self getAllRankRewards];
            rank_all_count = rewardsArray.count;
        } else if(is_rank_bronze_TabSlctd) {
            rankName = @"no BRONZE";
            [self getBronzeRankRewards];
            rank_bronze_count = rewardsArray.count;
        } else if(is_rank_silver_TabSlctd) {
            rankName = @"no SILVER";
            [self getSliverRankRewards];
            rank_silver_count = rewardsArray.count;
        } else if(is_rank_gold_TabSlctd) {
            rankName = @"no GOLD";
            [self getGoldRanksRewards];
            rank_gold_count = rewardsArray.count;
        }
     
        
//        for (int i = 0; i < fetchedResultsController.fetchedObjects.count; i++) {
//            BusinessReward *reward = [fetchedResultsController.fetchedObjects objectAtIndex:i];
//            rank_all_count = 0;
//            rank_bronze_count = 0;
//            rank_gold_count = 0;
//            rank_silver_count = 0;
//            for (int i = 0; i < [reward.redeemptionListArray count]; i ++) {
//                if ([[reward.redeemptionListArray objectAtIndex:i] rangeOfString:@"silver" options:NSCaseInsensitiveSearch].location != NSNotFound) {
//                    rank_silver_count++;
//                } else if ([[reward.redeemptionListArray objectAtIndex:i] rangeOfString:@"gold" options:NSCaseInsensitiveSearch].location != NSNotFound) {
//                    rank_gold_count++;
//                } else if ([[reward.redeemptionListArray objectAtIndex:i] rangeOfString:@"bronze" options:NSCaseInsensitiveSearch].location != NSNotFound) {
//                    rank_bronze_count++;
//                }
//            }
//            
//        }
//        rank_all_count = fetchedResultsController.fetchedObjects.count;
        
        [rank_tableView reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)getBronzeRankRewards {
    TCSTART
    for (int i = 0; i < fetchedResultsController.fetchedObjects.count; i ++) {
        BusinessReward *businessReward = [fetchedResultsController.fetchedObjects objectAtIndex:i];
        
        if ([self isNotNull:businessReward] && [businessReward.redeemptionListArray isKindOfClass:[NSArray class]]) {
            for(NSNumber *redeemNum in businessReward.redeemptionListArray)
            {
                if ([self isNotNull:redeemNum] && [redeemNum isKindOfClass:[NSNumber class]]) {
                    if([redeemNum intValue] == 0) {
                        [rewardsArray addObject:businessReward];
                        break;
                    }
                }
            }
        }
    }
    NSArray* reversed = [[rewardsArray reverseObjectEnumerator] allObjects];
    rewardsArray=[NSMutableArray arrayWithArray:reversed];
    TCEND
}

- (void)getSliverRankRewards {
    TCSTART
    for (int i = 0; i < fetchedResultsController.fetchedObjects.count; i ++) {
        BusinessReward *businessReward = [fetchedResultsController.fetchedObjects objectAtIndex:i];
        
        if ([self isNotNull:businessReward] && [businessReward.redeemptionListArray isKindOfClass:[NSArray class]]) {
            for(NSNumber *redeemNum in businessReward.redeemptionListArray)
            {
                if ([self isNotNull:redeemNum] && [redeemNum isKindOfClass:[NSNumber class]]) {
                    if(([redeemNum intValue] == 1) || ([redeemNum intValue] == 0)) {
                        [rewardsArray addObject:businessReward];
                        break;
                    }
                }
            }
        }
    }
    NSArray* reversed = [[rewardsArray reverseObjectEnumerator] allObjects];
    rewardsArray=[NSMutableArray arrayWithArray:reversed];
    TCEND
}

- (void)getGoldRanksRewards {
    TCSTART
    for (int i = 0; i < fetchedResultsController.fetchedObjects.count; i ++) {
        BusinessReward *businessReward = [fetchedResultsController.fetchedObjects objectAtIndex:i];
        
        if ([self isNotNull:businessReward] && [businessReward.redeemptionListArray isKindOfClass:[NSArray class]]) {
            for(NSNumber *redeemNum in businessReward.redeemptionListArray)
            {
                if ([self isNotNull:redeemNum] && [redeemNum isKindOfClass:[NSNumber class]]) {
                    if(([redeemNum intValue] == 2) || ([redeemNum intValue] == 1) || ([redeemNum intValue] == 0)) {
                        [rewardsArray addObject:businessReward];
                        break;
                    }
                }
            }
        }
    }
    NSArray* reversed = [[rewardsArray reverseObjectEnumerator] allObjects];
    rewardsArray=[NSMutableArray arrayWithArray:reversed];
 TCEND
}

- (void)getAllRankRewards {
    TCSTART
    for (int i = 0; i < fetchedResultsController.fetchedObjects.count; i ++) {
        BusinessReward *businessReward = [fetchedResultsController.fetchedObjects objectAtIndex:i];
        
        if ([self isNotNull:businessReward] && [businessReward.redeemptionListArray isKindOfClass:[NSArray class]]) {
            for(NSNumber *redeemNum in businessReward.redeemptionListArray)
            {
                if ([self isNotNull:redeemNum] && [redeemNum isKindOfClass:[NSNumber class]]) {
                    if([redeemNum intValue] == 3) {
                        [rewardsArray addObject:businessReward];
                        break;
                    }
                }
            }
        }
    }
    NSArray* reversed = [[rewardsArray reverseObjectEnumerator] allObjects];
    rewardsArray=[NSMutableArray arrayWithArray:reversed];
    TCEND
}
-(void)setImageForTopMenuBtns{
    
    @try {
        if(is_rank_all_TabSlctd)
            [selectedDetailBG_imageView setImage:[UIImage imageNamed:@"allRewardTab"]];
        if(is_rank_silver_TabSlctd)
            [selectedDetailBG_imageView setImage:[UIImage imageNamed:@"silverRewardTab"]];
        if(is_rank_bronze_TabSlctd)
            [selectedDetailBG_imageView setImage:[UIImage imageNamed:@"bronzeRewardTab"]];
        if(is_rank_gold_TabSlctd)
            [selectedDetailBG_imageView setImage:[UIImage imageNamed:@"goldRewardTab"]];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//-(void)rearrangeLikesDataForSeletedTab{
//
//    if ([self isNotNull:rank_MDict] && rank_MDict.count > 0) {
//        NSArray *temp = [rank_MDict objectForKey:@"userrankachvmnts"];
//        [rank_MArray removeAllObjects];
//        for (Rank *rank in  temp) {
//            if ([self isNotNull:rank] && [self isNotNull:rank.user_id]) {
//                if(is_rank_all_TabSlctd)                                                   // all_ranks
//                    [rank_MArray addObject:rank];
//                else if([self isNotNull:rank.rank_name] && [rank.rank_name isEqualToString:@"silver"] && is_rank_silver_TabSlctd)//silver ranks
//                    [rank_MArray  addObject:rank];
//                else if([self isNotNull:rank.rank_name] && [rank.rank_name isEqualToString:@"bronze"] && is_rank_bronze_TabSlctd)//bronze ranks
//                    [rank_MArray  addObject:rank];
//                else if([self isNotNull:rank.rank_name] && [rank.rank_name isEqualToString:@"gold"] && is_rank_gold_TabSlctd)//gold ranks
//                    [rank_MArray  addObject:rank];
//            }
//        }
//        [rank_tableView reloadData];
//    }
//}


#pragma mark Table Data Filling Related Methods.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
   	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    @try {
        if([self isNotNull:rewardsArray] && rewardsArray.count > 0){
            
            if(((is_rank_all_TabSlctd && rewardsArray.count < rank_all_count) || (is_rank_silver_TabSlctd && rewardsArray.count < rank_silver_count) || (is_rank_bronze_TabSlctd && rewardsArray.count < rank_bronze_count) || (is_rank_gold_TabSlctd && rewardsArray.count < rank_gold_count)) && !is_rank_response_Null && rewardsArray.count >= rank_pagenumber * 100 && rewardsArray.count < 1000) {
                
                return [rewardsArray count] + 1;
            } else
                return [rewardsArray count];
        } else {
            return 0;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (rewardsArray.count == 0) {
        return 80;
    }
    return 1.0;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        UIView *headerView; //
        UILabel *messageLabel;
        
        headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0.0, 0.0, 0.0)];
        if (rewardsArray.count == 0) {
            messageLabel = [[UILabel alloc] initWithFrame: CGRectMake((tableView.frame.size.width-270)/2, 5, 270,70)];
            messageLabel.textAlignment = NSTextAlignmentCenter;
            messageLabel.textColor = [UIColor whiteColor];
            messageLabel.font = [UIFont fontWithName:rewardAlertTextFontName size:descriptionTextFontSize];
            messageLabel.numberOfLines = 0;
            messageLabel.text = [NSString stringWithFormat:@"Currently, there are %@ rewards. Please try again later.",rankName];
            messageLabel.backgroundColor = [UIColor clearColor];
            [headerView addSubview:messageLabel];
        }
        headerView.backgroundColor = [UIColor clearColor];
        
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TCSTART
    if(indexPath.row == rewardsArray.count)
        return 40+(iPad?70:50);
    
    float leftSpaceSize=iPad?15:10;
    BusinessReward *businessReward = [rewardsArray objectAtIndex:indexPath.row];
    CGSize nameSize = [businessReward.rewardTitle sizeWithFont:[UIFont fontWithName:titleFontName size:rewardCellHeaderFontSize] constrainedToSize:CGSizeMake(rank_tableView.frame.size.width-(2*leftSpaceSize), 22222) lineBreakMode:NSLineBreakByWordWrapping];
    CGSize addressSize = [businessReward.rewardDescription sizeWithFont:[UIFont fontWithName:@"HelveticaNeue" size:addressFontSize] constrainedToSize:CGSizeMake(rank_tableView.frame.size.width-(2*leftSpaceSize), 22222) lineBreakMode:NSLineBreakByWordWrapping];
    return addressSize.height + nameSize.height + 15 + 30 + (iPad?70:50) ; //15 for date label and 20 for gap between all fields
    TCEND
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        //static NSString *user_messageCell = @"messageCell";
        static NSString *CellIndentifier = @"Cell";
        UITableViewCell *cell = nil;
        //        UIImageView *avtar_imgView = nil;
        //        UIImageView *rank_imgView = nil;
        UILabel *nameLbl = nil;
        UILabel *addressLbl = nil;
        UILabel *dateLbl = nil;
        UIView *lineView = nil;
        RedeemCutomButton *redeemButton = nil;
        float leftSpaceSize=iPad?15:10;
        CGFloat xOriginDiff =0;
        if (CURRENT_DEVICE_VERSION < 7.0f) {
            xOriginDiff =-10;
        }
        cell = [tableView dequeueReusableCellWithIdentifier:CellIndentifier];
        //initialize cell and its subviews instances once and use them when table scrolling through their instances retrieved based on "Tag" value
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIndentifier] ;
            if (CURRENT_DEVICE_VERSION >= 7.0f) {
                //[appDelegate addBackgroundViewToTheCell:cell];
            }
            nameLbl = [[UILabel alloc]init];
            [cell.contentView addSubview:nameLbl];
            nameLbl.backgroundColor = [UIColor clearColor];
            nameLbl.lineBreakMode = NSLineBreakByWordWrapping;
            
            nameLbl.tag = 3;
            nameLbl.numberOfLines = 0;
            nameLbl.font = [UIFont fontWithName:titleFontName size:rewardCellHeaderFontSize];
            nameLbl.textColor = [appDelegate colorWithHexString:@"55575c"];
            
            addressLbl = [[UILabel alloc]init];
            [cell.contentView addSubview:addressLbl];
            addressLbl.backgroundColor = [UIColor clearColor];
            addressLbl.lineBreakMode = NSLineBreakByWordWrapping;
            addressLbl.textAlignment  = NSTextAlignmentLeft;
            addressLbl.numberOfLines = 0;
            addressLbl.tag = 4;
            addressLbl.font = [UIFont fontWithName:@"HelveticaNeue" size:addressFontSize];
            addressLbl.textColor = [UIColor darkGrayColor];
            
            
            dateLbl = [[UILabel alloc]init];
            [cell.contentView addSubview:dateLbl];
            dateLbl.backgroundColor = [UIColor clearColor];
            dateLbl.textAlignment  = NSTextAlignmentLeft;
            dateLbl.tag = 5;
            dateLbl.font = [UIFont fontWithName:@"HelveticaNeue" size:dateFontSize];
            dateLbl.textColor = [UIColor grayColor];
            lineView=[[UIView alloc] init];
            [lineView setBackgroundColor:[UIColor lightGrayColor]];
            lineView.tag =6;
            [cell.contentView addSubview:lineView];
            
            redeemButton=[[RedeemCutomButton alloc] initWithFrame:CGRectZero];
            [redeemButton setImage:[UIImage imageNamed:@"redeemButton"] forState:UIControlStateNormal];
            [redeemButton addTarget:self action:@selector(redeemButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            redeemButton.tag=7;
            [cell.contentView addSubview:redeemButton];
            
            
        }
        if (!nameLbl)
            nameLbl = (UILabel *)[cell.contentView viewWithTag:3];
        if (!addressLbl)
            addressLbl = (UILabel *)[cell.contentView viewWithTag:4];
        if (!dateLbl) {
            dateLbl = (UILabel *)[cell.contentView viewWithTag:5];
        }
        if (!lineView) {
            lineView = (UIView *)[cell.contentView viewWithTag:6];
        }
        if (!redeemButton) {
            redeemButton = (RedeemCutomButton *)[cell.contentView viewWithTag:7];
        }
    
        CGRect cellRect=[rank_tableView rectForRowAtIndexPath:indexPath];
        //get the Like data for a row
        BusinessReward *reward = nil;
        if ([self isNotNull:rewardsArray] && rewardsArray.count > indexPath.row)
            reward = [rewardsArray objectAtIndex:indexPath.row];
        
        //check if Like data for a row is not null
        if ([self isNotNull:reward]) {
            if ([self isNotNull:reward.rewardStartDate]) {
                NSString *dateString;
                if ([self isNotNull:reward.rewardEndDate]) {
                    dateString = [NSString stringWithFormat:@"%@ - %@",[appDelegate convertDateNumberFormatToTextFormat:[self stringFromDate:reward.rewardStartDate]],[appDelegate convertDateNumberFormatToTextFormat:[self stringFromDate:reward.rewardEndDate]]];
                } else {
                    dateString = [appDelegate convertDateNumberFormatToTextFormat:[self stringFromDate:reward.rewardStartDate]];
                }
                dateLbl.text = dateString;
            } else {
                dateLbl.text = @"";
            }
            
            if ([self isNotNull:reward.canRedeem]) {
                redeemButton.isRedeem=[reward.canRedeem boolValue];
            }
            else {
                redeemButton.isRedeem=NO;
            }
            
            dateLbl.frame = CGRectMake(leftSpaceSize, iPad?15:10, rank_tableView.frame.size.width-100, 15);
            //Display the name of a business or user
            if ([self isNotNull:reward.rewardTitle]) {
                nameLbl.text = reward.rewardTitle;
            } else {
                nameLbl.text = @"";
            }
            CGSize nameSize = [reward.rewardTitle sizeWithFont:[UIFont fontWithName:titleFontName size:rewardCellHeaderFontSize] constrainedToSize:CGSizeMake(rank_tableView.frame.size.width-(2*leftSpaceSize), 22222) lineBreakMode:NSLineBreakByWordWrapping];
            CGSize addressSize = [reward.rewardDescription sizeWithFont:[UIFont fontWithName:@"HelveticaNeue" size:addressFontSize] constrainedToSize:CGSizeMake(rank_tableView.frame.size.width-(2*leftSpaceSize), 22222) lineBreakMode:NSLineBreakByWordWrapping];
            
            nameLbl.frame = CGRectMake(leftSpaceSize, dateLbl.frame.origin.y + dateLbl.frame.size.height+(iPad?6:3), rank_tableView.frame.size.width-(2*leftSpaceSize)+xOriginDiff, nameSize.height+5);// 25 for (15 for date label,10 for gaps) and 30 for rank imageview.
            
            if([self isNotNull:reward.rewardDescription]) {
                addressLbl.text = reward.rewardDescription;
            } else {
                addressLbl.text = @"";
            }
            
            addressLbl.frame = CGRectMake(leftSpaceSize, nameLbl.frame.origin.y + nameLbl.frame.size.height+(iPad?4:1), rank_tableView.frame.size.width-(2*leftSpaceSize)+xOriginDiff, addressSize.height+10);
            if (CURRENT_DEVICE_VERSION >= 7.0f) {
                [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:addressSize.height + nameSize.height + 15 + 30 andWidth:310];
            }
            
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        //        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        //cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]] ;
        
        UIView *cellbg = [[UIView alloc] init];
        CGFloat rowheight = cellRect.size.height;
        if(indexPath.row == (rewardsArray.count - 1)) {
            lineView.frame=CGRectZero;
        }
        else
            lineView.frame=CGRectMake(0,rowheight-0.5,[rank_tableView rectForRowAtIndexPath:indexPath].size.width , 0.5);
        
        if (iPad) {
            if (CURRENT_DEVICE_VERSION >= 7.0) {
                cellbg.frame = CGRectMake(0, -10, [rank_tableView rectForRowAtIndexPath:indexPath].size.width, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, -10, [rank_tableView rectForRowAtIndexPath:indexPath].size.width, rowheight);
            }
            //cellbg.backgroundColor = [UIColor colorWithRed:0.72f green:0.73f blue:0.77f alpha:1.0f];
            cellbg.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
        } else {
            if (CURRENT_DEVICE_VERSION >= 7.0) {
                cellbg.frame = CGRectMake(0, 0, [rank_tableView rectForRowAtIndexPath:indexPath].size.width, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, 0, [rank_tableView rectForRowAtIndexPath:indexPath].size.width+2*(xOriginDiff), rowheight);
                if(indexPath.row == (rewardsArray.count - 1)) {
                    lineView.frame=CGRectZero;
                }
                else
                    lineView.frame=CGRectMake(0,rowheight-0.5,[rank_tableView rectForRowAtIndexPath:indexPath].size.width+2*(xOriginDiff) , 0.5);
            }
            cellbg.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
        }
        
        [redeemButton setFrame:CGRectMake((cellRect.size.width-(iPad?200:150))/2,rowheight-(iPad?40:30)-15,iPad?200:150,iPad?40:30)];
        redeemButton.indexPath=indexPath;
        
        if (indexPath.row == 0) {
            if(rewardsArray.count == 1) {
            [appDelegate setMaskTo:cellbg byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(10.0, 10.0)];
            }
            else
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight withRadii:CGSizeMake(10.0, 10.0)];
        } else if (indexPath.row == (rewardsArray.count - 1)) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(10.0, 10.0)];
        } else {
            [appDelegate setMaskTo:cellbg byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(0.0, 0.0)];
        }
        cell.backgroundView = cellbg;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (indexPath.row == rewardsArray.count) {
            [self performSelector:@selector(loadMoreAcitivities:) withObject:nil afterDelay:0.001];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TCSTART
    /*
    if([self isNotNull:rewardsArray] && rewardsArray.count > indexPath.row){
        BusinessReward *businessReward = [rewardsArray objectAtIndex:indexPath.row];
//        CPBusinessEntity *entity = [locationsArray objectAtIndex:indexPath.row];
        CPSpecial *special = [[CPSpecial alloc] init];
        
        special.specialId = businessReward.rewardId;
        special.title     = businessReward.rewardTitle;
        special.details   = businessReward.rewardDescription;
        special.startDate = businessReward.rewardStartDate;
        special.endDate   = businessReward.rewardEndDate;
        special.imageURL  = [NSURL URLWithString:businessReward.imageURL];
        special.repeatably_redeemable = [businessReward.repeatably_redeemable boolValue];
        [self gotoRedeemSpecialViewControllerWithSpecial:special andLocationId:nil];
//        if ([self isNotNull:reward.businessRedeemsArray] && [reward.businessRedeemsArray count] > 0) {
//            RewardsLocationsViewController *rewardsLocationsVC = [[RewardsLocationsViewController alloc] initWithFrame:self.view.frame withBusinessReward:reward];
//            [self.navigationController pushViewController:rewardsLocationsVC animated:YES];
//        }
    }
     */
    TCEND
}

-(void)redeemButtonAction:(RedeemCutomButton*)sender {
    TCSTART
    NSLog(@"SenderIndex:%d",sender.indexPath.row);
    //if([self isNotNull:rewardsArray] && rewardsArray.count > sender.indexPath.row && sender.isRedeem)
    {
        BusinessReward *businessReward = [rewardsArray objectAtIndex:sender.indexPath.row];
        CPSpecial *special = [[CPSpecial alloc] init];
        special.specialId = businessReward.rewardId;
        special.title     = businessReward.rewardTitle;
        special.details   = businessReward.rewardDescription;
        special.startDate = businessReward.rewardStartDate;
        special.endDate   = businessReward.rewardEndDate;
        special.imageURL  = [NSURL URLWithString:businessReward.imageURL];
        special.repeatably_redeemable = [businessReward.repeatably_redeemable boolValue];
        special.can_redeem = businessReward.canRedeem;
        [self gotoRedeemSpecialViewControllerWithSpecial:special andLocationId:nil];
    }
//    else {
//        [appDelegate showErrorMsg:@"This Reward cannot be redeemed."];
//    }

    TCEND
}


- (void)gotoRedeemSpecialViewControllerWithSpecial:(CPSpecial *)special andLocationId:(NSString *)locationId {
    TCSTART
    NSString *imgURl = [appDelegate getSpecialImageUrlString:[special.imageURL absoluteString]];
    RedeemSpecialViewController *redeemSpecialVC = [[RedeemSpecialViewController alloc]initWithSpecial:special withImgUrl:imgURl andLocationId:locationId FromViewController:self canRepeatablyRedeemable:special.repeatably_redeemable];
    
    [self.navigationController pushViewController:redeemSpecialVC animated:YES];
    TCEND
}



#pragma mark LoadMore Followings.
-(void)loadMoreAcitivities:(id)sender{
    
    @try {
        if(is_rank_all_TabSlctd || is_rank_silver_TabSlctd || is_rank_bronze_TabSlctd || is_rank_gold_TabSlctd){
            rank_pagenumber++;
            [self getRewardsForRefresh:NO];
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


#pragma mark TableScrollView Delegate Methods
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // NSLog(@"scrollViewWillBeginDragging");
	if (!reloading)
	{
		checkForRefresh = YES;  //  only check offset when dragging
	}
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    @try {
        // NSLog(@"scrollViewDidScroll");
        if (reloading) return;
        
        if (checkForRefresh) {
            if (refreshNotificationsView.isFlipped && scrollView.contentOffset.y > -45.0f && scrollView.contentOffset.y < 0.0f && !reloading) {
                [refreshNotificationsView flipImageAnimated:YES];
                [refreshNotificationsView setStatus:kPullToReloadStatus];
                
            } else if (!refreshNotificationsView.isFlipped && scrollView.contentOffset.y < -45.0f) {
                [refreshNotificationsView flipImageAnimated:YES];
                [refreshNotificationsView setStatus:kReleaseToReloadStatus];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Load images for all onscreen rows when scrolling is finished
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    @try {
        if (reloading) return;
        
        if (scrollView.contentOffset.y <= -45.0f) {
            [self showReloadAnimationAnimated:YES];
            [self netWorkCallForRewardsRefresh];
        }
        checkForRefresh = NO;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
}

- (void) showReloadAnimationAnimated:(BOOL)animated {
    @try {
        reloading = YES;
        [refreshNotificationsView toggleActivityView:YES];
        
        if (animated) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            rank_tableView.contentInset = UIEdgeInsetsMake(40.0f, 0.0f, 0.0f,
                                                               0.0f);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)dataSourceDidFinishLoadingNewData {
    @try {
        reloading = NO;
        [refreshNotificationsView flipImageAnimated:NO];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        [rank_tableView setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
        [refreshNotificationsView setStatus:kPullToReloadStatus];
        [refreshNotificationsView toggleActivityView:NO];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)netWorkCallForRewardsRefresh {
    
    @try {
        //isRefreshingStream = YES;
        rank_pagenumber = 1;
        [self getRewardsForRefresh:YES];
        
        // NSLog(@"stream objects count after removing from managedObjectContext is %d",[[_fetchedResultsController fetchedObjects]count]);
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
