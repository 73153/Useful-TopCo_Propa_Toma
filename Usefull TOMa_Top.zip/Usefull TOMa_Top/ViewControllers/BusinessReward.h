//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface BusinessReward : NSManagedObject

@property (nonatomic, retain) id businessRedeemsArray;
@property (nonatomic, retain) NSString * imageURL;
@property (nonatomic, retain) id redeemptionListArray;
@property (nonatomic, retain) NSString * rewardDescription;
@property (nonatomic, retain) NSDate * rewardEndDate;
@property (nonatomic, retain) NSNumber * rewardId;
@property (nonatomic, retain) NSDate * rewardStartDate;
@property (nonatomic, retain) NSString * rewardTitle;
@property (nonatomic, retain) NSNumber * repeatably_redeemable;
@property (nonatomic, retain) NSNumber * canRedeem;

@end
