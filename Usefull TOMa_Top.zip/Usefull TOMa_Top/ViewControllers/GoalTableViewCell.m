//
//  GoalTableViewCell.m
//  Baldwin
//
//  Created by Jagadeesh J on 10/12/14.
//  Copyright (c) 2014 Spoors. All rights reserved.
//

#import "GoalTableViewCell.h"


@implementation GoalTableViewCell

@synthesize delegate;
@synthesize leftLabel;
@synthesize rightTextField;
@synthesize indexPath;
@synthesize cellBgView;
@synthesize hideLeftLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    @try {
        if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
            
            leftLabel = [[UILabel alloc] initWithFrame:CGRectZero];
            [leftLabel setBackgroundColor:[UIColor clearColor]];
            [leftLabel setTextColor:[UIColor grayColor]];
            leftLabel.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?17.0f:titleFontSize];
            leftLabel.textAlignment = NSTextAlignmentLeft;
            [leftLabel setText:@"Left Field"];
            [self addSubview:leftLabel];
            
            rightTextField = [[UITextField alloc] initWithFrame:CGRectZero];
            rightTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
            [rightTextField setDelegate:self];
            [rightTextField setFont:[UIFont fontWithName:titleFontName size:isiPhone6PLUS?17.0f:titleFontSize]];
            rightTextField.textColor = [UIColor whiteColor];
            rightTextField.backgroundColor = [UIColor clearColor];
            [rightTextField setReturnKeyType:UIReturnKeyNext];
            [self addSubview:rightTextField];
        }
        
        return self;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//Layout our fields in case of a layoutchange (fix for iPad doing strange things with margins if width is > 400)
- (void)layoutSubviews {
    @try {
        [super layoutSubviews];
        CGRect origFrame = self.contentView.frame;
        if (leftLabel.text != nil) {
            if (iPad) {
                leftLabel.frame = CGRectMake(origFrame.origin.x+10, origFrame.origin.y, 220, origFrame.size.height-1);
                rightTextField.frame = CGRectMake(leftLabel.frame.origin.x + leftLabel.frame.size.width + 40, origFrame.origin.y, origFrame.size.width - (leftLabel.frame.origin.x + leftLabel.frame.size.width + 40 + 10), origFrame.size.height);
            } else {
                leftLabel.frame = CGRectMake(origFrame.origin.x+10, origFrame.origin.y, 150+20, origFrame.size.height-1);
                
                rightTextField.frame = CGRectMake(origFrame.origin.x+130+(isiPhone6PLUS?60:40), origFrame.origin.y, origFrame.size.width-130, origFrame.size.height-1);
            }
            
        } else {
            leftLabel.hidden = YES;
            NSInteger imageWidth = 0;
            if (self.imageView.image != nil) {
                imageWidth = self.imageView.image.size.width + 5;
            }
            rightTextField.frame = CGRectMake(origFrame.origin.x+imageWidth+15, origFrame.origin.y, origFrame.size.width-imageWidth-20, origFrame.size.height-1);
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    @try {
        if([delegate respondsToSelector:@selector(textFielddidBeginEditingWithField:andIndexPath:)]) {
            
            [delegate performSelector:@selector(textFielddidBeginEditingWithField:andIndexPath:) withObject:textField withObject:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    @try {
        if([delegate respondsToSelector:@selector(textFieldDidReturnWithIndexPath:)]) {
            
            [delegate performSelector:@selector(textFieldDidReturnWithIndexPath:) withObject:indexPath];
        }
        
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    @try {
        NSString *textString = self.rightTextField.text;
        
        if (range.length > 0) {
            textString = [textString stringByReplacingCharactersInRange:range withString:@""];
        } else {
            if(range.location == [textString length]) {
                textString = [textString stringByAppendingString:string];
            } else {
                textString = [textString stringByReplacingCharactersInRange:range withString:string];
            }
        }
        
        if([delegate respondsToSelector:@selector(updateTextLabelAtIndexPath:string:)]) {
            [delegate performSelector:@selector(updateTextLabelAtIndexPath:string:) withObject:indexPath withObject:textString];
        }
        
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    if (action == @selector(paste:) || action == @selector(copy:) || action == @selector(cut:)) {
        //        return [super canPerformAction:action withSender:sender];
    }
    return NO;
}
- (void)dealloc {
    //
    //	[leftLabel release];
    //	[rightTextField release];
    //	[indexPath release];
    //    [super dealloc];
}

@end

