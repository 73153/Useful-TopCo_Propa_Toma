//
//  ProviderEventsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 18/11/14.
//
//

#import <UIKit/UIKit.h>
#import "StreamService.h"
#import "RefreshView.h"
#import "AppDelegate.h"

@interface ProviderEventsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,StreamServiceDelegate> {
   
    UITableView *providerLocationsTableView;
    NSMutableArray *locationsArray;
    
    RefreshView *refreshView;
    BOOL checkForRefresh;
	BOOL reloading;
    AppDelegate *appDelegate;
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;

@end
