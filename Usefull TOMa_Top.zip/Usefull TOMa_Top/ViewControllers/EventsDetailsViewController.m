//
//  DetailsView.m
//  LocationInfo
//
//  Created by shiva on 12/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "EventsDetailsViewController.h"
#import <QuartzCore/QuartzCore.h>

#import "DirectionsViewController.h"

@implementation EventsDetailsViewController

@synthesize tabbarMainVC;
@synthesize detailsTableView;
@synthesize streamInfoModel;
@synthesize mapFullVC;

- (id)initWithFrame:(CGRect)frame andHeader:(UIView *)headerview_
{
    self = [super init];
    if (self) {
        // Initialization code
        vcFrame = frame;
        tableHeaderView = headerview_;
    }
    return self;
}

-(void)viewDidLoad {
    
    @try {
        self.view.frame = vcFrame;
        self.view.backgroundColor = [UIColor clearColor];
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        //store the contacts info like address,website & phone.
        contactMArray = [[NSMutableArray alloc]init];
        detailsMArray = [[NSMutableArray alloc]init];
        
        btnName_Arry = [[NSArray alloc]initWithObjects:@"details_tab_map",@"details_tab_contact",@"details_tab_info", nil];
        
        //isMapSelected = YES;
        btnTag = -3;
        CGFloat originX;
        CGFloat diff;
        if (iPad) {
            originX = -30;
            diff = 10;
        } else {
            originX = -2.5;
            diff = 5;
        }
        if (CURRENT_DEVICE_VERSION >= 7.0) {
            if (iPad) {
                originX = 20;
            } else {
                originX = 5;
            }
        }
        //tableHeaderView.frame = CGRectMake(diff, 0, self.view.frame.size.width, tableHeaderView.frame.size.height);
        //[self.view addSubview:tableHeaderView];
        
        
        detailsTableView = [[UITableView alloc]initWithFrame:CGRectMake(originX, diff, self.view.frame.size.width + (2 * -originX), self.view.frame.size.height) style:UITableViewStyleGrouped];
        detailsTableView.delegate = self;
        detailsTableView.dataSource = self;
        detailsTableView.backgroundView = nil;
        detailsTableView.backgroundColor = [UIColor clearColor];
        detailsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:detailsTableView];
        verticalContentOffset=0;
        [detailsTableView reloadData];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    [self reloadTable];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
}

-(UIButton *)createDetailsMenuBtns:(CGRect)frame {
        
    @try {
        UIButton *btnDetails = [UIButton buttonWithType:UIButtonTypeCustom];
        btnDetails.frame = frame;
        btnDetails.backgroundColor = [UIColor darkGrayColor];
        btnDetails.titleLabel.font = [UIFont fontWithName:headerTitleFontName size:InfoTitleFontSize];
        [btnDetails addTarget:self action:@selector(switchToSelectedDetailPage:) forControlEvents:UIControlEventTouchUpInside];
        return btnDetails;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
//show Details based on category that user has selected.
-(void)switchToSelectedDetailPage:(id)sender
{
    @try {
        selectedMenu_Btn = (UIButton *)sender;
        btnTag = selectedMenu_Btn.tag;
        if (btnTag == -1) {
         //   NSLog(@"user selected Map");
            isMapSelected = YES;
            isContactSelected = NO;
        }
        else if(btnTag == -2){
          //  NSLog(@"user selected Contact");
            isMapSelected = NO;
            isContactSelected = YES;
        }
        else{
          //  NSLog(@"user selected Details");
            isMapSelected = NO;
            isContactSelected = NO;
        }
        verticalContentOffset  = detailsTableView.contentOffset.y;
        [detailsTableView reloadData];
        [detailsTableView setContentOffset:CGPointMake(0, verticalContentOffset)];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(CGFloat)getheightForRowInSection:(NSIndexPath *)indexPath {
    @try {
        CGFloat contactRowHeight = 0;
        NSMutableArray *temp;
        if (isContactSelected)
            temp = contactMArray;
        else
            temp = detailsMArray;
        
        if (!temp.count > 0) {
            return 100.0f;
        }
        
        NSDictionary *rowinfoDict;
        if ([self isNotNull:temp] && temp.count > indexPath.row) {
            rowinfoDict = [temp objectAtIndex:indexPath.row];
        }
        if(isiPhone6) {
            contactRowHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"] withConstraintWidth:300 - (iPad?85:55) withFontSize:InfoTitleFontSize withFontName:headerTitleFontName];
        }
        else
        contactRowHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"] withConstraintWidth:CELL_CONTENT_WIDTH - (iPad?85:55) withFontSize:InfoTitleFontSize withFontName:headerTitleFontName];
        
        //}
//        if (indexPath.row == 0) {
            return contactRowHeight + (iPad?55:30) ; // 5pxls more to start the first cell content 5pxls below the menu items..
//        }
        
        return contactRowHeight + (iPad?90:28) ;//"70" is for shwoing the header name. 20 for gap between 2lables.
        
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma -
#pragma mark tableView datasource & delegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if(section == 0) {
        return  tableHeaderView.frame.size.height;
    }
    else if(section == 1) {
        if (iPad) {
            return 75;
        } else {
            return 40;
        }
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        int rowHeight;
        if (isMapSelected) {
            rowHeight = [self getHeightOfMap];
        } else {//calculate the row height based on hours and description
            rowHeight = [self getheightForRowInSection:indexPath];
        }
        return rowHeight;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (CGFloat)getHeightOfMap {
    return detailsTableView.frame.size.height - (iPad?75:40);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    @try {
        if(section == 0) {
            return 0;
        }
        else if(section == 1) {
            int numberOfRowPerSection = 0;
            
            if (isMapSelected) {
                numberOfRowPerSection = 1;
            } else if(isContactSelected) {
                
                if (contactMArray.count > 0) {
                    numberOfRowPerSection = [contactMArray count];
                } else { //to show there are no contact details
                    numberOfRowPerSection = 1;
                }
            } else {
                
                if (detailsMArray.count > 0) {
                    numberOfRowPerSection = [detailsMArray count];
                } else { // to show there is no info
                    numberOfRowPerSection = 1;
                }
            }
            
            return numberOfRowPerSection;
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view;
    
    @try {
        if(section == 0) {
            return tableHeaderView;
        }
        else if (section == 1) {
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(19, 5, 748-30, 75)];
        view.layer.cornerRadius = 5.0f;
        view.backgroundColor = [UIColor clearColor];

        UIImageView *selectedDetailBG_imageView = [[UIImageView alloc]initWithFrame:CGRectMake(5 + 20,5, 748 -30, 80)];
        if (!iPad) {
            view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, 40);
            selectedDetailBG_imageView.frame = CGRectMake(10,10,290,40);
        }
        //selectedDetailsButtionBG Strip Image
        
        [view addSubview:selectedDetailBG_imageView];
        
        //send the menu items names.
        for (int i = 0; i < 3; i++) {
            //create the menu buttons.
            UIButton *detailsMenu_Btn;
            if(isiPhone6) {
                detailsMenu_Btn = [self createDetailsMenuBtns:CGRectMake(((i * (320/3)) + 5), 10, 320/3, selectedDetailBG_imageView.frame.size.height)];
            }
            else
                detailsMenu_Btn = [self createDetailsMenuBtns:CGRectMake(((i * (self.view.frame.size.width/3)) + 5), 10, self.view.frame.size.width/3, selectedDetailBG_imageView.frame.size.height)];
            
            detailsMenu_Btn.tag = -(i + 1);
            detailsMenu_Btn.backgroundColor = [UIColor clearColor];
            [view addSubview:detailsMenu_Btn];
            //specials_Btn.layer.cornerRadius = 2.0f;
            [view bringSubviewToFront:detailsMenu_Btn];
        }
        //highlight the first button(ALL) when view initializes, default will be always ALL SPECIALS.
        selectedMenu_Btn = (UIButton *)[view viewWithTag:btnTag];
            //check whether slected button and btnRef are equal if not then change the properties of a button to non slected
            if ([selectedMenu_Btn isKindOfClass:[UIButton class]]) {
                if (iPad) {
                    if (CURRENT_DEVICE_VERSION < 7.0) {
                        if (selectedMenu_Btn.tag == -1) {
                            selectedDetailBG_imageView.frame = CGRectMake(5+37, 5, 748-15, 70);
                        } else if (selectedMenu_Btn.tag == -3) {
                            selectedDetailBG_imageView.frame = CGRectMake(5+56, 5, 738-13, 70);
                        } else {
                            selectedDetailBG_imageView.frame = CGRectMake(5+50, 5, 748-30, 70);
                        }
                    } else {
                        if (selectedMenu_Btn.tag == -1) {
                            selectedDetailBG_imageView.frame = CGRectMake(-2, 5, 718, 70);
                        } else if (selectedMenu_Btn.tag == -3) {
                            selectedDetailBG_imageView.frame = CGRectMake(18, 5, 712, 70);
                        } else {
                            selectedDetailBG_imageView.frame = CGRectMake(8, 5, 710, 70);
                        }
                    }
                } else {
                    if (CURRENT_DEVICE_VERSION < 7.0) {
                        if (selectedMenu_Btn.tag == -1) {
                            selectedDetailBG_imageView.frame = CGRectMake(9, 10, 290, 35);
                        } else if (selectedMenu_Btn.tag == -3) {
                            selectedDetailBG_imageView.frame = CGRectMake(19, 10, 297, 35);
                        } else {
                            selectedDetailBG_imageView.frame = CGRectMake(23, 10, 280, 35);
                        }
                    } else {
                        if (selectedMenu_Btn.tag == -1) {
                            selectedDetailBG_imageView.frame = CGRectMake(0, 10, 290, 35);
                        } else if (selectedMenu_Btn.tag == -3) {
                            selectedDetailBG_imageView.frame = CGRectMake(15, 10, 295, 35);
                        } else {
                            selectedDetailBG_imageView.frame = CGRectMake(15, 10, 280, 35);
                        }
                    }
                }
                selectedDetailBG_imageView.image = [UIImage imageNamed:[btnName_Arry objectAtIndex:-(btnTag+1)]];
            }
        return view;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
    return view;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    @try {
        
        if (isMapSelected) {
            if (appDelegate.mapView) {
                appDelegate.mapView.hidden = NO;
            }
            return [self configureTableCellToShowMap:tableView cellForRowAtIndexPath:indexPath];
        } else if(isContactSelected) {
            if (appDelegate.mapView) {
                appDelegate.mapView.hidden = YES;
            }
            return [self configureTableCellToShowContactInfo:tableView cellForRowAtIndexPath:indexPath];
        } else {
            if (appDelegate.mapView) {
                appDelegate.mapView.hidden = YES;
            }
            return [self configureTableCellToShowDetailInfo:tableView cellForRowAtIndexPath:indexPath];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(UITableViewCell *)configureTableCellToShowMap:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   
    @try {
        UITableViewCell *cell;
        UIButton *userLocationAddressBtn = nil;
        UIButton *businessLocationAddressBtn = nil;
        UIButton *direction_Btn = nil;
        UIButton *fullMapView_Btn = nil;
        
        static NSString *MapIdentifier = @"MapIdentifier"; //For displaying comments
        
        cell = [tableView dequeueReusableCellWithIdentifier:MapIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MapIdentifier];
            
            //create a button to show the business address placed right side of the map
            userLocationAddressBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            userLocationAddressBtn.tag = 14;
            [userLocationAddressBtn addTarget:self action:@selector(showUserAddress:) forControlEvents:UIControlEventTouchUpInside];
            [userLocationAddressBtn setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:userLocationAddressBtn];
            
            //create a button to show the UserAddress placed right side of the map
            businessLocationAddressBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            businessLocationAddressBtn.tag = 15;
            [businessLocationAddressBtn addTarget:self action:@selector(showBusinessLocationAdress:) forControlEvents:UIControlEventTouchUpInside];
            [businessLocationAddressBtn setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:businessLocationAddressBtn];
            
            //create a button to openGoogleMap which is placed right side of the map
            direction_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            direction_Btn.tag = 16;
            [direction_Btn addTarget:self action:@selector(openGoogleMap:) forControlEvents:UIControlEventTouchUpInside];
            [direction_Btn setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:direction_Btn];
            
            //create a button to zoom MapView which is placed right side of the map
            fullMapView_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            fullMapView_Btn.tag = 17;
            [fullMapView_Btn addTarget:self action:@selector(zoomMapView:) forControlEvents:UIControlEventTouchUpInside];
            [fullMapView_Btn setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:fullMapView_Btn];
            
            UIImage *image = [UIImage imageNamed:@"mapArrow"];
            appDelegate.mapView.annotationImage = image; //set the image it will be displayed as annotation point
            appDelegate.mapView.showLeftCalloutAccessory = NO;
            appDelegate.mapView.showRightCalloutAccessory = NO;
            appDelegate.mapView.layer.borderWidth = 5.0f;
            appDelegate.mapView.layer.borderColor = [UIColor whiteColor].CGColor;
            //appDelegate.mapView.tag = 13;
            [cell.contentView addSubview:appDelegate.mapView];
            
            [self showBusinessLocationAdress:(id)businessLocationAddressBtn];
        }
                
        if (!userLocationAddressBtn) {
            userLocationAddressBtn = (UIButton *)[cell.contentView viewWithTag:14];
        }
        if (!businessLocationAddressBtn) {
            businessLocationAddressBtn = (UIButton *)[cell.contentView viewWithTag:15];
        }
        if (!direction_Btn) {
            direction_Btn = (UIButton *)[cell.contentView viewWithTag:16];
        }
        if (!fullMapView_Btn) {
            fullMapView_Btn = (UIButton *)[cell.contentView viewWithTag:17];
        }
        
        CGFloat height = [self getHeightOfMap];
    
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        int gapFromMap;
        
        UIView *cellbg = [[UIView alloc] init];
        if (!iPad) {
            appDelegate.mapView.frame = CGRectMake(5, 5, appDelegate.window.frame.size.width-70, height-10);
            gapFromMap = 8;
            userLocationAddressBtn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, appDelegate.mapView.frame.origin.y + 5, 30 ,30);
            businessLocationAddressBtn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, userLocationAddressBtn.frame.origin.y + userLocationAddressBtn.frame.size.height + 10, 30 ,30);
            direction_Btn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, businessLocationAddressBtn.frame.origin.y + businessLocationAddressBtn.frame.size.height + 10, 30 ,30);
            fullMapView_Btn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, direction_Btn.frame.origin.y + direction_Btn.frame.size.height + 10, 30 ,30);
            cellbg.frame = CGRectMake(0, 5, appDelegate.window.frame.size.width-10, [self getHeightOfMap]);
        } else {
            appDelegate.mapView.frame = CGRectMake(10, 10, 728 - 85, height-20);
            gapFromMap = 15;
            userLocationAddressBtn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, appDelegate.mapView.frame.origin.y + 5, 55 ,55);
            
            businessLocationAddressBtn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, userLocationAddressBtn.frame.origin.y + userLocationAddressBtn.frame.size.height + 10, 55 ,55);
            
            direction_Btn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, businessLocationAddressBtn.frame.origin.y + businessLocationAddressBtn.frame.size.height + 10, 55 ,55);
            
            fullMapView_Btn.frame = CGRectMake(5 + appDelegate.mapView.frame.size.width + gapFromMap, direction_Btn.frame.origin.y + direction_Btn.frame.size.height + 10, 55 ,55);
            cellbg.frame = CGRectMake(2, -10, (CURRENT_DEVICE_VERSION < 7.0)?740:728, [self getHeightOfMap]);
        }
                    
    
        [direction_Btn setImage:[UIImage imageNamed:@"directions"] forState:UIControlStateNormal];
        [fullMapView_Btn setImage:[UIImage imageNamed:@"details_zoomin"] forState:UIControlStateNormal];
        
        cell.backgroundView = cellbg;
        if (indexPath.row == 0) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerTopRight  withRadii:CGSizeMake(10.0, 10.0)];
        } else {
            [appDelegate setMaskTo:cellbg byRoundingCorners: UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(0.0, 0.0)];
        }
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
       NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (UITableViewCell *)configureTableCellToShowContactInfo:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        UITableViewCell *cell;
        
        static NSString *user_messageCellIdentifier = @"usermessageIdentifier";
        if(!contactMArray.count > 0) {
            cell = [tableView dequeueReusableCellWithIdentifier:user_messageCellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:user_messageCellIdentifier];
            }
            
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.font = [UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize];
            cell.textLabel.text = @"No Contact Details";
            cell.textLabel.backgroundColor = [UIColor clearColor];
            cell.textLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
            cell.textLabel.frame = CGRectMake(cell.textLabel.frame.origin.x + 10, cell.textLabel.frame.origin.y, cell.textLabel.frame.size.width, cell.textLabel.frame.size.height);
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        } else {
            UILabel *nameLbl = nil;
            UILabel *descLbl = nil;
            
            UIImageView *cellThmbIcon = nil;
            //get the data for this row
            NSDictionary *rowinfoDict;
            if ([self isNotNull:contactMArray] && contactMArray.count > indexPath.row) {
                rowinfoDict = [contactMArray objectAtIndex:indexPath.row];
            }
            
//            NSLog(@"summayLblHeight for contacts is %f",summaryLblHeight);
            static NSString *ContactIdentifier = @"ContactIdentifier"; //For displaying comments
            
            cell = [tableView dequeueReusableCellWithIdentifier:ContactIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ContactIdentifier];
                
                cellThmbIcon = [self createCellThumbIcon];
                [cell.contentView addSubview:cellThmbIcon];
                
                nameLbl = [self createTitleLbl];
                [cell.contentView addSubview:nameLbl];
                
                descLbl = [self createSummaryLbl];
                [cell.contentView addSubview:descLbl];
            }
            if (!cellThmbIcon)
                cellThmbIcon = (UIImageView *)[cell.contentView viewWithTag:12];
            if (!nameLbl)
                nameLbl = (UILabel *)[cell.contentView viewWithTag:10];
            if (!descLbl)
                descLbl = (UILabel *)[cell.contentView viewWithTag:11];
            
            descLbl.numberOfLines = 0;
            [descLbl sizeToFit];
            
            
            if ([self isNotNull:rowinfoDict] && [rowinfoDict isKindOfClass:[NSDictionary class]]) {
                if (iPad) {
                    cellThmbIcon.frame = CGRectMake(5 * 2,10,55,65);
                    nameLbl.frame = CGRectMake(cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10, 10, (748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 20)) ,35.0f);
                    CGFloat summaryLblHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"] withConstraintWidth:(748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10)) withFontSize:InfoTitleFontSize withFontName:headerTitleFontName];
                    descLbl.frame = CGRectMake(cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10, nameLbl.frame.origin.y + nameLbl.frame.size.height + 5, (748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 20)) ,MAX(summaryLblHeight, 0.0f));
                    
                } else {
                    CGFloat summaryLblHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"] withConstraintWidth:280 - (5 + 25) withFontSize:InfoTitleFontSize withFontName:headerTitleFontName];
                    if([[rowinfoDict objectForKey:@"name"] rangeOfString:@"facebook" options:NSCaseInsensitiveSearch].location != NSNotFound || [[rowinfoDict objectForKey:@"name"] rangeOfString:@"twitter" options:NSCaseInsensitiveSearch].location != NSNotFound) {// launch safari application
                        cellThmbIcon.frame = CGRectMake(5,5 + 2.5f,25,20);
                    } else {
                        cellThmbIcon.frame = CGRectMake(5,5 + 2.5f,25,25);
                    }

                    nameLbl.frame = CGRectMake(5 + cellThmbIcon.frame.size.width + 5, 5, (280 - (5 + 5)) ,20.0f);
                    descLbl.frame = CGRectMake(5 + cellThmbIcon.frame.size.width + 5, nameLbl.frame.origin.y + nameLbl.frame.size.height + 3, (280 - (5 + 25)) ,MAX(summaryLblHeight, 0.0f));
                }
                
                
                if ([self isNotNull:[rowinfoDict objectForKey:@"image"]]) {
                    cellThmbIcon.image = [UIImage imageNamed:[rowinfoDict objectForKey:@"image"]];
                } else {
                    cellThmbIcon.image = nil;
                }
                if ([self isNotNull:[rowinfoDict objectForKey:@"name"]]) {
                    nameLbl.text = [rowinfoDict objectForKey:@"name"];
                } else {
                    nameLbl.text = @"";
                }
                if ([self isNotNull:[rowinfoDict objectForKey:@"description"]]) {
                    descLbl.text = [rowinfoDict objectForKey:@"description"];
                } else {
                    descLbl.text = @"";
                }
            }
        }
        
        
        UIView *cellbg = [[UIView alloc] init];
        CGFloat rowheight = [self getheightForRowInSection:indexPath];
        if (iPad) {
            if (indexPath.row != 0 || (CURRENT_DEVICE_VERSION >= 7.0)) {
                cellbg.frame = CGRectMake(0, -10, (CURRENT_DEVICE_VERSION<7.0)?740:728, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, -10, 740, rowheight);
            }
        } else {
            if (indexPath.row != 0 || (CURRENT_DEVICE_VERSION >= 7.0)) {
                cellbg.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, rowheight);
            }
        }
        
        cell.backgroundView = cellbg;
        if (indexPath.row == 0) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight withRadii:CGSizeMake(10.0, 10.0)];
            if(indexPath.row == (contactMArray.count - 1)) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(10.0, 10.0)];
            }
        } else if (indexPath.row == (contactMArray.count - 1)) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(10.0, 10.0)];
        } else {
            [appDelegate setMaskTo:cellbg byRoundingCorners:nil withRadii:CGSizeMake(7.0, 7.0)];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(UITableViewCell *)configureTableCellToShowDetailInfo:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        UITableViewCell *cell;
        
        static NSString *user_messageCellIdentifier = @"usermessageIdentifier";
        if(!detailsMArray.count > 0) {
            cell = [tableView dequeueReusableCellWithIdentifier:user_messageCellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:user_messageCellIdentifier];
            }
            
            cell.imageView.image = [UIImage imageNamed:@"No-Details-Icon"]; //size 62.5x55
            cell.imageView.layer.cornerRadius = 4.0f;
            cell.imageView.layer.masksToBounds = YES;
            
            cell.textLabel.text = @"No details yet, check back soon";
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.textColor = [UIColor darkGrayColor];
            cell.textLabel.backgroundColor = [UIColor clearColor];
            cell.textLabel.frame = CGRectMake(cell.textLabel.frame.origin.x + 10, cell.textLabel.frame.origin.y, cell.textLabel.frame.size.width, cell.textLabel.frame.size.height);
            cell.textLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
        } else {
            UIImageView *cellThmbIcon = nil;
            UILabel *nameLbl = nil;
            UILabel *descLbl = nil;
            NSDictionary *rowinfoDict;
            if ([self isNotNull:detailsMArray] && detailsMArray.count > indexPath.row) {
                rowinfoDict = [detailsMArray objectAtIndex:indexPath.row];
            }

            static NSString *DetailsIdentifier = @"DetailsIdentifier"; //For displaying comments
            
            cell = [tableView dequeueReusableCellWithIdentifier:DetailsIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:DetailsIdentifier];
                
                cellThmbIcon = [self createCellThumbIcon];
                [cell.contentView addSubview:cellThmbIcon];
                
                nameLbl = [self createTitleLbl];
                [cell.contentView addSubview:nameLbl];
                
                descLbl = [self createSummaryLbl];
                [cell.contentView addSubview:descLbl];
            }
            if (!cellThmbIcon) {
                cellThmbIcon = (UIImageView *)[cell.contentView viewWithTag:12];
            }
            if (!nameLbl) {
                nameLbl = (UILabel *)[cell.contentView viewWithTag:10];
            }
            if (!descLbl) {
                descLbl = (UILabel *)[cell.contentView viewWithTag:11];
            }
            
            if ([self isNotNull:rowinfoDict]) {
                if (iPad) {
                    cellThmbIcon.frame = CGRectMake(5 * 2,10,55,65);
                    nameLbl.frame = CGRectMake(cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10, 10, (748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 20)) ,35.0f);
                    CGFloat summaryLblHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"] withConstraintWidth:(748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10)) withFontSize:InfoTitleFontSize withFontName:headerTitleFontName];
                    
                    descLbl.frame = CGRectMake(cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 10, nameLbl.frame.origin.y + nameLbl.frame.size.height + 5, (748 - (cellThmbIcon.frame.origin.x + cellThmbIcon.frame.size.width + 20)) ,MAX(summaryLblHeight, 0.0f));
                } else {
                    int summaryLblHeight = [appDelegate getStringHeight:[rowinfoDict objectForKey:@"description"]  withConstraintWidth:280 - (5 + 25 + 5) withFontSize:titleFontSize withFontName:headerTitleFontName];
                    if (summaryLblHeight > 0) {
                        summaryLblHeight += 2;
                    }
                    cellThmbIcon.frame = CGRectMake(5,5,25,25);
                    nameLbl.frame = CGRectMake(5 + cellThmbIcon.frame.size.width + 5, 5, ((appDelegate.window.frame.size.width-40) - (5 + 5)),MAX(20, 0.0f));
                    descLbl.frame = CGRectMake(5 + cellThmbIcon.frame.size.width + 5, nameLbl.frame.origin.y + nameLbl.frame.size.height + 2, ((appDelegate.window.frame.size.width-40) - (5 + cellThmbIcon.frame.size.width + 5)) ,MAX(summaryLblHeight, 0.0f));
                }
                
            
                if ([self isNotNull:[rowinfoDict objectForKey:@"image"]]) {
                    cellThmbIcon.image = [UIImage imageNamed:[rowinfoDict objectForKey:@"image"]];
                } else {
                    cellThmbIcon.image = nil;
                }
                if ([self isNotNull:[rowinfoDict objectForKey:@"name"]]) {
                    nameLbl.text = [rowinfoDict objectForKey:@"name"];
                } else {
                    nameLbl.text = @"";
                }
                if ([self isNotNull:[rowinfoDict objectForKey:@"description"]]) {
//                    NSLog(@"DESCRIPTION:%@",[rowinfoDict objectForKey:@"description"]);
                    descLbl.text = [rowinfoDict objectForKey:@"description"];
                }
            }
        }
        
        UIView *cellbg = [[UIView alloc] init];
        CGFloat rowheight = [self getheightForRowInSection:indexPath];
        if (iPad) {
            if (CURRENT_DEVICE_VERSION >= 7.0) {
                cellbg.frame = CGRectMake(0, -10, 728, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, -10, 740, rowheight);
            }
            
            cellbg.backgroundColor = [UIColor colorWithRed:0.72f green:0.73f blue:0.77f alpha:1.0f];
        } else {
            if (CURRENT_DEVICE_VERSION >= 7.0) {
                cellbg.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, rowheight-1);
            } else {
                cellbg.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width-10, rowheight);
            }
            
            cellbg.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
        }
        
        cell.backgroundView = cellbg;
    
        if (indexPath.row == 0) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerTopLeft  withRadii:CGSizeMake(10.0, 10.0)];
        } else if(indexPath.row == (detailsMArray.count -1)) {
            [appDelegate setMaskTo:cellbg byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(10.0, 10.0)];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (iPad) {
            cell.backgroundView.backgroundColor = [UIColor colorWithRed:0.72f green:0.73f blue:0.77f alpha:1.0f];
        } else {
            cell.backgroundView.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TCSTART
    NSIndexPath *currentSelectedIndexPath = [tableView indexPathForSelectedRow];
    if (currentSelectedIndexPath != nil) {
        UITableViewCell* cell = [detailsTableView cellForRowAtIndexPath:currentSelectedIndexPath];
        if (iPad) {
            cell.backgroundView.backgroundColor = [UIColor colorWithRed:0.72f green:0.73f blue:0.77f alpha:1.0f];
        } else {
            cell.backgroundView.backgroundColor = [UIColor colorWithRed:0.894f green:0.901f blue:0.937f alpha:1.0f];
        }
    }
    return indexPath;
    TCEND
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        if(indexPath.section == 1) {
            if (isContactSelected && [self isNotNull:contactMArray] && contactMArray.count > 0 ) {
                
                NSDictionary *contactDict = [contactMArray objectAtIndex:indexPath.row];
                NSString *type = [contactDict objectForKey:@"name"];
                UITableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
                [cell.backgroundView setBackgroundColor:tableRowSelectedColor];
                
                NSString *url = nil;
                if ([type rangeOfString:@"address" options:NSCaseInsensitiveSearch].location != NSNotFound) { //switch to mapview
                    
                    isMapSelected = YES;
                    isContactSelected = NO;
                    btnTag = -1;
                    //                [self showUserAddress:nil]; // call this to jump to business location from contact.
                    verticalContentOffset  = detailsTableView.contentOffset.y;
                    [detailsTableView reloadData];
                    [detailsTableView setContentOffset:CGPointMake(0, verticalContentOffset)];
                    
                } else if([type rangeOfString:@"phone" options:NSCaseInsensitiveSearch].location != NSNotFound){// launch call application
                    
                    //[appDelegate openPhoneApp:streamInfoModel.PhoneNo];
                    [tabbarMainVC openPhoneApp:nil];
                    
                } else if([type rangeOfString:@"website" options:NSCaseInsensitiveSearch].location != NSNotFound) {// launch safari application
                    url = streamInfoModel.loc_WebsiteUrl;
                    if ([url rangeOfString:@"http://"].location == NSNotFound && [url rangeOfString:@"https://"].location == NSNotFound)
                        url = [NSString stringWithFormat: @"http://%@", url];
                } else if([type rangeOfString:@"facebook" options:NSCaseInsensitiveSearch].location != NSNotFound) {// launch safari application
                    url = streamInfoModel.facebook_Url;
                    if ([url rangeOfString:@"http://"].location == NSNotFound && [url rangeOfString:@"https://"].location == NSNotFound)
                        url = [NSString stringWithFormat: @"http://%@", url];
                } else if([type rangeOfString:@"twitter" options:NSCaseInsensitiveSearch].location != NSNotFound) {// launch safari application
                    url = streamInfoModel.twitter_Url;
                    if ([url hasPrefix:@"@"]) {
                        url = [url substringFromIndex:1];
                    }
                    if ([url rangeOfString:@"http://"].location == NSNotFound && [url rangeOfString:@"https://"].location == NSNotFound)
                        url = [NSString stringWithFormat: @"https://twitter.com/%@", url];
                    NSLog(@"TwitterURL:%@",url);
                }
                
                if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:url]]) {
                    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
                } 
            }
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)showBusinessLocationAdress:(id)sender {
    
    @try {
        if ([self isNotNull:sender]) {
            UIButton *userLocationBtnRef = (UIButton *)sender;
            
            UIButton *businessLocationBtnRef = nil;
            UIView *cellContentView = (UIView *)[userLocationBtnRef superview];
            
            if ([self isNotNull:cellContentView]) {
                businessLocationBtnRef = (UIButton *)[cellContentView viewWithTag:14];
                [businessLocationBtnRef setImage:[UIImage imageNamed:@"details_businesslocation_arrow"] forState:UIControlStateNormal];
                
            }
            [userLocationBtnRef setImage:[UIImage imageNamed:@"currentlocationarrow_f"] forState:UIControlStateNormal];
        }
        
        MKCoordinateSpan span = {0.05, 0.05};
        NSDictionary *locDict1 = nil;
       
        if ([self isNotNull:streamInfoModel.loc_Latitude] && [self isNotNull:streamInfoModel.loc_Longitude]) {
            locDict1 = [[NSDictionary alloc]initWithObjectsAndKeys:streamInfoModel.loc_Latitude,@"lat",streamInfoModel.loc_Longitude,@"lng",streamInfoModel.loc_Address,@"address", nil];
        }
        
        NSMutableArray *temp_Arry = nil;
        if ([self isNotNull:locDict1]) {
            temp_Arry = [[NSMutableArray alloc] initWithObjects:locDict1,nil];
        }
        
        [appDelegate.mapView loadMapData:temp_Arry withSpan:span];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)showUserAddress:(id)sender {
    
    @try {
        
        if ([self isNotNull:sender]) {
            UIButton *businessLocationBtnRef = (UIButton *)sender;
            UIButton *userLocationBtnRef = nil;
            UIView *cellContentView = (UIView *)[businessLocationBtnRef superview];
            
            if ([self isNotNull:cellContentView]) {
                userLocationBtnRef = (UIButton *)[cellContentView viewWithTag:15];
                [userLocationBtnRef setImage:[UIImage imageNamed:@"currentlocationarrow"] forState:UIControlStateNormal];
                
            }
            [businessLocationBtnRef setImage:[UIImage imageNamed:@"details_businesslocation_arrow_f"] forState:UIControlStateNormal];
        }
        MKCoordinateRegion region; //
        MKCoordinateSpan span = {0.05, 0.05};
        if (tabbarMainVC.userNewLocation.coordinate.latitude != 0.0 && tabbarMainVC.userNewLocation.coordinate.longitude != 0.0) {
            region.center.latitude = tabbarMainVC.userNewLocation.coordinate.latitude;
            region.center.longitude = tabbarMainVC.userNewLocation.coordinate.longitude;
        }
        region.span = span;
        [appDelegate.mapView setRegion:region animated:YES];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)openGoogleMap:(id)sender {
    
    @try {
        
        Class itemClass = [MKMapItem class];
        if (itemClass && [itemClass respondsToSelector:@selector(openMapsWithItems:launchOptions:)]) {
            // Use class
            CLLocationCoordinate2D destinationlocation;            
            
            destinationlocation.latitude = [streamInfoModel.loc_Latitude floatValue];
            destinationlocation.longitude = [streamInfoModel.loc_Longitude floatValue];

            
            MKPlacemark *destinationPlaceMark = [[MKPlacemark alloc]initWithCoordinate:destinationlocation addressDictionary:nil];
            
            MKMapItem *destinationItem = [[MKMapItem alloc]initWithPlacemark:destinationPlaceMark];
                    
            MKPlacemark *sourcePlaceMark = [[MKPlacemark alloc]initWithCoordinate:tabbarMainVC.userNewLocation.coordinate addressDictionary:nil];
            MKMapItem *sourceItem = [[MKMapItem alloc]initWithPlacemark:sourcePlaceMark];
            
            //if we added only one mapitem object to array then maps app takes it as the destination location and source will be user's current location.
            NSArray *mapItems = [[NSArray alloc]initWithObjects:destinationItem,sourceItem, nil];
            
            CLLocation *businessLocation = [[CLLocation alloc]initWithLatitude:[streamInfoModel.loc_Latitude floatValue] longitude:[streamInfoModel.loc_Longitude floatValue]];
            
            if ([appDelegate checkBusinessAtLocation:businessLocation withUserLocation:tabbarMainVC.userNewLocation withReviewRadius:500]) {
                [MKMapItem openMapsWithItems:mapItems launchOptions:[NSDictionary dictionaryWithObject:MKLaunchOptionsDirectionsModeWalking forKey:MKLaunchOptionsDirectionsModeKey]];
            } else {
                [MKMapItem openMapsWithItems:mapItems launchOptions:[NSDictionary dictionaryWithObject:MKLaunchOptionsDirectionsModeDriving forKey:MKLaunchOptionsDirectionsModeKey]];
            }
            
        } else if ([self isNotNull:streamInfoModel.loc_Latitude] && [self isNotNull:streamInfoModel.loc_Longitude] && tabbarMainVC.userNewLocation.coordinate.latitude != 0.0 && tabbarMainVC.userNewLocation.coordinate.longitude != 0.0) {
            
            NSString* urlStr = [NSString stringWithFormat: @"http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f", tabbarMainVC.userNewLocation.coordinate.latitude, tabbarMainVC.userNewLocation.coordinate.longitude, [streamInfoModel.loc_Latitude floatValue], [streamInfoModel.loc_Longitude floatValue]];
            [[UIApplication sharedApplication] openURL: [NSURL URLWithString:urlStr]];
        }
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)zoomMapView:(id)sender{
    
    @try {
        UIViewController *fullMapVC = [[UIViewController alloc]init];
//        NSLog(@"sElf frame:%f",self.view.frame.size.height);
        fullMapVC.view.frame = CGRectMake(5, 0, appDelegate.window.frame.size.width - 10, appDelegate.window.frame.size.height);
        appDelegate.mapView.frame = CGRectMake(10, 5, appDelegate.window.frame.size.width - 20, appDelegate.window.frame.size.height - 30);
        UIImage *image = [UIImage imageNamed:@"mapArrow"];
        appDelegate.mapView.annotationImage = image;
        [fullMapVC.view addSubview:appDelegate.mapView];
        mapFullVC = fullMapVC;
        
        UIButton *cancelFullMap_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancelFullMap_btn.backgroundColor = [UIColor clearColor];
        //cancelFullMapVC.frame = CGRectMake(self.mapView.frame.size.width - 17, self.mapView.frame.origin.y - 16, 29, 28);
        if (iPad) {
            cancelFullMap_btn.frame = CGRectMake(appDelegate.mapView.frame.size.width - 12, appDelegate.mapView.frame.origin.y-20, 40, 48);
        } else {
            cancelFullMap_btn.frame = CGRectMake(appDelegate.mapView.frame.size.width - 12, appDelegate.mapView.frame.origin.y - 8, 29, 28);
        }
        
        [cancelFullMap_btn setImage:[UIImage imageNamed:@"popupCloseBtn"] forState:UIControlStateNormal];
        [cancelFullMap_btn addTarget:self action:@selector(zoomOutMapView:) forControlEvents:UIControlEventTouchUpInside];
        [mapFullVC.view addSubview:cancelFullMap_btn];
        
        [self performSelector:@selector(animateTransition:) withObject:[NSNumber numberWithFloat: TIME_FOR_EXPANDING]];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)zoomOutMapView:(id)sender{
    
    @try {
        [self performSelector:@selector(animateTransition:) withObject:[NSNumber numberWithFloat: TIME_FOR_SHRINKING]];
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)animateTransition:(NSNumber *)duration {
    
    @try {
        //self.view.userInteractionEnabled=NO;
        [[appDelegate window] addSubview:mapFullVC.view];
        //[[appDelegate window] bringSubviewToFront:mapFullVC.view];
        //[appDelegate.window setRootViewController:mapFullVC];
        if ((mapFullVC.view.hidden == false) && ([duration floatValue] == TIME_FOR_EXPANDING)) {
        
            [self setLocationTabButtonsStatus:NO];  
            
            mapFullVC.view.frame = CGRectMake(0,22, self.view.frame.size.width - 10, appDelegate.window.frame.size.height - 44);
            mapFullVC.view.transform = CGAffineTransformMakeScale(SCALED_DOWN_AMOUNT, SCALED_DOWN_AMOUNT);
        }
        mapFullVC.view.hidden = false;
        if ([duration floatValue] == TIME_FOR_SHRINKING) {
            
            [self setLocationTabButtonsStatus:YES];
            
            [UIView beginAnimations:@"animationShrink" context:NULL];
            [UIView setAnimationDuration:[duration floatValue]];
            mapFullVC.view.transform = CGAffineTransformMakeScale(SCALED_DOWN_AMOUNT, SCALED_DOWN_AMOUNT);
        }
        else {
            [UIView beginAnimations:@"animationExpand" context:NULL];
            [UIView setAnimationDuration:[duration floatValue]];
            mapFullVC.view.transform = CGAffineTransformMakeScale(1, 1);
        }
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)animationDidStop:(NSString *)animationID finished:(BOOL)finished context:(void *)context {
    
    @try {
        self.view.userInteractionEnabled=YES;
        if ([animationID isEqualToString:@"animationExpand"]) {
            [[self navigationController] pushViewController:mapFullVC animated:NO];
        }
        else {
            mapFullVC.view.hidden = true;
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:1];
            UITableViewCell *cell = [detailsTableView cellForRowAtIndexPath:indexPath];
            CGFloat height = [self getHeightOfMap];
            if (iPad) {
                appDelegate.mapView.frame = CGRectMake(10, 10, 728 - 85, height-20);
            } else {
                appDelegate.mapView.frame = CGRectMake(5, 5, appDelegate.window.frame.size.width-70, height-10);
            }
            
            UIImage *image = [UIImage imageNamed:@"mapArrow"];
            appDelegate.mapView.annotationImage = image;
            [cell.contentView addSubview:appDelegate.mapView];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)setLocationTabButtonsStatus:(BOOL)enabled {
    TCSTART
    [tabbarMainVC.provider_Btn setEnabled:enabled];
    [tabbarMainVC.interact_Btn setEnabled:enabled];
    [tabbarMainVC.details_Btn setEnabled:enabled];
    [tabbarMainVC.favorite_Btn setEnabled:enabled];
    TCEND
}
-(UILabel *)createTitleLbl{
    
    @try {
        UILabel *titleLbl = [[UILabel alloc]init];
        titleLbl.numberOfLines = 0;
        titleLbl.tag = 10;
        titleLbl.textColor = [UIColor darkGrayColor];
        titleLbl.backgroundColor = [UIColor clearColor];
        titleLbl.font = [UIFont fontWithName:headerTitleFontName size:PROFILE_LEFTLABEL_FONT_SIZE];
        return titleLbl;
    }
    @catch (NSException *exception) {
         NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (UILabel *)createSummaryLbl {
    @try {
        UILabel *summaryLbl = [[UILabel alloc]init];
        summaryLbl.numberOfLines = 0;
        [summaryLbl sizeToFit];
        summaryLbl.lineBreakMode = NSLineBreakByWordWrapping;
        summaryLbl.textAlignment = NSTextAlignmentLeft;
        summaryLbl.tag = 11;
        if (iPad) {
            summaryLbl.textColor = [UIColor grayColor];
        } else {
            summaryLbl.textColor = [UIColor lightGrayColor];
        }
        
        summaryLbl.backgroundColor = [UIColor clearColor];
        summaryLbl.font = [UIFont fontWithName:headerTitleFontName size:InfoTitleFontSize];
        
        return summaryLbl;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
-(UIImageView *)createCellThumbIcon {
    
    @try {
        UIImageView *cellThumbIcon = [[UIImageView alloc]init];
        cellThumbIcon.tag = 12;
        return cellThumbIcon;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)reloadTable {
    TCSTART
    if ([self isNotNull:streamInfoModel]) {
        if (contactMArray.count > 0) {
            [contactMArray removeAllObjects];
        }
        if (detailsMArray.count > 0) {
            [detailsMArray removeAllObjects];
        }
        if ([self isNotNull:streamInfoModel.loc_Address]) {
            NSDictionary *tempDict = [NSDictionary dictionaryWithObjectsAndKeys:@"ADDRESS:",@"name",@"details_address",@"image",[NSString stringWithFormat:@"%@, %@, %@", streamInfoModel.loc_Address?:@"",streamInfoModel.located_City?:@"",streamInfoModel.loc_State?:@""],@"description", nil];
            [contactMArray addObject:tempDict];
        }
        
        if ([self isNotNull:streamInfoModel.PhoneNo]) {
            
            NSString *newPhoneString = [appDelegate formatPhoneNumber:streamInfoModel.PhoneNo];
            if ([self isNotNull:newPhoneString]) {
                NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:newPhoneString,@"description",@"PHONE:",@"name",@"details_phone",@"image", nil];
                [contactMArray addObject:tempDict];
            }    
        }
        if ([self isNotNull:streamInfoModel.loc_WebsiteUrl]) {
            NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:streamInfoModel.loc_WebsiteUrl,@"description",@"WEBSITE:",@"name",@"WebsiteLogo",@"image", nil];
            [contactMArray addObject:tempDict];
        }
        
        if ([self isNotNull:streamInfoModel.twitter_Url]) {
            NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:streamInfoModel.twitter_Url,@"description",@"TWITTER:",@"name",@"TwitterLogo",@"image", nil];
            [contactMArray addObject:tempDict];
        }
        
        if ([self isNotNull:streamInfoModel.facebook_Url]) {
            NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:streamInfoModel.facebook_Url,@"description",@"FACEBOOK:",@"name",@"FacebookLogo",@"image", nil];
            [contactMArray addObject:tempDict];
        }
    }
    
    
    //store the details info like hours & description.
    if ([self isNotNull:streamInfoModel.startDate]) {
        NSMutableString *hours = [[NSMutableString alloc]init];
        [hours appendString:[appDelegate convertDateToEventString:streamInfoModel.startDate]];
        if ([self isNotNull:hours]) {
            NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:@"DATE AND TIME:",@"name",@"details_clock",@"image",hours,@"description", nil];
            [detailsMArray addObject:tempDict];
        }
    }
    if ([self isNotNull:streamInfoModel.loc_Summary]) {
        NSString *description = nil;
        description = [NSString stringWithString:streamInfoModel.loc_Summary];
        if ([self isNotNull:description]){
            NSDictionary *tempDict = [[NSDictionary alloc]initWithObjectsAndKeys:@"DESCRIPTION:",@"name",@"details_description",@"image",description,@"description", nil];
            [detailsMArray addObject:tempDict];
        }
    }
    verticalContentOffset  = detailsTableView.contentOffset.y;
    [detailsTableView reloadData];
    [detailsTableView setContentOffset:CGPointMake(0, verticalContentOffset)];
    TCEND
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(BOOL)shouldAutorotate {
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}
@end
