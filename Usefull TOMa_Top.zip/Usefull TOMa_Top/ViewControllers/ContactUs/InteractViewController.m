//
//  InteractViewController.m
//  LocationInfo
//
//  Created by shiva on 12/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "InteractViewController.h"
#import "StreamService.h"
#import "ShowAlert.h"
#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "NSObject+PE.h"

@implementation InteractViewController

@synthesize cancel_Btn;
@synthesize submit_Btn;
@synthesize headerLabel;
@synthesize popover;
@synthesize chooseProvider_Btn;
@synthesize contactOKButton;
//Comments
@synthesize comment_TextView = comment_TextView_;
@synthesize commentChars_Lbl = commentChars_Lbl_;

@synthesize caller;
//@synthesize isCommunicationTypeSelected;

//@synthesize locationDataModal_;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andCaller:(id)caller_ andPhysiciansArray:(NSArray *)physiciansArray_ isFromMainView:(BOOL)isFromMainView_
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        caller = caller_;
        physiciansArray = [[NSMutableArray alloc] initWithArray:physiciansArray_];
        isFromMainView = isFromMainView_;
        chooseProviderClicked = FALSE;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

//=========================================START OF VIEW LIFECYCLE==========================================//
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        [physiciansArray insertObject:[appDelegate getDefaultPhysician] atIndex:0];
        
        //set background color
        UIImageView *image = [[UIImageView alloc]initWithFrame:appDelegate.window.bounds];
        image.image = [UIImage imageNamed:@"bg"];
        [self.view insertSubview:image atIndex:0];
        
        headerLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        headerLabel.textAlignment = NSTextAlignmentCenter;
        [headerLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-headerLabel.frame.size.width)/2, headerLabel.frame.origin.y, headerLabel.frame.size.width, headerLabel.frame.size.height)];
        image_Data_ = nil;
        // Do any additional setup after loading the view from its nib.
        comment_TextView_.delegate = self;
        comment_TextView_.textColor = [UIColor lightGrayColor];
        [comment_TextView_ setReturnKeyType:UIReturnKeyDone];
        
        photoCaptureButton.imageView.layer.cornerRadius = 5.0f;
        photoCaptureButton.imageView.layer.masksToBounds = YES;
        
        CGRect lockRect;
        CGRect privateLabelRect;
        
        //        if (iPad) {
        //            lockRect = CGRectMake(588, 10, 30, 30);
        //            privateLabelRect = CGRectMake(620, 10, 30, 30);
        //        } else {
        //            lockRect = CGRectMake(225, 2, 30, 27);
        //            privateLabelRect = CGRectMake(255, 10, 30, 30);
        //        }
        //
        
        if (iPad) {
            lockRect = CGRectMake(575, 12, 20, 25);
            privateLabelRect = CGRectMake(605, 12, 95, 25);
        } else {
            lockRect = CGRectMake(appDelegate.window.frame.size.width-87, 7, 14, 18);
            privateLabelRect = CGRectMake(appDelegate.window.frame.size.width-65, .6, 45, 30);
        }
        
        //        plugSwitch = [UICustomSwitch switchWithLeftText:@"" andRight:@""];
        //
        UIImageView *cardImageView = [[UIImageView alloc]init];
        UILabel *privateLabel = [[UILabel alloc]init];
        //        cardImageView.frame = CGRectMake(imageFullView.view.frame.origin.x + 5, toplineIamge.frame.origin.y + toplineIamge.frame.size.height, imageFullView.view.frame.size.width - 10, imageFullView.view.frame.size.height - (toplineIamge.frame.origin.y + toplineIamge.frame.size.height + 10));
        cardImageView.frame = lockRect;
        privateLabel.frame = privateLabelRect;
        privateLabel.text =@"Private";
        [privateLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:(iPad?18.0f:14.0f)]];
        
        privateLabel.textColor = [UIColor colorWithRed:(102/255.0) green:(99/255.0) blue:(97/255.0) alpha:1];
        //                privateLabel.textColor = [UIColor grayColor];
        privateLabel.backgroundColor = [UIColor clearColor];
        cardImageView.image = [UIImage imageNamed:@"privateLockIcon"];
        
        //        [imageFullView.view addSubview:cardImageView];
        
        //
        //        plugSwitch.frame = plugSwitchRect;
        
        //        [plugSwitch setThumbImage:[UIImage imageNamed:@"ToggleThumb"] forState:UIControlStateNormal];
        //        [plugSwitch setMinimumTrackImage:[[UIImage imageNamed:@"TogglePrivate"]resizableImageWithCapInsets:UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)] forState:UIControlStateNormal];
        //        [plugSwitch setMaximumTrackImage:[[UIImage imageNamed:@"TogglePublic"]resizableImageWithCapInsets:UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0)] forState:UIControlStateNormal];
        
        [remainingView addSubview:cardImageView];
        [remainingView addSubview:privateLabel];
        
        //      [remainingView addSubview:plugSwitch];
        
        //        plugSwitch.on = YES;
        //        plugSwitch.userInteractionEnabled = NO;
        confirmationView.frame=appDelegate.window.frame;
        confirmationView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        confirmationView.hidden = YES;
        confirmationViewTitleLabel.text = @"Private Message";
        hasDisplayedConfirmatnView = NO;
        if(isiPhone6) {
            [self setiPhone6Support];
        }
        [appDelegate setMaskTo:comment_TextView_ byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight withRadii:CGSizeMake(7.0, 7.0)];
        [appDelegate setMaskTo:remainingView byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(7.0, 7.0)];
        /** Physician
         */
        //        if (!iPad) {
        //            [myFeedBackMessageBtn setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:dateFontName size:dateFontSize], UITextAttributeFont,nil] forState:UIControlStateNormal];
        txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, myFeedBackMessageBtn.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
        txtLabel.textAlignment = NSTextAlignmentCenter;
        txtLabel.font = [UIFont fontWithName:titleFontName size:(iPad?22:13)];
        if (isCommunicationTypeSelected) {
            txtLabel.text = @"My feedback/message is for:";
            txtLabel.font = [UIFont fontWithName:titleFontName size:(iPad?22:13)];
        }else{
            txtLabel.text = @"I want to:";
            txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        }
        
        myFeedBackMessageBtn.customView = txtLabel;
        //        }
        
        physicianNameLabel.font = [UIFont fontWithName:descriptionTextFontName size:descriptionTextFontSize];
        NSLog(@"Width:%f",[[UIScreen mainScreen] bounds].size.width);
        [physiciansPickerView setFrame:CGRectMake(physiciansPickerView.frame.origin.x, physiciansPickerView.frame.origin.y,[[UIScreen mainScreen] bounds].size.width, physiciansPickerView.frame.size.height)];
        [toolBar setFrame:CGRectMake(toolBar.frame.origin.x, toolBar.frame.origin.y,[[UIScreen mainScreen] bounds].size.width, toolBar.frame.size.height)];
        int index = ceil(physiciansArray.count/2);
        if (index < physiciansArray.count) {
            [physiciansPickerView selectRow:index inComponent:0 animated:YES];
            selectedPhysician = [physiciansArray objectAtIndex:index];
        } else {
            [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
            selectedPhysician = [physiciansArray objectAtIndex:0];
        }
        
        [physiciansPickerView reloadAllComponents];
        
        physiciansPickerDisplayView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        
        /** Resposneview
         */
        responseView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        [appDelegate setMaskTo:resposneViewBgLabel byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight withRadii:CGSizeMake(7.0, 7.0)];
        responseView.hidden = YES;
        resposneTextLabel.font = [UIFont fontWithName:descriptionTextFontName size:surveyTitleFontSize];
        
        [self setTextToResponseTextLabelAndConfirmationViewAccordingToTheResponseTimeFrame];
        resposneTextLabel.textColor = [UIColor grayColor];
        
        if ([self isNotNull:appDelegate.userProfileDataModel.authToken]) {
            [appDelegate getBusinessInfoWithCaller:self andAuthTokenNeeded:YES];
            [appDelegate showActivityIndicatorInView:self.view];
            physiciansPickerDisplayView.hidden = YES;
        }
        
        requestAppointmentCheckState = 1;
        
        HELP_TEXT_REQ_APPOINTMENT = @"Please provide the dates and times that you are available for an appointment.";
        HELP_TEXT_REFILL_MY_MEDICATION = @"If you would like to order a prescription refill, please provide the name of the medication, and the pharmacy where you would like to have it filled. If the request is urgent, please call our office.";
        HELP_TEXT_PROVIDE_FEEDBACK = @"We care about your experience. Please provide your comments and suggestions.";
        HELP_TEXT_ASK_MY_PROVIDER_A_QSTN = @"Please call 911 if you have an emergency. This is not an emergency line of communication. All messages between you and your healthcare provider are private. We will respond within 3 business days. If your issue requires a faster response, please call our office directly.";
        HELP_TEXT_ASK_NURSE_ADVICE_LINE_QSTN = @"You may submit medical questions to our Nurse Hotline here";
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)setTextToResponseTextLabelAndConfirmationViewAccordingToTheResponseTimeFrame {
    TCSTART
    resposneTextLabel.text = [NSString stringWithFormat:@"Please remember to call 911 if you have an emergency. This is not an emergency line of communication. All messages are private between you and your healthcare provider. We will respond within %@.",[[NSUserDefaults standardUserDefaults] objectForKey:@"responseTimeFrame"]];
    confirmationViewDescLabel.text = [NSString stringWithFormat:@"If this is an emergency, please dial 911. If you would like to send a non-urgent message to your provider to ask for an appointment, medication refill or get advice, for example, please type your message here. We will respond within %@.",[[NSUserDefaults standardUserDefaults] objectForKey:@"responseTimeFrame"]];
    //        comment_TextView_.text = [NSString stringWithFormat:@"Leave a secure message with your Provider or leave us feedback about your experience.  We will respond within %@.",[[NSUserDefaults standardUserDefaults] objectForKey:@"responseTimeFrame"]];
    
    TCEND
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
}

#pragma mark iPhone6 and iphone6+ Support.

-(void)setiPhone6Support {
    [comment_TextView_ setFrame:CGRectMake(comment_TextView_.frame.origin.x, comment_TextView_.frame.origin.y, appDelegate.window.frame.size.width-10, comment_TextView_.frame.size.height)];
    
    [responseView setFrame:CGRectMake(responseView.frame.origin.x, responseView.frame.origin.y, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height)];
    [resposneViewBgLabel setFrame:CGRectMake(((appDelegate.window.frame.size.width-310)/2), resposneViewBgLabel.frame.origin.y, resposneViewBgLabel.frame.size.width, resposneViewBgLabel.frame.size.height)];
    [resposneTextLabel setFrame:CGRectMake(((appDelegate.window.frame.size.width-296)/2), resposneTextLabel.frame.origin.y, resposneTextLabel.frame.size.width, resposneTextLabel.frame.size.height)];
    [contactOKButton setFrame:CGRectMake((appDelegate.window.frame.size.width-142)/2, contactOKButton.frame.origin.y, contactOKButton.frame.size.width, contactOKButton.frame.size.height)];
    
    [remainingView setFrame:CGRectMake(remainingView.frame.origin.x, remainingView.frame.origin.y, appDelegate.window.frame.size.width-10, remainingView.frame.size.height)];
    
    [commentChars_Lbl_ setFrame:CGRectMake((remainingView.frame.size.width-commentChars_Lbl_.frame.size.width)/2, commentChars_Lbl_.frame.origin.y, commentChars_Lbl_.frame.size.width, commentChars_Lbl_.frame.size.height)];
    [confirmationViewImageview setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2, confirmationViewImageview.frame.origin.y, confirmationViewImageview.frame.size.width, confirmationViewImageview.frame.size.height)];
    [confirmationViewDescLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2+confirmationViewDescLabel.frame.origin.x, confirmationViewDescLabel.frame.origin.y, confirmationViewDescLabel.frame.size.width, confirmationViewDescLabel.frame.size.height)];
    if(isiPhone6PLUS) {
    [confirmOKButton setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2+confirmOKButton.frame.origin.x, confirmOKButton.frame.origin.y-7, confirmOKButton.frame.size.width, confirmOKButton.frame.size.height)];
    [confirmationViewTitleLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2+confirmationViewTitleLabel.frame.origin.x, confirmationViewTitleLabel.frame.origin.y+6, confirmationViewTitleLabel.frame.size.width, confirmationViewTitleLabel.frame.size.height)];
    }
    else {
    [confirmOKButton setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2+confirmOKButton.frame.origin.x, confirmOKButton.frame.origin.y, confirmOKButton.frame.size.width, confirmOKButton.frame.size.height)];
    [confirmationViewTitleLabel setFrame:CGRectMake((appDelegate.window.frame.size.width-320)/2+confirmationViewTitleLabel.frame.origin.x, confirmationViewTitleLabel.frame.origin.y, confirmationViewTitleLabel.frame.size.width, confirmationViewTitleLabel.frame.size.height)];
    }
}


#pragma mark BusinessInfo Service delegate methods
- (void)didReceivedBusinessInfo:(CPBusinessInfo *) businessInfo
{
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    if ([self isNotNull:businessInfo.physiciansArray] && businessInfo.physiciansArray.count > 0) {
        [appDelegate savePhysicians:businessInfo.physiciansArray];
        if (isFromMainView) {
            [physiciansArray removeAllObjects];
            [physiciansArray addObject:[appDelegate getDefaultPhysician]];
            [physiciansArray addObjectsFromArray:[appDelegate getPhysicians]];
        }
    }
    
    if ([self isNotNull:businessInfo.responseTimeFrame]) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.responseTimeFrame forKey:@"responseTimeFrame"];
    }
    
    if ([self isNotNull:businessInfo.insuranceProviders] && businessInfo.insuranceProviders.count > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.insuranceProviders forKey:@"insuranceProviders"];
    }
    NSLog(@"COMMUNICATION TYPES: %@",businessInfo.communicationTypes);
    if ([self isNotNull:businessInfo.communicationTypes] && businessInfo.communicationTypes.count > 0) {
        //[[NSUserDefaults standardUserDefaults] setObject:businessInfo.communicationTypes forKey:@"communicationTypes"];
        communicationTypesArray = businessInfo.communicationTypes;
    }
    if ([self isNotNull:businessInfo.appointmentTypes] && businessInfo.appointmentTypes.count > 0) {
        appointmentTypesArray = businessInfo.appointmentTypes;
    }
    if ([self isNotNull:businessInfo.reasonsForVisit] && businessInfo.reasonsForVisit.count > 0) {
        reasonsForVisitArray = businessInfo.reasonsForVisit;
    }
    
    [self setTextToResponseTextLabelAndConfirmationViewAccordingToTheResponseTimeFrame];
    
    if ([self isNotNull:communicationTypesArray]&&[communicationTypesArray count]>0) {
        selectedCommunicationType = [communicationTypesArray objectAtIndex:0];
        comment_TextView_.text = [selectedCommunicationType objectForKey:@"hint"];
    }
    
    physiciansPickerDisplayView.hidden = NO;
    [physiciansPickerView reloadAllComponents];
    TCEND
}

- (void)didFailToReceiveBusinessInfoWithError:(NSError*) error {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    physiciansPickerDisplayView.hidden = NO;
    [physiciansPickerView reloadAllComponents];
    TCEND
}

- (IBAction)chooseProviders:(id)sender {
    chooseProviderClicked = TRUE;
    previousSelectedPhysician = selectedPhysician;
    
    [comment_TextView_ resignFirstResponder];
    physiciansPickerDisplayView.hidden = NO;
    [self.view bringSubviewToFront:physiciansPickerDisplayView];
    [physiciansPickerView reloadAllComponents];
}

#pragma mark pickerView Datasource and delgate methods
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (isCommunicationTypeSelected) {
        if([self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0)
        {
            if(requestAppointmentCheckState == 1){
                return [appointmentTypesArray count];
            }
            else if(requestAppointmentCheckState == 2){
                return [reasonsForVisitArray count];
            }
            else {
                [physiciansArray count];
            }
        }
        return [physiciansArray count];
    }else{
        return [communicationTypesArray count];
    }
    
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    //    CGSize nameSize;
    return 44;
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    TCSTART
    UIView *myView;
    
    UILabel *customLabel;// = [[UILabel alloc]init];
    CGSize nameSize;
    NSString *nameVal;
    
    if (isCommunicationTypeSelected) {
        if([self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0)
        {
            if(requestAppointmentCheckState == 1){
                nameVal = [[appointmentTypesArray objectAtIndex:row] objectForKey:@"name"];
            }
            else if(requestAppointmentCheckState == 2){
                nameVal = [[reasonsForVisitArray objectAtIndex:row] objectForKey:@"name"];
            }
            else {
                CPPhysician *physician = [physiciansArray objectAtIndex:row];
                nameVal = physician.physicianName;
            }
        }
        else
        {
            CPPhysician *physician = [physiciansArray objectAtIndex:row];
            nameVal = physician.physicianName;
        }
        
        
    }else{
        NSLog(@"CommunicatonType: %@",[communicationTypesArray objectAtIndex:row]);
        
        NSDictionary *communicationType = [communicationTypesArray objectAtIndex:row];
        nameVal=[communicationType objectForKey:@"name"];
        comment_TextView_.text = [selectedCommunicationType objectForKey:@"hint"];
    }
    if ([self isNotNull:nameVal]) {
        nameSize = [nameVal sizeWithFont:[UIFont fontWithName:titleFontName size:titleFontSize] constrainedToSize:CGSizeMake(CELL_CONTENT_WIDTH - (iPad?104:66), 2000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    }
    NSLog(@"name: %@",nameVal);
    CGFloat heightOfTheRow;
    heightOfTheRow = 65;
    if (nameSize.height > heightOfTheRow) {
        heightOfTheRow = nameSize.height ;
    }
    
    CGFloat movableHeight;
    if (iPad) {
        movableHeight = (iPad?0:20);
    }else{
        movableHeight = (CURRENT_DEVICE_VERSION>=7.0?0:20);
    }
    NSLog(@"height: %f",heightOfTheRow);
    
    customLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.origin.x ,self.view.frame.origin.y-movableHeight, CELL_CONTENT_WIDTH-20 ,heightOfTheRow)];
    myView =[[UIView alloc]initWithFrame:CGRectMake(self.view.frame.origin.x+5 ,self.view.frame.origin.y-20, CELL_CONTENT_WIDTH-5 ,heightOfTheRow)];
    
    customLabel.numberOfLines = 0;
    customLabel.backgroundColor=[UIColor clearColor];
    customLabel.textColor =[UIColor blackColor];
    [myView addSubview:customLabel];
    customLabel.text = nameVal;
    customLabel.textAlignment = NSTextAlignmentCenter;
    //    customLabel.textAlignment =NSTextAlignmentLeft;
    return myView;
    TCEND
}

//-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
//{
//    TCSTART
//
//    if (isCommunicationTypeSelected) {
//        CPPhysician *physician = [physiciansArray objectAtIndex:row];
//        return physician.physicianName;
//
//    }else{
//        NSLog(@"CommunicatonType: %@",[communicationTypesArray objectAtIndex:row]);
//
////        CPCcommunicationType *communicationType = [communicationTypesArray objectAtIndex:row];
//                NSDictionary *communicationType = [communicationTypesArray objectAtIndex:row];
//        return [communicationType objectForKey:@"name"];
//
//    }
//    TCEND
//}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    TCSTART
    if (isCommunicationTypeSelected) {
        if([self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0)
        {
            if(requestAppointmentCheckState == 1){
                appointmentType = [appointmentTypesArray objectAtIndex:row];
            }
            else if(requestAppointmentCheckState == 2) {
                reasonsType = [reasonsForVisitArray objectAtIndex:row];
            }
            else {
                selectedPhysician = [physiciansArray objectAtIndex:row];
                physicianNameLabel.text = selectedPhysician.physicianName;
            }
        }
        else{
            selectedPhysician = [physiciansArray objectAtIndex:row];
            physicianNameLabel.text = selectedPhysician.physicianName;
        }
    }else{
        selectedCommunicationType = [communicationTypesArray objectAtIndex:row];
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:selectedCommunicationType];
        [dict setObject:[NSNumber numberWithInt:row] forKey:@"row"];
        selectedCommunicationType = [dict mutableCopy];
        comment_TextView_.text = [selectedCommunicationType objectForKey:@"hint"];
        NSLog(@"comm.type: %@, \nhint: %@",selectedCommunicationType,[selectedCommunicationType objectForKey:@"hint"]);
    }
    
    TCEND
}
-(BOOL)customCompareStringWith:(NSString*)aString {
    NSString *mainString=@"requestanappointment";
    aString=[aString stringByReplacingOccurrencesOfString:@" " withString:@""];
    if([[aString lowercaseString] isEqualToString:mainString]){
        return YES;
    }
    else
        return  NO;
}

#pragma mark toolbar done clicked
- (IBAction)toolbarDoneSelected:(id)sender {
    NSLog(@"Select comm.type: %@",selectedCommunicationType);
    //    selectedPhysician.physicianId
    if (isCommunicationTypeSelected) {
        if([self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0)
        {
            if([txtLabel.text isEqualToString:@"Type of Appointment:"]) {requestAppointmentCheckState=2;}
            else if([txtLabel.text isEqualToString:@"Reason for Visit:"]) {requestAppointmentCheckState=0;}
            else if([txtLabel.text isEqualToString:@"My feedback/message is for:"]) {requestAppointmentCheckState=-1;}
            if(requestAppointmentCheckState == 1){
                txtLabel.text = @"Type of Appointment:";
                [physiciansPickerView reloadAllComponents];
            }
            else if(requestAppointmentCheckState == 2){
                txtLabel.text = @"Reason for Visit:";
                [physiciansPickerView reloadAllComponents];
                int index = ceil(reasonsForVisitArray.count/2);
                if (index < reasonsForVisitArray.count) {
                    [physiciansPickerView selectRow:index inComponent:0 animated:YES];
                    reasonsType = [reasonsForVisitArray objectAtIndex:index];
                } else {
                    [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
                    reasonsType = [reasonsForVisitArray objectAtIndex:0];
                }
            }
            else if(requestAppointmentCheckState == 0) {
                //TODO
                int index = ceil(physiciansArray.count/2);
                if (index < physiciansArray.count) {
                    [physiciansPickerView selectRow:index inComponent:0 animated:YES];
                    selectedPhysician = [physiciansArray objectAtIndex:index];
                } else {
                    [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
                    selectedPhysician = [physiciansArray objectAtIndex:0];
                }
                txtLabel.text = @"My feedback/message is for:";
                [physiciansPickerView reloadAllComponents];
            }
            else {
                txtLabel.text = @"My feedback/message is for:";
                physicianNameLabel.text = selectedPhysician.physicianName;
                
                if (!hasDisplayedConfirmatnView) {
                    hasDisplayedConfirmatnView = YES;
                    confirmationView.hidden = NO;
                }
                physiciansPickerDisplayView.hidden = YES;
            }
            txtLabel.font = [UIFont fontWithName:titleFontName size:(iPad?22:13)];
        }
        else {
            physicianNameLabel.text = selectedPhysician.physicianName;
            
            if (!hasDisplayedConfirmatnView) {
                hasDisplayedConfirmatnView = YES;
                confirmationView.hidden = NO;
            }
            physiciansPickerDisplayView.hidden = YES;
        }
    }else{
        
        if ([self isNotNull:selectedCommunicationType]) {
            if([[selectedCommunicationType objectForKey:@"relevant_to_provider"] intValue] ==1){
                //TODO
                physiciansPickerDisplayView.hidden = NO;
                isCommunicationTypeSelected = YES;
                if (isCommunicationTypeSelected) {
                    if(requestAppointmentCheckState == 1 && [self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0){
                        txtLabel.text = @"Type of Appointment:";
                        int index = ceil(appointmentTypesArray.count/2);
                        if (index < appointmentTypesArray.count) {
                            [physiciansPickerView selectRow:index inComponent:0 animated:YES];
                            appointmentType = [appointmentTypesArray objectAtIndex:index];
                        } else {
                            [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
                            appointmentType = [appointmentTypesArray objectAtIndex:0];
                        }
                    }
                    else if(requestAppointmentCheckState == 2 && [self customCompareStringWith:[selectedCommunicationType objectForKey:@"name"]] && reasonsForVisitArray.count > 0 && appointmentTypesArray.count > 0){
                        txtLabel.text = @"Reason for Visit:";
                        
                    }
                    else {
                        //TODO
                        int index = ceil(physiciansArray.count/2);
                        if (index < physiciansArray.count) {
                            [physiciansPickerView selectRow:index inComponent:0 animated:YES];
                            selectedPhysician = [physiciansArray objectAtIndex:index];
                        } else {
                            [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
                            selectedPhysician = [physiciansArray objectAtIndex:0];
                        }
                        txtLabel.text = @"My feedback/message is for:";
                    }
                    txtLabel.font = [UIFont fontWithName:titleFontName size:(iPad?22:13)];
                }else{
                    txtLabel.text = @"I want to:";
                    txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
                }
                physiciansPickerDisplayView.hidden = NO;
                
                [physiciansPickerView reloadAllComponents];
            }else{
                selectedPhysician.physicianId = @"-1";
                physiciansPickerDisplayView.hidden = YES;
                confirmationView.hidden = NO;
                chooseProvider_Btn.enabled = NO;
                isCommunicationTypeSelected = YES;
                if(selectedCommunicationType && [selectedCommunicationType objectForKey:@"name"]){
                    physicianNameLabel.text=[selectedCommunicationType objectForKey:@"name"];
                }
                else
                    physicianNameLabel.text = @"Nurse Advice Line";
            }
            comment_TextView_.text = [selectedCommunicationType objectForKey:@"hint"];
        }else{
            selectedCommunicationType = [communicationTypesArray objectAtIndex:0];
            comment_TextView_.text = [selectedCommunicationType objectForKey:@"hint"];
            //            physiciansPickerDisplayView.hidden = YES;
            //            confirmationView.hidden = NO;
            isCommunicationTypeSelected = YES;
            txtLabel.text = @"My feedback/message is for:";
            txtLabel.font = [UIFont fontWithName:titleFontName size:(iPad?22:13)];
            physiciansPickerDisplayView.hidden = NO;
            [physiciansPickerView reloadAllComponents];
        }
    }
}

- (IBAction)confirmationViewOKBtnClicked:(id)sender {
    TCSTART
    confirmationView.hidden = YES;
    TCEND
}

#pragma mark resposneViewRelated
- (IBAction)responseViewOkBtnClicked:(id)sender {
    TCSTART
    [self performSelector:@selector(sendPostPrivateMessageRequest:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.5];
    TCEND
}

- (void)sendPostPrivateMessageRequest:(NSNumber *)requestedResponse {
    TCSTART
    responseView.hidden = YES;
    [rateReviewDictionary setObject:requestedResponse forKey:@"requestedResponse"];
    NSLog(@"SelectedPhysician:%@ andId:%@ selected communicationtype: %@, requestedResponse: %@",selectedPhysician,selectedPhysician.physicianId,selectedCommunicationType,requestedResponse);
    
    [appDelegate privateMessageRequest:rateReviewDictionary andPhysicianId:selectedPhysician.physicianId andFromViewController:self];
    [comment_TextView_ resignFirstResponder];
    TCEND
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
//=========================================END OF VIEW LIFECYCLE===============================================//

#pragma mark Comment ********************************
//===============================START OF TEXTVIEW DELEGATE FOR COMMENT/REVIEW=================================//
#pragma mark - textView Delegate

- (BOOL) textViewShouldBeginEditing:(UITextView *)textView {
    
    return YES;
}

-(void)textViewDidBeginEditing:(UITextView *)textView {
    @try {
        
        if (textView.textColor == [UIColor lightGrayColor]) {
            textView.text = @"";
            textView.textColor = [UIColor blackColor];
            //            [textView becomeFirstResponder];
        }
        //        [self touchesBegan:nil withEvent:nil];
        int len = 140 - textView.text.length;
        commentChars_Lbl_.text= [NSString stringWithFormat:@"%d | %d remaining", textView.text.length,len];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)textViewDidChange:(UITextView *) textView  {
    @try {
        
        if (textView.textColor == [UIColor blackColor]) {
            
            int len = 140 - textView.text.length;
            commentChars_Lbl_.text= [NSString stringWithFormat:@"%d | %d remaining", textView.text.length,len];
        }
        
        if(textView.text.length == 0 && textView.textColor == [UIColor blackColor]) {
            textView.textColor = [UIColor lightGrayColor];
            [self setTextToResponseTextLabelAndConfirmationViewAccordingToTheResponseTimeFrame];
            [textView setSelectedRange:NSMakeRange(0, 0)];
            //            [textView resignFirstResponder];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    @try {
        if ([text isEqualToString:@"\n"]) {
            NSLog(@"Keyboard dismiss");
            [textView resignFirstResponder];
            return NO;
        }
        // Don't allow input beyond the char limit, other then backspace and cut
        if (textView.textColor == [UIColor lightGrayColor]) {
            textView.text = @"";
            textView.textColor = [UIColor blackColor];
        }
        int len = 140 - textView.text.length;
        if (len <= 0 && ![text isEqualToString:@""]) {
            return NO;
        }
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if(textView.text.length == 0 && textView.textColor == [UIColor blackColor]) {
        textView.textColor = [UIColor lightGrayColor];
        [self setTextToResponseTextLabelAndConfirmationViewAccordingToTheResponseTimeFrame];
        [textView setSelectedRange:NSMakeRange(0, 0)];
        //            [textView resignFirstResponder];
    }
}
//=========================================END OF TEXTVIEW DELEGATE============================================//

#pragma mark - Btn Action methods.

-(IBAction)submitRateNReview:(id)sender {
    @try {
        UIButton *tempBtn = (UIButton *)sender;
        rateReviewDictionary = [[NSMutableDictionary alloc]init];
        //Showing all specials
        
        if ([tempBtn isKindOfClass:[UIButton class]] && comment_TextView_.text.length > 0 && comment_TextView_.textColor == [UIColor blackColor]) {
            
            if ([self isNotNull:comment_TextView_] && comment_TextView_.text.length > 0) {
                comment_TextView_.text = [appDelegate removingLastSpecialCharecter:comment_TextView_.text];
            }
            if ([self isNotNull:comment_TextView_] && comment_TextView_.text.length > 0) {
                [rateReviewDictionary setObject:comment_TextView_.text forKey:@"description"];
            }
            //imageEncodedStr = nil;
            if ([self isNotNull:selectedCommunicationType]) {
                
                [rateReviewDictionary setObject:                    [selectedCommunicationType objectForKey:@"id"] forKey:@"communication_type_id"];
            }else{
                [rateReviewDictionary setObject:@"-1" forKey:@"communication_type_id"];
            }
            if ([self isNotNull:appointmentType]) {
                [rateReviewDictionary setObject:[appointmentType objectForKey:@"id"] forKey:@"appointment_type_id"];
            }
            if ([self isNotNull:reasonsType]) {
                [rateReviewDictionary setObject:[reasonsType objectForKey:@"id"] forKey:@"reason_type_id"];
            }
            
            if([self isNotNull:image_Data_]) {
                [rateReviewDictionary setObject:image_Data_ forKey:@"photo_data"];
            }
            
            responseView.hidden = NO;
            [self.view bringSubviewToFront:responseView];
            
        } else {
            [appDelegate showErrorMsg:@"Please give private message"];
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)clearScreen {
    if ([self isNotNull:comment_TextView_]) {
        comment_TextView_.text = @"";
        //comment_TextView_ = nil;
    }
    
    if (photoPopUp_View) {
        [photoPopUp_View removeFromSuperview];
        photoPopUp_View = nil;
    }
    
    if (preview_imgView) {
        [preview_imgView removeFromSuperview];
        preview_imgView = nil;
    }
    
    if (captured_Image_) {
        captured_Image_ = nil;
    }
    if (image_Data_) {
        image_Data_ = nil;
    }
    
}


-(IBAction)removeFromParentViewController:(id)sender {
    
    @try {
        UIButton *tempBtn = (UIButton *)sender;
        //Showing all specials
        if ([tempBtn isKindOfClass:[UIButton class]]) {
            
            [self clearScreen];
            
            //[self dismissModalViewControllerAnimated:YES];
            [self dismissViewControllerAnimated:YES completion:^{
                //code
            }];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

#pragma mark -
#pragma mark uploading picture *****************************
//=========================================START OF PICTURE RELATED METHODS==========================================//

-(IBAction)openCameraToTakePictureOrVideo:(id)sender {
    //UIButton *tempBtn = (UIButton *)sender;
    @try {
        
        [comment_TextView_ resignFirstResponder]; //dismiss the keyboard if present.
        if ([self isNull:captured_Image_] &&
            [self isNull:image_Data_] && [self isNull:photoPopUp_View]) {
            photoPopUp_View = [[UIView alloc]init];
            //            if (!photoPopUp_View) {
            //                photoPopUp_View = [[UIView alloc]init];
            //            } else if (photoPopUp_View) {
            //                for (UIView *subView in [photoPopUp_View subviews]) {
            //                    [subView removeFromSuperview];
            //                }
            //            }
            photoPopUp_View.backgroundColor = [UIColor clearColor];
            [self.view addSubview:photoPopUp_View];
            if (iPad) {
                photoPopUp_View.frame = CGRectMake(remainingView.frame.origin.x, remainingView.frame.origin.y + remainingView.frame.size.height+5, 427, 208);
            } else {
                photoPopUp_View.frame = CGRectMake(0, remainingView.frame.origin.y + remainingView.frame.size.height, appDelegate.window.frame.size.width, 150);
            }
            
            UIImageView *photoOption_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"plug_photoOptions"]];
            photoOption_ImgView.frame = CGRectMake(0, 0, photoPopUp_View.frame.size.width, photoPopUp_View.frame.size.height);
            [photoPopUp_View addSubview:photoOption_ImgView];
            
            UIButton *takePhotoOrVideo_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            takePhotoOrVideo_btn.frame = CGRectMake(18, 28, 390, 55);
            [photoPopUp_View addSubview:takePhotoOrVideo_btn];
            [takePhotoOrVideo_btn setBackgroundImage:[UIImage imageNamed:@"takephoto"] forState:UIControlStateNormal];
            takePhotoOrVideo_btn.backgroundColor = [UIColor clearColor];
            [takePhotoOrVideo_btn addTarget:self action:@selector(capturePhotoOrVideo:) forControlEvents:UIControlEventTouchUpInside];
            [photoPopUp_View bringSubviewToFront:takePhotoOrVideo_btn];
            
            UIButton *chooseFrmLibrary_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            chooseFrmLibrary_btn.frame = CGRectMake(18, 134, 390, 55);
            [photoPopUp_View addSubview:chooseFrmLibrary_btn];
            [chooseFrmLibrary_btn setBackgroundImage:[UIImage imageNamed:@"pickfromlibrary"] forState:UIControlStateNormal];
            chooseFrmLibrary_btn.backgroundColor = [UIColor clearColor];
            [chooseFrmLibrary_btn addTarget:self action:@selector(chooseFromLibrary:) forControlEvents:UIControlEventTouchUpInside];
            if (!iPad) {
                takePhotoOrVideo_btn.frame = CGRectMake((appDelegate.window.frame.size.width-270-4)/2, 25, 270, 38);
                chooseFrmLibrary_btn.frame = CGRectMake((appDelegate.window.frame.size.width-270-4)/2, takePhotoOrVideo_btn.frame.origin.y + takePhotoOrVideo_btn.frame.size.height + 30, 270, 38);
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)capturePhotoOrVideo:(id)sender {
    [comment_TextView_ resignFirstResponder]; //dismiss the keyboard if present.
    [self openCamera];
}

- (void)chooseFromLibrary:(id)sender {
    
    @try {
        [comment_TextView_ resignFirstResponder]; //dismiss the keyboard if present.
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            isImgSourceTypeCamera = NO;
            UIImagePickerController* imagePickerController = [[UIImagePickerController alloc] init];
            imagePickerController.delegate = self;
            imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            if (!iPad) {
                //[self presentModalViewController:imagePickerController animated:YES];
                [self presentViewController:imagePickerController animated:YES completion:^{
                    //code
                }];
            } else {
                if ([self isNull:self.popover]) {
                    self.popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
                } else {
                    self.popover.contentViewController = imagePickerController;
                }
                self.popover.delegate = self;
                [self.popover presentPopoverFromRect:CGRectMake(photoPopUp_View.frame.origin.x + 30, photoPopUp_View.frame.origin.y, 1, 1) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
            }
            
        } else{
            UIAlertView *camerAlert = [[UIAlertView alloc]initWithTitle:@"Message" message:@"Your device doesn't support camera or it is damaged" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil , nil];
            [camerAlert show];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (CURRENT_DEVICE_VERSION < 7.0f ) {
        viewController.contentSizeForViewInPopover = CGSizeMake(748, 600);
    } else {
        viewController.preferredContentSize = CGSizeMake(748, 600);
    }
    
}

#pragma mark popovercontroller delegate methods
- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    return YES;
}

- (void)useCurrentPictureOrVideo:(id)sender {
    
    @try {
        [addConfirmationView removeFromSuperview];
        
        for (UIView *subView in [photoPopUp_View subviews]) {
            [subView removeFromSuperview];
        }
        if (iPad) {
            photoPopUp_View.frame = CGRectMake(photoPopUp_View.frame.origin.x, photoPopUp_View.frame.origin.y, 688, 620);
        } else {
            photoPopUp_View.frame = CGRectMake(photoPopUp_View.frame.origin.x, photoPopUp_View.frame.origin.y, photoPopUp_View.frame.size.width, 235);
        }
        
        UIImageView *photoOption_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"showPreviewBG"]];
        photoOption_ImgView.frame = CGRectMake(0, 0, photoPopUp_View.frame.size.width, photoPopUp_View.frame.size.height);
        [photoPopUp_View addSubview:photoOption_ImgView];
        
        UIImage *croppedImage;
        if (iPad) {
            croppedImage = [appDelegate getImageByCroppingImage:captured_Image_ toRect:CGRectMake(0, 0, 600, 500)];
            preview_imgView = [[UIImageView alloc]initWithImage:croppedImage];
            preview_imgView.frame = CGRectMake(44, 150, 600, 480);
            preview_imgView.center = photoOption_ImgView.center;
        } else {
            croppedImage = [appDelegate getImageByCroppingImage:captured_Image_ toRect:CGRectMake(0, 0, 400, 400)];
            preview_imgView = [[UIImageView alloc]initWithImage:croppedImage];
            preview_imgView.frame = CGRectMake(55, 30, 200, 200);
        }
        
        
        [photoPopUp_View addSubview:preview_imgView];
        
        UIButton *cancelCaptureImg_Btn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancelCaptureImg_Btn.frame = CGRectMake((preview_imgView.frame.origin.x + preview_imgView.frame.size.width) - 12,preview_imgView.frame.origin.y -12, 29, 28);
        [photoPopUp_View addSubview:cancelCaptureImg_Btn];
        cancelCaptureImg_Btn.backgroundColor = [UIColor clearColor];
        [cancelCaptureImg_Btn setBackgroundImage:[UIImage imageNamed:@"popupCloseBtn"] forState:UIControlStateNormal];
        [cancelCaptureImg_Btn addTarget:self action:@selector(removeCapturedPhotoOrVideo:) forControlEvents:UIControlEventTouchUpInside];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(void)tryAgain:(id)sender {
    
    @try {
        if(isImgSourceTypeCamera)
            [self openCamera];
        else
            [self chooseFromLibrary:nil];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)cancelCapturedPictureOrVideo:(id)sender {
    
    @try {
        [addConfirmationView removeFromSuperview];
        if (captured_Image_) {
            captured_Image_ = nil;
        }
        if (image_Data_) {
            image_Data_ = nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

-(void)removeCapturedPhotoOrVideo:(id)sender {
    
    @try {
        [photoPopUp_View removeFromSuperview];
        photoPopUp_View = nil;
        
        [preview_imgView removeFromSuperview];
        preview_imgView = nil;
        if (captured_Image_) {
            captured_Image_ = nil;
        }
        if (image_Data_) {
            image_Data_ = nil;
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}

- (void)openCamera {
    
    @try {
        //Check whether camera is available or not
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            isImgSourceTypeCamera = YES;
            UIImagePickerController *picker=[[UIImagePickerController alloc]init];
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            
            picker.delegate = self;
            
            //[self presentModalViewController:picker animated:YES];
            [self presentViewController:picker animated:YES completion:^{
                //code
            }];
        }
        else{
            UIAlertView *camerAlert = [[UIAlertView alloc]initWithTitle:@"Message" message:@"Your device doesn't support camera or it is damaged" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil , nil];
            [camerAlert show];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
        
    }
}
#pragma mark -
#pragma mark UIImagePickerController Delegate
//camera delegate method called when you click on use photo button in camera view.
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        if (!addConfirmationView) {
            addConfirmationView = [[UIView alloc]initWithFrame:appDelegate.window.bounds];
        }
        
        addConfirmationView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
        [self.view addSubview:addConfirmationView];
        
        UIImageView *addConfirmationImgBGView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg"]];
        addConfirmationImgBGView.frame = addConfirmationView.frame;
        addConfirmationImgBGView.center = CGPointMake(addConfirmationView.frame.size.width/2, addConfirmationView.frame.size.height/2);
        [addConfirmationView addSubview:addConfirmationImgBGView];
        
        UIImageView *previewImagView = [[UIImageView alloc] init];
        previewImagView.frame = CGRectMake(34, 32, 700, 700);
        previewImagView.layer.cornerRadius = 5.0f;
        previewImagView.layer.masksToBounds = YES;
        previewImagView.backgroundColor = [UIColor clearColor];
        [addConfirmationView addSubview:previewImagView];
        
        UIButton *use_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        use_btn.frame = CGRectMake(184, 757, 400, 55);
        use_btn.backgroundColor = [UIColor clearColor];
        [use_btn addTarget:self action:@selector(useCurrentPictureOrVideo:) forControlEvents:UIControlEventTouchUpInside];
        [addConfirmationView addSubview:use_btn];
        
        UIButton *tryAgain_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        tryAgain_btn.frame = CGRectMake(184, 840, 400, 55);
        tryAgain_btn.backgroundColor = [UIColor clearColor];
        [tryAgain_btn addTarget:self action:@selector(tryAgain:) forControlEvents:UIControlEventTouchUpInside];
        [tryAgain_btn setImage:[UIImage imageNamed:@"tryagain"] forState:UIControlStateNormal];
        [addConfirmationView addSubview:tryAgain_btn];
        
        UIButton *cancel_btn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancel_btn.frame = CGRectMake(184, 919, 400, 55);
        cancel_btn.layer.cornerRadius = 5.0f;
        cancel_btn.layer.masksToBounds = YES;
        cancel_btn.backgroundColor = [UIColor clearColor];
        [cancel_btn addTarget:self action:@selector(cancelCapturedPictureOrVideo:) forControlEvents:UIControlEventTouchUpInside];
        [cancel_btn setImage:[UIImage imageNamed:@"cancelcapturedimage"] forState:UIControlStateNormal];
        
        if (!iPad) {
            previewImagView.frame = CGRectMake(10, 7, 300, 300);
            use_btn.frame = CGRectMake(20, 319, 280, 36);
            tryAgain_btn.frame = CGRectMake(20, 365, 280, 36);
            cancel_btn.frame = CGRectMake(20, 411, 280, 36);
        }
        [addConfirmationView addSubview:cancel_btn];
        
        
        NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
        if ([mediaType isEqualToString:@"public.image"]){
            
            CGSize newimageSize = CGSizeMake(0, 0);
            UIImage *rawImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
            CGSize imgsize = rawImage.size;
            //            NSLog(@"photo size: width %f, height %f",imgsize.width,imgsize.height);
            CGFloat imageCompressionRatio = 0.0f;
            if (imgsize.width >= imgsize.height) {
                imageCompressionRatio = 1024/imgsize.width;
                
            } else {
                imageCompressionRatio = 1024/imgsize.height;
            }
            newimageSize.width = (imgsize.width * imageCompressionRatio);
            newimageSize.height = (imgsize.height * imageCompressionRatio);
            captured_Image_ = [self imageWithImage:rawImage scaledToSize:newimageSize];
            
            [use_btn setImage:[UIImage imageNamed:@"UserThisPhoto"] forState:UIControlStateNormal];
            previewImagView.tag = 1; //set tag to 1 if captured is image.
            image_Data_= UIImagePNGRepresentation(captured_Image_);
        }
        else if ([mediaType isEqualToString:@"public.movie"]){
            
        }
        UIImage *croppedImage = nil;
        if (captured_Image_) {
            if (captured_Image_.size.width >= 600 && captured_Image_.size.height >= 600) {
                croppedImage = [appDelegate getImageByCroppingImage:captured_Image_ toRect:CGRectMake(0, 0, 600, 600)];
            } else if(captured_Image_.size.width <= 300 && captured_Image_.size.height <= 300 ){
                croppedImage = captured_Image_;
            } else {
                croppedImage = [appDelegate getImageByCroppingImage:captured_Image_ toRect:CGRectMake(0, 0, 300, 300)];
            }
            previewImagView.image = croppedImage;
        }
        
        //[picker dismissModalViewControllerAnimated:YES];
        [picker dismissViewControllerAnimated:YES completion:^{
            //code
        }];
        [self.popover dismissPopoverAnimated:YES];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

//Resize the image
- (UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSize:(CGSize)targetSize {
    @try {
        // UIImage *sourceImage = self;
        UIImage *newImage = nil;
        
        //   CGSize imageSize = sourceImage.size;
        //   CGFloat width = imageSize.width;
        //   CGFloat height = imageSize.height;
        
        CGFloat targetWidth = targetSize.width;
        CGFloat targetHeight = targetSize.height;
        
        //   CGFloat scaleFactor = 0.0;
        CGFloat scaledWidth = targetWidth;
        CGFloat scaledHeight = targetHeight;
        
        CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
        
        // this is actually the interesting part:
        
        UIGraphicsBeginImageContext(targetSize);
        
        CGRect thumbnailRect = CGRectZero;
        thumbnailRect.origin = thumbnailPoint;
        thumbnailRect.size.width  = scaledWidth;
        thumbnailRect.size.height = scaledHeight;
        
        [sourceImage drawInRect:thumbnailRect];
        
        newImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        if(newImage == nil) {
            //NSLog(@"could not scale image");
        }
        return newImage;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
//======================================END OF PICTURE RELATED=======================================================//

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    //    NSLog(@"plug View controller touchesbegan called");
    [comment_TextView_ resignFirstResponder];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(BOOL)shouldAutorotate {
    return NO;
}
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

-(IBAction)toolBarCancelSelected:(id)sender{
    TCSTART
    if (chooseProviderClicked) {
        if ([self isNotNull:previousSelectedPhysician]) {
            selectedPhysician = previousSelectedPhysician;
            physicianNameLabel.text = selectedPhysician.physicianName;
        }
        physiciansPickerDisplayView.hidden = YES;
    }else{
        [self clearScreen];
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:^{
            //code
        }];
    }
    TCEND
}
@end
