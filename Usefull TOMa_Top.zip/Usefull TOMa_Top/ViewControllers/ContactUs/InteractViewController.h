//
//  InteractViewController.h
//  LocationInfo
//
//  Created by shiva on 12/4/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RateView.h"
#import "Base64.h"
#import "UICustomSwitch.h"

#import "LocationInfoViewController.h"
#import "StreamService.h"
#import "StreamDataModel.h"
#import "AppDelegate.h"
#import "PhysicianService.h"

@class LocationInfoViewController;

@interface InteractViewController : UIViewController<UITextViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,UIWebViewDelegate,StreamServiceDelegate,UIPopoverControllerDelegate,UIPickerViewDataSource,UIPickerViewDelegate, CPBusinessInfoServiceDelegate> {
    
    UITextView *comment_TextView_;
    UILabel *commentChars_Lbl_;
    UIImage *captured_Image_;
    NSData *image_Data_;
    NSMutableDictionary *rateReviewDictionary;
    
    id caller;
    
    UIView *addConfirmationView;
    UIImageView *preview_imgView;
    UIView *photoPopUp_View;
    BOOL isImgSourceTypeCamera;
    
    //LocationDataModel *locationDataModal_;
    AppDelegate *appDelegate;
    
    IBOutlet UIButton *photoCaptureButton;
    IBOutlet UIView   *remainingView;
    
    //    UICustomSwitch *plugSwitch;
    
    /** Asking for show confirmation view again
     */
    IBOutlet UIView     *confirmationView;
    IBOutlet UIImageView *confirmationViewImageview;
    IBOutlet UILabel *confirmationViewTitleLabel;
    IBOutlet UILabel *confirmationViewDescLabel;
    BOOL hasDisplayedConfirmatnView;
    IBOutlet UIButton *confirmOKButton;
    
    UIPopoverController *popover;
    
    IBOutlet UILabel *physicianNameLabel;
    
    /** PhysiciansView and Physician
     */
    NSMutableArray *physiciansArray;
    NSArray *communicationTypesArray;
    NSArray *appointmentTypesArray;
    NSArray *reasonsForVisitArray;
    BOOL   isFromMainView;
    CPPhysician *selectedPhysician;
    CPPhysician *previousSelectedPhysician;
    NSDictionary *selectedCommunicationType;
    NSDictionary *appointmentType;
    NSDictionary *reasonsType;
    
    IBOutlet UIView  *physiciansPickerDisplayView;
    IBOutlet UIPickerView *physiciansPickerView;
    IBOutlet UIToolbar *toolBar;
    IBOutlet UIBarButtonItem *myFeedBackMessageBtn;
    
    /** Asking for response is needed in no.of days
     */
    IBOutlet UIView *responseView;
    IBOutlet UILabel *resposneViewBgLabel;
    IBOutlet UILabel *resposneTextLabel;
    BOOL isCommunicationTypeSelected;
    UILabel *txtLabel;
    
    int requestAppointmentCheckState;
    
    NSString *HELP_TEXT_REQ_APPOINTMENT;
    NSString *HELP_TEXT_REFILL_MY_MEDICATION;
    NSString *HELP_TEXT_PROVIDE_FEEDBACK;
    NSString *HELP_TEXT_ASK_MY_PROVIDER_A_QSTN;
    NSString *HELP_TEXT_ASK_NURSE_ADVICE_LINE_QSTN;
    BOOL chooseProviderClicked;
    
}

@property(strong, nonatomic) id caller;
@property(strong, nonatomic) IBOutlet UIButton *cancel_Btn;
@property(strong, nonatomic) IBOutlet UIButton *submit_Btn;
@property(strong, nonatomic) IBOutlet UIButton *chooseProvider_Btn;
@property (strong, nonatomic) IBOutlet UIButton *contactOKButton;

@property(strong,nonatomic) IBOutlet UITextView *comment_TextView;
@property(strong,nonatomic) IBOutlet UILabel *commentChars_Lbl;
@property(strong,nonatomic) IBOutlet UILabel *headerLabel;
@property (nonatomic, retain) UIPopoverController *popover;
//@property(nonatomic,readwrite)BOOL *isCommunicationTypeSelected;

//Rate
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andCaller:(id)caller_ andPhysiciansArray:(NSArray *)physiciansArray_ isFromMainView:(BOOL)isFromMainView_;
-(IBAction)removeFromParentViewController:(id)sender;
-(IBAction)submitRateNReview:(id)sender;

-(IBAction)openCameraToTakePictureOrVideo:(id)sender;
-(void)openCamera;
-(UIImage*)imageWithImage:(UIImage*)sourceImage scaledToSize:(CGSize)newSize;
-(void)clearScreen;

- (IBAction)chooseProviders:(id)sender;
- (IBAction)toolbarDoneSelected:(id)sender;
-(IBAction)toolBarCancelSelected:(id)sender;

- (IBAction)responseViewOkBtnClicked:(id)sender;
@end
