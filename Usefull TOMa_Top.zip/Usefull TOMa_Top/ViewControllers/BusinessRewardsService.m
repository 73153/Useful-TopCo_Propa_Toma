//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import "BusinessRewardsService.h"
#import "AppDelegate.h"
#import "BusinessReward.h"
@implementation BusinessRewardsService {
    AppDelegate *appDelegate;
}

@synthesize requestURL;
@synthesize auth_token;
@synthesize apiKey;
@synthesize isRequestForRefresh;

-(id)initWithCaller:(id)caller_
{
    if (self = [super init]) {
        caller = caller_;
        appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    }
    return  self;
}

- (void)getGlobalBusinessRewards {
    
    @try {
            CPCommonParameters *parameters = [[CPCommonParameters alloc] init];
            parameters.apiKey = apiKey;
            parameters.isDebug = YES;
            parameters.applicationURL = [NSURL URLWithString:requestURL];
            parameters.authenticationToken = auth_token;
            CPRankAchievementService *service = [[CPRankAchievementService alloc] initWithCommonParameters:parameters withDelegate:self];
            [service getGlobalBusinessRewards];
            //[service getBusinessRewardsPage:[NSNumber numberWithInteger:pageNum] nearLatitude:[latitude floatValue] andLongitude:[longitude floatValue]];
           //[service getBusinessRewardsPage:[NSNumber numberWithInteger:pageNum] nearLatitude:34.028478 andLongitude:-84.777553];
           //[service getBusinessRewardsPage:[NSNumber numberWithInteger:pageNum] nearLatitude:33.4238 andLongitude:-111.9401];
        }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)getLocation {
    
    @try {
        appDelegate.mapView.mapDelegate = self;
        appDelegate.mapView.stopUpdatingLocationInfo = YES;
        appDelegate.mapView.locationManager.desiredAccuracy = 50.0f;
        [appDelegate.mapView.locationManager stopUpdatingLocation];
        [appDelegate.mapView.locationManager startUpdatingLocation];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) didReceiveBusinessRewards:(NSArray*) rewards {
    @try {
       
        BOOL isDataSaved = NO;
        BOOL isResponseNull = YES;//required to show the load more option, if the response is an empty array then there are no more results at server.
        
        if (isRequestForRefresh) {
            NSDictionary *attributesDict = [[NSDictionary alloc] initWithObjectsAndKeys:@"BusinessReward",@"entityName", nil];
            
            [appDelegate removeAllObjectsInEntitityWithAttributes:attributesDict];
        }
        
        if ([self isNotNull:rewards] && rewards.count > 0) {
            isResponseNull = NO;
            for (int i = 0; i < rewards.count; i ++) {
                
                CPBusinessRewardEvent *rewardEvent = [rewards objectAtIndex:i];
                if ([self isNotNull:rewardEvent] && [self isNotNull:rewardEvent.rewardId]) {
                    
                    BusinessReward *businessReward = nil;
                    
                    businessReward = [NSEntityDescription insertNewObjectForEntityForName:@"BusinessReward" inManagedObjectContext:appDelegate.managedObjectContext];
                    
                    if([self isNotNull:businessReward]) { //check whether rank entitiy is created with the specified manged object context or not.
                        if([self isNotNull:rewardEvent.rewardTitle]) {
                            businessReward.rewardTitle = rewardEvent.rewardTitle;
                        }
                        
                        if([self isNotNull:rewardEvent.rewardDescription]) {
                            businessReward.rewardDescription = rewardEvent.rewardDescription;
                        }
                        
                        if([self isNotNull:rewardEvent.rewardId]) {
                            businessReward.rewardId = rewardEvent.rewardId;
                        }
                        
                        if([self isNotNull:rewardEvent.imageURL]) {
                            businessReward.imageURL = [rewardEvent.imageURL absoluteString];
                        }
                        
                        if([self isNotNull:rewardEvent.beginsOn]) {
                            businessReward.rewardStartDate = rewardEvent.beginsOn;
                        }
                        
                        businessReward.canRedeem = [NSNumber numberWithBool:rewardEvent.canRedeem];
                        
                        businessReward.repeatably_redeemable = [NSNumber numberWithBool:rewardEvent.repeatably_redeemable];
                        
                        if([self isNotNull:rewardEvent.endsOn]) {
                            businessReward.rewardEndDate = rewardEvent.endsOn;
                        }
                        
                        if([self isNotNull:rewardEvent.locationsRedeemsArray]) {
                            businessReward.businessRedeemsArray = rewardEvent.locationsRedeemsArray;
                        }
                        
                        if([self isNotNull:rewardEvent.redemptionList]) {
                            businessReward.redeemptionListArray = rewardEvent.redemptionList;
                        }
                    }
                }
            }
            NSError *error;
            isDataSaved = YES;
            // Store what we imported already
            if (![appDelegate.managedObjectContext save:&error]) {//save the entity data into managedobjectcontext.
                isDataSaved = NO;
                // Handle the error.
                // NSLog(@"%@", [error domain]);
            }
        }
        NSDictionary *userRankModalDataDict = [[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:isDataSaved],@"isdatasaved",[NSNumber numberWithBool:isResponseNull],@"response", nil];
        
        if(caller && [caller conformsToProtocol:@protocol(BusinessRewardsServiceDelegate)] && [caller respondsToSelector:@selector(didFinishedGettingBusinessRewards:)])
            [caller didFinishedGettingBusinessRewards:userRankModalDataDict];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
}

- (void) didFailToReceiveBusinessRewardsWithError:(NSError*) error {
    if(caller && [caller conformsToProtocol:@protocol(BusinessRewardsServiceDelegate)] && [caller respondsToSelector:@selector(didFailedTogetBusinessRewards:)])
        [caller didFailedTogetBusinessRewards:[error localizedDescription]];
    
}

#pragma mark MapVew Delegate methods.
//Get the user latitude and longitude
-(void) didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    
    @try {
        //  NSLog(@"User Latitude and longitude in viewcontroller class are lat:%f lang:%f",newLocation.coordinate.latitude,newLocation.coordinate.longitude);
        
        [appDelegate.mapView.locationManager stopUpdatingLocation];
        
        if (newLocation.speed == -1 && newLocation.coordinate.latitude == 0.0 && newLocation.coordinate.longitude == 0.0) {
            if (caller && [caller conformsToProtocol:@protocol(BusinessRewardsServiceDelegate)] && [caller respondsToSelector:@selector(didFailedTogetBusinessRewards:)]) {
                [caller didFailedTogetBusinessRewards:@"Please turn on location based services and allow the application to access your current location"];
            }
            //[appDelegate showErrorMsg:@"Please turn on location based services and allow the application to access your current location"];
        } else {
            appDelegate.userCurrentLocation = newLocation;
            latitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
            longitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
            [self getGlobalBusinessRewards];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)didFailedToUpdateLocationWithError:(NSError *)error {
    
    @try {
        [appDelegate.mapView.locationManager stopUpdatingLocation];

        //   NSLog(@"failed to update the location with error %@",error);
        if (caller && [caller conformsToProtocol:@protocol(BusinessRewardsServiceDelegate)] && [caller respondsToSelector:@selector(didFailedTogetBusinessRewards:)]) {
            [caller didFailedTogetBusinessRewards:@"Please turn on location based services and allow the application to access your current location"];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


@end