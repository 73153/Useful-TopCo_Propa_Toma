//
//  BusinessRewardsViewController.h
//  Baldwin
//
//  Created by Jagadeesh J on 03/11/14.
//

#import "RedeemSpecialViewController.h"
#import "AppDelegate.h"
#import "BusinessRewardsViewController.h"

@implementation RedeemSpecialViewController

- (id)initWithSpecial:(CPSpecial *)specialEvent withImgUrl:(NSString *)imageUrlStrng andLocationId:(NSString *)loc_id FromViewController:(id)viewcontrollerRef canRepeatablyRedeemable:(BOOL)canRepeatablyRedeemable
{
    if (self = [super init]) {
        repeatablyRedeemable = canRepeatablyRedeemable;
        // Custom initialization
        imgUrlStrng = imageUrlStrng;
        special = specialEvent;
        locationId = loc_id;
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        [self canRedeemSpecial];
        caller = viewcontrollerRef;
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    //TabBar is hidden when it was pushed with the API "hidesBottombarWhenPushed", and also we need to hide the images and labels that we created to get the given design look and feel.
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    @try {
        [super viewDidLoad];
        self.view.frame=appDelegate.window.frame;
        NSLog(@"SelfFrame:%f",self.view.frame.size.height);
        UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
        image.image = [UIImage imageNamed:@"bg"];
        [self.view addSubview:image];
        //        self.view.backgroundColor = [UIColor clearColor];
        
        /////////for profile lable representation
        UILabel *label;
        if (iPad) {
            label =[[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width - 300)/2,13 ,300,45)];
        } else {
            label = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, appDelegate.window.frame.size.width,25)];
        }
        label.backgroundColor = [UIColor clearColor];
        label.text = @"REDEEM";
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        [self.view addSubview:label];
        
        UIButton *redeemButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        redeemButton.frame = CGRectMake(self.view.frame.size.width- 100, 10, 95, 48);
        if (!iPad) {
            if(isiPhone6) {
                redeemButton.frame = CGRectMake(appDelegate.window.frame.size.width-65, 7, 60, isiPhone6PLUS?32:30);
            }
            else {
                redeemButton.frame = CGRectMake(265, 7, 50, 30);
            }
        }
        //        [redeemButton setTitle:@"Redeem" forState:UIControlStateNormal];
        [redeemButton setBackgroundImage:[UIImage imageNamed:@"Redeem"] forState:UIControlStateNormal];
        [redeemButton setBackgroundImage:[UIImage imageNamed:@"Redeem_f"] forState:UIControlStateHighlighted];
        [redeemButton addTarget:self action:@selector(redeemedSpecial) forControlEvents:UIControlEventTouchUpInside];
        redeemButton.tag = 1;
        redeemButton.hidden = YES;
        [self.view addSubview:redeemButton];
        
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        //set the position of the button
        if (iPad) {
            backButton.frame = CGRectMake(5,10, 84, 48);
        } else {
            backButton.frame = CGRectMake(5,7, 59, 32);
        }
        //set the button's title
        [backButton setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        //listen for clicks
        [backButton addTarget:self action:@selector(goToMainPage:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:backButton];
        
        UIImageView *lineImgView = [[UIImageView alloc]initWithFrame:LINEIMAGE_FRAME];
        lineImgView.image = [UIImage imageNamed:@"line"];
        [self.view addSubview:lineImgView];
        
        CGFloat originX = 0;
        if (CURRENT_DEVICE_VERSION >= 7.0) {
            originX = 5;
        }
        redeemSpecialTable = [[UITableView alloc]initWithFrame:CGRectMake(originX, lineImgView.frame.size.height+lineImgView.frame.origin.y+5, appDelegate.window.frame.size.width-(2 * originX), self.view.frame.size.height - (lineImgView.frame.size.height+lineImgView.frame.origin.y+10)) style:UITableViewStyleGrouped];
        redeemSpecialTable.delegate = self;
        redeemSpecialTable.dataSource = self;
        redeemSpecialTable.backgroundView = nil;
        redeemSpecialTable.backgroundColor = [UIColor clearColor];
        //        redeemSpecialTable.separatorColor = [UIColor whiteColor];
        if (CURRENT_DEVICE_VERSION>=7.0) {
            redeemSpecialTable.separatorStyle = UITableViewCellSeparatorStyleNone;
        }else{
            redeemSpecialTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        }
        [self.view addSubview:redeemSpecialTable];
        
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, redeemSpecialTable.frame.size.width, 114)];
        UILabel *footerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 2, footerView.frame.size.width, 110)];
        footerLabel.textAlignment = NSTextAlignmentCenter;
        footerLabel.textColor = [appDelegate colorWithHexString:@"53B546"];
        footerLabel.numberOfLines = 0;
        footerLabel.lineBreakMode = NSLineBreakByWordWrapping;
        footerLabel.backgroundColor = [UIColor clearColor];
        NSString *decLabel = @"Redeem button will show in upper right if redeemable";
        if (repeatablyRedeemable) {
            footerLabel.text = [NSString stringWithFormat:@"Redeemable Multiple Times\r%@",decLabel];
        } else {
            footerLabel.text = [NSString stringWithFormat:@"Redeemable Once\r%@",decLabel];
        }
        footerLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
        [footerView addSubview:footerLabel];
        
        redeemSpecialTable.tableFooterView = footerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0 && self.view.frame.size.height == appDelegate.window.frame.size.height) {
        CGRect viewBounds = self.view.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)canRedeemSpecial {
    TCSTART
    NSLog(@"In CanRedeem!");
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken] && [self isNotNull:special.specialId]) {
        [appDelegate canRedeemSpecialWithId:[NSString stringWithFormat:@"%d",[special.specialId intValue]] andCaller:self];
        [appDelegate showActivityIndicatorInView:self.view];
        [appDelegate showNetworkIndicator];
    }
    TCEND
}
//can redeem special
- (void)didFinishedGettingCanRedeemSpecialResponse:(BOOL)canRedeem {
    TCSTART
    UIButton *redeemButton = (UIButton *)[self.view viewWithTag:1];
    if (canRedeem) {
        redeemButton.hidden = NO;
    } else {
        redeemButton.hidden = YES;
    }
    
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
    TCEND
}
- (void)didFailCanRedeemSpecialWithErrorMsg:(NSString *) error {
    TCSTART
    [self showAlertWithMessage:error];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
    TCEND
}

- (void)redeemedSpecial {
    TCSTART
    NSLog(@"In RedeemSpecial");
    if ([self isNotNull:appDelegate.userProfileDataModel.authToken] && [self isNotNull:special.specialId]) {
        [appDelegate redeemedSpecialWithId:[NSString stringWithFormat:@"%d",[special.specialId intValue]] andCaller:self];
        [appDelegate showActivityIndicatorInView:self.view];
        [appDelegate showNetworkIndicator];
    }
    TCEND
}
//redeem special
- (void)didFinishedGettingRedeemSpecialResponse:(BOOL)canRedeemAgain {
    TCSTART
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
    if (canRedeemAgain) {
        if (repeatablyRedeemable) {
            [self showAlertWithMessage:@"You have successfully redeemed this reward."];
            //[self showAlertWithMessage:@"You've successfully redeemed this reward. Visit us again to redeem again!"];
        }
        else
        [self showAlertWithMessage:@"You have successfully redeemed this reward."];
    } else {
        UIButton *redeemButton = (UIButton *)[self.view viewWithTag:1];
        redeemButton.hidden = YES;
        [self showAlertWithMessage:@"You have successfully redeemed this reward!"];
    }
    
    TCEND
}
- (void)showAlertWithMessage:(NSString *)message {
    TCSTART
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    TCEND
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    TCSTART
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if ([title isEqualToString:@"OK"]) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    TCEND
}
- (void)didFailRedeemSpecialWithErrorMsg:(NSString *) error {
    [appDelegate showErrorMsg:error];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate hideNetworkIndicator];
}

- (void)viewWillAppear:(BOOL)animated {
    TCSTART
    TCEND
}
-(void)goToMainPage:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 1;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectZero];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row == 0) {
        return iPad?440:240;
    } else if(indexPath.row == 1) {
        return [self getheightForRowInSection];
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        UITableViewCell *cell = nil;
        UIImageView *redeemableSpecialImgView = nil;
        
        UILabel *dateLbl = nil;
        UILabel *specialName = nil;
        UILabel *specialDescr = nil;
        CGFloat rowHeight;
        
        if (indexPath.row == 0) {
            
            NSString *cellIdentifier = @"redeemableSpecialCellIdentifier";
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
                if (CURRENT_DEVICE_VERSION >= 7.0f) {
                    [appDelegate addBackgroundViewToTheCell:cell];
                }
                redeemableSpecialImgView = [[UIImageView alloc]init];
                redeemableSpecialImgView.frame = CGRectMake((tableView.frame.size.width-(iPad?400:200))/2, 20, iPad?400:200, iPad?400:200);
                redeemableSpecialImgView.tag = 1;
                redeemableSpecialImgView.layer.cornerRadius = 10.0f;
                redeemableSpecialImgView.layer.masksToBounds = YES;
                [cell.contentView addSubview:redeemableSpecialImgView];
                
            }
            if(!redeemableSpecialImgView) {
                redeemableSpecialImgView = (UIImageView *)[cell.contentView viewWithTag:1];
            }
            
            [redeemableSpecialImgView setImageWithURL:[NSURL URLWithString:imgUrlStrng] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
            rowHeight = iPad?440:240;
            redeemableSpecialImgView = nil;
            
        } else if(indexPath.row == 1) {
            NSString *cellIdentifier = @"SpecialCellIdentifier";
            cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
                if (CURRENT_DEVICE_VERSION >= 7.0f) {
                    [appDelegate addBackgroundViewToTheCell:cell];
                }
                //Date
                dateLbl = [[UILabel alloc]init];
                dateLbl.numberOfLines = 0;
                dateLbl.tag = 1;
                dateLbl.textColor = [UIColor darkGrayColor];
                dateLbl.backgroundColor = [UIColor clearColor];
                dateLbl.font = [UIFont fontWithName:dateFontName size:dateFontSize];
                [cell.contentView addSubview:dateLbl];
                
                //Special Name
                specialName = [[UILabel alloc]init];
                specialName.numberOfLines = 0;
                specialName.tag = 2;
                specialName.textColor = [UIColor whiteColor];
                specialName.backgroundColor = [UIColor clearColor];
                specialName.font = [UIFont fontWithName:titleFontName size:titleFontSize];
                [cell.contentView addSubview:specialName];
                
                //Special Description
                specialDescr = [[UILabel alloc]init];
                specialDescr.numberOfLines = 0;
                specialDescr.tag = 3;
                specialDescr.backgroundColor = [UIColor clearColor];
                specialDescr.textColor = [UIColor whiteColor];
                specialDescr.font = [UIFont fontWithName:@"Helvetica" size:addressFontSize];
                [cell.contentView addSubview:specialDescr];
                
            }
            if(!dateLbl) {
                dateLbl = (UILabel *)[cell.contentView viewWithTag:1];
            }
            if(!specialName) {
                specialName = (UILabel *)[cell.contentView viewWithTag:2];
            }
            if(!specialName) {
                specialName = (UILabel *)[cell.contentView viewWithTag:3];
            }
            
            CGFloat specialNameHeight = 0.0f;
            CGFloat specialDescStrHeight = 0.0f;
            
            specialNameHeight = [appDelegate getStringHeight:special.title withConstraintWidth:HEADER_WIDTH - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH) withFontSize:titleFontSize withFontName:titleFontName];
            
            specialDescStrHeight = [appDelegate getStringHeight:special.details withConstraintWidth:HEADER_WIDTH - (HEADER_MARGIN + REVIEWER_IMAGE_WIDTH) withFontSize:addressFontSize withFontName:@"HelveticaNeue"];
            
            dateLbl.frame = CGRectMake(CELL_CONTENT_MARGIN , 7, CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN ,MAX(15, 0.0f));
            NSMutableString *avaialabilityPeriodMutableString = [[NSMutableString alloc]init];
            
            
            
            if ([self isNotNull:special.startDate]) {
                
                [avaialabilityPeriodMutableString appendString:[appDelegate getReqDateFormatForRewards:[self stringFromDate:special.startDate]]];
            }
            
            if([self isNotNull:special.endDate]) {
                [avaialabilityPeriodMutableString appendString:@" - "];
                [avaialabilityPeriodMutableString appendString:[appDelegate getReqDateFormatForRewards:[self stringFromDate:special.endDate]]];
            }
            
            if ([self isNotNull:avaialabilityPeriodMutableString] && avaialabilityPeriodMutableString.length > 0) {
                dateLbl.text = avaialabilityPeriodMutableString;
            } else {
                dateLbl.text = @"";
            }
            
            if ([self isNotNull:special.title]) {
                specialName.text = special.title;
            } else {
                specialName.text = @"";
            }
            specialName.frame = CGRectMake(CELL_CONTENT_MARGIN, dateLbl.frame.origin.y + dateLbl.frame.size.height + (iPad?8:5), CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN ,MAX(specialNameHeight, 0.0f));
            
            if ([self isNotNull:special.details]) {
                specialDescr.text = special.details;
                //specialDescr.text = @"Dont forget about our $5 ORIGINAL GYM";
            } else {
                specialDescr.text = @"";
            }
            specialDescr.frame = CGRectMake(CELL_CONTENT_MARGIN, specialName.frame.origin.y + specialName.frame.size.height + (iPad?4:3), CELL_CONTENT_WIDTH - CELL_CONTENT_MARGIN ,MAX(specialDescStrHeight, 0.0f));
            
            cell.backgroundView = nil;
            
            rowHeight = specialDescStrHeight + specialNameHeight + 40 + (iPad?16:10);
        }
        if (CURRENT_DEVICE_VERSION >= 7.0f) {
            [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:rowHeight andWidth:appDelegate.window.frame.size.width-10];
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

-(CGFloat)getheightForRowInSection {
    
    @try {
        CGFloat specialNameHeight = 0;
        CGFloat specialDecStrHeight = 0;
        //if (self.locationDelegate && [self.locationDelegate conformsToProtocol:@protocol(LocationMainViewDelegate)] && specialsCat_Arr.count > indexPath.row) {
        //replace appDelegate with self.locationDelegate for static libraries
        
        specialNameHeight = [appDelegate getStringHeight:special.title withConstraintWidth:CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN + COMMENTOR_IMAGE_WIDTH) withFontSize:titleFontSize withFontName:titleFontName];
        
        specialDecStrHeight = [appDelegate getStringHeight:special.details withConstraintWidth:CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN + COMMENTOR_IMAGE_WIDTH) withFontSize:addressFontSize withFontName:@"Helvetica"];
        //}
        
        //  NSLog(@"header hieght is %f",specialNameHeight + specialDecStrHeight + 35.0f + 20);
        return specialNameHeight + specialDecStrHeight + 40 + (iPad?16:10);//"20" is for shwoing the time of review.
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)viewWillDisappear:(BOOL)animated {

}
@end
