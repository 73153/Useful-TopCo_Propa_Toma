//
//  SurveyView.h
//  BeefOBrady
//
//  Created by Aruna on 01/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RateView.h"
#import "AppDelegate.h"
#import "PhysicianService.h"
@interface SurveyView : UIView <RateViewDelegate,CPBusinessInfoServiceDelegate,UIPickerViewDataSource,UIPickerViewDelegate> {
    
    NSArray *textArray;
    
     UIButton *skipButton;
     UIButton *nextButton;
     UIButton *submitButton;
    
    CGFloat questionViewOriginY;
    
    int pageNumber;
    int privousPageLastQusNum;
    int currentlyDisplayedPageNumber;
    
    NSMutableDictionary *pagesDict;
    
    UILabel *titleLabel;
    
    id caller;
    
    AppDelegate *appDelegate;
    
    /** Physicians
     */
    NSMutableArray *physiciansArray;
    BOOL isPrimarySurvey;
    
    CPPhysician *selectedPhysician;
    
    UIView  *physiciansPickerDisplayView;
    UIPickerView *physiciansPickerView;
    UIToolbar *toolBar;
    
    NSString *survey_id;
    NSString *location_id;
}
@property (nonatomic, retain) NSString *survey_id;
@property (nonatomic, retain) NSString *location_id;
- (id)initWithFrame:(CGRect)frame andQuestionsArray:(NSMutableArray *)questionsArray andCaller:(id)caller_ andPhysiciansArray:(NSArray *)physiciansArray_ isPrimarysurvey:(BOOL)isPrimarysurvey_;

- (void)displyImDoneScreen;
@end
