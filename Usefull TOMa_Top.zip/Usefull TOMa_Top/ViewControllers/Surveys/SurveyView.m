//
//  SurveyView.m
//  BeefOBrady
//
//  Created by Aruna on 01/02/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "SurveyView.h"
#import "CustomButton.h"
#import "MyHistoryNRecentActivityViewController.h"

@implementation SurveyView
@synthesize survey_id;
@synthesize location_id;

- (id)initWithFrame:(CGRect)frame andQuestionsArray:(NSMutableArray *)questionsArray andCaller:(id)caller_ andPhysiciansArray:(NSArray *)physiciansArray_ isPrimarysurvey:(BOOL)isPrimarysurvey_
{
    TCSTART
    self = [super initWithFrame:frame];
    if (self) {
        
//        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
//        NSString *questionStr = @"Would you attend a conference,jahf tks shu syu jkshhsu hfu sdhfushusdhuhsdu ushdfuhsun ishiufhsdu sdhufdhsud iuhduhdfs hsuidfhsud   ihfd";
//        [dict setObject:questionStr forKey:@"text"];
//        [dict setObject:@"smiley" forKey:@"responseType"];
//        [questionsArray  addObject:dict];
//        
//        NSMutableDictionary *dict1 = [[NSMutableDictionary alloc] init];
//        NSString *questionStr1 = @"Would you attend a conference,jahf tks shu syu jkshhsu hfu sdhfushusdhuhsdu ushdfuhsun ishiufhsdu ";
//        [dict1 setObject:questionStr1 forKey:@"text"];
//        [dict1 setObject:@"star-rating" forKey:@"responseType"];
//        [questionsArray  addObject:dict1];
//        
//        NSMutableDictionary *dict2 = [[NSMutableDictionary alloc] init];
//        NSString *questionStr2 = @"Would you attend a conference,fushusdhuhsdu ghdfgh hgfhgf";
//        [dict2 setObject:questionStr2 forKey:@"text"];
//        [dict2 setObject:@"smiley" forKey:@"responseType"];
//        [questionsArray  addObject:dict2];
//        
//        NSMutableDictionary *dict3 = [[NSMutableDictionary alloc] init];
//        NSString *questionStr3 = @"Would you attend a conference,jahf tks shu syu jkshhsu hfu sdhfushusdhuhsdu ushdfuhsun ishiufhsdu sdhufdhsud iuhduhdfs hsuidfhsud   ihfd";
//        [dict3 setObject:questionStr3 forKey:@"text"];
//        [dict3 setObject:@"star-rating" forKey:@"responseType"];
//        [questionsArray  addObject:dict3];

        textArray = [[NSArray alloc] initWithArray:questionsArray];
        caller = caller_;
    
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        isPrimarySurvey = isPrimarysurvey_;
        self.frame = frame;
        
        physiciansArray = [[NSMutableArray alloc] initWithArray:physiciansArray_];
        [physiciansArray insertObject:[appDelegate getDefaultPhysician] atIndex:0];
        
        NSLog(@"frame :%f %f %f %f andPhysiciansArray:%@",self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height,physiciansArray);
        [self initialiseAllObjects];
        int index = ceil(physiciansArray.count/2);
        if (index < physiciansArray.count) {
            [physiciansPickerView selectRow:index inComponent:0 animated:YES];
            selectedPhysician = [physiciansArray objectAtIndex:index];
        } else {
            [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
            selectedPhysician = [physiciansArray objectAtIndex:0];
        }
//        if (physiciansArray.count > 2) {
//            [physiciansPickerView selectRow:2 inComponent:0 animated:YES];
//            selectedPhysician = [physiciansArray objectAtIndex:3];
//        } else  {
//            [physiciansPickerView selectRow:0 inComponent:0 animated:YES];
//            selectedPhysician = [physiciansArray objectAtIndex:0];
//        }
        
        if ([self isNotNull:appDelegate.userProfileDataModel.authToken]) {
            [appDelegate getBusinessInfoWithCaller:self andAuthTokenNeeded:YES];
            [appDelegate showActivityIndicatorInView:self];
            }
    }
    return self;
    TCEND
}

#pragma mark BusinessInfo Service delegate methods
- (void)didReceivedBusinessInfo:(CPBusinessInfo *) businessInfo {
    TCSTART

    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self];
    if ([self isNotNull:businessInfo.physiciansArray] && businessInfo.physiciansArray.count > 0) {
        [appDelegate savePhysicians:businessInfo.physiciansArray];
        
        [physiciansArray removeAllObjects];
        [physiciansArray addObject:[appDelegate getDefaultPhysician]];
        [physiciansArray addObjectsFromArray:[appDelegate getPhysicians]];
    }
    
    if ([self isNotNull:businessInfo.responseTimeFrame]) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.responseTimeFrame forKey:@"responseTimeFrame"];
    }

    if ([self isNotNull:businessInfo.insuranceProviders] && businessInfo.insuranceProviders.count > 0) {
        [[NSUserDefaults standardUserDefaults] setObject:businessInfo.insuranceProviders forKey:@"insuranceProviders"];
    }
    
    physiciansPickerDisplayView.hidden = NO;
    [physiciansPickerView reloadAllComponents];
    TCEND
}

- (void)didFailToReceiveBusinessInfoWithError:(NSError*) error {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self];
//    [appDelegate showErrorMsg:errorMsg];
    
    physiciansPickerDisplayView.hidden = NO;
    [physiciansPickerView reloadAllComponents];
    TCEND
}


#pragma mark pickerView Datasource and delgate methods
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [physiciansArray count];
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    CPPhysician *physician = [physiciansArray objectAtIndex:row];
    return physician.physicianName;
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    selectedPhysician = [physiciansArray objectAtIndex:row];
}


#pragma mark toolbar done clicked
- (IBAction)toolbarDoneSelected:(id)sender {
    physiciansPickerDisplayView.hidden = YES;
}

- (void)initialisePickerView {
    TCSTART
    physiciansPickerDisplayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    physiciansPickerDisplayView.backgroundColor = [UIColor colorWithRed:.2 green:.2 blue:.2 alpha:.8f];
    
    physiciansPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(self.frame.origin.x, self.frame.size.height - 216, self.frame.size.width, 216)];
    [physiciansPickerDisplayView addSubview:physiciansPickerView];
    physiciansPickerView.delegate = self;
    physiciansPickerView.dataSource = self;
    physiciansPickerView.showsSelectionIndicator = YES;
    physiciansPickerView.backgroundColor = [UIColor whiteColor];
    
    toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(self.frame.origin.x, self.frame.size.height - (216 + 44), self.frame.size.width, 44)];
    [toolBar setBarStyle:UIBarStyleBlack];
    
    UIBarButtonItem *leftBarbutton = [[UIBarButtonItem alloc] initWithTitle:@"My feedback/message is for:" style:UIBarButtonItemStylePlain target:nil action:nil];
//    if (!iPad) {
        leftBarbutton.width = (iPad?450:245);
        UILabel *txtLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, leftBarbutton.width, 44)];
        txtLabel.backgroundColor = [UIColor clearColor];
        txtLabel.textColor = [UIColor whiteColor];
    txtLabel.textAlignment = NSTextAlignmentLeft;
        txtLabel.font = [UIFont fontWithName:titleFontName size:titleFontSize];
        txtLabel.text = @"My feedback/message is for:";
        leftBarbutton.customView = txtLabel;
//    }
    
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *rightbutton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(toolbarDoneSelected:)];
    [rightbutton setTintColor:[UIColor blueColor]];
    toolBar.items = [NSArray arrayWithObjects:leftBarbutton,flexibleSpace,rightbutton, nil];
    
    [physiciansPickerDisplayView addSubview:toolBar];
    
    [self addSubview:physiciansPickerDisplayView];
    
//    if (isPrimarySurvey) {
//        physiciansPickerDisplayView.hidden = YES;
//    }
    
    TCEND
}


- (void)initialiseAllObjects
{
    TCSTART
    UIImageView *bg_ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Survey-Pop-Up"]];
    bg_ImgView.frame = CGRectMake(self.frame.origin.x, 0, self.frame.size.width, self.frame.size.height);
    [self addSubview:bg_ImgView];
    
    CGFloat gap;
    if (iPad) {
        titleLabel =[[UILabel alloc] initWithFrame:CGRectMake((self.frame.size.width - 300)/2,10 ,300,45)];
        gap = 10;
    } else {
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,7.5, appDelegate.window.frame.size.width,25)];
        gap = 0;
    }
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:headerTitleFontName size:headerTitleFontSize];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"SURVEY QUESTIONS";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:titleLabel];
    
    UIImageView *toplineIamge = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
    toplineIamge.frame = CGRectMake(0, titleLabel.frame.origin.y + titleLabel.frame.size.height, self.frame.size.width, 13);
    [self addSubview:toplineIamge];
    
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    closeButton.frame = CGRectMake(self.frame.size.width - (35 + gap), gap, 35, 35);
    [closeButton setImage:[UIImage imageNamed:@"Survey-Close"] forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(skipSurvey:) forControlEvents:UIControlEventTouchUpInside];
    closeButton.tag = -5000;
    [self addSubview:closeButton];
    
    UIImageView *bottomLineImg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"line"]];
    if (iPad) {
        bottomLineImg.frame = CGRectMake(0, 844 + 75 + 5, self.frame.size.width, 13);
    } else {
        bottomLineImg.frame = CGRectMake(0, MAXQUESTIONSDISPLAYAREA + 30, self.frame.size.width, 13);
    }
    
    bottomLineImg.tag = 1000;
    [self addSubview:bottomLineImg];
    
    skipButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [skipButton setBackgroundImage:[UIImage imageNamed:@"SurveySkipNormal"] forState:UIControlStateNormal];
    [skipButton setBackgroundImage:[UIImage imageNamed:@"SurveySkipSelected"] forState:UIControlStateHighlighted];
    skipButton.frame = CGRectMake(25, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 133, 60);
    skipButton.tag = 2;
    [skipButton addTarget:self action:@selector(skipSurvey:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:skipButton];
    
    nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [nextButton setBackgroundImage:[UIImage imageNamed:@"SurveyNextNormal"] forState:UIControlStateNormal];
    [nextButton setBackgroundImage:[UIImage imageNamed:@"SurveyNextSelected"] forState:UIControlStateHighlighted];
    nextButton.frame = CGRectMake(self.frame.size.width - 158, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 133, 60);
    [nextButton addTarget:self action:@selector(gotoNextPage:) forControlEvents:UIControlEventTouchUpInside];
    nextButton.hidden = YES;
    [self addSubview:nextButton];
    
    submitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [submitButton setBackgroundImage:[UIImage imageNamed:@"SurveySubmitNormal"] forState:UIControlStateNormal];
    [submitButton setBackgroundImage:[UIImage imageNamed:@"SurveySubmitSelected"] forState:UIControlStateHighlighted];
    submitButton.frame = CGRectMake(self.frame.size.width - 158, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 133, 60);
    submitButton.tag = -10000;
    [submitButton addTarget:self action:@selector(submitSurvey:) forControlEvents:UIControlEventTouchUpInside];
    submitButton.hidden = YES;
    [self addSubview:submitButton];
    
    if (!iPad) {
        skipButton.frame = CGRectMake((appDelegate.window.frame.size.width-(300))/2, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 124, 44);
        nextButton.frame = CGRectMake(skipButton.frame.origin.x+skipButton.frame.size.width+52, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 124, 44);
        submitButton.frame = CGRectMake(skipButton.frame.origin.x+skipButton.frame.size.width+52, bottomLineImg.frame.origin.y + bottomLineImg.frame.size.height, 124, 44);
    }
    questionViewOriginY = HEADERHEIGHT;
    
    pageNumber = 0;
    privousPageLastQusNum = 0;
    pagesDict = [[NSMutableDictionary alloc] init];
    
    [self decideNumberOfQuestionsToEachPage];
    
    [self initialisePickerView];
    
    TCEND
}

- (void)decideNumberOfQuestionsToEachPage {
    TCSTART
    if (textArray.count > 0) {
        CGFloat questionViewsHeight = 0;
        NSMutableArray *pageArray = [[NSMutableArray alloc] init];
        for (int i = privousPageLastQusNum; i < textArray.count; i ++) {
            CGFloat textlabelHeight = [self getStringHeight:[[textArray objectAtIndex:i] objectForKey:@"text"] withConstraintWidth:SURVEYVIW_WIDTH withFontSize:descriptionTextFontSize withFontName:titleFontName];
            questionViewsHeight = questionViewsHeight + (textlabelHeight+MINIMUMQUESTIONVIEWHEIGHT + 5 + (iPad?13:0));
//            if () {
                if (questionViewsHeight <= MAXQUESTIONSDISPLAYAREA) {
                [pageArray addObject:[textArray objectAtIndex:i]];
                [pagesDict setObject:pageArray forKey:[NSString stringWithFormat:@"%d",pageNumber]];
                if (i == textArray.count - 1) {
                    [self calculateNextPageNumber];
                }
            } else {
                [self calculateNextPageNumber];
                break;
            }
        }
    }
    TCEND
}

- (void)calculateNextPageNumber {
    TCSTART
    privousPageLastQusNum = [[pagesDict objectForKey:[NSString stringWithFormat:@"%d",pageNumber]] count] + privousPageLastQusNum;
    if (privousPageLastQusNum < textArray.count) {
        pageNumber ++;
        [self decideNumberOfQuestionsToEachPage];
    } else {
        currentlyDisplayedPageNumber = 0;
        [self createQuestionViewsAndAddToDisplayScreenQuestion:[pagesDict objectForKey:@"0"]];
        
    }
    TCEND
}

- (void)enableButtonsForPage:(int)displayedPageNumber {
    TCSTART
    nextButton.hidden = YES;
    submitButton.hidden = YES;
    skipButton.hidden = NO;
    if (displayedPageNumber == pageNumber) {
        submitButton.hidden = NO;
    }
    
    if (displayedPageNumber < pageNumber) {
        nextButton.hidden = NO;
    }
//    if (![skipButton isHidden] && ![submitButton isHidden]) {
//        submitButton.frame = CGRectMake(self.frame.size.width - (skipButton.frame.size.width + 10), submitButton.frame.origin.y, submitButton.frame.size.width, submitButton.frame.size.height);
//    } else {
//        submitButton.frame = CGRectMake((self.frame.size.width - submitButton.frame.size.width)/2, submitButton.frame.origin.y , submitButton.frame.size.width, submitButton.frame.size.height);
//    }
    TCEND
}

- (CGFloat)getFirstQuestionInScreenOriginY:(NSArray *)pageQuestionsArray {
    TCSTART
    CGFloat height = 0;
    for (int i = 0; i < pageQuestionsArray.count; i ++) {
        NSDictionary *dict = [pageQuestionsArray objectAtIndex:i];
        
        CGFloat textlabelHeight = [self getStringHeight:[dict objectForKey:@"text"] withConstraintWidth:SURVEYVIW_WIDTH withFontSize:descriptionTextFontSize withFontName:titleFontName];
        height = height + textlabelHeight + MINIMUMQUESTIONVIEWHEIGHT + 5 + (iPad ? 13:0);
    }
    
    if (pageQuestionsArray.count == 1) {
        height = (MAXQUESTIONSDISPLAYAREA - height)/2;
        return (height + HEADERHEIGHT);
    } else {
        height = (MAXQUESTIONSDISPLAYAREA - height)/pageQuestionsArray.count;
        return (height + HEADERHEIGHT);
    }
    TCEND
}

- (void)createQuestionViewsAndAddToDisplayScreenQuestion:(NSArray *)pageQuestionArray {
    TCSTART
    questionViewOriginY = HEADERHEIGHT;
    
    for (int i = 0; i < pageQuestionArray.count; i ++) {
        NSDictionary *dict = [pageQuestionArray objectAtIndex:i];
        
        CGFloat textlabelHeight = [self getStringHeight:[dict objectForKey:@"text"] withConstraintWidth:SURVEYVIW_WIDTH withFontSize:descriptionTextFontSize withFontName:titleFontName];
        
        
        CGRect questionViewFrame;
        CGRect textLabelFrame;
        CGFloat originY;
        CGRect bottomLineImgFrame;
        if (iPad) {
            questionViewFrame = CGRectMake(9, questionViewOriginY, 750, textlabelHeight+MINIMUMQUESTIONVIEWHEIGHT + 5);
            textLabelFrame = CGRectMake(10, 10, 730, textlabelHeight);
            originY = (textLabelFrame.origin.y + textlabelHeight + 15);
            bottomLineImgFrame = CGRectMake(-5, questionViewFrame.size.height - 2, 730 + 30, 13);
        }  else {
            questionViewFrame = CGRectMake(5, questionViewOriginY, appDelegate.window.frame.size.width-20, textlabelHeight+MINIMUMQUESTIONVIEWHEIGHT);
            textLabelFrame = CGRectMake(5, 5, appDelegate.window.frame.size.width-20, textlabelHeight);
            originY = (textLabelFrame.origin.y + textlabelHeight + 5);
            bottomLineImgFrame = CGRectMake(-5, questionViewFrame.size.height - 7, appDelegate.window.frame.size.width, 13);
        }
        
        UIView *questionView = [[UIView alloc] initWithFrame:questionViewFrame];
        questionView.backgroundColor = [UIColor clearColor];
        questionView.tag = 100;
        
        UILabel *textLabel = [[UILabel alloc] initWithFrame:textLabelFrame];
        textLabel.text = [dict objectForKey:@"text"];
        textLabel.textAlignment = NSTextAlignmentCenter;
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.textColor = [UIColor whiteColor];
        textLabel.font = [UIFont fontWithName:titleFontName size:descriptionTextFontSize];
        textLabel.numberOfLines = 0;
        textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        [questionView addSubview:textLabel];
        
        [self addViewToQuestionViewToDisplayOnScreen:dict andQuestionView:questionView andOriginY:originY andQuestionViewIndex:i];
       
        UIImageView *lineImage = [[UIImageView alloc] initWithFrame:bottomLineImgFrame];
        lineImage.image = [UIImage imageNamed:@"line"];
        [questionView addSubview:lineImage];
        
        if (i == pageQuestionArray.count-1) {
            lineImage.hidden = YES;
        }
        
        [self addSubview:questionView];
        
        questionViewOriginY = questionView.frame.origin.y + questionView.frame.size.height + (iPad?13:0);
    }
    [self enableButtonsForPage:currentlyDisplayedPageNumber];
   TCEND
}
- (void)addViewToQuestionViewToDisplayOnScreen:(NSDictionary *)questionDict andQuestionView:(UIView *)questionView andOriginY:(CGFloat)originY andQuestionViewIndex:(int)index {
    TCSTART
    CGRect textViewFrame;
    if (iPad) {
        textViewFrame = CGRectMake(10, originY, 730, 65);
    } else {
        textViewFrame = CGRectMake((appDelegate.window.frame.size.width-310)/2, originY, 300, 50);
    }
    if ([[questionDict objectForKey:@"responseType"] isEqualToString:@"ynidk"]) {
        
        UIView *textView = [[UIView alloc] initWithFrame:textViewFrame];
        textView.backgroundColor = [UIColor clearColor];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 0, textViewFrame.size.width, textViewFrame.size.height);
        imageView.tag = 5;
        [textView addSubview:imageView];
        
        if ([self isNotNull:[questionDict objectForKey:@"answer"]]) {
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%@",[questionDict objectForKey:@"answer"]]];
        } else {
            imageView.image = [UIImage imageNamed:@"Survey-Questions-Normal"];
        }
        
        for (int i = 1; i < 4 ; i ++) {
            CustomButton *btn = [CustomButton buttonWithType:UIButtonTypeCustom];
            btn.tag = i;
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(selectYNIDK:) forControlEvents:UIControlEventTouchUpInside];
            btn.titleLabel.font = [UIFont fontWithName:titleFontName size:descriptionTextFontSize];
            
            btn.questionDict = [NSMutableDictionary dictionaryWithDictionary:questionDict];
            btn.questionIndex = index;
            
            [textView addSubview:btn];
            if (i == 1) {
                [btn setTitle:@"Yes" forState:UIControlStateNormal];
                btn.frame = CGRectMake(0, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(0, 0, 100, 50);
                }
            } else if (i == 2) {
                [btn setTitle:@"No" forState:UIControlStateNormal];
                btn.frame = CGRectMake(244, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(100, 0, 100, 50);
                }
                
            } else {
                [btn setTitle:@"Not Sure" forState:UIControlStateNormal];
                btn.frame = CGRectMake(244*2, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(200, 0, 100, 50);
                }
            }
        }
        [questionView addSubview:textView];
        
    }  else if ([[questionDict objectForKey:@"responseType"] isEqualToString:@"ynna"]) {
        
        UIView *textView = [[UIView alloc] initWithFrame:textViewFrame];
        textView.backgroundColor = [UIColor clearColor];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 0, textViewFrame.size.width, textViewFrame.size.height);
        imageView.tag = 5;
        [textView addSubview:imageView];
        
        if ([self isNotNull:[questionDict objectForKey:@"answer"]]) {
            if ([[questionDict objectForKey:@"answer"] caseInsensitiveCompare:@"not_applicable"] == NSOrderedSame) {
                imageView.image = [UIImage imageNamed:@"SurveyQuestionsSelectedidk"];
            } else {
                imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%@",[questionDict objectForKey:@"answer"]]];
            }
        } else {
            imageView.image = [UIImage imageNamed:@"Survey-Questions-Normal"];
        }
        
        for (int i = 1; i < 4 ; i ++) {
            CustomButton *btn = [CustomButton buttonWithType:UIButtonTypeCustom];
            btn.tag = i;
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(selectYNNA:) forControlEvents:UIControlEventTouchUpInside];
            btn.titleLabel.font = [UIFont fontWithName:titleFontName size:descriptionTextFontSize];
            
            btn.questionDict = [NSMutableDictionary dictionaryWithDictionary:questionDict];
            btn.questionIndex = index;
            
            [textView addSubview:btn];
            if (i == 1) {
                [btn setTitle:@"Yes" forState:UIControlStateNormal];
                btn.frame = CGRectMake(0, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(0, 0, 100, 50);
                }
            } else if (i == 2) {
                [btn setTitle:@"No" forState:UIControlStateNormal];
                btn.frame = CGRectMake(244, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(100, 0, 100, 50);
                }
                
            } else {
                [btn setTitle:@"N/A" forState:UIControlStateNormal];
                btn.frame = CGRectMake(244*2, 0, 243, 65);
                if (!iPad) {
                    btn.frame = CGRectMake(200, 0, 100, 50);
                }
            }
        }
        [questionView addSubview:textView];
        
    } else if ([[questionDict objectForKey:@"responseType"] isEqualToString:@"smiley"]) {
        
        UIView *smileyView = [[UIView alloc] initWithFrame:textViewFrame];
        smileyView.backgroundColor = [UIColor clearColor];
        for (int i = 4; i >= 0; i -- ) {
            CustomButton *btn = [CustomButton buttonWithType:UIButtonTypeCustom];
            if (iPad) {
                 btn.frame = CGRectMake(124 + ((4-i) * 104), 0, 65, 65);
            } else {
                btn.frame = CGRectMake(12.5 + ((4-i) * (45+12.5)), 2, 45, 45);
            }
           
            btn.tag = i - 2;
            
            btn.questionDict = [NSMutableDictionary dictionaryWithDictionary:questionDict];
            btn.questionIndex = index;
            
            if ([self isNotNull:[questionDict objectForKey:@"answer"]] && [[questionDict objectForKey:@"answer"] intValue] == btn.tag) {
                [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d",btn.tag]] forState:UIControlStateNormal];
            } else {
                [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"Non%d",btn.tag]] forState:UIControlStateNormal];
            }
            
            [btn addTarget:self action:@selector(changeSmiley:) forControlEvents:UIControlEventTouchUpInside];
            [smileyView addSubview:btn];
        }
        [questionView addSubview:smileyView];
        
    } else if ([[questionDict objectForKey:@"responseType"] isEqualToString:@"star-rating"]) {
        UIView *textView = [[UIView alloc] initWithFrame:textViewFrame];
        textView.backgroundColor = [UIColor clearColor];
        
        RateView *rateView = nil;
        if (iPad) {
            rateView = [[RateView alloc] initWithFrame:CGRectMake(100, 0, 730 - 200, 65)];
        } else {
            rateView = [[RateView alloc] initWithFrame:CGRectMake(5, 0, 300, 50)];
        }
        rateView.notSelectedImage = [UIImage imageNamed:@"star_black"];
        rateView.fullSelectedImage = [UIImage imageNamed:@"star_green"];
        rateView.editable = YES;
        rateView.maxRating = 5;
        rateView.delegate = self;
        [textView addSubview:rateView];
        
        rateView.questionDict = [NSMutableDictionary dictionaryWithDictionary:questionDict];
        rateView.questionIndex = index;
        
        if ([self isNotNull:[questionDict objectForKey:@"answer"]]) {
            rateView.rating = (float)[[questionDict objectForKey:@"answer"] intValue];
        }
        
        [questionView addSubview:textView];
    }
    TCEND
}

- (CGFloat)getStringHeight:(NSString *)str withConstraintWidth:(NSInteger)width withFontSize:(NSInteger)fontSize withFontName:(NSString *)fontName {
    
    @try {
        //Calculate the Reviewer name height based on the font size and linebreakmode.
        CGSize constraint = CGSizeMake(width, 270.0f);//20000 is max contarined heigt.
        CGSize strSize;
        CGFloat strHeight = 0.0f;
        
        strSize = [str sizeWithFont:[UIFont fontWithName:fontName size:fontSize] constrainedToSize:constraint lineBreakMode:NSLineBreakByWordWrapping];
        
        strHeight = MAX(strSize.height, 0.0f);
        return strHeight;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)changeSmiley:(id)sender {
    TCSTART
    CustomButton *smileyButton = (CustomButton *)sender;
    UIView *smileyButtonSuperView = [smileyButton superview];
    int tag = smileyButton.tag;
    
    [self setImagesForAllSmilies:tag andSuperView:smileyButtonSuperView];
    
    if ([smileyButton.imageView.image isEqual:[UIImage imageNamed:[NSString stringWithFormat:@"Non%d",tag]]]) {
        [smileyButton setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d",tag]] forState:UIControlStateNormal];
    }
    
    if ([self isNotNull:smileyButton.questionDict]) {
        
        NSMutableDictionary *questionDict = smileyButton.questionDict;
        [questionDict setObject:[NSNumber numberWithInt:tag] forKey:@"answer"];
        
        [[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]] replaceObjectAtIndex:smileyButton.questionIndex withObject:questionDict];
    }
    TCEND
}

- (void)setImagesForAllSmilies:(int)selectedSmileyTag andSuperView:(UIView *)superView_ {
    TCSTART
    for (UIButton *btn in superView_.subviews) {
        if (btn.tag != selectedSmileyTag) {
            [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"Non%d",btn.tag]] forState:UIControlStateNormal];
        }
    }
    TCEND
}

- (IBAction)selectYNIDK:(id)sender {
    TCSTART
    CustomButton *btn = (CustomButton *)sender;
    UIView *superView = (UIView *)btn.superview;
    UIImageView *imageView = (UIImageView *)[superView viewWithTag:5];
//    imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%d",btn.tag]];
    
    if ([self isNotNull:btn.questionDict]) {
        NSMutableDictionary *questionDict = btn.questionDict;
        if (btn.tag == 1) {
            [questionDict setObject:@"yes" forKey:@"answer"];
        } else if (btn.tag == 2) {
            [questionDict setObject:@"no" forKey:@"answer"];
        } else {
            [questionDict setObject:@"idk" forKey:@"answer"];
        }
        
        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%@",[questionDict objectForKey:@"answer"]]];
        
        [[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]] replaceObjectAtIndex:btn.questionIndex withObject:questionDict];
    }
    TCEND
}

- (IBAction)selectYNNA:(id)sender {
    TCSTART
    CustomButton *btn = (CustomButton *)sender;
    UIView *superView = (UIView *)btn.superview;
    UIImageView *imageView = (UIImageView *)[superView viewWithTag:5];
    //    imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%d",btn.tag]];
    
    if ([self isNotNull:btn.questionDict]) {
        NSMutableDictionary *questionDict = btn.questionDict;
        if (btn.tag == 1) {
            [questionDict setObject:@"yes" forKey:@"answer"];
        } else if (btn.tag == 2) {
            [questionDict setObject:@"no" forKey:@"answer"];
        } else {
            [questionDict setObject:@"not_applicable" forKey:@"answer"];
        }
        
        if ([[questionDict objectForKey:@"answer"] caseInsensitiveCompare:@"not_applicable"] == NSOrderedSame) {
            imageView.image = [UIImage imageNamed:@"SurveyQuestionsSelectedidk"];
        } else {
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"SurveyQuestionsSelected%@",[questionDict objectForKey:@"answer"]]];
        }
        
        
        [[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]] replaceObjectAtIndex:btn.questionIndex withObject:questionDict];
    }
    
    NSLog(@"array:%@",[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]]);
    TCEND
}

#pragma mark - RateView Delegate

- (void)rateView:(RateView *)rateView ratingDidChange:(float)rating {
    TCSTART
    int rateCount_Int_ = rating;
    
    if ([self isNotNull:rateView.questionDict]) {
        NSMutableDictionary *questionDict = rateView.questionDict;
        [questionDict setObject:[NSNumber numberWithInt:rateCount_Int_] forKey:@"answer"];
        
        [[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]] replaceObjectAtIndex:rateView.questionIndex withObject:questionDict];
    }
    TCEND
}

- (void)gotoNextPage:(id)sender {
    TCSTART
    [self removeAllSubviewsFromQuestionView];
    
    currentlyDisplayedPageNumber ++;
    if (currentlyDisplayedPageNumber < textArray.count) {
        [self createQuestionViewsAndAddToDisplayScreenQuestion:[pagesDict objectForKey:[NSString stringWithFormat:@"%d",currentlyDisplayedPageNumber]]];
    }
    TCEND
}
- (void)skipSurvey:(id)sender {
    TCSTART
    [self submitSurvey:nil];
    [self removeSurveyViewFromSuperView:nil];
    TCEND
}
- (void)submitSurvey:(id)sender {
    TCSTART
    if (isPrimarySurvey) {
        [[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:@"PriamrySurveySubmittedtime"];
    }
    UIButton *btn = (UIButton *)sender;
    if ([caller isKindOfClass:[MyHistoryNRecentActivityViewController class]]) {
        MyHistoryNRecentActivityViewController *myHistoryVC = (MyHistoryNRecentActivityViewController *)caller;
        if (btn.tag == -10000) {
            myHistoryVC.isSubmitBtnOnSurveyViewClicked = YES;
        } else {
            myHistoryVC.isSubmitBtnOnSurveyViewClicked = NO;
        }
    }
    NSLog(@"pagesDict:%@",pagesDict);
    NSMutableArray *responseArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < [pagesDict allKeys].count ; i ++) {
        NSArray *array = [pagesDict objectForKey:[NSString stringWithFormat:@"%d",i]];
        for (NSDictionary *dict in array) {
            if ([self isNotNull:[dict objectForKey:@"answer"]]) {
                CPSurveyResponseData *data = [[CPSurveyResponseData alloc] init];
                data.promptId = [dict objectForKey:@"id"];
                if ([[dict objectForKey:@"responseType"] isEqualToString:@"ynidk"]) {
                    data.response = [dict objectForKey:@"answer"];
                } else if ([[dict objectForKey:@"responseType"] isEqualToString:@"ynna"]) {
                    data.response = [dict objectForKey:@"answer"];
                } else if ([[dict objectForKey:@"responseType"] isEqualToString:@"smiley"]) {
                    float smile = [[dict objectForKey:@"answer"] intValue]/2.0;
                    if (smile == -0.5 || smile == 0.5) {
                        NSLog(@"%@",[NSString stringWithFormat:@"%.01f", smile]);
                        data.response = [NSString stringWithFormat:@"%.01f", smile];
                    } else {
                        data.response = [NSString stringWithFormat:@"%d",(int)smile];
                    }
                    
                } else {
                    data.response = [[dict objectForKey:@"answer"] stringValue];
                }
                [responseArray addObject:data];
            }
        }
    }
    NSLog(@"responsesArray:%@ selected physician:%@",responseArray,selectedPhysician.physicianName);
    if ([self isNotNull:responseArray] && responseArray.count > 0) {
        [appDelegate postSurveyResponses:responseArray andchannel_Id:location_id andSurveyId:survey_id callBackObject:caller andPhysicianId:selectedPhysician.physicianId];
    } else if(btn.tag == 1){
        [appDelegate showErrorMsg:@"Please answer at least one question."];
    }
    TCEND
}

- (void)displyImDoneScreen {
    TCSTART
    [self removeAllSubviewsFromQuestionView];
    
    submitButton.hidden = YES;
    skipButton.hidden = YES;
    nextButton.hidden = YES;
    
    titleLabel.text = @"THANK YOU";
    
    UIButton *closeBtn = (UIButton *)[self viewWithTag:-5000];
    [closeBtn removeTarget:self action:@selector(skipSurvey:) forControlEvents:UIControlEventTouchUpInside];
    [closeBtn addTarget:self action:@selector(removeSurveyViewFromSuperView:) forControlEvents:UIControlEventTouchUpInside];
    
    CGRect imDoneButtonFrame;
    UILabel *textLabel;
    if (iPad) {
        textLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, HEADERHEIGHT + 50, self.frame.size.width - 80, 200)];
        imDoneButtonFrame = CGRectMake((self.frame.size.width - 355)/2, (self.frame.size.height-65)/2 , 355, 65);
    } else {
        textLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 60, appDelegate.window.frame.size.width-35, 156)];
        imDoneButtonFrame = CGRectMake(20, (self.frame.size.height/2)- 20 , appDelegate.window.frame.size.width-40, 44);
    }
    
    textLabel.text = @"Thank you for participating in our survey. Your feedback is greatly appreciated!";
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.backgroundColor = [UIColor clearColor];
    textLabel.textColor = [UIColor whiteColor];
    textLabel.font = [UIFont fontWithName:titleFontName size:descriptionTextFontSize];
    textLabel.numberOfLines = 0;
    textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    [self addSubview:textLabel];
    
    UIButton *imDoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [imDoneButton setImage:[UIImage imageNamed:@"BoB-Survey-Done"] forState:UIControlStateNormal];
    [imDoneButton setImage:[UIImage imageNamed:@"BoB-Survey-Done_f"] forState:UIControlStateHighlighted];
    imDoneButton.frame = imDoneButtonFrame;
    [imDoneButton addTarget:self action:@selector(imDoneClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:imDoneButton];
    
    UIImageView *imgView = (UIImageView *)[self viewWithTag:1000];
    imgView.hidden = YES;
    TCEND
}

- (void)removeSurveyViewFromSuperView:(id)sender {
    [self removeFromSuperview];
    appDelegate.surveyView = nil;
}

- (void)imDoneClicked:(id)sender {
    [self removeFromSuperview];
    appDelegate.surveyView = nil;
}

- (void)removeAllSubviewsFromQuestionView {
    TCSTART
    for (UIView *view in self.subviews) {
        if (view.tag == 100) {
            for (int k = 0; k < view.subviews.count; k ++) {
                [[view.subviews objectAtIndex:k] removeFromSuperview];
            }
            [view removeFromSuperview];
        }
    }
    TCEND
}

@end
