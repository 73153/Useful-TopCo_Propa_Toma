//
//  ResourcesViewController.m
//  QuiltersThread
//
//  Created by Aruna on 06/06/13.
//  Copyright (c) 2013 ayansys. All rights reserved.
//

#import "ProviderLocationsViewController.h"

@interface ProviderLocationsViewController ()

@end

@implementation ProviderLocationsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    TCSTART
    NSLog(@"ProviderViewController");
    [super viewDidLoad];
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.view.frame = CGRectMake(0, 0, appDelegate.window.frame.size.width, appDelegate.window.frame.size.height - 20);
    locationsArray = [[NSMutableArray alloc] init];
    
    [self.view addSubview:[appDelegate returnHeaderViewTocaller:self sectionHeaderImgName:@"providerlocation_title"]];
    
    
    CGFloat originX;
    CGFloat originY;
    if (iPad) {
        originX = -30;
        originY = 145;
    } else {
        originX = -2.5;
        originY = 90;
    }
    
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        originX = 5;
    }
    providerLocationsTableView = [[UITableView alloc] initWithFrame:CGRectMake(originX, originY, appDelegate.window.frame.size.width + (2 * -originX), self.view.frame.size.height - originY) style:UITableViewStyleGrouped];
    providerLocationsTableView.delegate = self;
    providerLocationsTableView.dataSource = self;
    providerLocationsTableView.showsVerticalScrollIndicator = YES;
    [self.view addSubview:providerLocationsTableView];
    providerLocationsTableView.backgroundView = nil;
    providerLocationsTableView.backgroundColor = [UIColor clearColor];
    if (CURRENT_DEVICE_VERSION < 7.0) {
        providerLocationsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {
        providerLocationsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    
    
    refreshView = [[RefreshView alloc] initWithFrame:
                   CGRectMake(self.view.frame.origin.x,- providerLocationsTableView.bounds.size.height,
                              appDelegate.window.frame.size.width, providerLocationsTableView.bounds.size.height)];
    [providerLocationsTableView addSubview:refreshView];
    TCEND
}

//For status bar in ios7
- (void) viewDidLayoutSubviews {
    if (CURRENT_DEVICE_VERSION >= 7.0) {
        CGRect viewBounds = appDelegate.window.bounds;
        CGFloat topBarOffset = self.topLayoutGuide.length;
        viewBounds.origin.y = -topBarOffset;
        self.view.bounds = viewBounds;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)viewWillAppear:(BOOL)animated {
    TCSTART
        if(locationsArray.count == 0 && [self isNotNull:appDelegate.userProfileDataModel.authToken]) {
            [appDelegate showNetworkIndicator];
            [appDelegate showActivityIndicatorInView:self.view];
            [appDelegate getProvidersLocations:self];
        }
    
    TCEND
}

- (void)hideNetworkIndicatorAndAddObjectsTolocationsArray:(NSDictionary *)results {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    if ([self isNotNull:results] && results.count > 0) {
        [locationsArray removeAllObjects];
        [locationsArray addObjectsFromArray:[results objectForKey:@"data"]];
    }
    [self dataSourceDidFinishLoadingNewData];
    [providerLocationsTableView reloadData];
    TCEND
}

- (void)hideNetworkIndicatorAndShowErrorMsg:(NSString *)error {
    TCSTART
    [appDelegate hideNetworkIndicator];
    [appDelegate removeNetworkIndicatorInView:self.view];
    [appDelegate showErrorMsg:error];
    
    [self dataSourceDidFinishLoadingNewData];
    TCEND
}

#pragma mark Provider Delegate Methods
- (void)didFinishedGettingAllProviderLocations:(NSDictionary *)results {
    [self hideNetworkIndicatorAndAddObjectsTolocationsArray:results];
}
- (void)didFailToGetAllProviderLocationsWithErrorMsg:(NSString *)error {
    [self hideNetworkIndicatorAndShowErrorMsg:error];
}

- (void)dataSourceDidFinishLoadingNewData {
    @try {
        reloading = NO;
        [refreshView flipImageAnimated:NO];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        [providerLocationsTableView setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
        [refreshView setStatus:kPullToReloadStatus];
        [refreshView toggleActivityView:NO];
        [UIView commitAnimations];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma -
#pragma mark tableView DataSource & Delegate Methods.

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
   	return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(locationsArray.count > 0){ //show search results
        return [locationsArray count];
    }  else {
        return 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (iPad) {
        return 100;
    } else {
        return (isiPhone6PLUS?80:60);
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 1.0;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    @try {
        UIView *headerView;
        headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0.0, 0.0, 0.0)];
        headerView.backgroundColor = [UIColor clearColor];
        
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        UITableViewCell *cell = nil;
        NSString *cellIdentifier = @"businessCell";
        UIImageView *avtar = nil;
        UILabel *name = nil;
        UILabel *addressLabel = nil;
        
        cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
            
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f) {
                [appDelegate addBackgroundViewToTheCell:cell];
            }
            
            cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]] ;
            
            CGFloat diff;
            CGFloat accessoryWidth;
            CGFloat nameOriginY;
            if (iPad) {
                diff = 10;
                accessoryWidth = 30;
                nameOriginY = 2;
            }else if (isiPhone6PLUS)
            {
                diff = 10;
                accessoryWidth = 20;
                nameOriginY = 10;
            }
            else {
                diff = 5;
                accessoryWidth = 20;
                nameOriginY = 5;
            }
            
            avtar = [[UIImageView alloc]initWithFrame:CGRectMake(diff, diff, REVIEWER_IMAGE_WIDTH + (diff * 2), REVIEWER_IMAGE_HEIGHT + (diff * 2))];
            [avtar setBackgroundColor:[UIColor clearColor]];
            [avtar.layer setBorderColor:[[UIColor clearColor]CGColor]];
            [avtar.layer setBorderWidth:1.0f];
            avtar.layer.cornerRadius = 5.0;
            avtar.layer.masksToBounds = YES;
            [avtar setTag:1];
            [cell.contentView addSubview:avtar];
            
            
            name = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff,nameOriginY,CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + (diff * 2) + accessoryWidth),accessoryWidth)];
            name.backgroundColor = [UIColor clearColor];
            name.font = [UIFont fontWithName:titleFontName size:isiPhone6PLUS?18.0f:titleFontSize];
            [name setTag:2];
            name.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:name];
            
            addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(avtar.frame.origin.x + avtar.frame.size.width + diff,name.frame.origin.y + name.frame.size.height + diff,CELL_CONTENT_WIDTH - (avtar.frame.origin.x + avtar.frame.size.width + (diff * 2) + accessoryWidth),accessoryWidth + diff)];
            addressLabel.backgroundColor = [UIColor clearColor];
            addressLabel.font = [UIFont fontWithName:descriptionTextFontName size:isiPhone6PLUS?18.0f:descriptionTextFontSize];
            [addressLabel setTag:3];
            addressLabel.textColor = [UIColor colorWithRed:(96.0/255.0) green:(98.0/255.0) blue:(105.0/255.0) alpha:1.0f];
            addressLabel.layer.shadowRadius = 1.0f;
            addressLabel.layer.shadowColor = [UIColor whiteColor].CGColor;
            [cell.contentView addSubview:addressLabel];
        }
        
        if (!avtar)
            avtar = (UIImageView*)[cell viewWithTag:1];
        if (!name)
            name = (UILabel*)[cell viewWithTag:2];
        if (!addressLabel)
            addressLabel = (UILabel*)[cell viewWithTag:3];
        
        StreamDataModel *shopData = nil;
        if([self isNotNull:locationsArray] && locationsArray.count > indexPath.row) {
            shopData = [locationsArray objectAtIndex:indexPath.row];
        }
        if ([self isNotNull:shopData.loc_Name]) {
            name.text = shopData.loc_Name;
        } else {
            name.text = @"";
        }
        if ([self isNotNull:shopData.loc_Address]) {
            addressLabel.text = shopData.loc_Address;
        }
        
        if ([self isNotNull:shopData.loc_PublicLogo_Url]
            && [shopData.loc_PublicLogo_Url rangeOfString:@"http" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            
            NSString *thumbUrl = [appDelegate getavatarThumbURL:shopData.loc_PublicLogo_Url];
            [avtar setImageWithURL:[NSURL URLWithString:thumbUrl] placeholderImage:[UIImage imageNamed:@"default-avatar-business"]];
        } else {
            avtar.image=[UIImage imageNamed:@"default-avatar-business"];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        
        [appDelegate setFrameAndMarginToTheBackGroundViewsInCell:cell withIndexPath:indexPath andTableView:tableView andHeight:(iPad?100:isiPhone6PLUS?78:60) andWidth:(iPad?745:appDelegate.window.frame.size.width-10)];
        if(iPhone && CURRENT_DEVICE_VERSION >= 8.0) {
            CGFloat aHeight = [tableView rectForRowAtIndexPath:indexPath].size.height;
            cell.accessoryView=nil;
            if([cell.contentView viewWithTag:9]) {
                //[[cell.contentView viewWithTag:9] removeFromSuperview];
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                [[cell.contentView viewWithTag:9] setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                
            } else {
                UIImageView *accessoryimgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"accessoryImage"]];
                accessoryimgView.tag=9;
                [accessoryimgView setFrame:CGRectMake(appDelegate.window.frame.size.width-5-22-(isiPhone6PLUS?5:0),(aHeight-accessoryimgView.frame.size.height)/2, accessoryimgView.frame.size.width, accessoryimgView.frame.size.height)];
                [cell.contentView addSubview:accessoryimgView];
            }
        }
        
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        
        if ([self isNotNull:locationsArray] && [locationsArray count] > indexPath.row) {
            StreamDataModel *streamData = [locationsArray objectAtIndex:indexPath.row];
            
            if ([self isNotNull:streamData] && [self isNotNull:streamData.channel_Id]) {
                [appDelegate pushToLoationPageFromViewContr:self withChannelId:streamData.channel_Id withLatitude:streamData.loc_Latitude.floatValue withLongitude:streamData.loc_Longitude.floatValue withReview_Radius:streamData.loc_ReviewRadius];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark -
#pragma mark Deferred image loading (UIScrollViewDelegate)
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    
    if (!reloading) {
        checkForRefresh = YES;  //  only check offset when dragging
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    @try {
        // NSLog(@"scrollViewDidScroll");
        if (reloading) return;
        
        if (checkForRefresh) {
            if (refreshView.isFlipped && scrollView.contentOffset.y > -45.0f && scrollView.contentOffset.y < 0.0f && !reloading) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kPullToReloadStatus];
                
            } else if (!refreshView.isFlipped && scrollView.contentOffset.y < -45.0f) {
                [refreshView flipImageAnimated:YES];
                [refreshView setStatus:kReleaseToReloadStatus];
            }
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Load images for all onscreen rows when scrolling is finished
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    @try {
        if (reloading) return;
        
        if (scrollView.contentOffset.y <= -45.0f) {
            [self showReloadAnimationAnimated:YES];
            [self networkCallForResourcesChannels];
        }
        checkForRefresh = NO;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark State Changes

- (void) showReloadAnimationAnimated:(BOOL)animated
{
    @try {
        reloading = YES;
        [refreshView toggleActivityView:YES];
        
        if (animated)
        {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            providerLocationsTableView.contentInset = UIEdgeInsetsMake(40.0f, 0.0f, 0.0f,
                                                                       0.0f);
            [UIView commitAnimations];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)networkCallForResourcesChannels {
    
    @try {
        //isRefreshingStream = YES;
        [appDelegate showNetworkIndicator];
        [appDelegate getProvidersLocations:self];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (void)gotoMainPage {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
