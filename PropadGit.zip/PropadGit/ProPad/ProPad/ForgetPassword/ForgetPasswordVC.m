//
//  ForgetPasswordVC.m
//  ProPad
//
//  Created by Bhumesh on 07/08/15.
//  Copyright (c) 2015 Zaptech. All rights reserved.
//

#import "ForgetPasswordVC.h"
#import "AppDelegate.h"
#import "AppConstant.h"
#import "ApplicationData.h"
#import "HTTPManager.h"
#import "LoginViewController.h"
#import "UIView+Toast.h"
@interface ForgetPasswordVC ()

@end

@implementation ForgetPasswordVC
{
    UIAlertView *alert ;
    bool isSuccess;
}
@synthesize txtUserName;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTextFieldWithImage:[UIImage imageNamed:@"user-icon"] txtField:txtUserName];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title = @"Forget Password";
    
    [[UIBarButtonItem   appearance]setTintColor:[UIColor whiteColor]];
    isSuccess=false;
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys: [UIColor whiteColor],NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica Neue" size:28],NSFontAttributeName, nil]];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setTextFieldWithImage:(UIImage*)image txtField:(UITextField*)txtField
{
    txtField.leftViewMode = UITextFieldViewModeAlways;
    UIImageView *imageView2 = [[UIImageView alloc] initWithFrame:
                               CGRectMake(0, 0, image.size.width, image.size.height)];
    imageView2.image = image;
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, image.size.width+5, image.size.height)];
    [paddingView addSubview:imageView2];
    txtField.leftView = paddingView;
    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(isSuccess)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (IBAction)onBtnSubmitTapped:(id)sender {
    [self.view endEditing:true];
    if(txtUserName.text.length==0){
        [self.view makeToast:@"Please enter email address"];
        return;
    }
    AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    
    if([appDelegateTemp checkInternetConnection]==true)
    {
        [[ApplicationData sharedInstance] showLoader];
        
        //  NSString *postString = [NSString stringWithFormat:@"nUserId=%@",strUserId];
        NSString *postString=[NSString stringWithFormat:@"sEmail=%@", txtUserName.text];
        
        
        
        
        HTTPManager *manager = [HTTPManager managerWithURL:KForgetPassword];
        
        [manager setPostString:postString];
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            DLog(@"%@",bodyDict);
            if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                alert = [[UIAlertView alloc] initWithTitle:@"Forget Password"                                                 message:[bodyDict valueForKey:@"msg"] delegate:self                                                      cancelButtonTitle:@"Ok"                                                      otherButtonTitles: nil, nil];
                [alert show];
                isSuccess=true;
            }
            else {
                alert = [[UIAlertView alloc] initWithTitle:@"Forget Password"                                                  message:[bodyDict valueForKey:@"msg"] delegate:self                                                      cancelButtonTitle:@"Ok"                                                      otherButtonTitles: nil, nil];
                [alert show];
                isSuccess=false;
                
            }
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
            
        }];
    }
}
@end
