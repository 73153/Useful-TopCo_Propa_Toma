//
//  EagerTransformation.h
//  Cloudinary
//
//  Created by Tal Lev-Ami on 26/10/12.
//  Copyright (c) 2012 Cloudinary Ltd. All rights reserved.
//

#import "CLTransformation.h"

@interface CLEagerTransformation : CLTransformation

@property NSString *format;

@end
