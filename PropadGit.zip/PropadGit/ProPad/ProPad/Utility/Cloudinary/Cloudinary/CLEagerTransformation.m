//
//  EagerTransformation.m
//  Cloudinary
//
//  Created by Tal Lev-Ami on 26/10/12.
//  Copyright (c) 2012 Cloudinary Ltd. All rights reserved.
//

#import "CLEagerTransformation.h"

@implementation CLEagerTransformation

@end
