//
//  AddClientSectionThreeViewController.m
//  ProPad
//
//  Created by Bhumesh on 02/07/15.
//  Copyright (c) 2015 Zaptech. All rights reserved.
//

#import "AddClientSectionThreeViewController.h"
#import "ActionSheetStringPicker.h"
#import "FMDBDataAccess.h"
//#import "ClientListViewController.h"
#import "AddClientSectionFourViewController.h"
#import "UIView+Toast.h"
#import "HTTPManager.h"
#import "ApplicationData.h"
#import  "AppConstant.h"
#import "ActionSheetDatePicker.h"
#import "IQKeyboardManager.h"

@interface AddClientSectionThreeViewController ()<UIAlertViewDelegate,UIGestureRecognizerDelegate,HTTPManagerDelegate,UITextFieldDelegate>
{
    NSString *strDesireMonthlyPayment;
    BOOL isDecisionMakerPresent;
    UITextField *activeField;
}
@end

@implementation AddClientSectionThreeViewController
@synthesize scrollView;
@synthesize txtCurrentlyFinancedWith,txtCurrentMothlyPayment,txtNextPaymentDue;
@synthesize btnHigher,btnIsDecisionMakersPresent,btnLower,btnSame;
@synthesize dataDictionary,lblCurrentlyFinance,lblCurrentMonthPay,lblDecisionMaker,lblDesireMonthPay,lblNextPaymentDue,lblQuestionSection;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"New Customer";
    if(IS_IPAD){
        heightConst.constant=1000;
        lblCurrentlyFinance.frame = CGRectMake(0, 0, 450, 20);
        lblCurrentMonthPay.frame = CGRectMake(0, 0, 450, 20);
        lblDecisionMaker.frame = CGRectMake(0, 0, 450, 20);
        lblDesireMonthPay.frame = CGRectMake(0, 0, 450, 20);
        lblNextPaymentDue.frame = CGRectMake(0, 0, 450, 20);
        
        lblCurrentlyFinance.font = [UIFont systemFontOfSize:16];
        lblCurrentMonthPay.font = [UIFont systemFontOfSize:16];
        lblDecisionMaker.font = [UIFont systemFontOfSize:16];
        lblDesireMonthPay.font = [UIFont systemFontOfSize:16];
        lblNextPaymentDue.font = [UIFont systemFontOfSize:16];
        
        lblQuestionSection.font = [UIFont systemFontOfSize:18];
        txtCurrentlyFinancedWith.font = [UIFont systemFontOfSize:16];
        txtCurrentMothlyPayment.font = [UIFont systemFontOfSize:16];
        txtNextPaymentDue.font = [UIFont systemFontOfSize:16];
        btnHigher.titleLabel.font = [UIFont systemFontOfSize:16];
        btnLower.titleLabel.font = [UIFont systemFontOfSize:16];
        btnSame.titleLabel.font = [UIFont systemFontOfSize:16];
    }
    else if (IS_IPHONE_6 || IS_IPHONE_6P)
    {
        heightConst.constant=1000;
    }
    isDecisionMakerPresent=false;
    txtNextPaymentDue.delegate=self;
    txtCurrentlyFinancedWith.delegate=self;
    txtCurrentMothlyPayment.delegate=self;
    
    txtCurrentMothlyPayment.tag=111;
    txtNextPaymentDue.tag=112;
    txtCurrentlyFinancedWith.tag=113;
    
    btnIsDecisionMakersPresent.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self registerForKeyboardNotifications];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
    self.navigationItem.title=@"";
}
-(void)viewDidAppear:(BOOL)animated
{
    @try{
        self.navigationItem.title  = @"New Customer";
        objUser = [UsersData sharedManager];
        NSDictionary *dictThirdUserData = [[NSDictionary alloc] init];
        dictThirdUserData = objUser.dictUsersData;
        
        if(dictThirdUserData.count>0)
            [dataDictionary addEntriesFromDictionary:dictThirdUserData];
        NSString *strCurrentMonthly = [dictThirdUserData valueForKey:@"sCurrentMonthly"];
        if( ![self isNotNull:strCurrentMonthly] && strCurrentMonthly.length>0)
            txtCurrentMothlyPayment.text = strCurrentMonthly;
        
        NSString *strDesireMonthly = [dictThirdUserData valueForKey:@"sDesireMonthly"];
        if( ![self isNotNull:strDesireMonthly] && strDesireMonthly.length>0)
            [self initDesireMonthlyPayment:strDesireMonthly];
        
        NSString *strNextPayment = [dictThirdUserData valueForKey:@"sNextPayment"];
        if( ![self isNotNull:strNextPayment] && strNextPayment.length>0)
            txtNextPaymentDue.text = strNextPayment;
        
        NSString *strCurrentlyFinance = [dictThirdUserData valueForKey:@"sCurrentlyFinance"];
        if( ![self isNotNull:strCurrentlyFinance] && strCurrentlyFinance.length>0)
            txtCurrentlyFinancedWith.text = strCurrentlyFinance;
        
        if([[objUser.dictUsersData valueForKey:@"sDescisionMaker"]isEqualToString:@"YES"])
            btnIsDecisionMakersPresent.selected=true;
        else
            btnIsDecisionMakersPresent.selected=false;
        
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
}

- (void)itemWasSelected:(NSNumber *)selectedIndex element:(id)element {
    
    DLog(@"%@",selectedIndex);
}

- (BOOL)textFieldShouldBeginEditing:(UITextField* )textField
{
    return YES;
}



- (IBAction)btnSelectDatePressed:(id)sender {
    @try{
        ActionSheetDatePicker *datePickerBest = [[ActionSheetDatePicker alloc] initWithTitle:@"Select Date" datePickerMode:UIDatePickerModeDate selectedDate:[NSDate date] target:self action:@selector(timeWasSelected:element:)  origin:sender];
        [datePickerBest showActionSheetPicker];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

#pragma mark ***********************Timer Picker*****************

-(void)timeWasCancelled:(NSDate *)selectedTime element:(id)element
{
    
}
-(void)timeWasSelected:(NSDate *)selectedTime element:(id)element
{
    @try{
        NSDateFormatter  *dateformatter=[[NSDateFormatter alloc] init];
        [dateformatter setDateFormat:@"MM-dd-yyyy"];
        NSString *dateString=[dateformatter stringFromDate:selectedTime];
        txtNextPaymentDue.text = dateString;
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)btnDecisionMakersPresentPressed:(id)sender {
    @try{
        btnIsDecisionMakersPresent.selected = ! btnIsDecisionMakersPresent.selected;
        isDecisionMakerPresent=!isDecisionMakerPresent;
        if(isDecisionMakerPresent)
        {
            [dataDictionary setObject:[NSString stringWithFormat:@"YES"] forKey:@"sDescisionMaker"];
            [objUser.dictUsersData setObject:[NSString stringWithFormat:@"YES"] forKey:@"sDescisionMaker"];
        }
        else
        {
            [dataDictionary setObject:[NSString stringWithFormat:@"NO"] forKey:@"sDescisionMaker"];
            [objUser.dictUsersData setObject:[NSString stringWithFormat:@"NO"] forKey:@"sDescisionMaker"];
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

- (IBAction)btnDesireMonthlyPaymentPressed:(id)sender {
    
    NSInteger btnTagValue =  [sender tag];
    switch (btnTagValue) {
        case 201:{
            strDesireMonthlyPayment=@"Lower";
            btnLower.selected=!btnLower.selected;
            btnSame.selected=false;
            btnHigher.selected=false;
        }
            break;
        case 202:{
            strDesireMonthlyPayment=@"Same";
            btnSame.selected=!btnSame.selected;
            btnLower.selected=false;
            btnHigher.selected=false;
        }
            break;
        case 203:{
            strDesireMonthlyPayment=@"Higher";
            btnHigher.selected=!btnHigher.selected;
            btnSame.selected=false;
            btnLower.selected=false;
        }
            break;
        default:
            break;
    }
}

-(void)initDesireMonthlyPayment: (NSString*)strDesireMonthlyPayments {
    
    if([strDesireMonthlyPayments isEqualToString:@"Lower"])
    {
        strDesireMonthlyPayment=@"Lower";
        btnLower.selected=true;
        btnSame.selected=false;
        btnHigher.selected=false;
    }
    if([strDesireMonthlyPayments isEqualToString:@"Same"]){
        strDesireMonthlyPayment=@"Same";
        btnSame.selected=true;
        btnLower.selected=false;
        btnHigher.selected=false;
    }
    if([strDesireMonthlyPayments isEqualToString:@"Higher"]){
        strDesireMonthlyPayment=@"Higher";
        btnHigher.selected=true;
        btnSame.selected=false;
        btnLower.selected=false;
    }
}


- (IBAction)btnNextPressed:(id)sender {
    [self.view endEditing:true];
    @try{
        /*if(txtCurrentMothlyPayment.text.length==0){
         [self.view makeToast:@"Please enter text for search"];
         return;
         }
         else if(strDesireMonthlyPayment.length==0){
         [self.view makeToast:@"Please selct desire monthly payment"];
         return;
         }
         else if(txtNextPaymentDue.text.length==0){
         [self.view makeToast:@"Please enter make" duration:1 position:CSToastPositionCenter title:nil];
         return;
         }
         else if(txtCurrentlyFinancedWith.text.length==0){
         [self.view makeToast:@"Please enter model"];
         return;
         }*/
        if(txtCurrentMothlyPayment.text.length!=0)
            [dataDictionary setObject:txtCurrentMothlyPayment.text forKey:@"sCurrentMonthly"];
        
        if(strDesireMonthlyPayment.length!=0)
            [dataDictionary setObject:strDesireMonthlyPayment forKey:@"sDesireMonthly"];
        
        if(txtNextPaymentDue.text.length!=0)
            
            [dataDictionary setObject:txtNextPaymentDue.text forKey:@"sNextPayment"];
        
        if(txtCurrentlyFinancedWith.text.length!=0)
            [dataDictionary setObject:txtCurrentlyFinancedWith.text forKey:@"sCurrentlyFinance"];
        
        
        
        AddClientSectionFourViewController *fourth=(AddClientSectionFourViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"AddClientSectionFourViewController"];
        fourth.dataDictionary = [[NSMutableDictionary alloc] init];
        fourth.dataDictionary = dataDictionary;
        [self.navigationController pushViewController:fourth animated:YES];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
    
}
- (BOOL) isNotNull:(NSObject*) object {
    if (!object)
        return YES;
    else if (object == [NSNull null])
        return YES;
    else if ([object isKindOfClass: [NSString class]] && object!=nil) {
        return ([((NSString*)object) isEqualToString:@""]
                || [((NSString*)object) isEqualToString:@"null"]
                || [((NSString*)object) isEqualToString:@"nil"]
                || [((NSString*)object) isEqualToString:@"<null>"]);
    }
    return NO;
}

#pragma mark - UITextField Delegate
#pragma mark
//------------------------------------------------------------------------------

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return TRUE;
}
//------------------------------------------------------------------------------

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [[IQKeyboardManager sharedManager] setEnable:FALSE];
    activeField = textField;
    //    scrollView.contentSize=CGSizeMake(self.view.frame.size.width, 1200);
    //    scrollView.contentOffset=CGPointMake(0, 0);
    
    //    heightConst.constant=1000;
}
//------------------------------------------------------------------------------

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0 animations:^{
        [[IQKeyboardManager sharedManager] setEnable:YES];
        //        scrollView.contentSize= CGSizeMake(self.view.frame.size.width, 617);
        //        scrollView.contentOffset=CGPointMake(0, 0);
        //        [scrollView setContentOffset:CGPointMake(0, 0)];
        
        
    }];
}

- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    @try{
        NSDictionary* info = [aNotification userInfo];
        CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
        UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height+50, 0.0);
        scrollView.translatesAutoresizingMaskIntoConstraints = NO;
        
        scrollView.contentInset = contentInsets;
        scrollView.scrollIndicatorInsets = contentInsets;
        
        // If active text field is hidden by keyboard, scroll it so it's visible
        // Your application might not need or want this behavior.
        CGRect aRect = self.view.frame;
        aRect.size.height -= kbSize.height;
        if (!CGRectContainsPoint(aRect, activeField.frame.origin) ) {
            CGPoint scrollPoint = CGPointMake(0.0, activeField.frame.origin.y-kbSize.height);
            [scrollView setContentOffset:scrollPoint animated:YES];
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}



@end
