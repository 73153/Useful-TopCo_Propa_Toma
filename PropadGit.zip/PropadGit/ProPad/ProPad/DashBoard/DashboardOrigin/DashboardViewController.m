//
//  DashboardViewController.m
//  ProPad
//
//  Created by Bhumesh on 24/07/15.
//  Copyright (c) 2015 Zaptech. All rights reserved.
//

#import "DashboardViewController.h"
#import "DEMOLeftMenuViewController.h"
#import "CustomerListViewController.h"
#import "AppDelegate.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "ApplicationData.h"
#import "AppConstant.h"
#import "FMDatabase.h"
#import "FMDBDataAccess.h"
#import "Base64.h"




@interface DashboardViewController ()<RESideMenuDelegate>
{
    NSInteger userIdInt;
    NSString *strUserId;
}
@end
@implementation DashboardViewController
@synthesize txtCustomerList;
@synthesize txtNewCustomer;
@synthesize txtAboutUs;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initV];
    [self setMenuIconForSideBar:@"menu"];
}
- (void)viewWillAppear:(BOOL)animated {
    [self performSelectorInBackground:@selector(insertDataWhenOnline) withObject:nil];
}
-(void)initV
{
    FMDBDataAccess *dbAccess = [FMDBDataAccess new];

    strUserId = [[NSUserDefaults standardUserDefaults]
                 stringForKey:UserId];
    NSString *strImage=[dbAccess getThumbImage:strUserId];
    
    NSData *imageData = [Base64 decode:strImage];

    UIImage* image = [UIImage imageWithData:imageData];
    self.imgCompanyThumb.image =image;
    self.navigationItem.title=@"DashBoard";
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys: [UIColor whiteColor],NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica Neue" size:28],NSFontAttributeName, nil]];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self setLeftModeForTextField:[UIImage imageNamed:@"customerlist"] txtField:txtCustomerList];
    [self setLeftModeForTextField:[UIImage imageNamed:@"newcustomer"] txtField:txtNewCustomer];
    [self setLeftModeForTextField:[UIImage imageNamed:@"about"] txtField:txtAboutUs];
    [self setRightModeForTextField:[UIImage imageNamed:@"rightarrow"] txtField:txtCustomerList];
    [self setRightModeForTextField:[UIImage imageNamed:@"rightarrow"] txtField:txtNewCustomer];
    [self setRightModeForTextField:[UIImage imageNamed:@"rightarrow"] txtField:txtAboutUs];
    
}


-(void)setLeftModeForTextField:(UIImage*)image txtField:(UITextField*)txtField
{
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, image.size.width, image.size.height)];
    imgView.image = image;
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [paddingView addSubview:imgView];
    [txtField setLeftViewMode:UITextFieldViewModeAlways];
    [txtField setLeftView:paddingView];
    txtField.leftViewMode = UITextFieldViewModeAlways;
}
-(void)setRightModeForTextField:(UIImage*)image txtField:(UITextField*)txtField
{
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(-5, 0, image.size.width, image.size.height)];
    imgView.image = image;
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [paddingView addSubview:imgView];
    [txtField setRightViewMode:UITextFieldViewModeAlways];
    [txtField setRightView:paddingView];
    txtField.rightViewMode = UITextFieldViewModeAlways;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onCustomerListTapped:(id)sender {
    DEMOLeftMenuViewController *leftMenuViewController = [DEMOLeftMenuViewController shareInstance];
    [leftMenuViewController setLeftmenuItems:1];

}

- (IBAction)onNewCustomerTapped:(id)sender {
    DEMOLeftMenuViewController *leftMenuViewController = [DEMOLeftMenuViewController shareInstance];
    [leftMenuViewController setLeftmenuItems:2];

}

- (IBAction)onAboutUsTapped:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Dashboard"                                                   message:@"Coming soon." delegate:self
                                          cancelButtonTitle:@"Ok"
                                          otherButtonTitles: nil, nil];
    [alert show];

}
-(void) dispData
{
    AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    FMDBDataAccess *dbAccess = [FMDBDataAccess new];
    if([appDelegateTemp checkInternetConnection]==true)
    {
        [[ApplicationData sharedInstance] showLoader];
        NSString *postString = [NSString stringWithFormat:@"nUserId=%@",strUserId];
        HTTPManager *manager = [HTTPManager managerWithURL:KUserList];
        [manager setPostString:postString];
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            DLog(@"%@",bodyDict);
            if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                NSArray *arrUser = [bodyDict valueForKey:@"userdetails"];
                userDetailArr = [arrUser mutableCopy];
                DLog(@"%@",userDetailArr);
            /*   [[NSUserDefaults standardUserDefaults] setObject:[userDetailArr valueForKey:@"thumb_CompanyImage"] forKey:@"thumb_CompanyImage"];
                NSURL *url;
                NSString *strImage = [NSString stringWithFormat:@"%@",[userDetailArr valueForKey:@"thumb_CompanyImage"]];
                url = [NSURL URLWithString:[strImage stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
              
                NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:strImage]];
                self.imgCompanyThumb.image = [UIImage imageWithData:imageData];*/
              /*  NSData* myEncodedImageData = [[NSUserDefaults standardUserDefaults] objectForKey:@"myEncodedImageDataKey"];
                UIImage* image = [UIImage imageWithData:myEncodedImageData];*/
            

            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"                                                 message:[bodyDict valueForKey:@"msg"] delegate:self                                                      cancelButtonTitle:@"Ok"                                                      otherButtonTitles: nil, nil];
                [alert show];
                
            }
            
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
            
        }];
    }
    else
    {
        NSArray *arrUser = [dbAccess getUsers:[NSString stringWithFormat:@"%@",strUserId]];
        userDetailArr = [arrUser[0] mutableCopy];
        DLog("%@",userDetailArr);
       
    }
}

-(void)insertDataWhenOnline
{
    FMDBDataAccess *dbAccess = [FMDBDataAccess new];
    NSArray *arrRemainingData=[dbAccess CheckRemainingDataForUser];
    AppDelegate *appDelegateTemp = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    if([appDelegateTemp checkInternetConnection]==true)
    {
        [[ApplicationData sharedInstance] showLoader];
        NSString *postString = [NSString stringWithFormat:@"sEmail=%@&sPassword=%@&sCode=%@&sFirstName=%@&sLastName=%@&mode=%@", [arrRemainingData valueForKey:@"sFirstName"],
                                [arrRemainingData valueForKey:@"sLastName"],
                                [arrRemainingData valueForKey:@"sEmail"],
                                [arrRemainingData valueForKey:@"nCompanyId"],
                                [arrRemainingData valueForKey:@"password"],@"add"];
        [[ApplicationData sharedInstance] showLoaderWith:MBProgressHUDModeIndeterminate];
        HTTPManager *manager = [HTTPManager managerWithURL:KRegisterNewUser];
        
        [manager setPostString:postString];
        manager.requestType = HTTPRequestTypeSignUp;
        [manager startDownloadOnSuccess:^(NSHTTPURLResponse *response, NSMutableDictionary *bodyDict) {
            DLog(@"%@",bodyDict);
            if(bodyDict.count>0)
                if ([[bodyDict valueForKey:@"status"]integerValue] == jSuccess) {
                    NSArray *userDetailArr = [response valueForKey:@"userdetails"];
                    NSDictionary *userDetailDict = [userDetailArr  objectAtIndex:0];
                    userIdInt = [[userDetailDict valueForKey:@"nUserId"] integerValue];
                    NSString *strId = [NSString stringWithFormat:@"%ld",(long)userIdInt];
                    UDSetObject(strId, UserId);
                }
            
        } failure:^(NSHTTPURLResponse *response, NSString *bodyString, NSError *error) {
            [[ApplicationData sharedInstance] ShowAlertWithTitle:@"Alert" Message:[error localizedDescription]];
            
        } didSendData:^(NSInteger bytesWritten, NSInteger totalBytesWritten, NSInteger totalBytesExpectedToWrite) {
            
        }];
        [[ApplicationData sharedInstance] hideLoader];
    }
}

@end
